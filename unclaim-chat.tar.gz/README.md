# Unclaim Chat — chat.unclaim.fr

Chat de support **multi-sites** d'Unclaim, hébergé chez vous : une bulle à coller sur n'importe quel site, une console pour répondre, une connexion Unclaim Auth, des permissions par site et par zone. Aucun service tiers (pas de Crisp).

- **Zéro dépendance** : Node ≥ 22.13 suffit (`node:http`, `node:sqlite`). Pas de `npm install`.
- **Une base SQLite** dans `DATA_DIR/chat.db` (sauvegarde = copier le fichier, serveur arrêté).
- **Temps réel** par Server-Sent Events : les réponses arrivent sans recharger, des deux côtés.

## Comment ça marche

```
Site hôte (unclaim.fr, radio…)            chat.unclaim.fr                     Agents
<script src=…/widget.js data-site=…> ──►  API widget (CORS par site) ◄──── /console (cookie)
  bulle, choix de la zone, messages       SQLite + flux temps réel          boîte, réglages, équipe
  connexion : redirection Unclaim Auth    Unclaim Auth (PKCE)               connexion Unclaim Auth
```

- **Site** : un projet qui embarque la bulle (`unclaim`, `radio`, `suite`…). Chacun a sa couleur, son titre, son message d'accueil, ses domaines autorisés et son assistant IA (facultatif).
- **Zone** : un service d'un site (Support, Proposer un projet, Partenariats, Bugs…). Le visiteur choisit la zone avant d'écrire.
- **Rôles** :
  - **super-admin** (`ADMIN_DISCORD_IDS`) : tous les sites, crée et supprime des sites ;
  - **admin d'un site** : réglages, zones, équipe et toutes les conversations du site ;
  - **agent** : conversations de sa zone (ou de tout le site).
- **Visiteurs** : connexion Unclaim Auth obligatoire pour écrire. La connexion se fait par **redirection** (pas de pop-up) : elle marche aussi dans les navigateurs intégrés de Discord, TikTok ou Instagram. Le jeton revient dans le fragment `#` de l'URL, jamais envoyé à un serveur, et le widget l'efface aussitôt.

## 1. Déclarer l'application sur Unclaim Auth

Sur le portail https://auth.unclaim.fr :
1. Créez une application « Unclaim Chat », autorisations `identify` + `email`.
2. URL de retour : `https://chat.unclaim.fr/auth/callback`.
3. Activez-la si elle est « en attente », puis notez le `client_id` et le `client_secret`.

## 2. Installer en une commande (Debian / Ubuntu)

Copiez l'archive sur le serveur, puis :
```sh
tar -xzf unclaim-chat.tar.gz -C unclaim-chat && cd unclaim-chat   # (créez d'abord le dossier : mkdir unclaim-chat)
sudo bash install.sh
```
Le script :
1. installe Node.js 22 si besoin (dépôt officiel NodeSource) ;
2. crée l'utilisateur système `unclaim-chat` et copie l'application dans `/opt/unclaim-chat` ;
3. vous demande l'adresse publique, le `client_id` / `client_secret` Unclaim Auth, votre ID Discord (super-admin), les domaines autorisés et, en option, la clé de l'assistant IA. La configuration est enregistrée dans `/etc/unclaim-chat/env`, lisible seulement par root et le service ;
4. crée et démarre le service `unclaim-chat` (systemd, durci : il ne peut écrire que dans `/var/lib/unclaim-chat`), puis vérifie qu'il répond.

**Mettre à jour** : décompressez la nouvelle version et relancez `sudo bash install.sh`. La configuration est gardée, et la base est sauvegardée avant la mise à jour (`/var/lib/unclaim-chat/chat.db.<date>.bak`).
**Retirer** : `sudo bash install.sh --uninstall` (garde les données) ou `--purge` (supprime tout, après confirmation).
**Sans questions** (automatisation) : `sudo PUBLIC_URL=… UNCLAIM_CLIENT_ID=… UNCLAIM_CLIENT_SECRET=… ADMIN_DISCORD_IDS=… bash install.sh --yes`.

Le nom de domaine (DNS) et le HTTPS restent à faire : le script affiche à la fin la configuration Caddy à utiliser (étape 3 ci-dessous).

## 2 bis. Configurer à la main (Docker ou autre)

```sh
cp .env.example .env
```
Renseignez au minimum `PUBLIC_URL`, `UNCLAIM_CLIENT_ID`, `UNCLAIM_CLIENT_SECRET` et `ADMIN_DISCORD_IDS` (votre ID Discord : vous serez super-admin).

## 3. Lancer

**Docker (recommandé)**
```sh
docker compose up -d --build
```

**Sans Docker**
```sh
npm start
```

Mettez un proxy HTTPS devant le port 4000. Avec Caddy :
```
chat.unclaim.fr {
  reverse_proxy localhost:4000 {
    flush_interval -1   # indispensable pour le temps réel (SSE)
  }
}
```

## 4. Premier démarrage

1. Ouvrez `https://chat.unclaim.fr/console` et connectez-vous (super-admin grâce à `ADMIN_DISCORD_IDS`).
2. Le site **unclaim** existe déjà, avec les zones Support, Proposer un projet et Partenariats. Dans **Réglages**, vérifiez les domaines autorisés (`https://unclaim.fr`), la couleur et l'accueil.
3. Dans **Équipe**, ajoutez les membres par **ID Discord**, sur tout le site ou sur une zone précise.
4. Pour un autre projet : **Réglages › Nouveau site**, puis copiez la ligne d'installation.

## 5. Installer la bulle sur un site

```html
<script src="https://chat.unclaim.fr/widget.js" data-site="unclaim" async></script>
```
- `data-zone="partenariats"` : ouvre directement cette zone (sans choix).
- `data-position="left"` : bulle à gauche.
- En JavaScript : `UnclaimChat.open("support")`, `UnclaimChat.close()` (ex. un bouton « Contacter le support »).

Le domaine du site doit être dans **Réglages › Domaines autorisés**, sinon la bulle ne s'affiche pas et l'API refuse les appels.

## Assistant IA (facultatif)

Renseignez `AI_API_KEY` (et `AI_BASE_URL`, `AI_MODEL` pour un autre fournisseur compatible OpenAI), puis activez l'assistant par site dans **Réglages**. Il répond en premier ; le visiteur clique sur « Parler à un humain » pour passer à l'équipe. Les conversations traitées par l'IA ne remontent pas dans la boîte des agents (filtre « Inclure l'assistant IA » pour les voir). Seul le texte de la conversation est envoyé au fournisseur, jamais l'identité.

## Tester en local (sans Unclaim Auth)

```sh
node --env-file=.env.test server.mjs
```
`.env.test` active `CHAT_DEV_LOGIN=1` : un formulaire de connexion simulée remplace Unclaim Auth (pseudo + ID factice), et `dev_admin` est super-admin. **Jamais en production** : désactivé automatiquement si `NODE_ENV=production`.

## Sécurité

- CORS strict : seuls les domaines autorisés d'un site peuvent appeler son API ; un jeton de visiteur ne vaut que pour son site.
- Console : cookie `HttpOnly`, `SameSite=Lax`, `Secure` en HTTPS ; les écritures venant d'une autre origine sont refusées.
- Limite : 20 messages par minute et par compte ; messages de 4 000 caractères maximum ; requêtes de 64 Ko maximum.
- Tout le contenu est affiché comme texte (jamais interprété comme HTML).
