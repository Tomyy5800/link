// Unclaim Chat — chat de support multi-sites (chat.unclaim.fr).
// Zéro dépendance : Node ≥ 22.13 (node:http, node:sqlite). Voir README.md.
import { createServer } from "node:http";
import { readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { all, get, id, run, seed, tx } from "./lib/db.mjs";
import {
  COOKIE, PUBLIC_URL, cookie, createSession, deleteSession, devLoginEnabled, exchangeCode,
  parseCookies, readLoginState, sessionUser, startLogin, upsertUser,
} from "./lib/auth.mjs";
import { canSeeConversation, isAgent, isSiteAdmin, isSuper, memberships, visibleWhere } from "./lib/perms.mjs";
import { publish, subscribe } from "./lib/realtime.mjs";
import { aiConfigured, aiReply } from "./lib/ai.mjs";

const ROOT = dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 4000);
const MAX_BODY = 64 * 1024;
const MAX_MESSAGE = 4000;

seed();

// ---------- utilitaires HTTP ----------
class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}
const fail = (status, message) => { throw new HttpError(status, message); };

function send(res, status, body, headers = {}) {
  const isJson = typeof body !== "string";
  res.writeHead(status, {
    "Content-Type": isJson ? "application/json; charset=utf-8" : "text/html; charset=utf-8",
    "X-Content-Type-Options": "nosniff",
    ...headers,
  });
  res.end(isJson ? JSON.stringify(body) : body);
}

async function readJson(req) {
  let size = 0;
  const chunks = [];
  for await (const c of req) {
    size += c.length;
    if (size > MAX_BODY) fail(413, "Requête trop volumineuse");
    chunks.push(c);
  }
  if (!chunks.length) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch {
    fail(400, "JSON invalide");
  }
}

const text = (v, max, field) => {
  const s = typeof v === "string" ? v.trim() : "";
  if (!s) fail(400, `${field} requis`);
  if (s.length > max) fail(400, `${field} trop long (${max} caractères max)`);
  return s;
};

// Limitation simple : 20 messages par minute et par compte.
const rate = new Map();
function rateLimit(key, max = 20, windowMs = 60_000) {
  const now = Date.now();
  const hits = (rate.get(key) || []).filter((t) => now - t < windowMs);
  if (hits.length >= max) fail(429, "Trop de messages, réessaie dans un instant.");
  hits.push(now);
  rate.set(key, hits);
}

const STATIC = {
  "/widget.js": ["public/widget.js", "text/javascript; charset=utf-8"],
  "/console": ["public/console/index.html", "text/html; charset=utf-8"],
  "/console/app.js": ["public/console/app.js", "text/javascript; charset=utf-8"],
  "/console/app.css": ["public/console/app.css", "text/css; charset=utf-8"],
};

// ---------- sites, origines, CORS ----------
const siteRow = (siteId) => get("SELECT * FROM sites WHERE id = ?", siteId);
const origins = (site) => { try { return JSON.parse(site.origins); } catch { return []; } };
const originAllowed = (site, origin) => !!site && !!origin && origins(site).includes(origin);

function corsFor(req, site) {
  const origin = req.headers.origin;
  if (!originAllowed(site, origin)) return {};
  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Headers": "Authorization, Content-Type",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Max-Age": "600",
    Vary: "Origin",
  };
}

// ---------- vues ----------
function convView(convId) {
  return get(
    `SELECT c.*, u.name AS visitor_name, u.avatar_url AS visitor_avatar, u.discord_id AS visitor_discord_id,
            s.name AS service_name, s.key AS service_key, a.name AS assignee_name,
            (SELECT body FROM messages WHERE conversation_id = c.id ORDER BY id DESC LIMIT 1) AS last_body
       FROM conversations c
       JOIN users u ON u.id = c.visitor_id
       JOIN services s ON s.id = c.service_id
       LEFT JOIN users a ON a.id = c.assignee_id
      WHERE c.id = ?`,
    convId,
  );
}
const messagesOf = (convId) =>
  all(
    `SELECT m.id, m.author, m.body, m.created_at, u.name AS author_name, u.avatar_url AS author_avatar
       FROM messages m LEFT JOIN users u ON u.id = m.user_id
      WHERE m.conversation_id = ? ORDER BY m.id`,
    convId,
  );

function addMessage(conv, author, userId, body) {
  const now = new Date().toISOString();
  const msgId = tx(() => {
    const r = run("INSERT INTO messages (conversation_id, author, user_id, body, created_at) VALUES (?, ?, ?, ?, ?)",
      conv.id, author, userId, body, now);
    const toAgents = author === "visitor" && conv.mode === "human";
    const toVisitor = author === "agent" || author === "ai";
    run(
      `UPDATE conversations SET last_message_at = ?, status = 'open',
         agent_unread = agent_unread + ?, visitor_unread = visitor_unread + ? WHERE id = ?`,
      now, toAgents ? 1 : 0, toVisitor ? 1 : 0, conv.id,
    );
    return Number(r.lastInsertRowid);
  });
  const message = messagesOf(conv.id).find((m) => m.id === msgId);
  const view = convView(conv.id);
  publish("message", view, { conversation: view, message });
  return message;
}

async function runAi(conv) {
  const site = siteRow(conv.site_id);
  try {
    addMessage(conv, "ai", null, await aiReply(site, conv.id));
  } catch (e) {
    console.error("Assistant IA indisponible :", e.message);
    addMessage(conv, "system", null, "L'assistant ne répond pas pour le moment. Clique sur « Parler à un humain » : l'équipe prend le relais.");
  }
}

// ---------- routes ----------
async function handle(req, res) {
  const url = new URL(req.url, PUBLIC_URL);
  const path = url.pathname.replace(/\/+$/, "") || "/";
  const method = req.method;
  const cookies = parseCookies(req.headers.cookie);

  if (path === "/") return send(res, 302, "", { Location: "/console" });
  if (path === "/health") return send(res, 200, { ok: true });

  if (method === "GET" && (STATIC[path] || path.startsWith("/console/"))) {
    const [file, type] = STATIC[path] || STATIC["/console"];
    const headers = { "Content-Type": type, "X-Content-Type-Options": "nosniff", "Cache-Control": "public, max-age=300" };
    if (path === "/widget.js") headers["Access-Control-Allow-Origin"] = "*";
    res.writeHead(200, headers);
    return res.end(readFileSync(join(ROOT, file)));
  }

  // ----- connexion -----
  if (method === "GET" && path === "/auth/start") {
    const mode = url.searchParams.get("mode") === "widget" ? "widget" : "console";
    const state = { mode };
    if (mode === "widget") {
      const site = siteRow(url.searchParams.get("site"));
      const origin = url.searchParams.get("origin");
      if (!originAllowed(site, origin)) return send(res, 400, "<p>Ce site n'est pas autorisé à utiliser le chat.</p>");
      // Retour sur la page d'origine après connexion (redirection, compatible navigateurs intégrés sans pop-up).
      let back = origin + "/";
      try {
        const r = new URL(url.searchParams.get("return") || back);
        if (r.origin === origin) back = r.origin + r.pathname + r.search;
      } catch { /* adresse invalide : retour à l'accueil du site */ }
      Object.assign(state, { site: site.id, origin, back });
    }
    if (devLoginEnabled() && url.searchParams.get("dev")) {
      const name = url.searchParams.get("dev").slice(0, 40);
      const userId = upsertUser({
        unclaim_id: `dev_${name}`, discord_id: url.searchParams.get("dev_discord") || `dev_${name}`,
        username: name, email: `${name}@dev.local`,
      });
      return finishLogin(res, state, userId);
    }
    if (!process.env.UNCLAIM_CLIENT_ID || !process.env.UNCLAIM_CLIENT_SECRET) {
      if (devLoginEnabled()) {
        // Test local sans Unclaim Auth : petit formulaire qui simule un compte.
        const keep = ["mode", "site", "origin"].map((k) => url.searchParams.get(k)
          ? `<input type="hidden" name="${k}" value="${url.searchParams.get(k).replace(/"/g, "&quot;")}">` : "").join("");
        const keepReturn = url.searchParams.get("return") ? `<input type="hidden" name="return" value="${url.searchParams.get("return").replace(/"/g, "&quot;")}">` : "";
        return send(res, 200, `<!doctype html><meta charset="utf-8"><title>Connexion de test</title>
<body style="font-family:system-ui;background:#0E0F12;color:#ECEAE4;display:grid;place-items:center;height:100vh;margin:0">
<form method="get" action="/auth/start" style="display:grid;gap:10px;width:300px">
<h2 style="margin:0">Connexion de test</h2><p style="color:#8A8C93;margin:0">Uniquement en local (CHAT_DEV_LOGIN=1).</p>
${keep}${keepReturn}<input name="dev" placeholder="Pseudo" required maxlength="40" style="padding:8px">
<input name="dev_discord" placeholder="ID Discord (facultatif)" maxlength="32" style="padding:8px">
<button style="padding:10px;background:#FF5A1F;border:0;font-weight:600">Se connecter</button></form>`);
      }
      return send(res, 500, "<p>Unclaim Auth n'est pas configuré.</p>");
    }
    const { url: to, cookie: c } = startLogin(state);
    return send(res, 302, "", { Location: to, "Set-Cookie": c });
  }

  if (method === "GET" && path === "/auth/callback") {
    const state = readLoginState(cookies, url.searchParams.get("state"));
    const clear = cookie("uc_oauth", "", 0);
    if (!state) return send(res, 400, "<p>Session de connexion expirée. Recommence.</p>", { "Set-Cookie": clear });
    if (url.searchParams.get("error")) return send(res, 400, "<p>Connexion annulée.</p>", { "Set-Cookie": clear });
    try {
      const user = await exchangeCode(url.searchParams.get("unclaim_code"), state.v);
      return finishLogin(res, state, upsertUser(user), clear);
    } catch (e) {
      console.error("Connexion refusée :", e.message);
      return send(res, 400, "<p>Unclaim Auth n'a pas validé la connexion. Réessaie.</p>", { "Set-Cookie": clear });
    }
  }

  if (method === "POST" && path === "/auth/logout") {
    deleteSession(cookies[COOKIE]);
    return send(res, 200, { ok: true }, { "Set-Cookie": cookie(COOKIE, "", 0) });
  }

  if (path.startsWith("/api/widget/")) return widgetApi(req, res, url, path.slice("/api/widget".length));
  if (path.startsWith("/api/console/")) return consoleApi(req, res, url, path.slice("/api/console".length), cookies);
  return send(res, 404, { error: "Introuvable" });
}

function finishLogin(res, state, userId, extraCookie) {
  const headers = {};
  if (state.mode === "widget") {
    const token = createSession(userId, "widget", state.site);
    if (extraCookie) headers["Set-Cookie"] = extraCookie;
    // Le jeton voyage dans le fragment (#) : jamais envoyé à un serveur ni dans le Referer, effacé par le widget.
    const back = state.back || `${state.origin}/`;
    return send(res, 302, "", { ...headers, Location: `${back}#unclaim-chat=${encodeURIComponent(state.site)}.${token}` });
  }
  const token = createSession(userId, "console");
  headers["Set-Cookie"] = [cookie(COOKIE, token, 30 * 86400), ...(extraCookie ? [extraCookie] : [])];
  return send(res, 302, "", { ...headers, Location: "/console" });
}

// ---------- API du widget (sites hôtes) ----------
async function widgetApi(req, res, url, sub) {
  const site = siteRow(url.searchParams.get("site"));
  const cors = corsFor(req, site);
  if (req.method === "OPTIONS") return send(res, 204, "", cors);
  if (!site) return send(res, 404, { error: "Site inconnu" }, cors);
  if (req.headers.origin && !cors["Access-Control-Allow-Origin"]) return send(res, 403, { error: "Origine non autorisée" });

  try {
    if (req.method === "GET" && sub === "/config") {
      const services = all("SELECT id, key, name FROM services WHERE site_id = ? ORDER BY position, id", site.id);
      return send(res, 200, {
        site: { id: site.id, title: site.title, color: site.color, greeting: site.greeting, ai: !!site.ai_enabled && aiConfigured() },
        services,
      }, cors);
    }

    const bearer = (req.headers.authorization || "").replace(/^Bearer\s+/i, "") || url.searchParams.get("token");
    const user = sessionUser(bearer, "widget", site.id);
    if (!user) return send(res, 401, { error: "Connexion requise" }, cors);

    if (req.method === "GET" && sub === "/stream") {
      // Le flux est lu depuis le site hôte : il lui faut les en-têtes CORS comme le reste de l'API.
      return subscribe(req, res, { kind: "widget", userId: user.id, siteId: site.id }, cors);
    }
    if (req.method === "GET" && sub === "/me") {
      const conversations = all(
        `SELECT c.id, c.service_id, c.status, c.mode, c.visitor_unread, c.last_message_at, s.name AS service_name
           FROM conversations c JOIN services s ON s.id = c.service_id
          WHERE c.visitor_id = ? AND c.site_id = ? ORDER BY c.last_message_at DESC LIMIT 20`,
        user.id, site.id,
      );
      return send(res, 200, { user: { name: user.name, avatar_url: user.avatar_url }, conversations }, cors);
    }
    if (req.method === "POST" && sub === "/logout") {
      deleteSession(bearer);
      return send(res, 200, { ok: true }, cors);
    }
    if (req.method === "POST" && sub === "/conversations") {
      const body = await readJson(req);
      const service = get("SELECT * FROM services WHERE id = ? AND site_id = ?", Number(body.service_id), site.id);
      if (!service) fail(400, "Zone inconnue");
      let conv = get("SELECT * FROM conversations WHERE visitor_id = ? AND site_id = ? AND service_id = ? AND status = 'open'",
        user.id, site.id, service.id);
      if (!conv) {
        const convId = id();
        const mode = site.ai_enabled && aiConfigured() ? "ai" : "human";
        run("INSERT INTO conversations (id, site_id, service_id, visitor_id, mode) VALUES (?, ?, ?, ?, ?)",
          convId, site.id, service.id, user.id, mode);
        conv = get("SELECT * FROM conversations WHERE id = ?", convId);
      }
      return send(res, 200, { conversation: conv }, cors);
    }

    const m = sub.match(/^\/conversations\/([\w-]+)(\/messages|\/human)?$/);
    if (m) {
      const conv = get("SELECT * FROM conversations WHERE id = ? AND visitor_id = ? AND site_id = ?", m[1], user.id, site.id);
      if (!conv) fail(404, "Conversation introuvable");
      if (req.method === "GET" && m[2] === "/messages") {
        run("UPDATE conversations SET visitor_unread = 0 WHERE id = ?", conv.id);
        return send(res, 200, { conversation: conv, messages: messagesOf(conv.id) }, cors);
      }
      if (req.method === "POST" && m[2] === "/messages") {
        rateLimit(user.id);
        const body = text((await readJson(req)).body, MAX_MESSAGE, "Message");
        const message = addMessage(conv, "visitor", user.id, body);
        if (conv.mode === "ai") runAi(conv);
        return send(res, 200, { message }, cors);
      }
      if (req.method === "POST" && m[2] === "/human") {
        if (conv.mode !== "human") {
          run("UPDATE conversations SET mode = 'human', agent_unread = agent_unread + 1 WHERE id = ?", conv.id);
          addMessage({ ...conv, mode: "human" }, "system", null, "Conversation transmise à l'équipe. Un membre te répond ici, en général dans la journée.");
        }
        return send(res, 200, { conversation: get("SELECT * FROM conversations WHERE id = ?", conv.id) }, cors);
      }
    }
    return send(res, 404, { error: "Introuvable" }, cors);
  } catch (e) {
    return send(res, e.status || 500, { error: e.status ? e.message : "Erreur serveur" }, cors);
  }
}

// ---------- API de la console agents ----------
const SITE_ID_RE = /^[a-z0-9-]{2,32}$/;
const COLOR_RE = /^#[0-9a-fA-F]{6}$/;
const ORIGIN_RE = /^(https:\/\/[a-z0-9.-]+(:\d+)?|http:\/\/(localhost|127\.0\.0\.1)(:\d+)?)$/;

async function consoleApi(req, res, url, sub, cookies) {
  try {
    const user = sessionUser(cookies[COOKIE], "console");
    if (!user) fail(401, "Connexion requise");
    // Protection CSRF : les écritures doivent venir de la console elle-même.
    if (req.method !== "GET" && req.headers.origin && req.headers.origin !== new URL(PUBLIC_URL).origin) fail(403, "Origine refusée");

    if (req.method === "GET" && sub === "/me") {
      const ms = memberships(user);
      const siteIds = [...new Set(ms.map((x) => x.site_id))];
      const sites = siteIds.map((sid) => ({
        ...siteRow(sid),
        admin: isSiteAdmin(user, sid),
        services: all("SELECT id, key, name, position FROM services WHERE site_id = ? ORDER BY position, id", sid),
        scope: ms.filter((x) => x.site_id === sid).map((x) => ({ service_id: x.service_id, role: x.role })),
      }));
      return send(res, 200, { user: { id: user.id, name: user.name, avatar_url: user.avatar_url, discord_id: user.discord_id }, super: isSuper(user), agent: isAgent(user), sites });
    }
    if (!isAgent(user)) fail(403, "Ton compte n'a accès à aucune zone. Demande à un admin de t'ajouter.");

    if (req.method === "GET" && sub === "/stream") return subscribe(req, res, { kind: "console", user });

    if (req.method === "GET" && sub === "/conversations") {
      const v = visibleWhere(user);
      const where = [v.sql];
      const params = [...v.params];
      const status = url.searchParams.get("status") || "open";
      where.push("c.status = ?"); params.push(status === "closed" ? "closed" : "open");
      if (url.searchParams.get("site")) { where.push("c.site_id = ?"); params.push(url.searchParams.get("site")); }
      if (url.searchParams.get("service")) { where.push("c.service_id = ?"); params.push(Number(url.searchParams.get("service"))); }
      if (url.searchParams.get("mine") === "1") { where.push("c.assignee_id = ?"); params.push(user.id); }
      if (url.searchParams.get("ai") !== "1") where.push("c.mode = 'human'");
      const rows = all(
        `SELECT c.id FROM conversations c WHERE ${where.join(" AND ")} ORDER BY c.agent_unread > 0 DESC, c.last_message_at DESC LIMIT 200`,
        ...params,
      );
      return send(res, 200, { conversations: rows.map((r) => convView(r.id)) });
    }

    const cm = sub.match(/^\/conversations\/([\w-]+)(\/messages)?$/);
    if (cm) {
      const conv = get("SELECT * FROM conversations WHERE id = ?", cm[1]);
      if (!canSeeConversation(user, conv)) fail(404, "Conversation introuvable");
      if (req.method === "GET" && !cm[2]) {
        run("UPDATE conversations SET agent_unread = 0 WHERE id = ?", conv.id);
        return send(res, 200, { conversation: convView(conv.id), messages: messagesOf(conv.id) });
      }
      if (req.method === "POST" && cm[2]) {
        const body = text((await readJson(req)).body, MAX_MESSAGE, "Message");
        run("UPDATE conversations SET mode = 'human', agent_unread = 0, assignee_id = COALESCE(assignee_id, ?) WHERE id = ?", user.id, conv.id);
        return send(res, 200, { message: addMessage({ ...conv, mode: "human" }, "agent", user.id, body) });
      }
      if (req.method === "PATCH" && !cm[2]) {
        const body = await readJson(req);
        if (body.status !== undefined) {
          if (!["open", "closed"].includes(body.status)) fail(400, "Statut invalide");
          run("UPDATE conversations SET status = ? WHERE id = ?", body.status, conv.id);
        }
        if (body.assignee_id !== undefined) {
          const target = body.assignee_id ? get("SELECT * FROM users WHERE id = ?", body.assignee_id) : null;
          if (body.assignee_id && !canSeeConversation(target, conv)) fail(400, "Cet agent n'a pas accès à cette zone");
          run("UPDATE conversations SET assignee_id = ? WHERE id = ?", target?.id ?? null, conv.id);
        }
        if (body.service_id !== undefined) {
          const service = get("SELECT * FROM services WHERE id = ? AND site_id = ?", Number(body.service_id), conv.site_id);
          if (!service) fail(400, "Zone inconnue");
          run("UPDATE conversations SET service_id = ? WHERE id = ?", service.id, conv.id);
        }
        const view = convView(conv.id);
        publish("conversation", view, { conversation: view });
        return send(res, 200, { conversation: view });
      }
    }

    // ----- sites, services, équipe -----
    if (req.method === "POST" && sub === "/sites") {
      if (!isSuper(user)) fail(403, "Réservé aux super-admins");
      const body = await readJson(req);
      const siteId = text(body.id, 32, "Identifiant").toLowerCase();
      if (!SITE_ID_RE.test(siteId)) fail(400, "Identifiant : lettres minuscules, chiffres et tirets (2 à 32)");
      if (siteRow(siteId)) fail(409, "Ce site existe déjà");
      tx(() => {
        run("INSERT INTO sites (id, name, title) VALUES (?, ?, ?)", siteId, text(body.name, 60, "Nom"), `Support ${body.name}`.slice(0, 60));
        run("INSERT INTO services (site_id, key, name) VALUES (?, 'support', 'Support')", siteId);
      });
      return send(res, 200, { site: siteRow(siteId) });
    }

    const sm = sub.match(/^\/sites\/([a-z0-9-]+)(\/services|\/members)?$/);
    if (sm) {
      const site = siteRow(sm[1]);
      if (!site) fail(404, "Site inconnu");
      if (!isSiteAdmin(user, site.id)) fail(403, "Réservé aux admins de ce site");

      if (req.method === "PATCH" && !sm[2]) {
        const b = await readJson(req);
        const next = { ...site };
        if (b.name !== undefined) next.name = text(b.name, 60, "Nom");
        if (b.title !== undefined) next.title = text(b.title, 60, "Titre");
        if (b.greeting !== undefined) next.greeting = text(b.greeting, 300, "Message d'accueil");
        if (b.color !== undefined) { if (!COLOR_RE.test(b.color)) fail(400, "Couleur : format #RRGGBB"); next.color = b.color; }
        if (b.origins !== undefined) {
          if (!Array.isArray(b.origins) || b.origins.length > 20) fail(400, "Origines invalides");
          const list = b.origins.map((o) => String(o).trim().replace(/\/+$/, "")).filter(Boolean);
          const bad = list.find((o) => !ORIGIN_RE.test(o));
          if (bad) fail(400, `Origine invalide : ${bad} (ex. https://unclaim.fr)`);
          next.origins = JSON.stringify(list);
        }
        if (b.ai_enabled !== undefined) next.ai_enabled = b.ai_enabled ? 1 : 0;
        if (b.ai_prompt !== undefined) next.ai_prompt = String(b.ai_prompt).slice(0, 4000);
        run("UPDATE sites SET name = ?, title = ?, greeting = ?, color = ?, origins = ?, ai_enabled = ?, ai_prompt = ? WHERE id = ?",
          next.name, next.title, next.greeting, next.color, next.origins, next.ai_enabled, next.ai_prompt, site.id);
        return send(res, 200, { site: siteRow(site.id) });
      }
      if (req.method === "DELETE" && !sm[2]) {
        if (!isSuper(user)) fail(403, "Réservé aux super-admins");
        run("DELETE FROM sites WHERE id = ?", site.id);
        return send(res, 200, { ok: true });
      }
      if (sm[2] === "/services") {
        const b = await readJson(req);
        if (req.method === "POST") {
          const key = text(b.key, 32, "Clé").toLowerCase();
          if (!SITE_ID_RE.test(key)) fail(400, "Clé : lettres minuscules, chiffres et tirets");
          if (get("SELECT 1 FROM services WHERE site_id = ? AND key = ?", site.id, key)) fail(409, "Cette zone existe déjà");
          const pos = get("SELECT COALESCE(MAX(position), -1) + 1 AS p FROM services WHERE site_id = ?", site.id).p;
          run("INSERT INTO services (site_id, key, name, position) VALUES (?, ?, ?, ?)", site.id, key, text(b.name, 60, "Nom"), pos);
          return send(res, 200, { ok: true });
        }
        const service = get("SELECT * FROM services WHERE id = ? AND site_id = ?", Number(b.id), site.id);
        if (!service) fail(404, "Zone inconnue");
        if (req.method === "PATCH") {
          run("UPDATE services SET name = ?, position = ? WHERE id = ?",
            b.name !== undefined ? text(b.name, 60, "Nom") : service.name,
            Number.isInteger(b.position) ? b.position : service.position, service.id);
          return send(res, 200, { ok: true });
        }
        if (req.method === "DELETE") {
          if (get("SELECT 1 FROM conversations WHERE service_id = ?", service.id)) fail(409, "Cette zone a des conversations : déplace-les avant de la supprimer");
          if (get("SELECT COUNT(*) AS n FROM services WHERE site_id = ?", site.id).n <= 1) fail(409, "Un site garde au moins une zone");
          tx(() => {
            run("DELETE FROM members WHERE service_id = ?", service.id);
            run("DELETE FROM services WHERE id = ?", service.id);
          });
          return send(res, 200, { ok: true });
        }
      }
      if (sm[2] === "/members") {
        if (req.method === "GET") {
          return send(res, 200, {
            members: all(
              `SELECT m.user_id, m.service_id, m.role, u.name, u.discord_id, u.avatar_url, u.unclaim_id IS NOT NULL AS has_logged_in
                 FROM members m JOIN users u ON u.id = m.user_id WHERE m.site_id = ? ORDER BY u.name`,
              site.id,
            ),
          });
        }
        const b = await readJson(req);
        if (req.method === "POST") {
          const discordId = text(b.discord_id, 32, "ID Discord");
          if (!/^\d{5,25}$/.test(discordId) && !(process.env.CHAT_DEV_LOGIN === "1" && discordId.startsWith("dev_"))) fail(400, "ID Discord : chiffres uniquement");
          const serviceId = Number(b.service_id || 0);
          if (serviceId && !get("SELECT 1 FROM services WHERE id = ? AND site_id = ?", serviceId, site.id)) fail(400, "Zone inconnue");
          const role = b.role === "admin" ? "admin" : "agent";
          if (role === "admin" && serviceId) fail(400, "Un admin couvre tout le site");
          let target = get("SELECT * FROM users WHERE discord_id = ?", discordId);
          if (!target) {
            const uid = id();
            run("INSERT INTO users (id, discord_id, name) VALUES (?, ?, ?)", uid, discordId, String(b.name || `Discord ${discordId}`).slice(0, 60));
            target = get("SELECT * FROM users WHERE id = ?", uid);
          }
          run("INSERT INTO members (user_id, site_id, service_id, role) VALUES (?, ?, ?, ?) ON CONFLICT DO UPDATE SET role = excluded.role",
            target.id, site.id, serviceId, role);
          return send(res, 200, { ok: true });
        }
        if (req.method === "DELETE") {
          run("DELETE FROM members WHERE user_id = ? AND site_id = ? AND service_id = ?", String(b.user_id), site.id, Number(b.service_id || 0));
          return send(res, 200, { ok: true });
        }
      }
    }
    if (req.method === "GET" && sub === "/sites/all") {
      if (!isSuper(user)) fail(403, "Réservé aux super-admins");
      return send(res, 200, { sites: all("SELECT id, name FROM sites ORDER BY name") });
    }
    return send(res, 404, { error: "Introuvable" });
  } catch (e) {
    if (!e.status) console.error(e);
    return send(res, e.status || 500, { error: e.status ? e.message : "Erreur serveur" });
  }
}

createServer((req, res) => {
  handle(req, res).catch((e) => {
    console.error(e);
    if (!res.headersSent) send(res, 500, { error: "Erreur serveur" });
  });
}).listen(PORT, () => {
  console.log(`Unclaim Chat sur ${PUBLIC_URL} (port ${PORT})${devLoginEnabled() ? " — connexion de test active" : ""}`);
});
