// Console agents Unclaim Chat : boîte de réception, réglages des sites, équipe et permissions.
(function () {
  "use strict";
  var S = {
    me: null, tab: "inbox",
    filter: { site: null, service: null, status: "open", mine: false, ai: false },
    convs: [], current: null, messages: [], draft: "",
    settingsSite: null, members: [],
  };
  var app = document.getElementById("app");

  // ---------- outils ----------
  function h(tag, attrs) {
    var n = document.createElement(tag);
    for (var k in attrs || {}) {
      var v = attrs[k];
      if (v == null || v === false) continue;
      if (k === "text") n.textContent = v;
      else if (k === "value") n.value = v;
      else if (k.slice(0, 2) === "on") n.addEventListener(k.slice(2), v);
      else n.setAttribute(k, v === true ? "" : v);
    }
    (function add(list) {
      list.forEach(function (x) {
        if (Array.isArray(x)) return add(x); // listes imbriquées (sites › zones)
        if (x != null && x !== false) n.appendChild(typeof x === "string" ? document.createTextNode(x) : x);
      });
    })(Array.prototype.slice.call(arguments, 2));
    return n;
  }
  function api(path, opts) {
    opts = opts || {};
    return fetch("/api/console" + path, {
      method: opts.method || "GET",
      headers: opts.body ? { "Content-Type": "application/json" } : {},
      body: opts.body ? JSON.stringify(opts.body) : undefined,
      credentials: "same-origin",
    }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (r.status === 401) { renderLogin(); throw new Error("Connexion requise"); }
        if (!r.ok) throw new Error(j.error || "Erreur");
        return j;
      });
    });
  }
  function toast(msg, err) {
    var t = h("div", { class: "toast" + (err ? " err" : ""), role: "status", text: msg });
    document.body.appendChild(t);
    setTimeout(function () { t.remove(); }, 3200);
  }
  var oops = function (e) { if (e.message !== "Connexion requise") toast(e.message, true); };
  function ago(iso) {
    var s = (Date.now() - new Date(iso).getTime()) / 1000;
    if (s < 60) return "à l'instant";
    if (s < 3600) return Math.floor(s / 60) + " min";
    if (s < 86400) return Math.floor(s / 3600) + " h";
    return new Date(iso).toLocaleDateString("fr-FR", { day: "numeric", month: "short" });
  }
  function avatar(url, name) {
    return url ? h("img", { class: "avatar", src: url, alt: "" }) : h("span", { class: "avatar", text: (name || "?").slice(0, 1).toUpperCase() });
  }
  var siteOf = function (id) { return S.me.sites.filter(function (s) { return s.id === id; })[0]; };
  var adminSites = function () { return S.me.sites.filter(function (s) { return s.admin; }); };
  function zoneLabel(site, serviceId) {
    if (!serviceId) return "Tout le site";
    var z = site.services.filter(function (s) { return s.id === serviceId; })[0];
    return z ? z.name : "Zone supprimée";
  }

  // ---------- connexion ----------
  function renderLogin(msg) {
    app.innerHTML = "";
    var local = /^(localhost|127\.0\.0\.1)$/.test(location.hostname);
    app.appendChild(h("div", { class: "login" },
      h("div", { class: "brand" }, h("b", {}, "un", h("span", { text: "claim" })), h("span", { class: "label", text: "chat" })),
      h("h1", { text: "Console de support" }),
      h("p", { class: "muted", text: msg || "Réponds aux conversations de tous les sites Unclaim. Connexion avec ton compte Unclaim (Discord)." }),
      h("a", { class: "btn", href: "/auth/start?mode=console", text: "Se connecter avec Unclaim Auth" }),
      local ? h("p", { class: "muted" }, "Test local : ", h("a", { href: "/auth/start?mode=console&dev=admin&dev_discord=dev_admin", text: "se connecter en admin de test" })) : null,
    ));
  }

  function logout() {
    fetch("/auth/logout", { method: "POST", credentials: "same-origin" }).then(function () { location.reload(); });
  }

  // ---------- coque ----------
  function shell(content) {
    app.innerHTML = "";
    var tabs = [["inbox", "Boîte de réception"]];
    if (adminSites().length) tabs.push(["settings", "Réglages"], ["team", "Équipe"]);
    app.appendChild(h("header", { class: "top" },
      h("div", { class: "brand" }, h("b", {}, "un", h("span", { text: "claim" })), h("span", { class: "label", text: "chat" })),
      h("nav", { class: "tabs", "aria-label": "Sections" }, tabs.map(function (t) {
        return h("button", { class: "tab" + (S.tab === t[0] ? " on" : ""), "aria-current": S.tab === t[0] ? "page" : null, text: t[1], onclick: function () { S.tab = t[0]; route(); } });
      })),
      h("div", { class: "me" },
        avatar(S.me.user.avatar_url, S.me.user.name),
        h("span", { text: S.me.user.name }),
        S.me.super ? h("span", { class: "chip", text: "super-admin" }) : null,
        h("button", { class: "btn ghost sm", text: "Déconnexion", onclick: logout }),
      ),
    ));
    app.appendChild(content);
  }

  function route() {
    if (S.tab === "settings") return renderSettings();
    if (S.tab === "team") return renderTeam();
    return renderInbox();
  }

  // ---------- boîte de réception ----------
  var listEl, threadEl;
  function renderInbox() {
    var f = S.filter;
    var side = h("aside", { class: "side", "aria-label": "Filtres" },
      h("div", { class: "filter" },
        h("span", { class: "label", text: "Statut" }),
        fbtn("Ouvertes", f.status === "open", function () { f.status = "open"; refilter(); }),
        fbtn("Fermées", f.status === "closed", function () { f.status = "closed"; refilter(); }),
        fbtn("Assignées à moi", f.mine, function () { f.mine = !f.mine; refilter(); }),
        fbtn("Inclure l'assistant IA", f.ai, function () { f.ai = !f.ai; refilter(); }),
      ),
      h("div", { class: "filter" },
        h("span", { class: "label", text: "Zones" }),
        fbtn("Toutes", !f.site, function () { f.site = null; f.service = null; refilter(); }),
        S.me.sites.map(function (s) {
          return [
            fbtn(s.name, f.site === s.id && !f.service, function () { f.site = s.id; f.service = null; refilter(); }),
            s.services.filter(function (z) { return s.admin || s.scope.some(function (x) { return x.service_id === 0 || x.service_id === z.id; }); })
              .map(function (z) { return fbtn(z.name, f.service === z.id, function () { f.site = s.id; f.service = z.id; refilter(); }, "zone"); }),
          ];
        }),
      ),
    );
    listEl = h("section", { class: "list", "aria-label": "Conversations" });
    threadEl = h("section", { class: "thread", "aria-label": "Conversation" });
    shell(h("main", { class: "inbox" }, side, listEl, threadEl));
    renderList();
    renderThread();
  }
  // Changement de filtre : on redessine les filtres puis on recharge la liste.
  function refilter() { renderInbox(); reload(); }
  function fbtn(label, on, fn, extra) {
    return h("button", { class: "fbtn" + (on ? " on" : "") + (extra ? " " + extra : ""), "aria-pressed": on ? "true" : "false", text: label, onclick: fn });
  }

  function reload() {
    var f = S.filter;
    var q = "?status=" + f.status + (f.site ? "&site=" + encodeURIComponent(f.site) : "") + (f.service ? "&service=" + f.service : "") + (f.mine ? "&mine=1" : "") + (f.ai ? "&ai=1" : "");
    return api("/conversations" + q).then(function (j) {
      S.convs = j.conversations;
      // Seule la liste est redessinée : la réponse en cours de frappe garde le focus.
      if (S.tab === "inbox" && listEl && listEl.isConnected) renderList();
    }).catch(oops);
  }

  function renderList() {
    listEl.innerHTML = "";
    if (!S.convs.length) return listEl.appendChild(h("p", { class: "empty", text: S.filter.status === "open" ? "Aucune conversation en attente. Tout est à jour." : "Aucune conversation fermée." }));
    S.convs.forEach(function (c) {
      var site = siteOf(c.site_id);
      listEl.appendChild(h("button", { class: "item" + (S.current && S.current.id === c.id ? " on" : ""), onclick: function () { openConv(c.id); } },
        avatar(c.visitor_avatar, c.visitor_name),
        h("div", { style: "min-width:0" },
          h("div", { class: "l1" }, h("span", { text: c.visitor_name || "Visiteur" }), c.agent_unread ? h("span", { class: "unread", text: String(c.agent_unread) }) : h("span", { class: "muted", style: "font-weight:400;font-size:12px", text: ago(c.last_message_at) })),
          h("div", { class: "l2", text: c.last_body || "(pas encore de message)" }),
          h("div", { class: "l3" },
            h("span", { text: site ? site.name : c.site_id }), h("span", { text: "·" }), h("span", { text: c.service_name }),
            c.mode === "ai" ? h("span", { text: "· IA" }) : null,
            c.assignee_name ? h("span", { text: "· " + c.assignee_name }) : null),
        )));
    });
  }

  function openConv(id) {
    return api("/conversations/" + id).then(function (j) {
      S.current = j.conversation; S.messages = j.messages; S.draft = "";
      S.convs.forEach(function (c) { if (c.id === id) c.agent_unread = 0; });
      renderList(); renderThread();
    }).catch(oops);
  }

  function renderThread() {
    threadEl.innerHTML = "";
    var c = S.current;
    if (!c) return threadEl.appendChild(h("p", { class: "empty", text: "Choisis une conversation à gauche." }));
    var site = siteOf(c.site_id);
    var zoneSelect = h("select", { "aria-label": "Déplacer vers une zone", onchange: function (e) { patch({ service_id: Number(e.target.value) }); } },
      (site ? site.services : []).map(function (z) { var o = h("option", { value: String(z.id), text: z.name }); if (z.id === c.service_id) o.selected = true; return o; }));
    threadEl.appendChild(h("div", { class: "thead" },
      h("div", { class: "who" }, avatar(c.visitor_avatar, c.visitor_name), h("div", { style: "min-width:0" },
        h("h3", { text: c.visitor_name || "Visiteur" }),
        h("div", { class: "label", text: (site ? site.name : c.site_id) + " · Discord " + (c.visitor_discord_id || "?") }))),
      h("div", { class: "actions" },
        zoneSelect,
        c.assignee_id === S.me.user.id
          ? h("button", { class: "btn ghost sm", text: "Me retirer", onclick: function () { patch({ assignee_id: null }); } })
          : h("button", { class: "btn ghost sm", text: c.assignee_name ? "Reprendre (" + c.assignee_name + ")" : "M'assigner", onclick: function () { patch({ assignee_id: S.me.user.id }); } }),
        c.status === "open"
          ? h("button", { class: "btn sm", text: "Fermer", onclick: function () { patch({ status: "closed" }); } })
          : h("button", { class: "btn ghost sm", text: "Rouvrir", onclick: function () { patch({ status: "open" }); } }),
      )));
    var msgs = h("div", { class: "msgs", "aria-live": "polite" });
    S.messages.forEach(function (m) {
      if (m.author === "system") return msgs.appendChild(h("div", { class: "msg system", text: m.body }));
      var who = m.author === "visitor" ? (c.visitor_name || "Visiteur") : m.author === "ai" ? "Assistant IA" : (m.author_name || "Équipe");
      msgs.appendChild(h("div", { class: "msg " + m.author },
        h("div", { class: "meta", text: who + " · " + ago(m.created_at) }),
        h("div", { class: "txt", text: m.body })));
    });
    threadEl.appendChild(msgs);
    var ta = h("textarea", { rows: "2", placeholder: "Réponds à " + (c.visitor_name || "ce visiteur") + "…  (Entrée pour envoyer, Maj+Entrée pour aller à la ligne)", "aria-label": "Réponse", maxlength: "4000", value: S.draft,
      oninput: function (e) { S.draft = e.target.value; },
      onkeydown: function (e) { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendReply(); } } });
    threadEl.appendChild(h("div", { class: "reply" }, ta, h("button", { class: "btn", text: "Envoyer", onclick: sendReply })));
    msgs.scrollTop = msgs.scrollHeight;
  }

  function sendReply() {
    var body = S.draft.trim();
    if (!body || !S.current) return;
    S.draft = "";
    api("/conversations/" + S.current.id + "/messages", { method: "POST", body: { body: body } })
      .then(function (j) { if (!S.messages.some(function (m) { return m.id === j.message.id; })) S.messages.push(j.message); renderThread(); })
      .catch(function (e) { S.draft = body; renderThread(); oops(e); });
  }

  function patch(changes) {
    api("/conversations/" + S.current.id, { method: "PATCH", body: changes })
      .then(function (j) { S.current = j.conversation; reload(); renderThread(); })
      .catch(oops);
  }

  // ---------- temps réel ----------
  var es;
  function stream() {
    es = new EventSource("/api/console/stream");
    var refresh = debounce(reload, 300);
    es.addEventListener("message", function (e) {
      var d = JSON.parse(e.data);
      if (S.current && S.current.id === d.conversation.id) {
        S.current = d.conversation;
        if (!S.messages.some(function (m) { return m.id === d.message.id; })) S.messages.push(d.message);
        if (S.tab === "inbox" && threadEl && threadEl.isConnected) renderThread();
        if (d.message.author === "visitor") api("/conversations/" + d.conversation.id).catch(function () {}); // lu
      } else if (d.message.author === "visitor" && d.conversation.mode === "human") {
        notify(d.conversation.visitor_name, d.message.body);
      }
      refresh();
    });
    es.addEventListener("conversation", function (e) {
      var d = JSON.parse(e.data);
      if (S.current && S.current.id === d.conversation.id) { S.current = d.conversation; if (S.tab === "inbox" && threadEl && threadEl.isConnected) renderThread(); }
      refresh();
    });
  }
  function debounce(fn, ms) { var t; return function () { clearTimeout(t); t = setTimeout(fn, ms); }; }
  function notify(name, body) {
    document.title = "• Nouveau message — Unclaim Chat";
    if ("Notification" in window && Notification.permission === "granted" && document.hidden) new Notification(name || "Nouveau message", { body: body.slice(0, 120) });
  }
  window.addEventListener("focus", function () { document.title = "Unclaim Chat — Console"; });

  // ---------- réglages ----------
  function pickSite(list) {
    if (!S.settingsSite || !list.some(function (s) { return s.id === S.settingsSite; })) S.settingsSite = list[0] && list[0].id;
    return siteOf(S.settingsSite);
  }
  function siteSelector(list, then) {
    return h("div", { class: "row" },
      h("span", { class: "label", text: "Site" }),
      h("select", { style: "width:auto", "aria-label": "Site", onchange: function (e) { S.settingsSite = e.target.value; then(); } },
        list.map(function (s) { var o = h("option", { value: s.id, text: s.name }); if (s.id === S.settingsSite) o.selected = true; return o; })));
  }

  function renderSettings() {
    var list = adminSites();
    var site = pickSite(list);
    var page = h("main", { class: "page" });
    page.appendChild(h("div", { class: "row", style: "justify-content:space-between" }, h("h1", { text: "Réglages" }), siteSelector(list, renderSettings)));
    if (site) {
      var f = {
        name: h("input", { value: site.name, maxlength: "60" }),
        title: h("input", { value: site.title, maxlength: "60" }),
        color: h("input", { type: "color", value: site.color, style: "height:38px;padding:2px" }),
        greeting: h("textarea", { rows: "2", maxlength: "300", value: site.greeting }),
        origins: h("textarea", { rows: "3", value: JSON.parse(site.origins || "[]").join("\n") }),
        ai: h("input", { type: "checkbox", style: "width:auto" }),
        prompt: h("textarea", { rows: "4", maxlength: "4000", value: site.ai_prompt }),
      };
      f.ai.checked = !!site.ai_enabled;
      page.appendChild(h("section", { class: "card", style: "border-top-color:" + site.color },
        h("h2", { text: "Apparence et accueil" }),
        h("div", { class: "grid2" },
          h("label", { class: "field" }, h("span", { class: "label", text: "Nom du site" }), f.name),
          h("label", { class: "field" }, h("span", { class: "label", text: "Titre du chat" }), f.title)),
        h("div", { class: "grid2" },
          h("label", { class: "field" }, h("span", { class: "label", text: "Couleur" }), f.color),
          h("label", { class: "field" }, h("span", { class: "label", text: "Message d'accueil" }), f.greeting)),
        h("label", { class: "field" }, h("span", { class: "label", text: "Domaines autorisés (un par ligne)" }), f.origins,
          h("span", { class: "muted", text: "Le chat ne s'affiche que sur ces adresses, ex. https://unclaim.fr" })),
        h("label", { class: "row" }, f.ai, h("span", { text: "Assistant IA en première réponse (l'équipe reprend sur « Parler à un humain »)" })),
        h("label", { class: "field" }, h("span", { class: "label", text: "Consignes de l'assistant IA" }), f.prompt),
        h("div", { class: "row" }, h("button", { class: "btn", text: "Enregistrer", onclick: function () {
          api("/sites/" + site.id, { method: "PATCH", body: {
            name: f.name.value, title: f.title.value, color: f.color.value, greeting: f.greeting.value,
            origins: f.origins.value.split(/\s+/).filter(Boolean), ai_enabled: f.ai.checked, ai_prompt: f.prompt.value,
          } }).then(function () { toast("Réglages enregistrés"); return boot(true); }).catch(oops);
        } })),
      ));

      var newKey = h("input", { placeholder: "cle-courte (ex. bugs)", maxlength: "32" });
      var newName = h("input", { placeholder: "Nom affiché (ex. Signaler un bug)", maxlength: "60" });
      page.appendChild(h("section", { class: "card", style: "border-top-color:" + site.color },
        h("h2", { text: "Zones (services)" }),
        h("p", { class: "muted", text: "Le visiteur choisit la zone avant d'écrire. Les agents peuvent être limités à certaines zones (onglet Équipe)." }),
        h("table", {}, h("thead", {}, h("tr", {}, h("th", { text: "Nom" }), h("th", { text: "Clé" }), h("th", { text: "" }))),
          h("tbody", {}, site.services.map(function (z) {
            var name = h("input", { value: z.name, maxlength: "60", "aria-label": "Nom de la zone " + z.key });
            return h("tr", {}, h("td", {}, name), h("td", {}, h("code", { text: z.key })), h("td", { style: "text-align:right;white-space:nowrap" },
              h("button", { class: "btn ghost sm", text: "Renommer", onclick: function () { api("/sites/" + site.id + "/services", { method: "PATCH", body: { id: z.id, name: name.value } }).then(function () { toast("Zone renommée"); boot(true); }).catch(oops); } }), " ",
              h("button", { class: "btn danger sm", text: "Supprimer", onclick: function () { if (confirm("Supprimer la zone « " + z.name + " » ?")) api("/sites/" + site.id + "/services", { method: "DELETE", body: { id: z.id } }).then(function () { toast("Zone supprimée"); boot(true); }).catch(oops); } })));
          }))),
        h("div", { class: "grid2" }, newKey, newName),
        h("div", { class: "row" }, h("button", { class: "btn ghost", text: "Ajouter la zone", onclick: function () {
          api("/sites/" + site.id + "/services", { method: "POST", body: { key: newKey.value, name: newName.value } }).then(function () { toast("Zone ajoutée"); boot(true); }).catch(oops);
        } })),
      ));

      var snippet = '<script src="' + location.origin + '/widget.js" data-site="' + site.id + '" async></script>';
      page.appendChild(h("section", { class: "card", style: "border-top-color:" + site.color },
        h("h2", { text: "Installer sur le site" }),
        h("p", { class: "muted", text: "Colle cette ligne avant </body>. Ajoute data-zone=\"cle\" pour ouvrir directement une zone, data-position=\"left\" pour placer la bulle à gauche." }),
        h("pre", { text: snippet }),
        h("div", { class: "row" }, h("button", { class: "btn ghost", text: "Copier", onclick: function () { navigator.clipboard.writeText(snippet).then(function () { toast("Copié"); }); } }))));
    }
    if (S.me.super) {
      var sid = h("input", { placeholder: "identifiant (ex. radio)", maxlength: "32" });
      var sname = h("input", { placeholder: "Nom (ex. Unclaim Radio)", maxlength: "60" });
      page.appendChild(h("section", { class: "card" },
        h("h2", { text: "Nouveau site" }),
        h("p", { class: "muted", text: "Chaque projet Unclaim peut avoir son chat, avec ses couleurs, ses zones et son équipe." }),
        h("div", { class: "grid2" }, sid, sname),
        h("div", { class: "row" }, h("button", { class: "btn", text: "Créer le site", onclick: function () {
          api("/sites", { method: "POST", body: { id: sid.value, name: sname.value } }).then(function (j) { S.settingsSite = j.site.id; toast("Site créé"); boot(true); }).catch(oops);
        } }),
          site ? h("button", { class: "btn danger", text: "Supprimer « " + site.name + " »", onclick: function () {
            if (confirm("Supprimer le site « " + site.name + " » et toutes ses conversations ? C'est définitif.")) api("/sites/" + site.id, { method: "DELETE" }).then(function () { S.settingsSite = null; toast("Site supprimé"); boot(true); }).catch(oops);
          } }) : null)));
    }
    shell(page);
  }

  // ---------- équipe ----------
  function renderTeam() {
    var list = adminSites();
    var site = pickSite(list);
    var page = h("main", { class: "page" });
    page.appendChild(h("div", { class: "row", style: "justify-content:space-between" }, h("h1", { text: "Équipe" }), siteSelector(list, renderTeam)));
    if (!site) return shell(page);
    var tbody = h("tbody", {}, h("tr", {}, h("td", { colspan: "4", class: "muted", text: "Chargement…" })));
    page.appendChild(h("section", { class: "card", style: "border-top-color:" + site.color },
      h("h2", { text: "Accès à « " + site.name + " »" }),
      h("p", { class: "muted", text: "Admin : réglages, zones, équipe et toutes les conversations du site. Agent : répond aux conversations de sa zone (ou de tout le site)." }),
      h("table", {}, h("thead", {}, h("tr", {}, h("th", { text: "Membre" }), h("th", { text: "Zone" }), h("th", { text: "Rôle" }), h("th", { text: "" }))), tbody)));
    api("/sites/" + site.id + "/members").then(function (j) {
      tbody.innerHTML = "";
      if (!j.members.length) tbody.appendChild(h("tr", {}, h("td", { colspan: "4", class: "muted", text: "Personne pour l'instant. Les super-admins ont accès à tout." })));
      j.members.forEach(function (m) {
        tbody.appendChild(h("tr", {},
          h("td", {}, h("div", { class: "row" }, avatar(m.avatar_url, m.name), h("div", {}, h("div", { text: m.name }), h("div", { class: "label", text: "Discord " + m.discord_id + (m.has_logged_in ? "" : " · jamais connecté") })))),
          h("td", { text: zoneLabel(site, m.service_id) }),
          h("td", {}, h("span", { class: "chip", text: m.role })),
          h("td", { style: "text-align:right" }, h("button", { class: "btn danger sm", text: "Retirer", onclick: function () {
            api("/sites/" + site.id + "/members", { method: "DELETE", body: { user_id: m.user_id, service_id: m.service_id } }).then(function () { toast("Accès retiré"); renderTeam(); }).catch(oops);
          } }))));
      });
    }).catch(oops);

    var did = h("input", { placeholder: "ID Discord (ex. 217839201847562240)", inputmode: "numeric", maxlength: "32" });
    var dname = h("input", { placeholder: "Nom (facultatif, mis à jour à sa connexion)", maxlength: "60" });
    var zone = h("select", { "aria-label": "Zone" }, h("option", { value: "0", text: "Tout le site" }), site.services.map(function (z) { return h("option", { value: String(z.id), text: z.name }); }));
    var role = h("select", { "aria-label": "Rôle" }, h("option", { value: "agent", text: "Agent" }), h("option", { value: "admin", text: "Admin (tout le site)" }));
    page.appendChild(h("section", { class: "card", style: "border-top-color:" + site.color },
      h("h2", { text: "Ajouter un membre" }),
      h("p", { class: "muted", text: "Dans Discord : Paramètres › Avancés › Mode développeur, puis clic droit sur le pseudo › Copier l'identifiant." }),
      h("div", { class: "grid2" }, did, dname),
      h("div", { class: "grid2" }, zone, role),
      h("div", { class: "row" }, h("button", { class: "btn", text: "Donner l'accès", onclick: function () {
        api("/sites/" + site.id + "/members", { method: "POST", body: { discord_id: did.value.trim(), name: dname.value.trim(), service_id: Number(zone.value), role: role.value } })
          .then(function () { toast("Accès donné"); renderTeam(); }).catch(oops);
      } }))));
    shell(page);
  }

  // ---------- démarrage ----------
  function boot(keepTab) {
    return api("/me").then(function (me) {
      S.me = me;
      if (!me.agent) return renderLogin("Ton compte (" + me.user.name + ") n'a encore accès à aucune zone. Demande à un admin de t'ajouter dans l'onglet Équipe.");
      if (!keepTab) S.tab = "inbox";
      route();
      if (!es) stream();
      return reload();
    }).catch(oops);
  }
  if ("Notification" in window && Notification.permission === "default") document.addEventListener("click", function once() { Notification.requestPermission(); document.removeEventListener("click", once); });
  boot();
})();
