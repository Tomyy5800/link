/*! Unclaim Chat — widget embarquable.
 * <script src="https://chat.unclaim.fr/widget.js" data-site="unclaim" async></script>
 * Options : data-zone="support" (zone ouverte par défaut), data-position="left".
 * API : window.UnclaimChat.open(zoneKey?), .close()
 */
(function () {
  "use strict";
  var script = document.currentScript || document.querySelector('script[src*="widget.js"][data-site]');
  if (!script || window.UnclaimChat) return;
  var BASE = new URL(script.src).origin;
  var SITE = script.getAttribute("data-site");
  var DEFAULT_ZONE = script.getAttribute("data-zone");
  var LEFT = script.getAttribute("data-position") === "left";
  var KEY = "unclaim-chat:" + SITE + ":token";

  var state = { config: null, token: load(), user: null, convs: [], conv: null, messages: [], open: false, view: "home", unread: 0, busy: false, error: "" };
  var es = null;

  function load() { try { return localStorage.getItem(KEY); } catch (e) { return null; } }
  function save(t) { try { t ? localStorage.setItem(KEY, t) : localStorage.removeItem(KEY); } catch (e) {} }

  function api(path, opts) {
    opts = opts || {};
    var sep = path.indexOf("?") < 0 ? "?" : "&";
    var headers = { "Content-Type": "application/json" };
    if (state.token) headers.Authorization = "Bearer " + state.token;
    return fetch(BASE + "/api/widget" + path + sep + "site=" + encodeURIComponent(SITE), {
      method: opts.method || "GET", headers: headers, body: opts.body ? JSON.stringify(opts.body) : undefined,
    }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (r.status === 401 && state.token) { logout(true); }
        if (!r.ok) throw new Error(j.error || "Erreur réseau");
        return j;
      });
    });
  }

  // ---------- rendu ----------
  var host = document.createElement("div");
  host.setAttribute("data-unclaim-chat", "");
  var root = host.attachShadow({ mode: "open" });
  var css =
    ":host{all:initial}*{box-sizing:border-box;margin:0;padding:0;font-family:Inter,ui-sans-serif,system-ui,-apple-system,'Segoe UI',sans-serif}" +
    ".launch{position:fixed;bottom:20px;" + (LEFT ? "left" : "right") + ":20px;z-index:2147483000;width:56px;height:56px;border:0;border-radius:6px;background:var(--c);color:var(--on);cursor:pointer;display:grid;place-items:center;box-shadow:0 10px 30px -10px rgba(0,0,0,.5);transition:transform .15s ease-out}" +
    ".launch:hover{transform:translateY(-2px)}.launch svg{width:26px;height:26px}" +
    ".badge{position:absolute;top:-8px;right:-8px;min-width:22px;height:22px;padding:0 5px;border-radius:3px;background:#ECEAE4;color:#0E0F12;font:600 12px/22px ui-monospace,Consolas,monospace;text-align:center}" +
    ".panel{position:fixed;bottom:16px;" + (LEFT ? "left" : "right") + ":16px;z-index:2147483000;width:min(380px,calc(100vw - 24px));height:min(600px,calc(100vh - 32px));display:flex;flex-direction:column;background:#0E0F12;color:#ECEAE4;border:1px solid #2A2D34;border-top:6px solid var(--c);border-radius:0 0 6px 6px;box-shadow:0 24px 60px -20px rgba(0,0,0,.7);overflow:hidden;font-size:14px;line-height:1.5}" +
    ".head{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:12px 14px;border-bottom:1px solid #2A2D34}" +
    ".title{font-weight:800;font-size:16px;letter-spacing:-.02em}.sub{display:flex;align-items:center;gap:6px;font-size:12px;color:#8A8C93}" +
    ".dot{width:8px;height:8px;background:var(--c);flex-shrink:0}" +
    ".icon{background:none;border:0;color:#8A8C93;cursor:pointer;padding:6px;border-radius:3px;display:grid;place-items:center}.icon:hover{color:#ECEAE4;background:#1C1E23}.icon svg{width:16px;height:16px}" +
    ".body{flex:1;overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:10px}" +
    ".bubble{max-width:85%;white-space:pre-wrap;word-wrap:break-word;padding:8px 11px;border-radius:3px;background:#1C1E23}" +
    ".me{align-self:flex-end;background:var(--c);color:var(--on)}.who{font:500 10.5px ui-monospace,Consolas,monospace;letter-spacing:.08em;text-transform:uppercase;color:#8A8C93;margin-bottom:3px}" +
    ".sys{align-self:center;text-align:center;font-size:12px;color:#8A8C93;max-width:92%}" +
    ".row{display:flex;flex-direction:column}.row.me-row{align-items:flex-end}" +
    ".btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;height:42px;padding:0 16px;border-radius:2px;border:1px solid var(--c);background:var(--c);color:var(--on);font-weight:600;font-size:14px;cursor:pointer}" +
    ".btn.ghost{background:transparent;color:#ECEAE4;border-color:#2A2D34}.btn.ghost:hover{border-color:#ECEAE4}.btn:disabled{opacity:.6;cursor:default}" +
    ".zone{display:flex;justify-content:space-between;align-items:center;width:100%;text-align:left;padding:12px 14px;border:1px solid #2A2D34;border-radius:3px;background:#1C1E23;color:#ECEAE4;cursor:pointer;font-size:14px}.zone:hover{border-color:#ECEAE4}" +
    ".tag{font:500 11px ui-monospace,Consolas,monospace;color:#8A8C93}.tag b{color:var(--c)}" +
    ".compose{display:flex;gap:8px;align-items:flex-end;padding:10px;border-top:1px solid #2A2D34}" +
    "textarea{flex:1;resize:none;max-height:110px;min-height:40px;background:#1C1E23;color:#ECEAE4;border:1px solid #2A2D34;border-radius:2px;padding:9px 10px;font-size:14px;line-height:1.4}textarea:focus{outline:none;border-color:#ECEAE4}" +
    ".send{width:40px;height:40px;border:0;border-radius:2px;background:var(--c);color:var(--on);cursor:pointer;display:grid;place-items:center}.send:disabled{opacity:.5}.send svg{width:16px;height:16px}" +
    ".human{border:0;border-top:1px solid #2A2D34;background:none;color:#8A8C93;font-size:12px;padding:8px;cursor:pointer}.human:hover{color:#ECEAE4}" +
    ".foot{display:flex;justify-content:space-between;padding:6px 12px 8px;font-size:11px;color:#8A8C93}.foot a,.foot button{color:#8A8C93;background:none;border:0;font-size:11px;cursor:pointer;text-decoration:underline}" +
    ".err{color:#F04438;font-size:13px}.muted{color:#8A8C93}" +
    ":focus-visible{outline:2px solid var(--c);outline-offset:2px}";

  var ICON_CHAT = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="square"><path d="M4 4h16v12H9l-5 4z"/></svg>';
  var ICON_X = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 6l12 12M18 6L6 18"/></svg>';
  var ICON_BACK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 6l-6 6 6 6"/></svg>';
  var ICON_SEND = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="square"><path d="M4 12h14M13 6l6 6-6 6"/></svg>';

  function el(tag, attrs, kids) {
    var n = document.createElement(tag);
    for (var k in attrs || {}) {
      if (k === "text") n.textContent = attrs[k];
      else if (k === "html") n.innerHTML = attrs[k]; // icônes internes uniquement, jamais de contenu utilisateur
      else if (k.slice(0, 2) === "on") n.addEventListener(k.slice(2), attrs[k]);
      else n.setAttribute(k, attrs[k]);
    }
    (kids || []).forEach(function (c) { if (c) n.appendChild(c); });
    return n;
  }

  function onColor(hex) {
    var c = hex.replace("#", ""); var r = parseInt(c.substr(0, 2), 16) / 255, g = parseInt(c.substr(2, 2), 16) / 255, b = parseInt(c.substr(4, 2), 16) / 255;
    var L = function (v) { return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
    return 0.2126 * L(r) + 0.7152 * L(g) + 0.0722 * L(b) > 0.18 ? "#0E0F12" : "#FFFFFF";
  }

  function render() {
    root.innerHTML = "";
    root.appendChild(el("style", { text: css }));
    var color = state.config.site.color;
    host.style.setProperty("--c", color);
    host.style.setProperty("--on", onColor(color));
    if (!state.open) {
      var b = el("button", { class: "launch", "aria-label": "Ouvrir le chat " + state.config.site.title, html: ICON_CHAT, onclick: function () { openChat(); } });
      if (state.unread > 0) b.appendChild(el("span", { class: "badge", text: String(state.unread) }));
      root.appendChild(b);
      return;
    }
    var site = state.config.site;
    var multi = state.config.services.length > 1;
    var back = state.view === "conv" && multi
      ? el("button", { class: "icon", "aria-label": "Retour aux sujets", html: ICON_BACK, onclick: function () { state.view = "home"; state.conv = null; refreshMe(); } })
      : null;
    var head = el("div", { class: "head" }, [
      el("div", { style: "display:flex;align-items:center;gap:6px;min-width:0" }, [back, el("div", {}, [
        el("div", { class: "title", text: state.view === "conv" && state.conv ? site.title + " · " + zoneName(state.conv.service_id) : site.title }),
        el("div", { class: "sub" }, [el("span", { class: "dot" }), el("span", { text: state.conv && state.conv.mode === "ai" ? "Assistant IA, l'équipe en renfort" : "L'équipe répond en général dans la journée" })]),
      ])]),
      el("button", { class: "icon", "aria-label": "Fermer le chat", html: ICON_X, onclick: function () { state.open = false; render(); } }),
    ]);
    var panel = el("div", { class: "panel", role: "dialog", "aria-label": site.title }, [head]);
    var body = el("div", { class: "body", "aria-live": "polite" });
    panel.appendChild(body);

    if (!state.token) {
      body.appendChild(el("div", { class: "bubble", text: site.greeting }));
      body.appendChild(el("p", { class: "muted", text: "Connecte-toi avec ton compte Unclaim (Discord) pour écrire à l'équipe : on pourra te répondre et tu retrouveras la conversation." }));
      body.appendChild(el("button", { class: "btn", text: "Se connecter avec Unclaim", onclick: login }));
    } else if (state.view === "home") {
      body.appendChild(el("div", { class: "bubble", text: site.greeting }));
      body.appendChild(el("p", { class: "muted", text: "Choisis le sujet :" }));
      state.config.services.forEach(function (s) {
        var open = state.convs.filter(function (c) { return c.service_id === s.id && c.status === "open"; })[0];
        var tag = open ? el("span", { class: "tag" }, [document.createTextNode(open.visitor_unread ? "" : "en cours"), open.visitor_unread ? el("b", { text: open.visitor_unread + " nouveau" + (open.visitor_unread > 1 ? "x" : "") }) : null]) : null;
        body.appendChild(el("button", { class: "zone", onclick: function () { openZone(s.id); } }, [el("span", { text: s.name }), tag]));
      });
    } else {
      state.messages.forEach(function (m) {
        if (m.author === "system") return body.appendChild(el("p", { class: "sys", text: m.body }));
        var mine = m.author === "visitor";
        var who = m.author === "ai" ? "Assistant IA" : m.author === "agent" ? (m.author_name || "Équipe") : null;
        body.appendChild(el("div", { class: "row" + (mine ? " me-row" : "") }, [
          who ? el("div", { class: "who", text: who }) : null,
          el("div", { class: "bubble" + (mine ? " me" : ""), text: m.body }),
        ]));
      });
      if (!state.messages.length) body.appendChild(el("div", { class: "bubble", text: site.greeting }));
    }
    if (state.error) body.appendChild(el("p", { class: "err", text: state.error }));

    if (state.token && state.view === "conv" && state.conv) {
      if (state.conv.mode === "ai") panel.appendChild(el("button", { class: "human", text: "Parler à un humain", onclick: toHuman }));
      var ta = el("textarea", { rows: "1", placeholder: "Ton message…", "aria-label": "Message", maxlength: "4000" });
      var sendBtn = el("button", { class: "send", "aria-label": "Envoyer", html: ICON_SEND });
      var submit = function () { var v = ta.value.trim(); if (v && !state.busy) { ta.value = ""; sendMessage(v); } };
      ta.addEventListener("keydown", function (e) { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submit(); } });
      sendBtn.addEventListener("click", submit);
      panel.appendChild(el("div", { class: "compose" }, [ta, sendBtn]));
      setTimeout(function () { ta.focus(); }, 0);
    }
    var foot = el("div", { class: "foot" }, [
      el("span", { text: "Unclaim Chat" }),
      state.token ? el("button", { text: "Se déconnecter", onclick: function () { logout(false); } }) : null,
    ]);
    panel.appendChild(foot);
    root.appendChild(panel);
    body.scrollTop = body.scrollHeight;
  }

  function zoneName(serviceId) {
    var s = state.config.services.filter(function (x) { return x.id === serviceId; })[0];
    return s ? s.name : "";
  }

  // ---------- actions ----------
  // Connexion par redirection : fonctionne aussi dans les navigateurs intégrés (Discord, TikTok…) sans pop-up.
  function login() {
    try { sessionStorage.setItem("unclaim-chat:reopen", "1"); } catch (e) {}
    location.href = BASE + "/auth/start?mode=widget&site=" + encodeURIComponent(SITE) +
      "&origin=" + encodeURIComponent(location.origin) +
      "&return=" + encodeURIComponent(location.origin + location.pathname + location.search);
  }

  // Retour de connexion : le jeton arrive dans le fragment #unclaim-chat=<site>.<jeton>, on le range et on l'efface.
  function takeTokenFromHash() {
    var m = location.hash.match(/(?:^#|&)unclaim-chat=([^&]+)/);
    if (!m) return false;
    var raw = decodeURIComponent(m[1]);
    var dot = raw.indexOf(".");
    if (raw.slice(0, dot) === SITE) { state.token = raw.slice(dot + 1); save(state.token); }
    history.replaceState(null, "", location.pathname + location.search);
    return true;
  }

  function logout(expired) {
    if (!expired && state.token) api("/logout", { method: "POST" }).catch(function () {});
    state.token = null; save(null); state.convs = []; state.conv = null; state.messages = []; state.view = "home"; state.unread = 0;
    if (es) { es.close(); es = null; }
    if (expired) state.error = "Ta session a expiré, reconnecte-toi.";
    render();
  }

  function refreshMe() {
    if (!state.token) return Promise.resolve();
    return api("/me").then(function (j) {
      state.user = j.user; state.convs = j.conversations;
      state.unread = j.conversations.reduce(function (n, c) { return n + c.visitor_unread; }, 0);
      render();
    }).catch(function () {});
  }

  function openChat(zoneKey) {
    state.open = true; state.error = "";
    if (state.token && (zoneKey || DEFAULT_ZONE || state.config.services.length === 1)) return openZone(null, zoneKey);
    render();
  }

  function openZone(serviceId, zoneKey) {
    var key = zoneKey || DEFAULT_ZONE;
    var service = serviceId
      ? { id: serviceId }
      : state.config.services.filter(function (s) { return s.key === key; })[0] || state.config.services[0];
    state.busy = true;
    return api("/conversations", { method: "POST", body: { service_id: service.id } })
      .then(function (j) { state.conv = j.conversation; state.view = "conv"; return loadMessages(); })
      .catch(function (e) { state.error = e.message; render(); })
      .then(function () { state.busy = false; });
  }

  function loadMessages() {
    return api("/conversations/" + state.conv.id + "/messages").then(function (j) {
      state.conv = j.conversation; state.messages = j.messages;
      render();
      return refreshMe(); // recompte les non-lus après lecture
    });
  }

  function sendMessage(v) {
    state.busy = true; state.error = "";
    api("/conversations/" + state.conv.id + "/messages", { method: "POST", body: { body: v } })
      .then(function (j) { if (!state.messages.some(function (m) { return m.id === j.message.id; })) state.messages.push(j.message); render(); })
      .catch(function (e) { state.error = e.message; render(); })
      .then(function () { state.busy = false; });
  }

  function toHuman() {
    api("/conversations/" + state.conv.id + "/human", { method: "POST" })
      .then(function (j) { state.conv = j.conversation; render(); })
      .catch(function (e) { state.error = e.message; render(); });
  }

  // ---------- temps réel ----------
  function stream() {
    if (!state.token || es || typeof EventSource === "undefined") return;
    es = new EventSource(BASE + "/api/widget/stream?site=" + encodeURIComponent(SITE) + "&token=" + encodeURIComponent(state.token));
    es.addEventListener("message", function (e) {
      var d = JSON.parse(e.data);
      var here = state.open && state.view === "conv" && state.conv && state.conv.id === d.conversation.id;
      if (here) {
        state.conv.mode = d.conversation.mode;
        if (!state.messages.some(function (m) { return m.id === d.message.id; })) state.messages.push(d.message);
        if (d.message.author !== "visitor") api("/conversations/" + state.conv.id + "/messages").catch(function () {}); // marque comme lu
      } else if (d.message.author === "agent" || d.message.author === "ai") {
        state.unread += 1;
      }
      render();
    });
    es.onerror = function () { if (es && es.readyState === 2) { es = null; setTimeout(stream, 5000); } };
  }

  // ---------- démarrage ----------
  fetch(BASE + "/api/widget/config?site=" + encodeURIComponent(SITE))
    .then(function (r) { if (!r.ok) throw new Error("config"); return r.json(); })
    .then(function (cfg) {
      state.config = cfg;
      var justLoggedIn = takeTokenFromHash();
      var reopen = false;
      try { reopen = sessionStorage.getItem("unclaim-chat:reopen") === "1"; sessionStorage.removeItem("unclaim-chat:reopen"); } catch (e) {}
      document.body.appendChild(host);
      render();
      if (state.token) refreshMe().then(function () { stream(); if (justLoggedIn || reopen) openChat(); });
    })
    .catch(function () { /* site non autorisé ou serveur injoignable : pas de bulle */ });

  window.UnclaimChat = {
    open: function (zoneKey) { if (state.config) openChat(zoneKey); },
    close: function () { state.open = false; if (state.config) render(); },
  };
})();
