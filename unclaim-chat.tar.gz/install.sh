#!/usr/bin/env bash
# Unclaim Chat — installation sur un serveur Debian / Ubuntu.
#
#   sudo ./install.sh              installe ou met à jour (garde la config et les données)
#   sudo ./install.sh --uninstall  retire le service (garde les données)
#   sudo ./install.sh --purge      retire le service ET supprime config + données
#
# Options : --port 4000   --yes (aucune question : utilise les variables d'environnement ci-dessous)
# Variables acceptées en mode --yes : PUBLIC_URL, UNCLAIM_CLIENT_ID, UNCLAIM_CLIENT_SECRET,
#   ADMIN_DISCORD_IDS, SEED_SITE_ORIGINS, AI_API_KEY, AI_BASE_URL, AI_MODEL
#
# Le nom de domaine (DNS) et le HTTPS ne sont pas gérés ici : voir les instructions affichées à la fin.
set -euo pipefail

APP_NAME="unclaim-chat"
APP_DIR="/opt/${APP_NAME}"
DATA_DIR="/var/lib/${APP_NAME}"
CONF_DIR="/etc/${APP_NAME}"
ENV_FILE="${CONF_DIR}/env"
SERVICE_USER="${APP_NAME}"
UNIT="/etc/systemd/system/${APP_NAME}.service"
NODE_MIN="22.13.0"
PORT="4000"
MODE="install"
ASSUME_YES=0
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

c_ok=$'\e[32m'; c_warn=$'\e[33m'; c_err=$'\e[31m'; c_dim=$'\e[2m'; c_off=$'\e[0m'
step() { printf '\n%s==>%s %s\n' "$c_ok" "$c_off" "$*"; }
warn() { printf '%s!%s %s\n' "$c_warn" "$c_off" "$*"; }
die()  { printf '%sErreur :%s %s\n' "$c_err" "$c_off" "$*" >&2; exit 1; }

while [ $# -gt 0 ]; do
  case "$1" in
    --port) PORT="${2:?--port attend un numéro}"; shift 2 ;;
    --yes|-y) ASSUME_YES=1; shift ;;
    --uninstall) MODE="uninstall"; shift ;;
    --purge) MODE="purge"; shift ;;
    -h|--help) sed -n '2,13p' "$0"; exit 0 ;;
    *) die "option inconnue : $1 (voir --help)" ;;
  esac
done

[ "$(id -u)" -eq 0 ] || die "lance ce script avec sudo."
command -v systemctl >/dev/null || die "systemd est requis."
[[ "$PORT" =~ ^[0-9]{2,5}$ ]] || die "port invalide : $PORT"

# ---------- désinstallation ----------
if [ "$MODE" != "install" ]; then
  step "Arrêt et retrait du service"
  systemctl disable --now "$APP_NAME" 2>/dev/null || true
  rm -f "$UNIT"
  systemctl daemon-reload
  rm -rf "$APP_DIR"
  if [ "$MODE" = "purge" ]; then
    if [ "$ASSUME_YES" -ne 1 ]; then
      read -r -p "Supprimer définitivement la configuration et TOUTES les conversations ? Tape « oui » : " ans
      [ "$ans" = "oui" ] || die "annulé, rien n'a été supprimé en dehors du service."
    fi
    rm -rf "$DATA_DIR" "$CONF_DIR"
    userdel "$SERVICE_USER" 2>/dev/null || true
    echo "Unclaim Chat a été entièrement supprimé."
  else
    echo "Service retiré. Données gardées dans $DATA_DIR, configuration dans $CONF_DIR."
  fi
  exit 0
fi

# ---------- vérifications ----------
for f in server.mjs package.json lib/db.mjs public/widget.js public/console/index.html; do
  [ -f "$SRC_DIR/$f" ] || die "fichier manquant : $f. Lance le script depuis le dossier décompressé d'Unclaim Chat."
done
command -v apt-get >/dev/null || die "ce script vise Debian / Ubuntu (apt). Ailleurs, voir le README (Docker)."

version_ge() { [ "$(printf '%s\n%s\n' "$2" "$1" | sort -V | head -n1)" = "$2" ]; }

# ---------- Node.js ----------
step "Node.js ${NODE_MIN} ou plus"
NODE_OK=0
if command -v node >/dev/null; then
  current="$(node -v | sed 's/^v//')"
  if version_ge "$current" "$NODE_MIN"; then NODE_OK=1; echo "Node $current déjà présent."; fi
fi
if [ "$NODE_OK" -eq 0 ]; then
  echo "Installation de Node.js 22 (dépôt officiel NodeSource)…"
  apt-get update -qq
  apt-get install -y -qq ca-certificates curl gnupg >/dev/null
  install -d -m 0755 /etc/apt/keyrings
  curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | gpg --dearmor --yes -o /etc/apt/keyrings/nodesource.gpg
  echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_22.x nodistro main" > /etc/apt/sources.list.d/nodesource.list
  apt-get update -qq
  apt-get install -y -qq nodejs >/dev/null
  version_ge "$(node -v | sed 's/^v//')" "$NODE_MIN" || die "Node installé trop ancien : $(node -v)"
  echo "Node $(node -v) installé."
fi
NODE_BIN="$(command -v node)"
command -v curl >/dev/null || apt-get install -y -qq curl >/dev/null

# ---------- utilisateur et dossiers ----------
step "Utilisateur système et dossiers"
id "$SERVICE_USER" >/dev/null 2>&1 || useradd --system --home-dir "$DATA_DIR" --shell /usr/sbin/nologin "$SERVICE_USER"
install -d -m 0750 -o "$SERVICE_USER" -g "$SERVICE_USER" "$DATA_DIR"
install -d -m 0750 -o root -g "$SERVICE_USER" "$CONF_DIR"
echo "Données : $DATA_DIR · configuration : $ENV_FILE"

# ---------- fichiers de l'application ----------
step "Copie des fichiers dans $APP_DIR"
if [ -f "$DATA_DIR/chat.db" ]; then
  backup="$DATA_DIR/chat.db.$(date +%Y%m%d-%H%M%S).bak"
  systemctl stop "$APP_NAME" 2>/dev/null || true
  cp -p "$DATA_DIR/chat.db" "$backup"
  echo "Sauvegarde de la base avant mise à jour : $backup"
fi
rm -rf "${APP_DIR}.new"
install -d -m 0755 "${APP_DIR}.new"
cp -r "$SRC_DIR/server.mjs" "$SRC_DIR/package.json" "$SRC_DIR/lib" "$SRC_DIR/public" "${APP_DIR}.new/"
[ -f "$SRC_DIR/README.md" ] && cp "$SRC_DIR/README.md" "${APP_DIR}.new/"
chown -R root:root "${APP_DIR}.new"
chmod -R a+rX,go-w "${APP_DIR}.new"
rm -rf "$APP_DIR"
mv "${APP_DIR}.new" "$APP_DIR"

# ---------- configuration ----------
ask() { # ask VAR "Question" "défaut" [secret]
  local var="$1" q="$2" def="${3:-}" secret="${4:-}" val="${!1:-}"
  if [ "$ASSUME_YES" -eq 1 ]; then printf -v "$var" '%s' "${val:-$def}"; return; fi
  local prompt="$q"; [ -n "$def" ] && prompt="$q [$def]"
  if [ -n "$secret" ]; then read -r -s -p "$prompt : " val; echo; else read -r -p "$prompt : " val; fi
  printf -v "$var" '%s' "${val:-$def}"
}
env_line() { printf '%s=%s\n' "$1" "$2"; }

if [ -f "$ENV_FILE" ]; then
  step "Configuration existante conservée ($ENV_FILE)"
  echo "Pour la modifier : sudo nano $ENV_FILE, puis sudo systemctl restart $APP_NAME"
  if grep -q '^PORT=' "$ENV_FILE"; then PORT="$(grep '^PORT=' "$ENV_FILE" | cut -d= -f2)"; fi
else
  step "Configuration"
  echo "${c_dim}Déclare d'abord l'application sur https://auth.unclaim.fr :"
  echo "  autorisations identify + email, URL de retour <adresse publique>/auth/callback${c_off}"
  ask PUBLIC_URL "Adresse publique du chat (sans / final)" "https://chat.unclaim.fr"
  PUBLIC_URL="${PUBLIC_URL%/}"
  [[ "$PUBLIC_URL" =~ ^https?://[^/]+$ ]] || die "adresse publique invalide : $PUBLIC_URL"
  ask UNCLAIM_CLIENT_ID "Unclaim Auth : client_id" ""
  ask UNCLAIM_CLIENT_SECRET "Unclaim Auth : client_secret (caché)" "" secret
  ask ADMIN_DISCORD_IDS "Ton ID Discord (super-admin ; plusieurs : séparés par des virgules)" ""
  ask SEED_SITE_ORIGINS "Domaines du site « unclaim » autorisés à afficher la bulle" "https://unclaim.fr,https://www.unclaim.fr"
  ask AI_API_KEY "Clé API de l'assistant IA (facultatif, Entrée pour passer)" "" secret
  AI_BASE_URL="${AI_BASE_URL:-https://api.openai.com/v1}"
  AI_MODEL="${AI_MODEL:-gpt-4o-mini}"
  [ -n "$UNCLAIM_CLIENT_ID" ] && [ -n "$UNCLAIM_CLIENT_SECRET" ] || warn "Unclaim Auth n'est pas renseigné : personne ne pourra se connecter tant que $ENV_FILE n'est pas complété."
  [ -n "$ADMIN_DISCORD_IDS" ] || warn "Aucun super-admin : ajoute ton ID Discord dans $ENV_FILE (ADMIN_DISCORD_IDS)."

  umask 077
  {
    echo "# Unclaim Chat — configuration (générée par install.sh le $(date '+%d/%m/%Y %H:%M'))"
    env_line NODE_ENV production
    env_line PORT "$PORT"
    env_line DATA_DIR "$DATA_DIR"
    env_line PUBLIC_URL "$PUBLIC_URL"
    env_line UNCLAIM_API_URL "https://auth.unclaim.fr"
    env_line UNCLAIM_CLIENT_ID "$UNCLAIM_CLIENT_ID"
    env_line UNCLAIM_CLIENT_SECRET "$UNCLAIM_CLIENT_SECRET"
    env_line ADMIN_DISCORD_IDS "$ADMIN_DISCORD_IDS"
    env_line SEED_SITE_ORIGINS "$SEED_SITE_ORIGINS"
    env_line AI_API_KEY "$AI_API_KEY"
    env_line AI_BASE_URL "$AI_BASE_URL"
    env_line AI_MODEL "$AI_MODEL"
  } > "$ENV_FILE"
  umask 022
  chown root:"$SERVICE_USER" "$ENV_FILE"
  chmod 0640 "$ENV_FILE"
  echo "Configuration écrite dans $ENV_FILE (lisible seulement par root et le service)."
fi

# ---------- service systemd ----------
step "Service systemd"
cat > "$UNIT" <<EOF
[Unit]
Description=Unclaim Chat (chat de support multi-sites)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${SERVICE_USER}
Group=${SERVICE_USER}
WorkingDirectory=${APP_DIR}
EnvironmentFile=${ENV_FILE}
ExecStart=${NODE_BIN} ${APP_DIR}/server.mjs
Restart=on-failure
RestartSec=3
# Durcissement : le service ne peut écrire que dans son dossier de données.
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
PrivateDevices=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictSUIDSGID=true
LockPersonality=true
ReadWritePaths=${DATA_DIR}

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable "$APP_NAME" >/dev/null 2>&1
systemctl restart "$APP_NAME"

# ---------- vérification ----------
step "Vérification"
ok=0
for _ in $(seq 1 20); do
  if curl -fsS "http://127.0.0.1:${PORT}/health" >/dev/null 2>&1; then ok=1; break; fi
  sleep 1
done
if [ "$ok" -ne 1 ]; then
  journalctl -u "$APP_NAME" -n 30 --no-pager || true
  die "le service ne répond pas sur le port ${PORT}. Journal ci-dessus."
fi
echo "Unclaim Chat répond sur http://127.0.0.1:${PORT} ✓"

PUBLIC_URL_SHOWN="$(grep '^PUBLIC_URL=' "$ENV_FILE" | cut -d= -f2)"
cat <<EOF

${c_ok}Installation terminée.${c_off}

Reste à faire (hors de ce script) :
  1. DNS : fais pointer le domaine de ${PUBLIC_URL_SHOWN} vers ce serveur.
  2. HTTPS : place un proxy devant le port ${PORT}. Avec Caddy :
       ${PUBLIC_URL_SHOWN#https://} {
         reverse_proxy 127.0.0.1:${PORT} {
           flush_interval -1    # indispensable pour le temps réel
         }
       }
     (Nginx : proxy_buffering off; proxy_read_timeout 1h; pour /api/*/stream)
  3. Unclaim Auth : URL de retour ${PUBLIC_URL_SHOWN}/auth/callback
  4. Ouvre ${PUBLIC_URL_SHOWN}/console et connecte-toi.

Commandes utiles :
  sudo systemctl status ${APP_NAME}       état du service
  sudo journalctl -u ${APP_NAME} -f       journal en direct
  sudo nano ${ENV_FILE}                   modifier la configuration (puis restart)
  sudo ./install.sh                       mettre à jour avec une nouvelle version
EOF
