# Link by Unclaim — feuille de route

Mise à jour : 17 octobre 2026. Le tableau de bord `/admin` reprend la partie « Avant la mise en ligne » sous forme de
liste de contrôle (« Prêt pour la mise en ligne »).

## Où on en est

- **Pages de profil** : 22 blocs (dont radio en direct, agenda, anniversaire, dossiers de liens), thèmes, grille modulable sur ordinateur, style par bloc, effets, musique et vidéo,
  CSS personnalisé, intégrations libres et widgets HTML, statistiques avec sources et appareils.
- **Connexion** : tous les fournisseurs d'Unclaim Auth (Discord, Google, Microsoft, Apple, Twitch, NationsGlory), sans
  écran intermédiaire. Discord n'est plus obligatoire : les blocs Discord demandent simplement un compte Discord rattaché.
  Une connexion NationsGlory prouve le pseudo et affiche le badge « compte vérifié » à côté du pseudo NationsGlory.
- **Link+** : fonctions payantes réglables depuis l'administration (gratuit / payant / coupé), limites par offre, codes,
  page des tarifs `/plus`, abonnements Stripe (mensuels, annuels, résiliables en ligne), changement de formule au prorata,
  remboursement. Badges officiels, page staff, rôles Discord, boutique officielle, domaines personnels, rôles personnalisés
  (configuration externe : [CONFIGURATION.md](CONFIGURATION.md)).
- **Mon espace** : vue d'ensemble de toutes les pages, messages, compte et données (appareils, export, suppression du
  compte), offre, partenariat. **Plusieurs pages par compte** et **équipes** (éditeurs, lecteurs, invitations par lien).
- **CGU** : page `/cgu`, acceptation obligatoire à la première connexion et à chaque nouvelle version.
- **Partenaires** : candidature, examen dans `/admin/partners`, badge, Link+ inclus, limites dédiées, annuaire `/partenaires`.
- **Jeux** : bloc « Profil de jeu » (Minecraft, Chess.com, Lichess, Steam, Roblox en direct ; Paladium, Wolfy, Hypixel,
  Valorant, LoL, Fortnite… en carte manuelle). **Formulaire de contact** avec boîte de réception.
- **Assistant de création** : la page se construit en discutant (Claude si `ANTHROPIC_API_KEY` est renseignée, sinon
  un assistant guidé en cinq questions), aperçu en direct, création en un clic, écran de bienvenue.
- **Automatisations** : bandeaux, mise en avant, masquage et thème selon un créneau hebdomadaire, des dates, les lives
  (statut Discord « en stream ») ou l'anniversaire. **Notifications Discord** (messages, bilan hebdomadaire), **polices
  Google Fonts**, **kit de marque**, **duplication de page**, **palette de commandes** (Ctrl+K).
- **Formules** : Gratuit, Link+, Pro, Équipe, avec conversion du temps restant (voir [TARIFS.md](TARIFS.md)).
- **Prise en main** : 5 modèles de départ (joueur NationsGlory, streamer, créateur, minimal), liste « Premiers pas »
  dans l'éditeur, export de toutes ses données (JSON) depuis les réglages.
- **Finitions** : accueil refait (fournisseurs de connexion réels, modèles, questions fréquentes), pages d'erreur et de
  chargement, plan du site, `robots.txt`, manifeste d'application, image d'aperçu pour les réseaux, lien d'évitement et
  focus clavier visibles.
- **Administration** : vue d'ensemble, comptes, pages, signalements, ventes, tarifs et vente, fonctionnalités, codes,
  journal.
- **Légal** : CGV, mentions légales et politique de confidentialité générées à partir des informations saisies dans
  l'administration (modèles à faire relire).

## Avant la mise en ligne

1. **Hébergement** : un serveur (VPS) avec Docker, un nom de domaine et un proxy https (Caddy le fait tout seul).
   `docker compose up -d --build` avec un `.env.production` complet. Prévoir une sauvegarde quotidienne du volume `/data`
   (base SQLite et fichiers importés).
2. **Unclaim Auth** : déclarer `https://<domaine>/api/auth/callback` dans le site Link by Unclaim de la passerelle,
   choisir les fournisseurs autorisés pour ce site, puis renseigner `UNCLAIM_*`. Couper `UNCLAIM_AUTH_DEV_LOGIN`.
3. **Administrateur** : `ADMIN_UNCLAIM_IDS` avec ton ID `uncl_…` (visible dans le portail de la passerelle).
4. **NationsGlory** : dès que la clé est disponible, `NATIONSGLORY_API_KEY`, `NATIONSGLORY_MOCK="false"`, déclarer l'IP
   du serveur dans la clé, puis « Vider le cache NationsGlory » dans `/admin`.
5. **Vente** :
   - statut de vendeur (la micro-entreprise suffit pour démarrer) et numéro SIRET ;
   - compte Stripe vérifié, clés `sk_test_…` pour essayer de bout en bout (carte 4242 4242 4242 4242), puis `sk_live_…` ;
   - webhook `https://<domaine>/api/webhooks/stripe` (événements listés dans `/admin/pricing`) et `STRIPE_WEBHOOK_SECRET` ;
   - adhésion à un médiateur de la consommation (obligatoire pour vendre à des particuliers) ;
   - remplir « Informations légales » dans `/admin/pricing` et **faire relire les CGV** : ce sont des modèles, pas un
     avis juridique.
6. **Annonce** : un message dans l'éditeur (`/admin/settings`) et un post Discord avec le lien de la page des tarifs.

## Formules et tarifs

Quatre formules (Gratuit, Link+, Link+ Pro, Link+ Équipe), vendues par abonnement sans engagement. Le détail, le
raisonnement des prix et les pistes si la vente démarre lentement sont dans **[TARIFS.md](TARIFS.md)**.

**Frais de paiement** (Stripe, cartes européennes, environ 1,5 % + 0,25 € par paiement, à vérifier sur stripe.com) :
les petits montants coûtent proportionnellement cher, c'est pour ça que les offres annuelles sont mises en avant.

**TVA** : en franchise (micro-entreprise sous les seuils), les prix sont nets et la mention « TVA non applicable, art.
293 B du CGI » figure dans les CGV. Au-delà, les prix affichés restent TTC et la TVA s'applique ; pour des ventes à des
particuliers d'autres pays de l'UE au-delà de 10 000 € par an, la TVA du pays de l'acheteur s'applique (guichet OSS).

## Prochaines étapes

**Court terme**

- Reçus par e-mail : activer les reçus automatiques de Stripe (aucun code à écrire).
- Factures à la demande : numérotation et PDF depuis `/admin/sales`.
- « Mes achats » dans les réglages de l'éditeur, avec les codes cadeaux déjà achetés.
- Explorer : un annuaire des pages mises en avant, filtrable par serveur et par pays NationsGlory.
- Réponse aux messages de contact depuis « Mon espace » (e-mail transactionnel).
- Automatisations : déclencheur « nouveau palier de vues » et action « redirection temporaire ».
- Assistant : modification d'une page existante en discutant (« ajoute mon TikTok », « passe en thème sombre »).
- Paladium : brancher l'API officielle (`api.paladium.games`) dès qu'une clé d'application est obtenue auprès de
  l'équipe Paladium ; même démarche pour Wolfy si une API publique ouvre. Hypixel (clé gratuite), Riot (Valorant, LoL),
  Supercell (Brawl Stars, Clash Royale) et osu! demandent aussi une clé : à ajouter en mode « live » une par une.

**Moyen terme**

- Pages de pays NationsGlory (une page partagée par les membres d'un même pays, gérée par son chef).
- Domaine personnalisé pour une page (fonction Link+).
- Notifications de modération sur Discord (nouveau signalement, achat, remboursement).
- Passerelle : un écran de choix du fournisseur directement dans Unclaim Auth, pour que Link n'affiche plus jamais le
  sien quand plusieurs moyens de connexion sont ouverts.

**Montée en charge**

- PostgreSQL à la place de SQLite, stockage objet (S3 compatible) pour les fichiers, Redis pour les limites de débit
  partagées entre plusieurs instances.
- Supervision : `/api/health` surveillé, alertes sur les erreurs de paiement et les échecs de l'API NationsGlory.
