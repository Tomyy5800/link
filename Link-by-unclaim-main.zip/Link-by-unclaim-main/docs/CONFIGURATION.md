# Configuration externe

Ce qui ne se règle pas dans le code : comptes chez Stripe et Discord, DNS, proxy inverse. Tant
qu'une étape manque, la fonction correspondante reste **inactive** et l'administration le dit
(rien n'est simulé : pas de faux paiement, pas de fausse synchronisation, pas de domaine
« actif » sans vérification).

Variables d'environnement : voir `.env.example` (toutes commentées). Après une modification du
`.env`, redémarrer le serveur.

## 1. Fondateurs et administrateurs

| Variable | Rôle |
| --- | --- |
| `FOUNDER_UNCLAIM_IDS` / `FOUNDER_DISCORD_IDS` | Fondateurs : toutes les permissions, badge « Fondateur », seuls à nommer des administrateurs et à leur donner des permissions sensibles. |
| `ADMIN_UNCLAIM_IDS` / `ADMIN_DISCORD_IDS` | Administrateurs d'office. Sans fondateur déclaré, ils ont le niveau fondateur. |

Ton ID Unclaim (`uncl_…`) s'affiche dans Mon espace › Compte. Personne ne peut devenir fondateur
depuis le site : le niveau ne vient que de ces variables.

Permissions sensibles (accordées par un fondateur dans `/admin/staff`) :

- **Valider les badges** : poser ou retirer le sceau officiel ;
- **Badges du staff** : attribuer les badges Administrateur, Développeur, Modérateur, Staff officiel ;
- **Synchronisation Discord** : configurer le serveur officiel et les rôles ;
- **Réglages sensibles** : boutiques personnelles, accès offert à tous, boutique officielle.

## 2. Stripe (abonnements et boutique officielle)

1. Compte sur stripe.com (identité et RIB du vendeur), puis **Développeurs › Clés API** : copier la
   clé secrète dans `STRIPE_SECRET_KEY` (`sk_test_…` pour tester, `sk_live_…` pour vendre).
2. **Développeurs › Webhooks › Ajouter un point de terminaison** :
   `https://<ton-domaine>/api/webhooks/stripe`, avec les événements :
   - `checkout.session.completed`, `checkout.session.async_payment_succeeded`,
     `checkout.session.async_payment_failed`, `checkout.session.expired`
   - `customer.subscription.created`, `customer.subscription.updated`, `customer.subscription.deleted`
   - `invoice.paid`, `invoice.payment_failed`
   - `charge.refunded`

   Copier le secret de signature dans `STRIPE_WEBHOOK_SECRET`. Indispensable en production : sans
   lui, les renouvellements, échecs de paiement et résiliations ne sont pas vus.
3. **Paramètres › Facturation › Portail client** : activer le portail (mise à jour de la carte,
   factures) et enregistrer. Le bouton « Carte et factures » de Mon espace › Offre l'ouvre.
4. Compléter les informations légales dans `/admin/pricing` et faire relire les CGV.

Fonctionnement : chaque événement reçu est authentifié (signature HMAC, moins de 5 minutes), puis
l'abonnement est **relu dans l'API Stripe** (version figée `2024-06-20`) avant de modifier les droits
du compte. Un abonnement n'est rattaché qu'au compte dont il porte le client Stripe. La formule reste
active jusqu'à la fin de la période payée, plus 3 jours de grâce si un prélèvement échoue.

Tester en local : avec une clé `sk_test_…`, la souscription est confirmée au retour sur
`/plus/merci` (lecture de la session) ; pour les renouvellements, utiliser la Stripe CLI
(`stripe listen --forward-to localhost:3000/api/webhooks/stripe`).

## 3. Synchronisation des rôles Discord

1. https://discord.com/developers/applications › **New Application**, puis onglet **Bot** :
   copier le jeton dans `DISCORD_BOT_TOKEN` (secret, jamais envoyé au navigateur).
2. Onglet **Bot** › activer **Server Members Intent** (lecture de tous les membres d'un coup ;
   sans elle, les comptes sont lus un par un, 300 au plus par passage).
3. **OAuth2 › URL Generator** : portée `bot`, aucune permission ; ouvrir l'URL et inviter le bot sur
   le serveur officiel.
4. Redémarrer, puis `/admin/discord` : identifiant du serveur (clic droit sur le serveur ›
   Copier l'identifiant, mode développeur activé), **Tester et lire les rôles**, associer chaque rôle
   à un badge (Administrateur, Développeur, Modérateur, Staff officiel…), choisir s'il est retiré
   quand le rôle est perdu, activer la synchronisation automatique.

Sécurité : un compte Link n'est relié qu'au compte Discord prouvé par sa connexion Unclaim Auth
(OAuth Discord dans la passerelle). La synchronisation passe à chaque connexion et à l'intervalle
choisi ; elle ne retire jamais un badge donné à la main ou acheté.

## 4. Domaines personnels (Pro et Équipe)

Le site doit être derrière un **proxy inverse** qui accepte n'importe quel nom d'hôte et émet les
certificats HTTPS à la demande. Exemple avec Caddy (recommandé) :

```caddyfile
{
	on_demand_tls {
		ask http://127.0.0.1:3000/api/domains/tls-check
	}
}

link.unclaim.fr {
	reverse_proxy 127.0.0.1:3000
}

# Domaines des clients : certificat émis seulement si /api/domains/tls-check répond 200
# (propriété du domaine prouvée par son enregistrement TXT).
https:// {
	tls {
		on_demand
	}
	reverse_proxy 127.0.0.1:3000
}
```

Puis dans `.env` :

- `CUSTOM_DOMAIN_CNAME` : nom d'hôte que les sous-domaines des clients viseront en CNAME
  (par exemple `domaines.link.unclaim.fr`, lui-même un enregistrement A vers le serveur) ;
- `CUSTOM_DOMAIN_IPV4` : IPv4 publique(s) du serveur, pour les domaines racines (enregistrement A).

Tant que les deux sont vides, le routage des domaines est désactivé (le site se comporte comme
avant) et l'éditeur prévient que la vérification ne peut pas aboutir.

Ce que fait le client (affiché dans l'éditeur, Réglages › Domaine personnel) :

| Type | Nom | Valeur |
| --- | --- | --- |
| TXT | `_link-unclaim.mondomaine.fr` | jeton propre au domaine (preuve de propriété) |
| CNAME | `www.mondomaine.fr` | valeur de `CUSTOM_DOMAIN_CNAME` |
| A | `mondomaine.fr` | valeur(s) de `CUSTOM_DOMAIN_IPV4` |

Le domaine devient **actif** seulement quand les trois contrôles du serveur réussissent : TXT trouvé,
domaine qui pointe vers la cible, et requête `https://<domaine>/api/domains/probe` arrivée sur cette
application (signature propre au serveur). Les domaines actifs sont revérifiés chaque jour ; un
domaine dont le propriétaire perd sa formule n'affiche plus la page.

Pterodactyl : l'egg Node.js n'expose qu'un port ; le proxy (Caddy) tourne en dehors du conteneur,
sur la machine hôte ou un autre serveur, et transmet vers ce port.

## 5. Boutiques personnelles des profils

Fermées par défaut. `/admin/settings` › Fonctionnalités sensibles › **Boutiques personnelles des
profils** (confirmation, historique). Fermées : aucune boutique visible, aucune commande acceptée
(l'API refuse), le bloc ne peut plus être ajouté ; les boutiques et commandes existantes sont
conservées. Link by Unclaim n'encaisse rien pour les vendeurs : avant d'ouvrir, vérifier que les
CGU couvrent ces ventes entre utilisateurs.

## 6. Tâches périodiques

Pas de planificateur à installer : après une requête (page publique, espace, administration), le
serveur lance au plus toutes les 5 minutes les tâches dues — badges arrivés à échéance, places
« premiers comptes » restantes, synchronisation Discord (selon l'intervalle choisi), revérification
des domaines. Un verrou en base empêche deux lancements simultanés.
