# Déployer Link by Unclaim sur Pterodactyl

Le site tourne avec l'egg **Node.js** générique (parkervcp), sans rien installer ni compiler sur le
serveur : on y dépose un paquet déjà construit.

## 1. Construire le paquet

```bash
npm run build:pterodactyl
```

Résultat : `deploy/link-by-unclaim-pterodactyl.zip` (`--x64` pour retirer les moteurs ARM64 et
alléger le paquet, si le serveur est en x86_64).

Le script copie le projet dans un dossier temporaire et y construit le site : un `npm start` lancé
dans le projet continue de tourner, et le `.env` local n'entre ni dans le build ni dans le paquet.
Rien n'y est figé au build (adresse du site, base) : tout est lu au démarrage du serveur.

Contenu de l'archive :

| Élément | Rôle |
| --- | --- |
| `start.js` | « Main file » de l'egg : lit `.env`, prépare `data/`, applique les migrations, lance le serveur |
| `app/` | serveur Next.js autonome, fichiers statiques, migrations, CLI et moteurs Prisma pour Linux |
| `.env.example` | modèle de configuration commenté |
| `LISEZMOI.txt` | mode d'emploi court |

Les moteurs Prisma inclus visent Debian 12 (OpenSSL 3) en x64 et ARM64 : ce sont les images
`ghcr.io/parkervcp/yolks:nodejs_*` de l'egg. Une image Alpine n'est pas prise en charge.

## 2. Créer le serveur

- **Egg** : Node.js. **Image** : Node.js 22 ou plus récente (Next.js 16 demande Node 20.9 au
  minimum, et Node 20 n'est plus maintenu).
- **Startup** : `Main file` = `start.js` ; `User Uploaded Files` = 1 ; `Auto Update` = 0 ;
  `Additional Node packages` vide.
- **Ressources** : 512 Mo de mémoire au minimum, 1 Go conseillé ; 1 Go de disque plus les fichiers
  importés. Une seule allocation (port) suffit.

L'egg lance `npm install` quand il trouve un `package.json` à la racine : le paquet n'en met pas,
et c'est voulu. Laisser `Additional Node packages` vide, sinon npm en créerait un.

## 3. Déposer et configurer

1. Gestionnaire de fichiers : envoyer l'archive à la racine, **Unarchive**, supprimer l'archive.
   (SFTP fonctionne aussi, notamment si l'hébergeur limite la taille des envois.)
2. Créer `.env` à partir de `.env.example` et remplir au minimum :
   - `APP_URL` : l'adresse publique **en HTTPS**, sans slash final ;
   - `UNCLAIM_API_URL`, `UNCLAIM_CLIENT_ID`, `UNCLAIM_CLIENT_SECRET` ;
   - `ADMIN_UNCLAIM_IDS` ou `ADMIN_DISCORD_IDS` pour le premier administrateur.
3. Dans la passerelle Unclaim Auth, déclarer l'adresse de retour `<APP_URL>/api/auth/callback`
   (`npm run site:add` dans unclaim-api, voir le README).

`SESSION_SECRET` peut rester vide : `start.js` en génère un et le garde dans `data/session-secret`.

## 4. Démarrer

Au démarrage, `start.js` :

1. vérifie la version de Node.js et l'image ;
2. lit `.env` ; les chemins relatifs (`./data/…`) partent du dossier de `start.js`, jamais de
   `app/` ;
3. crée `data/` : base `data/link.db`, fichiers importés `data/uploads/` (`UPLOADS_DRIVER=disk`
   par défaut) ;
4. si la nouvelle version apporte des migrations, copie d'abord la base dans `data/sauvegardes/`
   (les cinq dernières copies sont gardées), puis applique les migrations (`prisma migrate deploy`) ;
5. lance le serveur sur le port alloué (`SERVER_PORT`, toutes interfaces) et écrit
   `Link by Unclaim est en ligne : <APP_URL>` dès que `/api/health` répond.

L'egg générique attend un texte de démarrage factice : le panneau peut rester sur « Starting »
alors que le site répond. Un administrateur du panneau peut le corriger dans
*Admin › Nests › Node.js › Configuration › Start Configuration* : `{"done": "est en ligne"}`.

## 5. HTTPS et nom de domaine

Pterodactyl expose `http://IP:PORT`. En production, les cookies de connexion sont « Secure » : il
faut que les visiteurs arrivent en HTTPS. Trois façons de faire :

- **Proxy HTTPS sur la machine** (Nginx, Caddy, Nginx Proxy Manager) : `link.mondomaine.fr` vers
  `http://IP:PORT`, certificat Let's Encrypt.
- **Cloudflare** : enregistrement DNS proxifié vers l'IP du nœud, une *Origin Rule* qui réécrit
  le port de destination vers le port alloué, SSL en mode « Flexible ».
- **Tunnel Cloudflare** (`cloudflared`) vers `http://IP:PORT`, sans port public.

Dans tous les cas, `APP_URL` est l'adresse HTTPS finale.

## 6. Mettre à jour

1. `npm run build:pterodactyl` sur ta machine.
2. Sur le panneau : **Stop**, supprimer `app/`, `start.js` et `LISEZMOI.txt`.
3. Envoyer et décompresser la nouvelle archive, puis **Start**.

`data/` et `.env` ne sont jamais touchés. La version en ligne est écrite dans
`app/build-info.json`.

## 7. Sauvegarder

Sauvegarder `data/` (base, fichiers importés, secret) et `.env`. Les sauvegardes Pterodactyl du
serveur les incluent. Pour restaurer une copie de `data/sauvegardes/` : arrêter le serveur,
remplacer `data/link.db` par la copie, redémarrer.

## Dépannage

| Message ou symptôme | Cause et solution |
| --- | --- |
| « Node.js … est trop ancien » | Image Node.js 22 ou plus récente (onglet Startup › Docker Image). |
| « Image Alpine détectée » | Image Debian : `ghcr.io/parkervcp/yolks:nodejs_22`. |
| « Moteurs de base de données … absents » | Paquet construit avec `--x64` sur un serveur ARM : reconstruire sans l'option. |
| « libssl.so.3 » introuvable | Image trop ancienne (Debian 11) : prendre une image Node.js 22 récente. |
| Retour en boucle sur l'écran de connexion | Site ouvert en HTTP, ou `APP_URL` différente de l'adresse utilisée. |
| `redirect_uri` refusé par Unclaim Auth | `<APP_URL>/api/auth/callback` n'est pas déclarée pour le site. |
| « Les migrations de la base ont échoué » | Lire le message de Prisma au-dessus ; la base d'avant est dans `data/sauvegardes/`. |
| Données NationsGlory vides | Pas de clé `NATIONSGLORY_API_KEY`, ou adresse IP du serveur non déclarée dans la clé. |
