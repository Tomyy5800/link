# Formules et tarifs de Link by Unclaim

Mise à jour : 19 octobre 2026. Tout se règle dans l'administration, sans redéployer :
`/admin/pricing` (abonnements et prix) et `/admin/settings` (quelle fonction appartient à quelle
formule, limites de chaque formule, réglages sensibles).

> Les formules sont vendues **par abonnement** (mensuel ou annuel, sans engagement). Tant qu'aucune
> clé Stripe n'est configurée, rien n'est en vente et **rien n'est offert** : seuls les comptes avec
> une formule active et vérifiée (abonnement, code, don d'un administrateur) ont les fonctions
> payantes. Pour tout offrir pendant un lancement, active « Accès offert à tous » dans les réglages
> sensibles de `/admin/settings` (confirmation et historique).

## Les quatre formules

| | Gratuit | Link+ | Link+ Pro | Link+ Équipe |
| --- | --- | --- | --- | --- |
| Pour qui | tout le monde | joueurs, membres de communauté, créateurs qui débutent | streamers, vidéastes, artistes, chefs de pays | serveurs, équipes e-sport, associations, marques |
| Promesse | une vraie page, l'assistant, les blocs de base | se démarquer | travailler son audience | gérer à plusieurs, partout la même image |
| Pages | 1 | 3 | 10 | 25 |
| Collaborateurs par page | 1 | 2 | 5 | 20 |
| Rôles personnalisés par page | — | 3 | 8 | 20 |
| Domaines personnels | — | — | 1 | 5 |
| Statistiques | 14 jours | 90 jours | 120 jours | 120 jours |
| Assistant IA (messages / jour) | 20 | 60 | 200 | 400 |

Chaque formule comprend tout ce que contient la précédente.

- **Link+** : effets animés, musique et vidéo de fond, polices Google Fonts, automatisations,
  retrait de la mention, statistiques avancées, adresse courte, rôles personnalisés.
- **Pro** : CSS personnalisé, intégrations libres, widgets HTML, redirection de live,
  notifications Discord, export des statistiques, domaine personnel.
- **Équipe** : kit de marque (un thème appliqué à toutes les pages en un clic), et surtout des
  limites faites pour un collectif (5 domaines, 20 rôles par page).

Les **partenaires officiels** ont toutes les fonctions et leurs propres limites (30 pages,
25 collaborateurs), tant que le partenariat dure.

## Prix proposés (abonnement, sans engagement)

| | Mensuel | Annuel |
| --- | --- | --- |
| Link+ | 2,49 € / mois | 19,99 € / an (≈ 1,67 € / mois) |
| Link+ Pro | 4,99 € / mois | 39,99 € / an (≈ 3,33 € / mois) |
| Link+ Équipe | 9,99 € / mois | 79,99 € / an (≈ 6,67 € / mois) |

Un changement de prix ne touche que les nouvelles souscriptions : chaque abonnement garde le prix de
sa souscription (jusqu'à un changement de formule).

## Le raisonnement

1. **Une entrée sous 2,50 €.** Le public visé est jeune et achète surtout de petits montants (achats
   en jeu, passes de combat). Un mois de Link+ doit pouvoir se prendre sans réfléchir.
2. **L'année vaut huit mois.** Un tiers de remise : c'est la période à pousser, celle qui coûte le
   moins en frais de paiement (environ 1,5 % + 0,25 € par transaction : 2,49 € perdent ~12 %,
   19,99 € moins de 3 %) et qui fidélise.
3. **Chaque formule double la précédente.** Lecture simple, écarts nets. Pro vise ceux dont
   l'audience rapporte (le CSS, la redirection de live, les notifications et le domaine personnel
   leur font gagner du temps) ; Équipe se partage : avec 20 collaborateurs, moins de 35 centimes par
   personne et par mois.
4. **Pro est la formule mise en avant.** Trois paliers payants placent l'offre du milieu en point de
   comparaison : elle paraît raisonnable à côté d'Équipe, complète à côté de Link+.
5. **Sans engagement, résiliation en ligne.** L'abonné résilie depuis Mon espace › Offre en deux
   clics et garde sa formule jusqu'à la fin de la période payée ; il peut reprendre tant qu'elle
   court. C'est aussi une obligation légale (résiliation en ligne des contrats souscrits en ligne).
6. **Changement au prorata.** Monter ou descendre de formule est immédiat : Stripe facture ou
   crédite la différence pour la période en cours.
7. **Les codes restent.** Les codes Link+ (`/admin/codes`, partenaires, événements) ajoutent une
   durée de formule sans abonnement ; si un compte a aussi un abonnement, la formule la plus haute
   s'applique.

## Si les formules payantes se vendent mal

C'est attendu au début : la valeur d'un service comme celui-ci tient d'abord à la qualité de
l'expérience gratuite. Pistes, de la moins coûteuse à la plus engageante :

- **Activer l'accès offert à tous** (réglages sensibles) le temps de construire l'audience, puis
  ouvrir la vente avec une annonce dans l'éditeur.
- **Tester un premier mois à 0,99 €** pour Link+ : moins pour gagner que pour faire franchir le pas
  du premier paiement.
- **Offrir Link+ aux pages qui grandissent** (codes distribués depuis `/admin/codes`, par exemple à
  partir de 1 000 vues) : elles deviennent la vitrine du site.
- **Passer par les partenaires** : un serveur ou une nation partenaire peut offrir des codes à ses
  membres, et en parle mieux que n'importe quelle publicité.
- **Revoir la répartition** plutôt que les prix : déplacer une fonction très demandée (par exemple
  les automatisations) d'une formule à l'autre se fait en un clic dans `/admin/settings`.

## Ce qu'il faut régler avant d'ouvrir la vente

Voir `docs/CONFIGURATION.md` (Stripe : clés, webhook et ses événements, portail client) et la
feuille de route (`docs/FEUILLE-DE-ROUTE.md`, « Avant la mise en ligne ») : statut de vendeur,
médiateur de la consommation, informations légales, relecture des CGV.
