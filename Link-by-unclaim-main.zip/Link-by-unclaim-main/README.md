# Link by Unclaim

La bio Discord transformée en vraie page de profil : présentation, liens, réseaux, galerie, intégrations, statut Discord en direct,
profil et pays **NationsGlory**, **skin 3D**. La connexion passe par **Unclaim Auth**, la passerelle d'identité d'Unclaim
(Discord, Google, Microsoft, Apple, Twitch ou NationsGlory). L'offre payante **Link+** se vend sur `/plus`.

La suite (mise en ligne, tarifs, prochaines fonctions) : [`docs/FEUILLE-DE-ROUTE.md`](docs/FEUILLE-DE-ROUTE.md).

- Page publique : `https://<ton-domaine>/<adresse>`, à coller dans sa bio Discord (aperçu riche aux couleurs de la page).
- Éditeur protégé : `/dashboard`. Blocs en glisser-déposer, thèmes, aperçu en direct, sauvegarde automatique, annuler/rétablir.

## Démarrage rapide

Prérequis : Node.js 20.9+ (testé avec Node 24).

```bash
npm install
cp .env.example .env          # puis compléter (voir ci-dessous)
npm run db:migrate            # crée la base SQLite (prisma/dev.db)
npm run db:seed               # optionnel : page d'exemple sur /exemple
npm run dev                   # http://localhost:3000
```

Pour tester sans passerelle : `UNCLAIM_AUTH_DEV_LOGIN="true"` et `NATIONSGLORY_MOCK="true"` dans `.env`, puis
« Connexion de démonstration » sur `/login` (désactivée en production). Avec `ADMIN_DISCORD_IDS="100000000000000001"`,
ce compte de démonstration accède aussi à l'administration (`/admin`).

| Commande | Rôle |
| --- | --- |
| `npm run dev` | Serveur de développement |
| `npm run build` / `npm start` | Build et serveur de production |
| `npm run typecheck` | Vérification TypeScript |
| `npm test` | Tests unitaires (Vitest) |
| `npm run db:migrate` / `db:deploy` | Migrations (dev / production) |
| `npm run db:studio` | Explorer la base |

## Connexion avec Unclaim Auth

Link by Unclaim est un **site client** de la passerelle Unclaim Auth (projet `unclaim-api`). Il n'y a pas d'écran de
connexion propre à Link : « Se connecter » envoie directement chez le fournisseur choisi, via la passerelle.

1. Link lit les fournisseurs en service sur la passerelle (`/auth/config`), limités à ceux autorisés pour le site
   (`/api/v1/site`). S'il n'y en a qu'un, le clic part directement chez lui ; s'il y en a plusieurs, l'accueil et `/login`
   affichent un bouton par fournisseur (un seul clic, pas d'écran supplémentaire de la passerelle).
2. `GET /auth/<fournisseur>` sur la passerelle, avec `state` et PKCE S256.
3. Retour sur `/api/auth/callback`, échange du code (`POST /api/v1/token`), vérification du jeton Ed25519.
4. Le compte local est créé ou retrouvé par l'ID Unclaim (`uncl_…`). Aucun e-mail n'est conservé ; seuls les pseudos
   publics par nature (Discord, Twitch, NationsGlory) peuvent apparaître sur une page.

Discord n'est plus obligatoire. Les blocs « Profil Discord » et « Statut Discord » demandent un compte Discord rattaché
dans la passerelle (portail `/apps`) ; un compte NationsGlory rattaché remplit le pseudo à la création de la page et
affiche le badge « compte NationsGlory vérifié ».

### Déclarer Link by Unclaim dans ta passerelle

Dans `unclaim-api` (la passerelle et Link by Unclaim ne peuvent pas partager le port 3000 en local) :

```bash
npm run site:add -- "Link by Unclaim" http://localhost:3000/api/auth/callback --id link-by-unclaim --pkce
```

Lance la passerelle avec `PORT=4000` et `PUBLIC_URL=http://localhost:4000`, et déclare
`http://localhost:4000/auth/discord/callback` dans le portail Discord. Recopie ensuite le `client_id` et le `client_secret`
affichés (le secret n'est montré qu'une fois) dans le `.env` de Link by Unclaim. En production, ajoute l'adresse
`https://<ton-domaine>/api/auth/callback` au site.

## Configuration (`.env`)

| Variable | Description |
| --- | --- |
| `APP_URL` | URL publique, sans `/` final. Sert à la redirection Unclaim Auth et aux aperçus de lien. |
| `SESSION_SECRET` | Secret aléatoire (obligatoire en production) pour anonymiser les statistiques. |
| `DATABASE_URL` | `file:./dev.db` (SQLite, relatif au dossier `prisma/`) ou une URL PostgreSQL. |
| `UNCLAIM_API_URL` | `PUBLIC_URL` de la passerelle Unclaim Auth (aussi l'émetteur attendu des jetons). |
| `UNCLAIM_CLIENT_ID` / `UNCLAIM_CLIENT_SECRET` | Identifiants du site Link by Unclaim dans la passerelle. |
| `UNCLAIM_PROVIDERS` | Fournisseurs proposés si la passerelle ne répond pas (par défaut `discord`). En temps normal, la liste est lue sur la passerelle. |
| `UNCLAIM_AUTH_DEV_LOGIN` | `true` : connexion de démonstration, ignorée en production. |
| `NATIONSGLORY_API_URL` / `NATIONSGLORY_API_KEY` | API publique NationsGlory. La clé ne quitte jamais le serveur. |
| `NATIONSGLORY_SKINS_URL` | Serveur de skins (`https://skins.nationsglory.fr`). |
| `NATIONSGLORY_MOCK` | `true` : données de jeu fictives (dev / démo, ou tant que la clé n'est pas disponible). |
| `NATIONSGLORY_RATE_LIMIT` | Requêtes par minute que l'application s'autorise vers NationsGlory (quota d'une clé : 60). |
| `FOUNDER_UNCLAIM_IDS` / `FOUNDER_DISCORD_IDS` | Fondateurs : toutes les permissions, badge « Fondateur », seuls à nommer des administrateurs. |
| `ADMIN_UNCLAIM_IDS` / `ADMIN_DISCORD_IDS` | Administrateurs d'office (IDs `uncl_…` ou IDs Discord), séparés par des virgules. |
| `STRIPE_SECRET_KEY` / `STRIPE_WEBHOOK_SECRET` | Abonnements Link+ et boutique officielle (Stripe). Sans elles, rien n'est en vente. |
| `DISCORD_BOT_TOKEN` | Bot du serveur Discord officiel : rôles du staff → badges (`/admin/discord`). |
| `CUSTOM_DOMAIN_CNAME` / `CUSTOM_DOMAIN_IPV4` | Cible DNS des domaines personnels (Pro, Équipe). Vides : domaines personnels inactifs. |
| `ANTHROPIC_API_KEY` / `ASSISTANT_MODEL` | Assistant de création en langage naturel (Claude). Sans clé : assistant guidé local. Modèle par défaut : `claude-opus-5-5`. |
| `UPLOADS_DRIVER` / `UPLOADS_DIR` | `db` (fichiers en base) ou `disk` (fichiers sous `UPLOADS_DIR`, recommandé en production). |

## Fonctionnalités

**Mon espace** (`/dashboard`) : toutes les pages du compte (et celles partagées avec lui) avec leurs chiffres de la semaine,
**messages** reçus par le formulaire de contact, **compte et données** (comptes reliés via Unclaim Auth, appareils connectés et
déconnexion à distance, export JSON, suppression du compte), **offre** (Link+, limites, achats, codes) et **partenariat**
(candidature, statut). L'éditeur d'une page est à `/dashboard/pages/<id>`, la création à `/dashboard/nouvelle`.

**Assistant de création** (`/dashboard/assistant`) : la page se construit en discutant, avec un aperçu en direct et un
minuteur (objectif : moins de cinq minutes). Avec `ANTHROPIC_API_KEY`, Claude (Claude Opus 5.5 par défaut, `ASSISTANT_MODEL`
pour un autre modèle) comprend le langage naturel, en sortie structurée, avec un quota quotidien par formule ; sans clé,
un assistant guidé pose cinq questions et reconnaît liens, pseudos « plateforme pseudo », jeux, anniversaire et ambiance.
Les nouveaux comptes y arrivent directement ; le formulaire classique reste à `/dashboard/nouvelle`.

**Automatisations** (Réglages de la page) : règles « quand… alors… » évaluées à l'affichage, au fuseau de la page.
Déclencheurs : créneau hebdomadaire (y compris de nuit), période entre deux dates, live en cours (statut Discord « en
stream » via Lanyard), jour de l'anniversaire. Actions : bandeau (accent, live, fête, info), bloc mis en avant, bloc
masqué, autre thème. Modèles prêts à l'emploi et simulation dans l'aperçu ; les règles ne sont jamais envoyées au
navigateur des visiteurs.

**Notifications Discord** : un webhook (stocké à part, jamais envoyé avec la page) reçoit les nouveaux messages de
contact et un bilan hebdomadaire, sans aucune mention possible. **Kit de marque** : le thème d'une page appliqué à
toutes les autres. **Polices Google Fonts** pour le texte et les titres. **Duplication** d'une page (copie privée).

**Confort** : palette de commandes (Ctrl+K) dans « Mon espace » et l'éditeur, Ctrl+S qui confirme l'enregistrement
automatique, écran de bienvenue après la création, caps de vues fêtés, astuce du jour.

**Conditions d'utilisation** : `/cgu`, à accepter (avec confirmation de l'âge, 15 ans ou accord parental) à la première
connexion puis à chaque nouvelle version (`TERMS_VERSION` dans `src/lib/legal.ts`) ; version et date conservées.

**Plusieurs pages et équipes** : chaque compte crée le nombre de pages prévu par son offre (1 en gratuit, 5 avec Link+,
20 pour les partenaires, réglable). Le propriétaire invite des collaborateurs par lien à usage unique (7 jours) : **éditeur**
(modifie la page) ou **lecteur** (statistiques et messages). Fonctions et limites d'une page sont celles de son propriétaire.

**Programme partenaires** : candidature depuis « Mon espace », examen dans `/admin/partners` ; un partenaire a le badge
« Partenaire » sur ses pages, Link+ inclus, les limites « partenaires » et une place dans l'annuaire public `/partenaires`.

**24 blocs** : titre, texte, séparateur, lien, dossier de liens, réseaux sociaux, image, galerie (grille ou carrousel, avec
visionneuse), intégration, **radio** (LyxiaRadio ou toute radio AzuraCast / flux https, titre en cours, pochette, auditeurs),
**« Écouter partout »** (un morceau, un lien par plateforme), **agenda** (événements à l'heure du visiteur, ajout au calendrier),
questions dépliables, badges, compte à rebours (date ou **anniversaire** qui revient chaque année, avec confettis le jour J),
valeur à copier, **profil de jeu**, **formulaire de contact**, profil Discord, serveur Discord, statut Discord en direct (Lanyard), profil NationsGlory, pays NationsGlory,
skin 3D. Chaque bloc peut être masqué, dupliqué, **programmé** et stylé (fond, couleur du texte, alignement, masquage par écran).

**Prise en main** : à la création, choix d'un **modèle** (joueur NationsGlory, streamer, créateur, minimal) qui place les
blocs et un thème assorti ; liste **« Premiers pas »** dans l'éditeur (présentation, 3 liens, ouvrir sa page, copier son
lien), masquable ; **export** de toutes ses données en JSON (Réglages › Mes données).

**Liens** : émoji ou vignette, grande image mise en avant, animation d'appel (pulsation, vibration, balancement, reflet),
**contenu sensible** (confirmation avant d'ouvrir).

**Mise en forme Discord** dans la présentation et les textes : gras, italique, spoilers, titres, citations, mais aussi les
**dates Discord** `<t:1767225600:R>` (affichées à l'heure de chaque visiteur, « dans 3 jours »), les **émojis de serveur**
`<:nom:id>` / `<a:nom:id>` et les codes `:fire:`. L'éditeur insère émojis et dates au curseur.

**Page** : bouton « Partager » (lien, QR code, partage du téléphone), titre et description pour Google et les aperçus,
masquage des moteurs de recherche, avertissement 18+, **redirection temporaire** vers un live (Link+).

**Mise en page sur ordinateur** : colonne, **grille modulable** (2 à 4 colonnes, espacement et hauteur de rangée réglables) ou
**profil latéral**. Chaque bloc choisit sa largeur (1 à 4 colonnes) et sa hauteur (1 à 4 rangées), depuis son onglet
« Disposition et style » ou directement dans l'aperçu « Ordinateur » (poignées sur chaque bloc ; un clic ouvre le bloc dans
l'éditeur). Sur mobile, la page reste en colonne (pleine ou demi-largeur).

**Intégrations** : YouTube, Twitch (live, VOD, clip, chat), Kick, Spotify, Deezer, Apple Music, SoundCloud, Vimeo,
Dailymotion, Streamable, TikTok, X, Instagram, widget Discord, Google Maps ; **n'importe quel site** en iframe (https) et
**widgets HTML** isolés (iframe sans même origine : le code ne peut ni lire la page ni ses cookies).

**Personnalisation** : 12 thèmes de départ, couleurs, fond (couleur, dégradé, image, **vidéo**) avec effets, cartes, boutons,
en-tête, 8 polices, animation d'apparition, import/export du thème en JSON ; **effets** (particules, curseur, animation du nom,
bio en machine à écrire, cartes inclinables — coupés si le visiteur réduit les animations) ; **musique de fond** (fichier ou
webradio en direct, lecteur à gauche, à droite ou réduit, démarrage au premier clic ou à l'écran d'entrée facultatif, une seule
source audio à la fois) ; **CSS personnalisé** assaini et cantonné à la page.

**Référencement** : `sitemap.xml` (pages publiées et indexables), `robots.txt` (éditeur, administration et API exclus),
manifeste d'application, image d'aperçu générée pour l'accueil, pages d'erreur et de chargement.

**Profil de jeu** : Minecraft, Chess.com, Lichess, Steam et Roblox en direct (API publiques sans clé, cache 15 min avec
repli 24 h) ; Paladium, Hypixel, Wolfy, Valorant, League of Legends, Fortnite, Rocket League, Brawl Stars, Clash Royale, osu!,
Genshin Impact ou tout autre jeu en carte remplie à la main (rang, statistiques, lien du profil). Paladium et Wolfy n'ont pas
d'API publique utilisable aujourd'hui.

**Formulaire de contact** : les visiteurs écrivent sans voir d'e-mail ; les messages arrivent dans « Mon espace › Messages »
(propriétaire et équipe). Anti-spam : champ piège, 6 envois par 10 minutes par adresse, 5 par jour et par page par visiteur.

**Statistiques** : vues uniques par jour, clics par lien, et en version avancée sources de trafic (domaine d'origine) et
appareils, sur 7 à 120 jours selon l'offre. Robots et propriétaire exclus, aucune adresse IP stockée.

**Statut Discord en direct** : passe par [Lanyard](https://github.com/Phineas/lanyard). La personne rejoint une fois le serveur
Discord de Lanyard ; le relais `/api/discord/presence/:id` n'accepte que les comptes connus de l'application.

## Offre payante et administration

**Quatre formules** : Gratuit, Link+, Link+ Pro, Link+ Équipe ; chaque fonction appartient à une formule (ou à tous),
chaque formule a ses limites (pages, collaborateurs, blocs, fichiers, statistiques, messages à l'assistant IA). Le
raisonnement des prix est dans [docs/TARIFS.md](docs/TARIFS.md).

**Les formules sont des abonnements** (mensuels ou annuels, sans engagement). Sans clé Stripe, rien n'est en vente et rien
n'est offert : seules les formules actives et vérifiées donnent accès aux fonctions payantes. L'« accès offert à tous » (lancement)
est un réglage sensible de `/admin/settings`, désactivé par défaut. Configuration externe : [docs/CONFIGURATION.md](docs/CONFIGURATION.md).

Chaque fonctionnalité a un **mode** réglé dans `/admin/settings`, sans redéploiement : **Tous** (gratuite), **Payant**
(réservée à l'offre payante, « Link+ » par défaut, nom modifiable) ou **Coupé** (masquée partout, même sur les pages
existantes). Par défaut, sont payants : intégrations libres, widgets HTML, effets animés, musique et vidéo de fond, CSS
personnalisé, retrait de la mention « Link by Unclaim », statistiques avancées et adresses courtes (3 ou 4 caractères).
Les **limites** (blocs, fichiers, taille des images et des médias, profondeur des statistiques) se règlent par offre.

L'offre s'active de trois façons : **abonnement** sur `/plus` (Stripe Checkout ; résiliation, reprise, changement de formule
au prorata et factures dans Mon espace › Offre), **code** échangé dans les réglages (`/admin/codes`), ou **don** d'un
administrateur depuis `/admin/users`. La formule la plus haute s'applique. Dans l'éditeur, les réglages réservés restent visibles avec un cadenas qui mène à la carte de l'offre.

**Vente** : les abonnements (nom, prix TTC, période mensuelle ou annuelle, mise en avant) se règlent dans `/admin/pricing`, avec les informations
légales reprises par `/cgv`, `/mentions-legales` et `/confidentialite`. Avant de payer, l'acheteur accepte les CGV et
demande l'accès immédiat (renonciation au droit de rétractation, art. L221-28 du Code de la consommation). Chaque événement
Stripe (signature vérifiée) déclenche une relecture de l'abonnement dans l'API Stripe avant de changer les droits ; un
remboursement depuis `/admin/sales` ou Stripe les retire.

**Badges officiels** (`/admin/badges`) : Fondateur, Administrateur, Développeur, Modérateur, Staff officiel, Partenaire,
Utilisateur vérifié, Early Supporter (N premiers comptes, attribution atomique), Membre historique, Premium, et badges
personnalisés (logo, couleur, visibilité, durée, règle d'attribution, historique). Le **sceau officiel** se pose avec la
permission « Valider les badges ». Rôles du serveur Discord officiel → badges (`/admin/discord`). Page publique `/staff`.

**Boutique officielle** (`/boutique`, gérée dans `/admin/boutique`) : badges exclusifs et cadres d'avatar, paiement unique,
livrés après confirmation Stripe. Les **boutiques personnelles** des profils sont fermées par défaut (réglage sensible).

**Profils** : `/<adresse>` et `/profil/<adresse>`, anciennes adresses redirigées et réservées 30 jours, noms officiels
protégés. **Domaines personnels** (Pro, Équipe) vérifiés par TXT, CNAME/A et HTTPS. **Rôles personnalisés** (Link+) :
permissions limitées à la page.
Logo de l'offre : `charte/logos/link-plus-*.svg`.

**Administration** (`/admin`, rôle `admin` ou `ADMIN_DISCORD_IDS`) :

- **Vue d'ensemble** : comptes, pages, abonnés, ventes, vues, stockage, signalements ; liste de contrôle « Prêt pour la mise
  en ligne » (https, secrets, Unclaim Auth, clé NationsGlory, Stripe, informations légales) ; vidage du cache NationsGlory.
- **Partenaires** : candidatures à accepter ou refuser (motif affiché), partenaires actuels.
- **Comptes** : recherche et filtres ; offrir ou retirer l'offre payante, badge **vérifié**, statut **partenaire**, rôle administrateur, suspension
  avec motif (sessions fermées, page masquée, motif affiché au propriétaire).
- **Pages** : signalées, suspendues, privées ; suspension avec motif, mise **à la une** (affichée sur l'accueil), suppression.
- **Signalements** : envoyés par les visiteurs (« Signaler » en bas de chaque page) ; traiter, classer, ou suspendre la page.
- **Ventes** : chiffre d'affaires, panier moyen, ventes par offre, commandes, remboursement, validation manuelle.
- **Tarifs et vente** : offres et prix, achat pour offrir, informations légales, état du paiement en ligne.
- **Fonctionnalités** : modes, limites par offre, création de pages ouverte ou fermée, annonce dans l'éditeur,
  **domaines bloqués** dans les intégrations.
- **Journal** : chaque action d'administration et chaque échange de code.

## Charte graphique

Le dossier [`charte/`](charte) contient la charte de Link by Unclaim : jetons (`project/tokens.json`), livre de marque
(`project/README.md`), composants de référence et logos (`logos/`). L'idée : **la carte des chunks**. L'application reprend la
nuit, les liserés, la grille HUD et la couleur d'action (cyan `signal`) d'Unclaim Auth, et signe avec l'ambre `claim`.
Display Chakra Petch, interface Inter, données JetBrains Mono. Les jetons sont repris dans `src/app/globals.css`.

## Architecture

Next.js 16 (App Router) · React 19 · TypeScript · Tailwind CSS 4 · Prisma 6 · Zod 4 · skinview3d · dnd-kit · qrcode.

```
src/
  app/
    page.tsx                 landing
    login/                   connexion Unclaim Auth
    dashboard/               Mon espace : pages, messages, compte, offre, partenariat ; nouvelle/ ; pages/[id] (éditeur)
    bienvenue/               acceptation des CGU (première connexion, nouvelle version)
    invitation/[token]       rejoindre l'équipe d'une page
    partenaires/             programme et annuaire des partenaires
    admin/                   administration (comptes, pages, signalements, ventes, tarifs, fonctionnalités, codes, journal)
    plus/                    page des tarifs Link+ et retour de paiement
    cgu, cgv, mentions-legales, confidentialite   pages légales (remplies depuis l'administration)
    [slug]/                  page publique + image Open Graph
    api/
      auth/                  login, callback Unclaim Auth, logout, connexion de démo
      me/pages/[id]          lire, sauvegarder, renommer, supprimer ; adresse, stats (JSON ou CSV), équipe, messages
      me/                    liste et création des pages, CGU, compte (suppression), sessions, export, partenariat, code, commandes
      invitations/[token]    acceptation d'une invitation
      games/[game]           profils publics des jeux (Minecraft, Chess.com, Lichess, Steam, Roblox)
      checkout, webhooks/    achat de Link+ (Stripe Checkout) et notifications de paiement
      pages/[slug]/          compteur de vues, suivi des clics, signalement, formulaire de contact
      admin/                 actions d'administration (accès vérifié à chaque appel, journalisées)
      health                 sonde de santé (application + base)
      nationsglory/          proxys joueur et pays (clé côté serveur)
      discord/               invitations de serveur, statut en direct (Lanyard)
      skin/[username]        textures et rendus de skin (pour le 3D)
      uploads/               import (image, audio, vidéo) et diffusion avec requêtes partielles
  components/
    page/                    rendu des pages (partagé public / aperçu / démo)
    editor/                  éditeur (blocs, profil, apparence, réglages, offre)
    admin/                   écrans et actions de l'administration
  lib/
    blocks.ts theme.ts …     schémas Zod et logique partagés
    features.ts              fonctionnalités pilotables, limites par offre
    css.ts embeds.ts         CSS personnalisé (assaini, cantonné) et résolution des intégrations
    server/unclaim-auth/     client de la passerelle, sessions, synchronisation
    server/                  Prisma, NationsGlory, Discord, cache, sécurité, droits, réglages, codes, stockage
prisma/schema.prisma         User, Session, Page, PageMember, PageInvite, Block, PageView, LinkClick, ContactMessage,
                             Upload, Report, PartnerApplication, AppSetting, PremiumCode, CodeRedemption, Order,
                             AuditLog, CacheEntry
charte/                      charte graphique (jetons, livre de marque, logos)
```

### NationsGlory

- **API publique v1** (`https://publicapi.nationsglory.fr/v1`, clé `ngp_…` dans l'en-tête `X-API-Key`, jamais dans l'URL) :
  joueur et dernière connexion par serveur (`/servers/{serveur}/players/{pseudo}`), liste paginée des pays (curseur),
  fiche et membres d'un pays (`/servers/{serveur}/countries/{country_id}`), drapeaux par empreinte SHA-256.
- **Quota** : 60 requêtes/minute par clé. L'application s'en tient à `NATIONSGLORY_RATE_LIMIT` toutes routes confondues,
  met chaque réponse en cache (joueurs et pays 5 min, liste des pays 30 min) et **ressert la dernière valeur connue** si l'API
  ne répond pas. Pense à déclarer l'adresse IP du serveur dans la clé (sinon `403 ip_not_allowed`).
- **Sans clé** : tant que la clé n'est pas disponible, `NATIONSGLORY_MOCK="true"` affiche des données fictives (étiquetées
  « démo ») ; sans clé ni mode démo, les blocs affichent « données indisponibles » aux visiteurs et le sélecteur de pays de
  l'éditeur passe en saisie libre du nom. L'administration indique l'état de la connexion et permet de vider le cache une fois
  la clé branchée.
- **Skins** : `skins.nationsglory.fr/skin?username=` (texture 64×64), `/face/{pseudo}/{taille}`, `/body/{pseudo}/{taille}`,
  relayés par `/api/skin`. Le serveur n'expose pas de cape.

## Mise en production

### Docker (une instance)

```bash
cp .env.example .env.production   # APP_URL en https, SESSION_SECRET, UNCLAIM_*, NATIONSGLORY_*, ADMIN_DISCORD_IDS
docker compose up -d --build
```

L'image (`Dockerfile`, serveur Next.js autonome) applique les migrations au démarrage et garde la base SQLite et les fichiers
importés dans le volume `/data` (`UPLOADS_DRIVER=disk`). Sonde de santé : `GET /api/health`. Place un proxy https (Caddy,
Nginx, Traefik) devant le port 3000 et ajoute `https://<ton-domaine>/api/auth/callback` au site dans Unclaim Auth.

### Pterodactyl (egg Node.js)

```bash
npm run build:pterodactyl
```

Produit `deploy/link-by-unclaim-pterodactyl.zip` : serveur autonome, moteurs Prisma pour Linux (x64 et ARM64), migrations
et `start.js`, le « Main file » de l'egg. Rien n'est installé ni compilé sur le serveur ; la base et les fichiers vivent
dans `data/`, à côté de `start.js`. Le build se fait dans une copie du projet : un `npm start` local n'est pas
interrompu. Installation, HTTPS et mises à jour : [docs/PTERODACTYL.md](docs/PTERODACTYL.md).

### À plus grande échelle

1. **PostgreSQL** : dans `prisma/schema.prisma`, `provider = "postgresql"`, supprimer `prisma/migrations/`, puis
   `npx prisma migrate dev --name init` contre la nouvelle base.
2. **Plusieurs instances** : le limiteur de débit (dont le quota NationsGlory) est en mémoire, à remplacer par un stockage
   partagé (Redis…) ; les réglages d'administration sont relus en base toutes les 30 secondes par chaque instance.
3. **Fichiers** : `UPLOADS_DRIVER=disk` sur un volume partagé, ou un stockage objet derrière `src/lib/server/storage.ts`.
4. Hors Docker : `npm run build`, `npm run db:deploy`, puis `npm start`.

Les fichiers importés sont nettoyés automatiquement une heure après ne plus être utilisés par la page.

---

Projet indépendant, non affilié à Discord ni à NationsGlory.
