import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, BadgeCheck, Handshake } from "lucide-react";
import { SiteFooter, SiteHeader } from "@/components/site/SiteChrome";
import { PageTransition } from "@/components/site/PageTransition";
import { SmoothScroll } from "@/components/site/SmoothScroll";
import { toOwnerProfile } from "@/lib/discord-cdn";
import { partnerPerks } from "@/lib/partners";
import { prisma } from "@/lib/server/db";
import { env } from "@/lib/server/env";
import { getSettings } from "@/lib/server/settings";
import { getCurrentUser } from "@/lib/server/unclaim-auth";
import { accentOnDark, parseTheme } from "@/lib/theme";

export const metadata: Metadata = {
  title: "Partenaires",
  description: "Les créateurs, serveurs, nations et équipes partenaires officiels de Link by Unclaim, et comment le devenir.",
};

// Programme partenaires : avantages, annuaire des pages partenaires, candidature.
export default async function PartnersPage() {
  const [user, settings] = await Promise.all([getCurrentUser(), getSettings()]);
  const pages = await prisma.page
    .findMany({
      where: { published: true, status: "active", user: { partner: true, banned: false, suspendedAt: null } },
      orderBy: [{ featured: "desc" }, { views: "desc" }],
      take: 60,
      select: { slug: true, displayName: true, bio: true, theme: true, avatarSource: true, avatarUrl: true, user: true },
    })
    .catch(() => []);
  const perks = partnerPerks(settings.limits.partner, settings.premiumName);
  const host = new URL(env.appUrl).host;

  return (
    <PageTransition>
      <div className="bg-hud min-h-screen">
        <SiteHeader loggedIn={Boolean(user)} premiumName={settings.premiumName} />
        <main className="mx-auto max-w-6xl px-4 pt-14 pb-20 sm:px-6">
          <p className="hud-label inline-flex items-center gap-2 text-claim">
            <Handshake size={14} /> Programme partenaires
          </p>
          <h1 className="mt-3 max-w-3xl font-display text-4xl font-bold tracking-tight text-balance sm:text-5xl">Construisons ta présence, ensemble.</h1>
          <p className="mt-4 max-w-2xl text-lg text-ink-300">
            Créateurs, serveurs de jeu, nations, équipes e-sport, associations : le partenariat t&apos;ouvre les outils des pros et une place dans la
            vitrine de Link by Unclaim.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              href={user ? "/dashboard/partenariat" : "/login?next=/dashboard/partenariat"}
              className="inline-flex items-center gap-2 rounded-md bg-brand-500 px-5 py-3 font-semibold text-ink-950 transition hover:bg-brand-400"
            >
              Devenir partenaire <ArrowRight size={18} />
            </Link>
            <a href="#annuaire" className="rounded-md border border-ink-500 px-4 py-3 font-semibold text-ink-200 transition hover:border-ink-300">
              Voir les partenaires
            </a>
          </div>

          <ul className="mt-14 grid gap-px overflow-hidden rounded-lg border border-ink-700 bg-ink-700 sm:grid-cols-2 lg:grid-cols-3">
            {perks.map((perk) => (
              <li key={perk.title} className="bg-ink-900 p-6">
                <BadgeCheck size={20} className="text-brand-300" />
                <h2 className="mt-3 font-display text-lg font-semibold">{perk.title}</h2>
                <p className="mt-1 text-sm text-ink-300">{perk.text}</p>
              </li>
            ))}
            <li className="bg-ink-900 p-6">
              <Handshake size={20} className="text-claim" />
              <h2 className="mt-3 font-display text-lg font-semibold">Comment ça marche</h2>
              <p className="mt-1 text-sm text-ink-300">Candidate depuis « Mon espace », l&apos;équipe étudie ton projet et te répond, en général sous une semaine.</p>
            </li>
          </ul>

          <section id="annuaire" className="mt-16 scroll-mt-24">
            <h2 className="font-display text-3xl font-bold tracking-tight">Ils sont partenaires</h2>
            {pages.length === 0 ? (
              <p className="mt-4 text-ink-400">Les premiers partenaires arrivent bientôt. Ta page pourrait être la première ici.</p>
            ) : (
              <ul className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {pages.map((p) => {
                  const accent = accentOnDark(parseTheme(p.theme).accent);
                  const avatar = p.avatarSource === "custom" && p.avatarUrl ? p.avatarUrl : toOwnerProfile(p.user).avatarUrl;
                  return (
                    <li key={p.slug}>
                      <a
                        href={`/${p.slug}`}
                        className="group flex h-full items-start gap-3 rounded-md border border-ink-700 bg-ink-900 p-4 transition hover:border-ink-500"
                        style={{ boxShadow: `inset 3px 0 0 ${accent}` }}
                      >
                        <img src={avatar} alt="" className="h-12 w-12 shrink-0 rounded-full object-cover" loading="lazy" />
                        <span className="min-w-0">
                          <span className="flex items-center gap-1.5 font-semibold text-ink-100 group-hover:text-white">
                            <span className="truncate">{p.displayName}</span>
                            <BadgeCheck size={15} className="shrink-0 text-brand-300" aria-label="Partenaire officiel" />
                          </span>
                          <span className="block truncate font-mono text-xs text-ink-400">
                            {host}/<span style={{ color: accent }}>{p.slug}</span>
                          </span>
                          {p.bio && <span className="mt-1 line-clamp-2 block text-sm text-ink-300">{p.bio.replace(/[*_~`>#|<]/g, "")}</span>}
                        </span>
                      </a>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>
        </main>
        <SiteFooter premiumName={settings.premiumName} />
        <SmoothScroll />
      </div>
    </PageTransition>
  );
}
