import type { Metadata } from "next";
import { AssistantStudio } from "@/components/account/AssistantStudio";
import { toOwnerProfile } from "@/lib/discord-cdn";
import { ownedPageCount, requireAccountPage } from "@/lib/server/access";
import { entitlementsFrom } from "@/lib/server/entitlements";
import { env } from "@/lib/server/env";
import { getSettings } from "@/lib/server/settings";

export const metadata: Metadata = { title: "Assistant de création", robots: { index: false } };

// Assistant de création : la page se construit en discutant, avec un aperçu en direct.
export default async function AssistantPage() {
  const user = await requireAccountPage("/dashboard/assistant");
  const [settings, owned] = await Promise.all([getSettings(), ownedPageCount(user.id)]);
  const rights = entitlementsFrom(user, settings);
  return (
    <AssistantStudio
      owner={toOwnerProfile(user)}
      host={new URL(env.appUrl).host}
      features={rights.features}
      allowShortSlug={rights.features.shortSlug}
      premiumName={settings.premiumName}
      existingPages={owned}
      limitReached={owned >= rights.limits.pages || (!settings.registrationsOpen && !rights.admin)}
    />
  );
}
