import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { PageInsights } from "@/components/account/PageInsights";
import { Editor } from "@/components/editor/Editor";
import { toOwnerProfile } from "@/lib/discord-cdn";
import { hasPagePermission, listAccountPages, pageAccess, requireAccountPage } from "@/lib/server/access";
import { entitlementsFrom, suspension } from "@/lib/server/entitlements";
import { env } from "@/lib/server/env";
import { nationsGloryReady } from "@/lib/server/nationsglory";
import { getEditorPage } from "@/lib/server/pages";
import { getSettings } from "@/lib/server/settings";
import { publicBadgesOf } from "@/lib/server/badges";
import { framesOf } from "@/lib/server/official-shop";

export const metadata: Metadata = { title: "Éditeur", robots: { index: false } };

// Éditeur d'une page : propriétaire et éditeurs. Les lecteurs voient ses statistiques.
export default async function PageEditor({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ bienvenue?: string }> }) {
  const { id } = await params;
  const welcome = (await searchParams).bienvenue === "1";
  const user = await requireAccountPage(`/dashboard/pages/${id}`);
  const access = await pageAccess(user.id, id);
  if (!access) notFound();

  // Sans droit de modification (lecteur, ou rôle personnalisé sans « Modifier la page ») : ce que le rôle permet de voir.
  if (!hasPagePermission(access, "content")) return <PageInsights access={access} />;

  // Fonctions et limites : celles du propriétaire de la page, même pour un collaborateur.
  const owner = access.page.user;
  const [page, settings, pages, badges, frames] = await Promise.all([getEditorPage(id), getSettings(), listAccountPages(user.id), publicBadgesOf(owner), framesOf(owner)]);
  if (!page) notFound();
  const entitlements = { ...entitlementsFrom(owner, settings), admin: entitlementsFrom(user, settings).admin };
  const suspended = suspension(owner, access.page);

  return (
    <Editor
      key={id}
      pageId={id}
      role={access.role === "owner" ? "owner" : "editor"}
      label={access.page.label}
      pages={pages.map((p) => ({ id: p.id, name: p.name, slug: p.slug, avatar: p.avatar, role: p.role }))}
      initialPage={page}
      owner={toOwnerProfile(owner)}
      host={new URL(env.appUrl).host}
      appUrl={env.appUrl}
      entitlements={entitlements}
      verified={owner.verified}
      partner={owner.partner}
      blockedDomains={settings.blockedDomains}
      ngMode={nationsGloryReady()}
      announcement={settings.announcement}
      suspended={suspended ? { reason: suspended.reason } : null}
      welcome={welcome && access.role === "owner"}
      badges={badges}
      frames={frames}
    />
  );
}
