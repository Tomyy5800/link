// Chargement de l'éditeur : la structure s'affiche tout de suite (barre, onglets, aperçu).
export default function DashboardLoading() {
  const bar = "ui-skeleton rounded-md";
  return (
    <div className="flex h-dvh flex-col bg-ink-950" aria-busy="true" aria-label="Chargement de l'éditeur">
      <div className="flex h-14 shrink-0 items-center gap-3 border-b border-ink-800 px-4">
        <div className={`${bar} h-7 w-32`} />
        <div className={`${bar} ml-auto h-8 w-28`} />
      </div>
      <div className="flex min-h-0 flex-1">
        <div className="w-full space-y-3 border-ink-800 p-4 lg:w-[460px] lg:border-r">
          <div className={`${bar} h-10`} />
          {Array.from({ length: 6 }, (_, i) => (
            <div key={i} className={`${bar} h-14`} />
          ))}
        </div>
        <div className="hidden flex-1 items-start justify-center p-6 lg:flex">
          <div className={`${bar} h-[80%] w-[380px] rounded-[2.2rem]`} />
        </div>
      </div>
    </div>
  );
}
