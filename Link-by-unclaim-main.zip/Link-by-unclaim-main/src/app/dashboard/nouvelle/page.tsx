import type { Metadata } from "next";
import { Onboarding } from "@/components/editor/Onboarding";
import { toOwnerProfile } from "@/lib/discord-cdn";
import { ownedPageCount, requireAccountPage } from "@/lib/server/access";
import { entitlementsFrom } from "@/lib/server/entitlements";
import { env } from "@/lib/server/env";
import { getSettings } from "@/lib/server/settings";
import { suggestSlug, validateSlug } from "@/lib/slug";
import { getTemplate } from "@/lib/templates";

export const metadata: Metadata = { title: "Nouvelle page", robots: { index: false } };

// Création d'une page : adresse, nom affiché, modèle et thème de départ.
// ?adresse= (revendiquée sur la landing) et ?modele= (choisi dans la galerie) pré-remplissent le formulaire.
export default async function NewPage({ searchParams }: { searchParams: Promise<{ adresse?: string; modele?: string }> }) {
  const { adresse, modele } = await searchParams;
  const user = await requireAccountPage("/dashboard/nouvelle");
  const [settings, owned] = await Promise.all([getSettings(), ownedPageCount(user.id)]);
  const entitlements = entitlementsFrom(user, settings);
  const owner = toOwnerProfile(user);
  const claimed = adresse ? validateSlug(adresse, { allowShort: entitlements.features.shortSlug }) : null;

  return (
    <Onboarding
      owner={owner}
      suggestedSlug={
        claimed?.ok ? claimed.slug : suggestSlug(owned ? `${user.globalName ?? user.username}-${owned + 1}` : (user.globalName ?? user.username))
      }
      claimed={Boolean(claimed?.ok)}
      initialTemplate={modele && getTemplate(modele) ? modele : undefined}
      host={new URL(env.appUrl).host}
      allowShortSlug={entitlements.features.shortSlug}
      premiumName={settings.premiumName}
      closed={!settings.registrationsOpen && !entitlements.admin}
      existingPages={owned}
      pageLimit={entitlements.limits.pages}
      canUpgrade={!entitlements.premium}
    />
  );
}
