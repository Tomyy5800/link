import type { Metadata } from "next";
import Link from "next/link";
import { Inbox as InboxIcon } from "lucide-react";
import { Inbox } from "@/components/account/Inbox";
import { PageTitle, Panel } from "@/components/admin/ui";
import { listAccountPages, requireAccountPage } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";

export const metadata: Metadata = { title: "Messages" };

// Messages laissés par les visiteurs avec le bloc « Formulaire de contact », toutes pages confondues.
export default async function MessagesPage({ searchParams }: { searchParams: Promise<{ page?: string }> }) {
  const user = await requireAccountPage("/dashboard/messages");
  // Seulement les pages dont le rôle du compte permet de lire les messages.
  const pages = (await listAccountPages(user.id)).filter((p) => p.permissions.includes("messages.read"));
  const filter = (await searchParams).page;
  const selected = pages.find((p) => p.id === filter);
  const ids = selected ? [selected.id] : pages.map((p) => p.id);

  const rows = await prisma.contactMessage.findMany({
    where: { pageId: { in: ids } },
    orderBy: { createdAt: "desc" },
    take: 300,
    select: { id: true, pageId: true, name: true, contact: true, message: true, read: true, createdAt: true },
  });
  const byId = new Map(pages.map((p) => [p.id, p]));
  const messages = rows.map((m) => {
    const page = byId.get(m.pageId)!;
    return { ...m, createdAt: m.createdAt.toISOString(), pageName: page.name, pageSlug: page.slug, canDelete: page.permissions.includes("messages.manage") };
  });

  return (
    <div className="ui-stagger">
      <PageTitle title="Messages" description="Reçus par le bloc « Formulaire de contact » de tes pages. Seuls toi et ton équipe les voient." />
      {pages.length > 1 && (
        <nav className="mb-4 flex flex-wrap gap-1.5" aria-label="Filtrer par page">
          <Link
            href="/dashboard/messages"
            aria-current={!selected ? "page" : undefined}
            className={`rounded-md border px-2.5 py-1 text-xs ${!selected ? "border-brand-400 bg-brand-500/10 text-ink-100" : "border-ink-700 text-ink-400 hover:text-ink-200"}`}
          >
            Toutes
          </Link>
          {pages.map((p) => (
            <Link
              key={p.id}
              href={`/dashboard/messages?page=${p.id}`}
              aria-current={selected?.id === p.id ? "page" : undefined}
              className={`rounded-md border px-2.5 py-1 text-xs ${selected?.id === p.id ? "border-brand-400 bg-brand-500/10 text-ink-100" : "border-ink-700 text-ink-400 hover:text-ink-200"}`}
            >
              {p.name}
              {p.unread > 0 && <span className="ml-1 text-brand-300">· {p.unread}</span>}
            </Link>
          ))}
        </nav>
      )}
      {messages.length === 0 ? (
        <Panel>
          <div className="flex flex-col items-center gap-2 py-10 text-center">
            <InboxIcon size={28} className="text-ink-500" />
            <p className="font-semibold">Aucun message pour l&apos;instant</p>
            <p className="max-w-md text-sm text-ink-400">
              Ajoute le bloc « Formulaire de contact » à une page : tes visiteurs pourront t&apos;écrire sans connaître ton e-mail ni ton pseudo
              Discord.
            </p>
          </div>
        </Panel>
      ) : (
        <Inbox initial={messages} showPage={!selected && pages.length > 1} />
      )}
    </div>
  );
}
