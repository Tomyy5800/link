import type { Metadata } from "next";
import { after } from "next/server";
import { ViewTransition } from "react";
import Link from "next/link";
import { LogOut, Plus, Shield } from "lucide-react";
import { AccountNav } from "@/components/account/AccountNav";
import { Logo } from "@/components/brand/Logo";
import { toOwnerProfile } from "@/lib/discord-cdn";
import { listAccountPages, requireAccountPage } from "@/lib/server/access";
import { AccountPalette } from "@/components/account/AccountPalette";
import { PaletteButton } from "@/components/ui/CommandPalette";
import { prisma } from "@/lib/server/db";
import { isAdmin } from "@/lib/server/entitlements";
import { maybeRunJobs } from "@/lib/server/jobs";
import { getSettings } from "@/lib/server/settings";

export const metadata: Metadata = { title: { default: "Mon espace", template: "%s · Mon espace" }, robots: { index: false } };

// « Mon espace » : pages, messages, compte, offre et partenariat du compte connecté.
export default async function AccountLayout({ children }: { children: React.ReactNode }) {
  const user = await requireAccountPage("/dashboard");
  const [settings, pages] = await Promise.all([getSettings(), listAccountPages(user.id)]);
  // Compteurs limités aux pages dont le rôle du compte ouvre les messages ou les commandes.
  const readable = pages.filter((p) => p.permissions.includes("messages.read")).map((p) => p.id);
  const sellable = pages.filter((p) => p.permissions.includes("orders")).map((p) => p.id);
  const [unread, newOrders] = await Promise.all([
    readable.length ? prisma.contactMessage.count({ where: { read: false, pageId: { in: readable } } }) : 0,
    sellable.length ? prisma.shopOrder.count({ where: { status: "new", pageId: { in: sellable } } }) : 0,
  ]);
  after(() => maybeRunJobs().catch(() => undefined));
  const profile = toOwnerProfile(user);

  return (
    <div className="bg-hud min-h-screen">
      <header className="sticky top-0 z-30 border-b border-ink-800 bg-ink-950/90 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-7xl items-center gap-3 px-4">
          <Logo />
          <span className="hud-label hidden rounded-sm border border-ink-600 px-2 py-0.5 text-[10px] text-ink-300 sm:inline">Mon espace</span>
          <div className="ml-auto flex items-center gap-2">
            <PaletteButton />
            {isAdmin(user) && (
              <Link
                href="/admin"
                className="hidden h-8 items-center gap-1.5 rounded-lg border border-claim/40 px-2.5 text-xs font-semibold text-claim transition hover:bg-claim/10 sm:inline-flex"
              >
                <Shield size={14} /> Admin
              </Link>
            )}
            <Link href="/dashboard/compte" className="flex items-center gap-2 rounded-lg px-1.5 py-1 text-sm text-ink-200 transition hover:bg-ink-800">
              <img src={profile.avatarUrl} alt="" className="h-7 w-7 rounded-full object-cover" />
              <span className="hidden max-w-[10rem] truncate sm:inline">{profile.globalName ?? profile.username}</span>
            </Link>
            <form action="/api/auth/logout" method="post">
              <button
                type="submit"
                className="flex h-8 w-8 items-center justify-center rounded-lg text-ink-400 transition hover:bg-ink-800 hover:text-ink-100"
                aria-label="Se déconnecter"
                title="Se déconnecter"
              >
                <LogOut size={16} />
              </button>
            </form>
          </div>
        </div>
      </header>
      <div className="mx-auto flex max-w-7xl flex-col gap-6 px-4 py-6 lg:flex-row">
        <aside className="space-y-4 lg:sticky lg:top-20 lg:w-56 lg:shrink-0 lg:self-start">
          <Link
            href="/dashboard/nouvelle"
            className="ui-press ui-shine hidden items-center justify-center gap-2 rounded-md bg-brand-500 px-3 py-2 text-sm font-semibold text-ink-950 transition hover:bg-brand-400 lg:flex"
          >
            <Plus size={16} /> Nouvelle page
          </Link>
          <AccountNav unread={unread} orders={newOrders} premiumName={settings.premiumName} />
        </aside>
        <main id="espace" className="min-w-0 flex-1 pb-16">
          {/* Fondu entre les sections, seulement quand on passe par le menu (type « ui-nav »). */}
          <ViewTransition update={{ "ui-nav": "ui-page", default: "none" }} default="none">
            <div>{children}</div>
          </ViewTransition>
        </main>
        <AccountPalette pages={pages.filter((p) => p.permissions.includes("content")).map((p) => ({ id: p.id, name: p.name, slug: p.slug }))} admin={isAdmin(user)} />
      </div>
    </div>
  );
}
