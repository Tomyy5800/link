import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Receipt } from "lucide-react";
import { SubscriptionManager } from "@/components/account/SubscriptionManager";
import { Chip, PageTitle, Panel, formatDate } from "@/components/admin/ui";
import { PlusCard } from "@/components/editor/PlusCard";
import { formatPrice } from "@/lib/features";
import { requireAccountPage } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { activeTier, entitlementsFrom } from "@/lib/server/entitlements";
import { env } from "@/lib/server/env";
import { currentSubscription, subscriptionGivesAccess } from "@/lib/server/payments";
import { tierName } from "@/lib/plans";
import { getSettings } from "@/lib/server/settings";

export const metadata: Metadata = { title: "Offre" };

const STATUS: Record<string, { label: string; tone: "mint" | "danger" | "muted" | "claim" }> = {
  paid: { label: "payé", tone: "mint" },
  pending: { label: "en attente", tone: "muted" },
  refunded: { label: "remboursé", tone: "claim" },
  failed: { label: "échoué", tone: "danger" },
  canceled: { label: "annulé", tone: "muted" },
  expired: { label: "expiré", tone: "muted" },
};

const KIND: Record<string, string> = { subscription: "Abonnement", item: "Boutique", plan: "Achat" };

// Offre du compte : abonnement (statut, résiliation, reprise), limites, historique des paiements et codes.
export default async function SubscriptionPage() {
  const user = await requireAccountPage("/dashboard/abonnement");
  const [settings, orders, subscription] = await Promise.all([
    getSettings(),
    prisma.order.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" }, take: 60 }),
    currentSubscription(user.id),
  ]);
  const rights = entitlementsFrom(user, settings);
  const bought = activeTier(user);
  const name = tierName(bought === "free" ? "plus" : bought, settings.premiumName);
  const limits = rights.limits;
  const live = subscription && subscriptionGivesAccess(subscription) ? subscription : null;
  const status = rights.partner
    ? `Partenaire officiel : ${name} est inclus tant que le partenariat dure.`
    : rights.freeForAll
      ? "Pour le lancement, toutes les formules sont offertes à tout le monde."
      : rights.admin && bought === "free"
        ? "Administrateur : toutes les fonctions sont débloquées pour les tester. Ton compte n'a pas d'abonnement."
      : rights.subscription
        ? rights.subscription.renews
          ? `Abonnement ${tierName(rights.subscription.tier, settings.premiumName)} : prochaine échéance le ${formatDate(rights.subscription.until)}.`
          : `Abonnement résilié : ${tierName(rights.subscription.tier, settings.premiumName)} reste actif jusqu'au ${formatDate(rights.subscription.until)}.`
        : rights.premium
          ? rights.premiumUntil
            ? `${name} est actif jusqu'au ${formatDate(rights.premiumUntil)}.`
            : `${name} est actif, sans limite de durée.`
          : "Tu utilises l'offre gratuite.";
  const visibleOrders = orders.filter((o) => o.status !== "pending" || Date.now() - o.createdAt.getTime() < 86_400_000);

  return (
    <div className="ui-stagger">
      <PageTitle
        title={bought === "free" ? "Ta formule" : name}
        description={status}
        aside={
          !rights.freeForAll && (
            <Link href="/plus" className="inline-flex items-center gap-1.5 rounded-md bg-claim px-3.5 py-2 text-sm font-semibold text-ink-950 transition hover:brightness-110">
              {live ? "Changer de formule" : bought === "team" ? "Voir les formules" : "S'abonner"} <ArrowRight size={15} />
            </Link>
          )
        }
      />

      {live && rights.subscription && (
        <Panel title="Abonnement" className="mb-4">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="space-y-1 text-sm">
              <p className="flex flex-wrap items-center gap-2 font-semibold text-ink-100">
                {tierName(rights.subscription.tier, settings.premiumName)} · {live.interval === "year" ? "annuel" : "mensuel"} · {formatPrice(live.amountCents)}
                {live.interval === "year" ? " / an" : " / mois"}
                {live.status === "past_due" ? (
                  <Chip tone="danger">paiement en retard</Chip>
                ) : rights.subscription.renews ? (
                  <Chip tone="mint">actif</Chip>
                ) : (
                  <Chip tone="claim">résilié</Chip>
                )}
              </p>
              <p className="text-ink-400">
                {live.status === "past_due"
                  ? "Le dernier prélèvement a échoué : Stripe réessaie automatiquement. Mets ta carte à jour pour garder ta formule."
                  : rights.subscription.renews
                    ? `Renouvelé automatiquement le ${formatDate(rights.subscription.until)}.`
                    : `Plus aucun prélèvement : ta formule s'arrête le ${formatDate(rights.subscription.until)}.`}
              </p>
            </div>
            <SubscriptionManager renews={rights.subscription.renews} until={rights.subscription.until} portal={env.stripe.configured} />
          </div>
        </Panel>
      )}

      <div className="grid gap-4 xl:grid-cols-[1fr_1fr]">
        <PlusCard entitlements={rights} />
        <Panel title="Tes limites">
          <dl className="grid grid-cols-2 gap-3 text-sm">
            {(
              [
                ["Pages", limits.pages],
                ["Collaborateurs par page", limits.members],
                ["Blocs par page", limits.blocks],
                ["Fichiers importés", limits.uploads],
                ["Image", `${limits.imageMb} Mo`],
                ["Audio / vidéo", limits.mediaMb ? `${limits.mediaMb} Mo` : "—"],
                ["Statistiques", `${limits.statsDays} jours`],
                ["Assistant IA", `${limits.aiMessages} messages / jour`],
                ["Rôles personnalisés", limits.roles && rights.features.customRoles ? `${limits.roles} par page` : "—"],
                ["Domaines personnels", limits.domains && rights.features.customDomains ? limits.domains : "—"],
              ] as const
            ).map(([label, value]) => (
              <div key={label} className="rounded-[2px] border border-ink-800 bg-ink-850/60 px-3 py-2">
                <dt className="text-xs text-ink-400">{label}</dt>
                <dd className="font-display text-lg font-bold tabular-nums">{value}</dd>
              </div>
            ))}
          </dl>
        </Panel>
      </div>

      <Panel title="Historique des paiements" className="mt-4">
        {visibleOrders.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-6 text-center">
            <Receipt size={24} className="text-ink-500" aria-hidden="true" />
            <p className="text-sm text-ink-400">Aucun paiement pour l&apos;instant.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[520px] text-sm">
              <thead>
                <tr className="text-left text-xs text-ink-400">
                  <th className="py-2 font-medium">Date</th>
                  <th className="py-2 font-medium">Type</th>
                  <th className="py-2 font-medium">Détail</th>
                  <th className="py-2 font-medium">Montant</th>
                  <th className="py-2 font-medium">Statut</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-800">
                {visibleOrders.map((o) => {
                  const s = STATUS[o.status] ?? { label: o.status, tone: "muted" as const };
                  return (
                    <tr key={o.id}>
                      <td className="py-2 pr-3 text-ink-300">{formatDate(o.paidAt ?? o.createdAt)}</td>
                      <td className="py-2 pr-3 text-ink-300">{KIND[o.kind] ?? "Achat"}</td>
                      <td className="py-2 pr-3 text-ink-100">
                        {o.offerName}
                        {o.note && <span className="ml-1.5 text-xs text-ink-400">({o.note})</span>}
                        {o.gift && <span className="ml-1.5 text-xs text-ink-400">(à offrir)</span>}
                      </td>
                      <td className="py-2 pr-3 font-mono tabular-nums">{formatPrice(o.amountCents)}</td>
                      <td className="py-2">
                        <Chip tone={s.tone}>{s.label}</Chip>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
        <p className="mt-3 text-xs text-ink-400">
          Paiements traités par Stripe : Link by Unclaim ne voit jamais tes données de carte.{" "}
          <Link href="/cgv" className="text-brand-300 hover:underline">
            Conditions de vente
          </Link>
        </p>
      </Panel>
    </div>
  );
}
