import type { Metadata } from "next";
import { cookies } from "next/headers";
import Link from "next/link";
import { Download, ExternalLink, Monitor, ShieldCheck, Smartphone } from "lucide-react";
import { DeleteAccount, SignOutOthers, SyncButton } from "@/components/account/AccountActions";
import { MyBadges, type MyBadge } from "@/components/account/MyBadges";
import { badgesOf, toPublicBadge } from "@/lib/server/badges";
import { Chip, PageTitle, Panel, formatDate } from "@/components/admin/ui";
import { ProviderIcon } from "@/components/auth/ProviderButton";
import { toOwnerProfile } from "@/lib/discord-cdn";
import { parseIdentities, providerMeta } from "@/lib/identity";
import { TERMS_UPDATED } from "@/lib/legal";
import { requireAccountPage } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { env } from "@/lib/server/env";
import { sha256 } from "@/lib/server/security";
import { SESSION_COOKIE } from "@/lib/server/unclaim-auth";

export const metadata: Metadata = { title: "Compte et données" };

/** « Chrome · Windows » à partir de l'agent utilisateur enregistré avec la session. */
function describeDevice(ua: string | null): { label: string; mobile: boolean } {
  if (!ua) return { label: "Appareil inconnu", mobile: false };
  const browser = /Edg\//.test(ua) ? "Edge" : /OPR\//.test(ua) ? "Opera" : /Firefox\//.test(ua) ? "Firefox" : /Chrome\//.test(ua) ? "Chrome" : /Safari\//.test(ua) ? "Safari" : "Navigateur";
  const os = /Windows/.test(ua) ? "Windows" : /Android/.test(ua) ? "Android" : /iPhone|iPad/.test(ua) ? "iOS" : /Mac OS X/.test(ua) ? "macOS" : /Linux/.test(ua) ? "Linux" : "";
  return { label: os ? `${browser} · ${os}` : browser, mobile: /Mobile|Android|iPhone/.test(ua) };
}

const UNLOCKS: Record<string, string> = {
  discord: "statut en direct, carte et serveur Discord",
  nationsglory: "badge « compte NationsGlory vérifié »",
  twitch: "pseudo Twitch vérifié",
};

// Compte : identité Unclaim Auth, comptes reliés, appareils, conditions, export et suppression.
export default async function AccountPage() {
  const user = await requireAccountPage("/dashboard/compte");
  const token = (await cookies()).get(SESSION_COOKIE)?.value ?? "";
  const [sessions, pageCount, owned] = await Promise.all([
    prisma.session.findMany({ where: { userId: user.id, expiresAt: { gt: new Date() } }, orderBy: { createdAt: "desc" }, take: 20 }),
    prisma.page.count({ where: { userId: user.id } }),
    badgesOf(user).catch(() => []),
  ]);
  const myBadges: MyBadge[] = owned.map((o) => ({
    id: o.badge.id,
    badge: toPublicBadge(o.badge),
    hidden: o.hidden,
    visibility: o.badge.visibility === "hidden" ? "hidden" : "public",
    until: o.grant?.expiresAt?.toISOString() ?? null,
  }));
  const profile = toOwnerProfile(user);
  const identities = parseIdentities(user.identities);
  const current = sha256(token);
  const portal = env.unclaim.configured ? `${env.unclaim.apiUrl}/apps` : null;

  return (
    <div className="ui-stagger">
      <PageTitle title="Compte et données" description="Ton identité vient d'Unclaim Auth : Link by Unclaim ne connaît ni ton mot de passe ni ton e-mail." />
      <div className="grid gap-4 xl:grid-cols-2">
        <Panel title="Profil">
          <div className="flex items-center gap-4">
            <img src={profile.avatarUrl} alt="" className="h-16 w-16 rounded-full object-cover ring-2 ring-ink-700" />
            <div className="min-w-0">
              <p className="flex flex-wrap items-center gap-2 text-lg font-semibold">
                {profile.globalName ?? profile.username}
                {user.verified && <Chip tone="mint">vérifié</Chip>}
                {user.partner && <Chip tone="brand">partenaire</Chip>}
              </p>
              <p className="flex items-center gap-1.5 text-sm text-ink-400">
                <ProviderIcon provider={user.provider} size={14} /> Connecté·e avec {providerMeta(user.provider).name}
              </p>
            </div>
          </div>
          <dl className="mt-4 grid grid-cols-[auto_1fr] gap-x-4 gap-y-1.5 text-sm">
            <dt className="text-ink-400">ID Unclaim</dt>
            <dd className="truncate font-mono text-xs leading-5 text-ink-200 select-all">{user.unclaimId ?? "—"}</dd>
            <dt className="text-ink-400">Membre depuis</dt>
            <dd className="text-ink-200">{formatDate(user.createdAt)}</dd>
            <dt className="text-ink-400">Dernière connexion</dt>
            <dd className="text-ink-200">{formatDate(user.lastLoginAt, true)}</dd>
          </dl>
          <div className="mt-4 flex flex-wrap items-center gap-3">
            {env.unclaim.configured && user.unclaimId && <SyncButton />}
            {portal && (
              <a href={portal} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 text-sm text-brand-300 hover:underline">
                Gérer mon compte Unclaim <ExternalLink size={13} />
              </a>
            )}
          </div>
        </Panel>

        <Panel title="Mes badges">
          <MyBadges initial={myBadges} />
          <p className="mt-3 text-xs text-ink-500">Les badges sont attribués par le serveur (équipe, formule, rôles Discord, boutique officielle) ; tu choisis seulement lesquels afficher sur tes pages.</p>
        </Panel>

        <Panel title="Comptes reliés">
          <ul className="space-y-2">
            {identities.length === 0 && <li className="text-sm text-ink-400">Aucun autre compte relié pour l&apos;instant.</li>}
            {identities.map((id) => (
              <li key={`${id.provider}-${id.username}`} className="flex items-center gap-2.5 text-sm">
                <span className="flex h-8 w-8 items-center justify-center rounded-md border border-ink-700 bg-ink-850 text-ink-200">
                  <ProviderIcon provider={id.provider} size={16} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-ink-100">{providerMeta(id.provider).name}</span>
                  <span className="block truncate text-xs text-ink-400">{id.username ?? "relié"}</span>
                </span>
                {UNLOCKS[id.provider] && <span className="hidden text-right text-xs text-ink-500 sm:block">{UNLOCKS[id.provider]}</span>}
              </li>
            ))}
          </ul>
          <p className="mt-3 text-xs leading-relaxed text-ink-400">
            Relie Discord, Google, Microsoft, Twitch ou NationsGlory dans Unclaim Auth : tu pourras te connecter avec n&apos;importe lequel, et
            certains débloquent des blocs (statut Discord, badge NationsGlory).
          </p>
        </Panel>

        <Panel title="Appareils connectés">
          <ul className="space-y-2">
            {sessions.map((s) => {
              const device = describeDevice(s.userAgent);
              const Icon = device.mobile ? Smartphone : Monitor;
              return (
                <li key={s.id} className="flex items-center gap-2.5 text-sm">
                  <Icon size={16} className="text-ink-400" />
                  <span className="min-w-0 flex-1 truncate text-ink-200">{device.label}</span>
                  {s.id === current ? <Chip tone="mint">cet appareil</Chip> : <span className="text-xs text-ink-500">depuis le {formatDate(s.createdAt)}</span>}
                </li>
              );
            })}
          </ul>
          <div className="mt-4">
            <SignOutOthers others={sessions.filter((s) => s.id !== current).length} />
          </div>
        </Panel>

        <Panel title="Conditions et confidentialité">
          <p className="flex items-start gap-2 text-sm text-ink-300">
            <ShieldCheck size={16} className="mt-0.5 shrink-0 text-mint" />
            {user.termsAcceptedAt
              ? `Conditions d'utilisation acceptées le ${formatDate(user.termsAcceptedAt, true)} (version du ${TERMS_UPDATED}).`
              : "Conditions d'utilisation à accepter."}
          </p>
          <ul className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-sm">
            <li>
              <Link href="/cgu" className="text-brand-300 hover:underline">
                Conditions d&apos;utilisation
              </Link>
            </li>
            <li>
              <Link href="/confidentialite" className="text-brand-300 hover:underline">
                Confidentialité
              </Link>
            </li>
            <li>
              <Link href="/cgv" className="text-brand-300 hover:underline">
                Conditions de vente
              </Link>
            </li>
          </ul>
          <div className="mt-4 border-t border-ink-800 pt-4">
            <p className="text-sm text-ink-300">
              Télécharge tout ce que Link by Unclaim conserve sur toi : compte, pages, blocs, équipes, messages reçus, statistiques et achats.
            </p>
            <a
              href="/api/me/export"
              download
              className="mt-3 inline-flex items-center gap-2 rounded-md border border-ink-700 px-3 py-1.5 text-sm font-medium text-ink-200 transition hover:border-ink-500"
            >
              <Download size={15} /> Télécharger mes données (JSON)
            </a>
          </div>
        </Panel>
      </div>

      <section className="mt-4 rounded-[2px] border border-danger/40 bg-danger/5 p-4">
        <h2 className="hud-label mb-3 text-danger">Supprimer mon compte</h2>
        <DeleteAccount pages={pageCount} />
      </section>
    </div>
  );
}
