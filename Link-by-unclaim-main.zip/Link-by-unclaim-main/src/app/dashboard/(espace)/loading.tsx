// Chargement d'une section de « Mon espace ».
export default function AccountLoading() {
  const bar = "ui-skeleton rounded-xl";
  return (
    <div className="space-y-4" aria-busy="true" aria-label="Chargement">
      <div className={`${bar} h-8 w-64`} />
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {Array.from({ length: 4 }, (_, i) => (
          <div key={i} className={`${bar} h-20`} />
        ))}
      </div>
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {Array.from({ length: 3 }, (_, i) => (
          <div key={i} className={`${bar} h-40`} />
        ))}
      </div>
    </div>
  );
}
