import type { Metadata } from "next";
import Link from "next/link";
import { BadgeCheck, Clock, Handshake } from "lucide-react";
import { PartnerForm } from "@/components/account/PartnerForm";
import { Chip, PageTitle, Panel, formatDate } from "@/components/admin/ui";
import { PARTNER_KINDS, PARTNER_STATUS_LABELS, partnerPerks, type PartnerKind } from "@/lib/partners";
import { requireAccountPage } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { getSettings } from "@/lib/server/settings";

export const metadata: Metadata = { title: "Partenariat" };

// Programme partenaires : avantages, statut et candidature.
export default async function PartnershipPage() {
  const user = await requireAccountPage("/dashboard/partenariat");
  const [settings, applications] = await Promise.all([
    getSettings(),
    prisma.partnerApplication.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" }, take: 5 }),
  ]);
  const perks = partnerPerks(settings.limits.partner, settings.premiumName);
  const pending = applications.find((a) => a.status === "pending");
  const last = applications[0];

  return (
    <div className="ui-stagger">
      <PageTitle
        title="Partenariat"
        description="Pour les créateurs, serveurs, nations, équipes et événements qui veulent aller plus loin avec Link by Unclaim."
        aside={
          <Link href="/partenaires" className="text-sm text-brand-300 hover:underline">
            Voir l&apos;annuaire des partenaires
          </Link>
        }
      />

      {user.partner && (
        <div className="mb-4 flex items-start gap-3 rounded-[2px] border border-brand-500/40 bg-brand-500/10 p-4">
          <BadgeCheck size={22} className="mt-0.5 shrink-0 text-brand-300" />
          <div>
            <p className="font-semibold">Tu es partenaire officiel{user.partnerSince ? ` depuis le ${formatDate(user.partnerSince)}` : ""}.</p>
            <p className="mt-1 text-sm text-ink-300">Merci ! Tes avantages sont actifs sur toutes tes pages.</p>
          </div>
        </div>
      )}

      <Panel title={user.partner ? "Tes avantages" : "Ce que le partenariat apporte"}>
        <ul className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {perks.map((perk) => (
            <li key={perk.title} className="rounded-[2px] border border-ink-800 bg-ink-850/60 p-3">
              <p className="flex items-center gap-2 font-semibold text-ink-100">
                <Handshake size={15} className="text-claim" /> {perk.title}
              </p>
              <p className="mt-1 text-sm text-ink-400">{perk.text}</p>
            </li>
          ))}
        </ul>
      </Panel>

      {!user.partner && (
        <Panel title={pending ? "Ta candidature" : "Candidater"} className="mt-4">
          {pending ? (
            <div className="flex items-start gap-3">
              <Clock size={20} className="mt-0.5 shrink-0 text-claim" />
              <div className="text-sm">
                <p className="font-semibold text-ink-100">
                  {pending.name} · {PARTNER_KINDS[pending.kind as PartnerKind] ?? pending.kind}
                </p>
                <p className="mt-1 text-ink-300">Envoyée le {formatDate(pending.createdAt)}, en cours d&apos;examen par l&apos;équipe.</p>
              </div>
            </div>
          ) : (
            <>
              {last?.status === "refused" && (
                <p className="mb-4 rounded-[2px] border border-ink-700 bg-ink-850/60 p-3 text-sm text-ink-300">
                  Ta dernière candidature ({formatDate(last.createdAt)}) n&apos;a pas été retenue
                  {last.reviewNote ? ` : ${last.reviewNote}` : "."} Tu peux en envoyer une nouvelle.
                </p>
              )}
              <PartnerForm />
            </>
          )}
        </Panel>
      )}

      {applications.length > 0 && (
        <Panel title="Historique" className="mt-4">
          <ul className="space-y-2 text-sm">
            {applications.map((a) => (
              <li key={a.id} className="flex flex-wrap items-center gap-2">
                <span className="text-ink-200">{a.name}</span>
                <span className="text-xs text-ink-500">{formatDate(a.createdAt)}</span>
                <Chip tone={a.status === "accepted" ? "mint" : a.status === "refused" ? "danger" : "claim"}>
                  {PARTNER_STATUS_LABELS[a.status as keyof typeof PARTNER_STATUS_LABELS] ?? a.status}
                </Chip>
              </li>
            ))}
          </ul>
        </Panel>
      )}
    </div>
  );
}
