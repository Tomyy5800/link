import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, ShoppingBag } from "lucide-react";
import { OrdersBoard, type OrderRow } from "@/components/account/OrdersBoard";
import { PageTitle, Panel } from "@/components/admin/ui";
import { listAccountPages, requireAccountPage } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { isOrderStatus, parseOrderItems } from "@/lib/shop";

export const metadata: Metadata = { title: "Commandes" };

// Demandes de commande reçues par le bloc « Boutique » de toutes les pages du compte.
export default async function OrdersPage({ searchParams }: { searchParams: Promise<{ page?: string }> }) {
  const user = await requireAccountPage("/dashboard/commandes");
  // Seulement les pages dont le rôle du compte permet de gérer les commandes (coordonnées des acheteurs).
  const pages = (await listAccountPages(user.id)).filter((p) => p.permissions.includes("orders"));
  const filter = (await searchParams).page;
  const selected = pages.find((p) => p.id === filter);
  const ids = selected ? [selected.id] : pages.map((p) => p.id);

  const rows = await prisma.shopOrder.findMany({
    where: { pageId: { in: ids } },
    orderBy: { createdAt: "desc" },
    take: 300,
  });
  const byId = new Map(pages.map((p) => [p.id, p]));
  const orders: OrderRow[] = rows.map((o) => {
    const page = byId.get(o.pageId)!;
    return {
      id: o.id,
      pageId: o.pageId,
      pageName: page.name,
      pageSlug: page.slug,
      reference: o.id.slice(-6).toUpperCase(),
      items: parseOrderItems(o.items),
      total: o.total,
      currency: o.currency,
      name: o.name,
      contact: o.contact,
      note: o.note,
      status: isOrderStatus(o.status) ? o.status : "new",
      createdAt: o.createdAt.toISOString(),
      canEdit: page.permissions.includes("orders"),
    };
  });
  const editable = pages.find((p) => p.permissions.includes("content"));

  return (
    <div className="ui-stagger">
      <PageTitle title="Commandes" description="Demandes reçues par le bloc « Boutique » de tes pages. Le paiement se règle directement avec l'acheteur." />
      {pages.length > 1 && (
        <nav className="mb-4 flex flex-wrap gap-1.5" aria-label="Filtrer par page">
          <Link
            href="/dashboard/commandes"
            aria-current={!selected ? "page" : undefined}
            className={`rounded-md border px-2.5 py-1 text-xs ${!selected ? "border-brand-400 bg-brand-500/10 text-ink-100" : "border-ink-700 text-ink-400 hover:text-ink-200"}`}
          >
            Toutes les pages
          </Link>
          {pages.map((p) => (
            <Link
              key={p.id}
              href={`/dashboard/commandes?page=${p.id}`}
              aria-current={selected?.id === p.id ? "page" : undefined}
              className={`rounded-md border px-2.5 py-1 text-xs ${selected?.id === p.id ? "border-brand-400 bg-brand-500/10 text-ink-100" : "border-ink-700 text-ink-400 hover:text-ink-200"}`}
            >
              {p.name}
            </Link>
          ))}
        </nav>
      )}
      {orders.length === 0 ? (
        <Panel>
          <div className="flex flex-col items-center gap-3 py-10 text-center">
            <span className="animate-float flex h-14 w-14 items-center justify-center rounded-2xl border border-pink-400/40 bg-pink-400/10 text-pink-300">
              <ShoppingBag size={26} />
            </span>
            <p className="font-semibold">Aucune commande pour l&apos;instant</p>
            <p className="max-w-md text-sm text-ink-400">
              Ajoute le bloc « Boutique » à ta page : photos, prix, promos, variantes. Choisis « Commande via le panier » sur un produit et les demandes
              arriveront ici, avec le contact de l&apos;acheteur.
            </p>
            {editable && (
              <Link
                href={`/dashboard/pages/${editable.id}`}
                className="ui-press ui-shine mt-2 inline-flex items-center gap-2 rounded-md bg-brand-500 px-4 py-2 text-sm font-semibold text-ink-950 transition hover:bg-brand-400"
              >
                Ouvrir l&apos;éditeur <ArrowRight size={16} />
              </Link>
            )}
          </div>
        </Panel>
      ) : (
        <OrdersBoard initial={orders} showPage={!selected && pages.length > 1} />
      )}
    </div>
  );
}
