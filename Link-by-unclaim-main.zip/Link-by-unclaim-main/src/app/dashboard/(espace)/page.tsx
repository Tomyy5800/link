import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowRight, Bot, ExternalLink, Eye, Handshake, Inbox, Layers, Lightbulb, Lock, Mail, MousePointerClick, Pencil, Plus, ShoppingBag, Sparkles, Users } from "lucide-react";
import { DuplicateButton } from "@/components/account/DuplicateButton";
import { Milestones } from "@/components/account/Milestones";
import { Chip } from "@/components/admin/ui";
import { CopyButton } from "@/components/ui/CopyButton";
import { CountUp } from "@/components/ui/CountUp";
import { Sparkline } from "@/components/ui/Sparkline";
import { PageThumbnail } from "@/components/account/PageThumbnail";
import { listAccountPages, requireAccountPage, ROLE_LABELS, type AccountPage } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { activeTier, entitlementsFrom } from "@/lib/server/entitlements";
import { tierName } from "@/lib/plans";
import { env } from "@/lib/server/env";
import { todayKey } from "@/lib/server/pages";
import { getSettings } from "@/lib/server/settings";
import { ORDER_STATUS_LABEL, formatMoney, isOrderStatus, parseOrderItems } from "@/lib/shop";

export const metadata: Metadata = { title: "Mes pages" };

/** Une astuce par jour, pour découvrir ce que le site sait faire. */
const TIPS = [
  "Ctrl+K ouvre la palette de commandes : ajoute un bloc, change d'onglet ou de page sans lâcher le clavier.",
  "Les automatisations changent ta page toute seule : un bandeau pendant tes lives, un thème festif le jour de ton anniversaire.",
  "Colle ton adresse dans ta bio Discord (Paramètres › Profils › À propos de moi) : elle s'affiche avec un aperçu à tes couleurs.",
  "Le QR code de ta page est dans Réglages : parfait pour un écran de fin de stream ou une affiche d'événement.",
  "Invite ton équipe sur une page : chacun garde son compte, toi tu gardes la main (Réglages › Équipe).",
  "Le bloc « Formulaire de contact » protège ton e-mail : les messages arrivent ici, dans Messages.",
  "Le bloc « Profil de jeu » affiche tes stats Chess.com, Lichess, Steam ou Roblox en direct, et ta tête Minecraft.",
  "Programme un bloc entre deux dates (menu du bloc › Programmer) pour une promo, un tournoi ou une sortie.",
  "L'assistant crée une page complète en discutant, en moins de cinq minutes : idéal pour un nouveau projet.",
  "Les polices Google Fonts donnent du caractère à ta page : Apparence › Typographie.",
];

const DAYS = 7;

function StatTile({
  icon: Icon,
  label,
  value,
  hint,
  spark,
  tone = "brand",
}: {
  icon: React.ComponentType<{ size?: number; className?: string }>;
  label: string;
  value: React.ReactNode;
  hint?: React.ReactNode;
  spark?: number[];
  tone?: "brand" | "claim" | "mint";
}) {
  const color = tone === "claim" ? "#ffc247" : tone === "mint" ? "#00bc7d" : "#22c9e8";
  return (
    <div data-spotlight className="ui-spotlight rounded-xl border border-ink-700 bg-ink-900/80 p-4">
      <div className="flex items-center justify-between gap-2">
        <p className="hud-label text-[10px] text-ink-500">{label}</p>
        <span className="flex h-7 w-7 items-center justify-center rounded-md" style={{ background: `${color}1f`, color }}>
          <Icon size={15} />
        </span>
      </div>
      <div className="mt-2 flex items-end justify-between gap-3">
        <p className="min-w-0 truncate font-display text-2xl font-bold sm:text-3xl" style={tone === "claim" ? { color } : undefined}>
          {value}
        </p>
        {spark && spark.some((v) => v > 0) && <Sparkline values={spark} color={color} width={96} height={32} className="mb-1 shrink-0" />}
      </div>
      {hint && <p className="mt-1 truncate text-xs text-ink-400">{hint}</p>}
    </div>
  );
}

function PageCard({
  page,
  host,
  appUrl,
  views,
  clicks,
  blocks,
}: {
  page: AccountPage;
  host: string;
  appUrl: string;
  views: number[];
  clicks: number;
  blocks: { type: string; width: string }[];
}) {
  const weekViews = views.reduce((a, b) => a + b, 0);
  return (
    <li data-spotlight className="ui-spotlight ui-lift group flex flex-col overflow-hidden rounded-xl border border-ink-700 bg-ink-900/90">
      {/* Miniature de la page (elle « défile » un peu au survol) */}
      <Link href={`/dashboard/pages/${page.id}`} className="relative block h-44 overflow-hidden border-b border-ink-800" tabIndex={-1} aria-hidden="true">
        <PageThumbnail theme={page.theme} avatar={page.avatar} name={page.displayName} hasBio={page.hasBio} blocks={blocks} />
        <div className="absolute inset-x-0 bottom-0 h-14 bg-gradient-to-b from-transparent to-ink-900/95" />
        <div className="absolute top-3 right-3 flex items-center gap-1.5">
          {page.suspended ? (
            <Chip tone="danger">suspendue</Chip>
          ) : page.published ? (
            <span className="inline-flex items-center gap-1.5 rounded-full border border-mint/40 bg-mint/10 px-2 py-0.5 text-[11px] font-semibold text-mint">
              <span className="ui-live-dot !h-1.5 !w-1.5" /> en ligne
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 rounded-full border border-ink-500 bg-ink-950/80 px-2 py-0.5 text-[11px] font-semibold text-ink-200 backdrop-blur">
              <Lock size={10} /> privée
            </span>
          )}
        </div>
      </Link>
      <div className="px-4 pt-3">
        <p className="truncate font-display text-lg font-semibold text-ink-100">{page.name}</p>
        <a href={`/${page.slug}`} target="_blank" rel="noopener noreferrer" className="block truncate font-mono text-xs text-ink-400 hover:text-ink-100">
          {host}/<span style={{ color: page.accent }}>{page.slug}</span>
        </a>
        <div className="mt-2 flex flex-wrap gap-1.5">
          {page.role !== "owner" && (
            <Chip tone="brand">
              {ROLE_LABELS[page.role]} · {page.ownerName}
            </Chip>
          )}
          {page.role === "owner" && page.members > 0 && (
            <Chip>
              <Users size={11} /> {page.members + 1}
            </Chip>
          )}
          {page.unread > 0 && (
            <Chip tone="claim">
              {page.unread} message{page.unread > 1 ? "s" : ""}
            </Chip>
          )}
        </div>
      </div>
      <div className="mt-3 grid grid-cols-[1fr_auto] items-end gap-3 border-y border-ink-800 px-4 py-3">
        <dl className="flex gap-4">
          <div>
            <dt className="hud-label whitespace-nowrap text-[9px] text-ink-500">Vues 7 j</dt>
            <dd className="font-display text-xl font-bold">
              <CountUp value={weekViews} />
            </dd>
          </div>
          <div>
            <dt className="hud-label whitespace-nowrap text-[9px] text-ink-500">Clics 7 j</dt>
            <dd className="font-display text-xl font-bold">
              <CountUp value={clicks} />
            </dd>
          </div>
          <div>
            <dt className="hud-label whitespace-nowrap text-[9px] text-ink-500">Total</dt>
            <dd className="font-display text-xl font-bold">
              <CountUp value={page.views} />
            </dd>
          </div>
        </dl>
        {weekViews > 0 && <Sparkline values={views} color={page.accent} width={84} height={30} />}
      </div>
      <div className="mt-auto flex gap-2 p-3">
        <Link
          href={`/dashboard/pages/${page.id}`}
          className="ui-press inline-flex flex-1 items-center justify-center gap-1.5 rounded-md bg-ink-100 px-3 py-2 text-sm font-semibold text-ink-950 transition hover:bg-white"
        >
          {page.role === "viewer" ? <Eye size={15} /> : <Pencil size={15} />} {page.role === "viewer" ? "Statistiques" : "Modifier"}
        </Link>
        <a
          href={`/${page.slug}`}
          target="_blank"
          rel="noopener noreferrer"
          className="ui-press inline-flex items-center justify-center rounded-md border border-ink-600 px-2.5 py-2 text-ink-300 transition hover:border-ink-400 hover:text-ink-100"
          title="Voir la page"
          aria-label={`Voir la page ${page.name}`}
        >
          <ExternalLink size={15} />
        </a>
        <CopyButton
          value={`${appUrl}/${page.slug}`}
          className="inline-flex items-center justify-center rounded-md border border-ink-600 px-2.5 py-2 text-ink-300 transition hover:border-ink-400 hover:text-ink-100"
        />
        {page.role === "owner" && <DuplicateButton pageId={page.id} name={page.name} />}
      </div>
    </li>
  );
}

/** « il y a 5 min », « il y a 2 j ». */
function since(date: Date): string {
  const minutes = Math.round((Date.now() - date.getTime()) / 60_000);
  if (minutes < 1) return "à l'instant";
  if (minutes < 60) return `il y a ${minutes} min`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `il y a ${hours} h`;
  const days = Math.round(hours / 24);
  return days < 30 ? `il y a ${days} j` : date.toLocaleDateString("fr-FR", { dateStyle: "medium" });
}

/** Somme des commandes à encaisser, par devise (« 84 € » ou « 84 € + 12 $ »). */
function pendingSum(rows: { total: number | null; currency: string }[]): string | null {
  const sums = new Map<string, number>();
  for (const r of rows) if (r.total !== null) sums.set(r.currency, (sums.get(r.currency) ?? 0) + r.total);
  return sums.size ? [...sums.entries()].map(([currency, cents]) => formatMoney(cents, currency)).join(" + ") : null;
}

/**
 * Le « cockpit » en haut de l'espace : salutation, raccourcis et la page la plus vue en grand,
 * qui s'incline sous le pointeur, prête à être modifiée, ouverte ou partagée.
 */
function Cockpit({
  title,
  subtitle,
  page,
  host,
  appUrl,
  blocks,
  canCreate,
}: {
  title: React.ReactNode;
  subtitle: string;
  page: AccountPage | undefined;
  host: string;
  appUrl: string;
  blocks: { type: string; width: string }[];
  canCreate: boolean;
}) {
  return (
    <section className="relative isolate mb-6 overflow-hidden rounded-2xl border border-ink-700 bg-ink-900/70 p-5 sm:p-7">
      <div className="pointer-events-none absolute inset-0 -z-10" aria-hidden="true">
        <span className="ui-ambient -top-24 -left-20 h-72 w-72 bg-brand-500" />
        <span className="ui-ambient -right-16 -bottom-28 h-80 w-80 bg-[#7c5cf5] [animation-delay:-9s]" />
        <span className="absolute inset-0 bg-[linear-gradient(rgb(255_255_255/0.04)_1px,transparent_1px),linear-gradient(90deg,rgb(255_255_255/0.04)_1px,transparent_1px)] [mask-image:radial-gradient(ellipse_at_70%_40%,#000,transparent_70%)] bg-[size:32px_32px]" />
      </div>
      <div className="grid items-center gap-8 lg:grid-cols-[1.25fr_0.75fr]">
        <div>
          <p className="hud-label flex items-center gap-2 text-brand-300">
            <span className="ui-live-dot !h-1.5 !w-1.5 text-mint" /> Mon espace
          </p>
          <h1 className="mt-2 font-display text-3xl font-bold tracking-tight sm:text-4xl">{title}</h1>
          <p className="mt-2 max-w-xl text-sm text-ink-300">{subtitle}</p>
          <div className="mt-5 flex flex-wrap gap-2">
            {page && page.role !== "viewer" && (
              <Link
                href={`/dashboard/pages/${page.id}`}
                className="ui-press ui-shine inline-flex items-center gap-2 rounded-lg bg-brand-500 px-4 py-2 text-sm font-semibold text-ink-950 transition hover:bg-brand-400"
              >
                <Pencil size={15} /> Modifier ma page
              </Link>
            )}
            {page && (
              <a
                href={`/${page.slug}`}
                target="_blank"
                rel="noopener noreferrer"
                className="ui-press inline-flex items-center gap-2 rounded-lg border border-ink-500 px-4 py-2 text-sm font-semibold text-ink-100 transition hover:border-ink-300 hover:bg-ink-800"
              >
                <ExternalLink size={15} /> Voir en ligne
              </a>
            )}
            {page && (
              <CopyButton
                value={`${appUrl}/${page.slug}`}
                label="Copier le lien"
                className="ui-press inline-flex items-center gap-2 rounded-lg border border-ink-600 px-3.5 py-2 text-sm text-ink-200 transition hover:border-ink-400 hover:text-ink-100"
              >
                Copier le lien
              </CopyButton>
            )}
            {canCreate && (
              <Link
                href="/dashboard/nouvelle"
                className="ui-press inline-flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold text-brand-300 transition hover:bg-brand-500/10 lg:hidden"
              >
                <Plus size={15} /> Nouvelle page
              </Link>
            )}
          </div>
        </div>
        {page && (
          <Link
            href={`/dashboard/pages/${page.id}`}
            data-tilt="8"
            className="ui-tilt group relative mx-auto block h-56 w-full max-w-xs overflow-hidden rounded-2xl border border-ink-600 shadow-[0_30px_60px_-30px_#000] sm:h-64"
            aria-label={`Modifier ${page.name}`}
          >
            <PageThumbnail theme={page.theme} avatar={page.avatar} name={page.displayName} hasBio={page.hasBio} blocks={blocks} />
            <span className="absolute inset-x-0 bottom-0 flex items-center justify-between gap-2 bg-gradient-to-t from-ink-950/95 to-transparent px-3 pt-8 pb-3">
              <span className="min-w-0">
                <span className="block truncate text-sm font-semibold text-ink-50">{page.name}</span>
                <span className="block truncate font-mono text-[11px] text-ink-300">
                  {host}/<span style={{ color: page.accent }}>{page.slug}</span>
                </span>
              </span>
              {page.published && !page.suspended && (
                <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-mint/40 bg-mint/10 px-2 py-0.5 text-[11px] font-semibold text-mint">
                  <span className="ui-live-dot !h-1.5 !w-1.5" /> en ligne
                </span>
              )}
            </span>
          </Link>
        )}
      </div>
    </section>
  );
}

/** « Bonjour » ou « Bonsoir », à l'heure de Paris. */
function greeting(now = new Date()): string {
  const hour = Number(new Intl.DateTimeFormat("fr-FR", { hour: "numeric", hourCycle: "h23", timeZone: "Europe/Paris" }).format(now));
  return hour >= 18 || hour < 5 ? "Bonsoir" : "Bonjour";
}

// Vue d'ensemble : toutes les pages du compte (et celles partagées avec lui), chiffres de la semaine.
export default async function AccountHome() {
  const user = await requireAccountPage("/dashboard");
  const [pages, settings] = await Promise.all([listAccountPages(user.id), getSettings()]);
  // Première visite : l'assistant crée la page en discutant (le formulaire reste accessible).
  if (pages.length === 0) redirect("/dashboard/assistant");

  const rights = entitlementsFrom(user, settings);
  const ids = pages.map((p) => p.id);
  const days = Array.from({ length: DAYS }, (_, i) => todayKey(new Date(Date.now() - (DAYS - 1 - i) * 86_400_000)));
  const [viewRows, clickRows, blockRows, recentMessages, recentOrders, openOrders] = await Promise.all([
    prisma.pageView.groupBy({ by: ["pageId", "day"], where: { pageId: { in: ids }, day: { gte: days[0] } }, _count: { _all: true } }),
    prisma.linkClick.groupBy({ by: ["pageId", "day"], where: { pageId: { in: ids }, day: { gte: days[0] } }, _sum: { count: true } }),
    // Blocs visibles, pour dessiner la miniature de chaque page.
    prisma.block.findMany({ where: { pageId: { in: ids }, visible: true }, orderBy: { position: "asc" }, select: { pageId: true, type: true, width: true } }),
    // Fil d'activité : derniers messages et dernières commandes.
    prisma.contactMessage.findMany({ where: { pageId: { in: ids } }, orderBy: { createdAt: "desc" }, take: 6, select: { id: true, pageId: true, name: true, message: true, read: true, createdAt: true } }),
    prisma.shopOrder.findMany({ where: { pageId: { in: ids } }, orderBy: { createdAt: "desc" }, take: 6, select: { id: true, pageId: true, name: true, items: true, total: true, currency: true, status: true, createdAt: true } }),
    prisma.shopOrder.findMany({ where: { pageId: { in: ids }, status: { in: ["new", "accepted"] } }, take: 500, select: { total: true, currency: true, status: true } }),
  ]);
  const series = (rows: { pageId: string; day: string; value: number }[], pageId?: string) =>
    days.map((day) => rows.filter((r) => r.day === day && (!pageId || r.pageId === pageId)).reduce((n, r) => n + r.value, 0));
  const views = viewRows.map((r) => ({ pageId: r.pageId, day: r.day, value: r._count._all }));
  const clicks = clickRows.map((r) => ({ pageId: r.pageId, day: r.day, value: r._sum.count ?? 0 }));
  const allViews = series(views);
  const allClicks = series(clicks);
  const sum = (values: number[]) => values.reduce((a, b) => a + b, 0);

  const owned = pages.filter((p) => p.role === "owner");
  const shared = pages.filter((p) => p.role !== "owner");
  const unread = pages.reduce((n, p) => n + p.unread, 0);
  const host = new URL(env.appUrl).host;
  const name = user.globalName ?? user.username;
  const offer = rights.partner
    ? "Partenaire"
    : rights.admin
      ? "Administrateur"
      : rights.freeForAll
        ? "Tout offert"
        : tierName(activeTier(user), settings.premiumName);
  const canCreate = owned.length < rights.limits.pages && (settings.registrationsOpen || rights.admin);
  const weekViews = sum(allViews);
  const newOrders = openOrders.filter((o) => o.status === "new").length;
  const pending = pendingSum(openOrders);
  const featured = [...owned].sort((a, b) => b.views - a.views)[0] ?? pages[0];
  const pageName = new Map(pages.map((p) => [p.id, p.name]));
  const activity = [
    ...recentMessages.map((m) => ({
      key: `m-${m.id}`,
      kind: "message" as const,
      at: m.createdAt,
      title: `${m.name} t'a écrit`,
      detail: m.message,
      page: pageName.get(m.pageId) ?? "",
      fresh: !m.read,
      href: `/dashboard/messages?page=${m.pageId}`,
    })),
    ...recentOrders.map((o) => {
      const items = parseOrderItems(o.items);
      const count = items.reduce((n, i) => n + i.quantity, 0);
      return {
        key: `o-${o.id}`,
        kind: "order" as const,
        at: o.createdAt,
        title: `${o.name} a commandé ${count} article${count > 1 ? "s" : ""}`,
        detail: [items.map((i) => i.name).join(", "), o.total !== null ? formatMoney(o.total, o.currency) : "", isOrderStatus(o.status) ? ORDER_STATUS_LABEL[o.status] : ""]
          .filter(Boolean)
          .join(" · "),
        page: pageName.get(o.pageId) ?? "",
        fresh: o.status === "new",
        href: `/dashboard/commandes?page=${o.pageId}`,
      };
    }),
  ]
    .sort((a, b) => b.at.getTime() - a.at.getTime())
    .slice(0, 6);
  const subtitle = newOrders
    ? `${newOrders} nouvelle${newOrders > 1 ? "s" : ""} commande${newOrders > 1 ? "s t'attendent" : " t'attend"} dans ta boutique.`
    : unread
    ? `Tu as ${unread} message${unread > 1 ? "s" : ""} non lu${unread > 1 ? "s" : ""}.`
    : weekViews
      ? `Tes pages ont reçu ${weekViews} visite${weekViews > 1 ? "s" : ""} ces 7 derniers jours.`
      : "Partage ton lien dans ta bio pour recevoir tes premières visites.";

  return (
    <div className="ui-stagger">
      <Cockpit
        title={
          <>
            {greeting()}, {name} <span className="ui-wave">👋</span>
          </>
        }
        subtitle={subtitle}
        page={featured}
        host={host}
        appUrl={env.appUrl}
        blocks={featured ? blockRows.filter((b) => b.pageId === featured.id) : []}
        canCreate={canCreate}
      />

      <Milestones pages={pages.filter((p) => p.role !== "viewer").map((p) => ({ id: p.id, name: p.name, slug: p.slug, views: p.views }))} />

      {settings.announcement && (
        <p role="status" className="mb-5 rounded-xl border border-brand-500/30 bg-brand-500/10 px-4 py-3 text-sm text-ink-100">
          {settings.announcement}
        </p>
      )}

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <StatTile
          icon={Layers}
          label="Pages"
          value={`${owned.length}/${rights.limits.pages}`}
          hint={shared.length ? `+ ${shared.length} partagée(s) avec toi` : "dont tu es propriétaire"}
        />
        <StatTile icon={Eye} label="Vues · 7 jours" value={<CountUp value={weekViews} />} hint="toutes tes pages" spark={allViews} />
        <StatTile icon={MousePointerClick} label="Clics · 7 jours" value={<CountUp value={sum(allClicks)} />} hint="liens, réseaux, dossiers" spark={allClicks} tone="mint" />
        {openOrders.length || recentOrders.length ? (
          <StatTile
            icon={ShoppingBag}
            label="Commandes"
            value={<CountUp value={newOrders} />}
            tone="claim"
            hint={pending ? `${pending} à encaisser` : "aucune commande en cours"}
          />
        ) : (
          <StatTile
            icon={Sparkles}
            label="Offre"
            value={offer}
            tone="claim"
            hint={unread ? `${unread} message(s) non lu(s)` : "aucun message en attente"}
          />
        )}
      </div>

      <section className="mt-8" aria-labelledby="mes-pages">
        <h2 id="mes-pages" className="hud-label mb-3 text-ink-400">
          Mes pages
        </h2>
        <ul className="ui-stagger grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {owned.map((p) => (
            <PageCard key={p.id} page={p} host={host} appUrl={env.appUrl} views={series(views, p.id)} clicks={sum(series(clicks, p.id))} blocks={blockRows.filter((b) => b.pageId === p.id)} />
          ))}
          <li>
            {canCreate ? (
              <Link
                href="/dashboard/nouvelle"
                data-spotlight
                className="ui-spotlight group flex h-full min-h-[18rem] flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-ink-600 p-6 text-center text-ink-300 transition hover:border-brand-400 hover:text-ink-100"
              >
                <span className="flex h-14 w-14 items-center justify-center rounded-2xl border border-brand-500/40 bg-brand-500/10 text-brand-300">
                  <Plus size={26} />
                </span>
                <span className="font-display text-lg font-semibold">Nouvelle page</span>
                <span className="max-w-[16rem] text-xs text-ink-400">Un projet, une équipe, un serveur, un partenariat…</span>
                <span className="mt-1 inline-flex items-center gap-1.5 text-xs font-semibold text-brand-300">
                  <Bot size={14} /> ou crée-la avec l&apos;assistant
                </span>
              </Link>
            ) : (
              <div className="flex h-full min-h-[18rem] flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-ink-700 p-6 text-center text-sm text-ink-400">
                <Lock size={20} className="text-claim" />
                {rights.limits.pages === 1 ? "Ton offre comprend une page." : `Limite de ${rights.limits.pages} pages atteinte.`}
                {!rights.premium && (
                  <Link href="/plus" className="font-semibold text-claim hover:underline">
                    Plus de pages avec {settings.premiumName}
                  </Link>
                )}
              </div>
            )}
          </li>
        </ul>
      </section>

      {shared.length > 0 && (
        <section className="mt-8" aria-labelledby="partagees">
          <h2 id="partagees" className="hud-label mb-3 text-ink-400">
            Partagées avec moi
          </h2>
          <ul className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {shared.map((p) => (
              <PageCard key={p.id} page={p} host={host} appUrl={env.appUrl} views={series(views, p.id)} clicks={sum(series(clicks, p.id))} blocks={blockRows.filter((b) => b.pageId === p.id)} />
            ))}
          </ul>
        </section>
      )}

      {activity.length > 0 && (
        <section className="mt-8" aria-labelledby="activite">
          <h2 id="activite" className="hud-label mb-3 text-ink-400">
            Activité récente
          </h2>
          <ol className="ui-stagger relative space-y-1 before:absolute before:top-3 before:bottom-3 before:left-[1.65rem] before:w-px before:bg-ink-700">
            {activity.map((item) => (
              <li key={item.key}>
                <Link href={item.href} className="group relative flex items-start gap-3 rounded-xl border border-transparent p-2 transition hover:border-ink-700 hover:bg-ink-900/70">
                  <span
                    className={`relative z-10 flex h-9 w-9 shrink-0 items-center justify-center rounded-full border bg-ink-950 ${
                      item.kind === "order" ? "border-pink-400/40 text-pink-300" : "border-brand-400/40 text-brand-300"
                    }`}
                  >
                    {item.kind === "order" ? <ShoppingBag size={15} /> : <Mail size={15} />}
                    {item.fresh && <span className="absolute -top-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-claim ring-2 ring-ink-950" aria-label="nouveau" />}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex flex-wrap items-baseline gap-x-2">
                      <span className="font-semibold text-ink-100">{item.title}</span>
                      <span className="text-xs text-ink-500">
                        {since(item.at)}
                        {pages.length > 1 && item.page ? ` · ${item.page}` : ""}
                      </span>
                    </span>
                    <span className="block truncate text-sm text-ink-400">{item.detail}</span>
                  </span>
                  <ArrowRight size={15} className="mt-2 shrink-0 text-ink-500 opacity-0 transition-opacity group-hover:opacity-100" />
                </Link>
              </li>
            ))}
          </ol>
        </section>
      )}

      <p className="mt-8 flex items-start gap-3 rounded-xl border border-claim/25 bg-[linear-gradient(110deg,rgba(255,194,71,0.08),transparent_60%)] px-4 py-3.5 text-sm text-ink-300">
        <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-claim/15 text-claim">
          <Lightbulb size={15} aria-hidden="true" />
        </span>
        <span className="pt-0.5">
          <strong className="text-ink-100">Astuce du jour · </strong>
          {TIPS[Math.floor(Date.now() / 86_400_000) % TIPS.length]}
        </span>
      </p>

      <section className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {[
          {
            href: "/dashboard/commandes",
            icon: ShoppingBag,
            color: "text-pink-300",
            title: newOrders ? `Commandes · ${newOrders} nouvelle${newOrders > 1 ? "s" : ""}` : "Commandes",
            text: "Ce que tes visiteurs commandent avec le bloc « Boutique ».",
          },
          {
            href: "/dashboard/messages",
            icon: Inbox,
            color: "text-brand-300",
            title: unread ? `Messages · ${unread} non lu${unread > 1 ? "s" : ""}` : "Messages",
            text: "Ce que tes visiteurs t'écrivent avec le bloc « Formulaire de contact ».",
          },
          {
            href: "/dashboard/partenariat",
            icon: Handshake,
            color: "text-claim",
            title: user.partner ? "Ton partenariat" : "Devenir partenaire",
            text: user.partner ? "Tes avantages de partenaire officiel." : "Badge officiel, plus de pages, équipe élargie et mise en avant.",
          },
          {
            href: "/dashboard/compte",
            icon: MousePointerClick,
            color: "text-mint",
            title: "Compte et données",
            text: "Comptes reliés, appareils connectés, export et suppression.",
          },
        ].map(({ href, icon: Icon, color, title, text }) => (
          <Link key={href} href={href} data-spotlight className="ui-spotlight ui-lift group rounded-xl border border-ink-700 bg-ink-900/80 p-4">
            <Icon size={18} className={`${color}`} />
            <p className="mt-2 inline-flex items-center gap-1 font-semibold">
              {title} <ArrowRight size={14} className="opacity-0 transition-opacity group-hover:opacity-100" />
            </p>
            <p className="mt-1 text-sm text-ink-400">{text}</p>
          </Link>
        ))}
      </section>
    </div>
  );
}
