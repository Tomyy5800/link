import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, Shield } from "lucide-react";
import { AdminNav } from "@/components/admin/AdminNav";
import { Logo } from "@/components/brand/Logo";
import { after } from "next/server";
import { requireAdminPage } from "@/lib/server/admin";
import { prisma } from "@/lib/server/db";
import { maybeRunJobs } from "@/lib/server/jobs";
import { isFounderLevel } from "@/lib/server/staff";

export const metadata: Metadata = { title: { default: "Administration", template: "%s · Administration" }, robots: { index: false } };

// Espace d'administration : accès vérifié côté serveur à chaque page (et à chaque appel /api/admin).
export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const admin = await requireAdminPage();
  after(() => maybeRunJobs().catch(() => undefined));
  const [openReports, pendingPartners] = await Promise.all([
    prisma.report.count({ where: { status: "open" } }),
    prisma.partnerApplication.count({ where: { status: "pending" } }),
  ]);

  return (
    <div className="bg-hud min-h-screen">
      <header className="sticky top-0 z-30 border-b border-ink-800 bg-ink-950/90 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-7xl items-center gap-3 px-4">
          <Logo />
          <span className="inline-flex items-center gap-1.5 rounded-sm border border-claim/40 px-2 py-0.5 font-mono text-[11px] font-semibold tracking-wide text-claim">
            <Shield size={12} aria-hidden="true" /> ADMIN
          </span>
          <span className="ml-auto hidden text-xs text-ink-400 sm:inline">
            Connecté·e : <span className="text-ink-200">{admin.globalName ?? admin.username}</span>
            <span className="ml-1.5 rounded-sm border border-ink-600 px-1.5 py-px font-mono text-[10px] text-ink-300">{isFounderLevel(admin) ? "fondateur" : "admin"}</span>
          </span>
          <Link href="/dashboard" className="inline-flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-sm text-ink-300 transition hover:bg-ink-800 hover:text-ink-100">
            <ArrowLeft size={15} /> Mon espace
          </Link>
        </div>
      </header>
      <div className="mx-auto flex max-w-7xl flex-col gap-6 px-4 py-6 lg:flex-row">
        <aside className="lg:sticky lg:top-20 lg:w-56 lg:shrink-0 lg:self-start">
          <AdminNav openReports={openReports} pendingPartners={pendingPartners} />
        </aside>
        <main className="min-w-0 flex-1 pb-16">{children}</main>
      </div>
    </div>
  );
}
