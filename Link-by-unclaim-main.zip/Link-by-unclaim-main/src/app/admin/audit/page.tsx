import { PageTitle, Pager, Panel, formatDate, pageNumber } from "@/components/admin/ui";
import { ACTION_LABELS } from "@/lib/server/admin";
import { prisma } from "@/lib/server/db";

export const metadata = { title: "Journal" };

const PER_PAGE = 50;

type Search = { searchParams: Promise<Record<string, string | string[] | undefined>> };

/** Résumé lisible des détails JSON d'une action. */
function details(raw: string): string {
  try {
    const value = JSON.parse(raw) as Record<string, unknown>;
    return Object.entries(value)
      .filter(([, v]) => v !== "" && v !== null && v !== undefined)
      .map(([k, v]) => `${k} : ${typeof v === "object" ? JSON.stringify(v) : String(v)}`)
      .join(" · ")
      .slice(0, 240);
  } catch {
    return "";
  }
}

export default async function AdminAudit({ searchParams }: Search) {
  const page = pageNumber((await searchParams).page);
  const [total, rows] = await Promise.all([
    prisma.auditLog.count(),
    prisma.auditLog.findMany({ orderBy: { createdAt: "desc" }, skip: (page - 1) * PER_PAGE, take: PER_PAGE }),
  ]);
  const ids = [...new Set(rows.flatMap((r) => [r.actorId, ...(r.targetType === "user" ? [r.targetId] : [])]))];
  const users = new Map((await prisma.user.findMany({ where: { id: { in: ids } }, select: { id: true, username: true } })).map((u) => [u.id, u.username]));
  const pageIds = rows.filter((r) => r.targetType === "page").map((r) => r.targetId);
  const slugs = new Map((await prisma.page.findMany({ where: { id: { in: pageIds } }, select: { id: true, slug: true } })).map((p) => [p.id, p.slug]));

  const target = (type: string, id: string) =>
    type === "user" ? `@${users.get(id) ?? id.slice(0, 8)}` : type === "page" ? (slugs.has(id) ? `/${slugs.get(id)}` : "page supprimée") : type;

  return (
    <>
      <PageTitle title="Journal" description="Toutes les actions d'administration et les échanges de codes, des plus récentes aux plus anciennes." />
      <Panel>
        <ul className="divide-y divide-ink-800">
          {rows.map((r) => (
            <li key={r.id} className="grid gap-1 py-2.5 text-sm sm:grid-cols-[150px_1fr]">
              <span className="font-mono text-xs text-ink-500">{formatDate(r.createdAt, true)}</span>
              <span className="min-w-0">
                <span className="font-medium text-ink-100">{ACTION_LABELS[r.action] ?? r.action}</span>
                <span className="text-ink-400">
                  {" "}
                  par @{users.get(r.actorId) ?? "?"} · {target(r.targetType, r.targetId)}
                </span>
                {details(r.details) && <span className="block truncate font-mono text-[11px] text-ink-500">{details(r.details)}</span>}
              </span>
            </li>
          ))}
          {rows.length === 0 && <li className="py-6 text-center text-sm text-ink-400">Le journal est vide.</li>}
        </ul>
        <Pager page={page} pages={Math.max(1, Math.ceil(total / PER_PAGE))} href={(p) => `/admin/audit?page=${p}`} />
      </Panel>
    </>
  );
}
