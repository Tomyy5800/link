import { CircleAlert, CircleCheck } from "lucide-react";
import { PricingForm } from "@/components/admin/PricingForm";
import { Chip, PageTitle, Panel } from "@/components/admin/ui";
import { missingLegal } from "@/lib/features";
import { env } from "@/lib/server/env";
import { getSettings } from "@/lib/server/settings";

export const metadata = { title: "Tarifs et vente" };

/** Événements Stripe à déclarer sur le webhook. */
const EVENTS = [
  "checkout.session.completed",
  "checkout.session.async_payment_succeeded",
  "checkout.session.async_payment_failed",
  "checkout.session.expired",
  "customer.subscription.created",
  "customer.subscription.updated",
  "customer.subscription.deleted",
  "invoice.paid",
  "invoice.payment_failed",
  "charge.refunded",
];

export default async function AdminPricing() {
  const settings = await getSettings();
  const missing = missingLegal(settings.legal);
  const webhook = `${env.appUrl}/api/webhooks/stripe`;

  return (
    <>
      <PageTitle
        title="Tarifs et vente"
        description="Ce que voient les acheteurs sur /plus : abonnements (mensuels, annuels), prix, et les informations légales du vendeur."
        aside={
          <a href="/plus" target="_blank" className="rounded-md border border-ink-600 px-3 py-1.5 text-sm text-ink-200 hover:border-ink-400">
            Voir la page des tarifs
          </a>
        }
      />

      <Panel title="Paiement en ligne" className="mb-6">
        {env.stripe.configured ? (
          <div className="space-y-2 text-sm">
            <p className="flex flex-wrap items-center gap-2 text-ink-100">
              <CircleCheck size={17} className="text-mint" /> Stripe est branché : les abonnements s&apos;activent sur le compte dès le premier paiement.
              {env.stripe.testMode ? <Chip tone="claim">mode test</Chip> : <Chip tone="mint">paiements réels</Chip>}
            </p>
            {env.stripe.webhookConfigured ? (
              <p className="flex items-center gap-2 text-ink-300">
                <CircleCheck size={16} className="text-mint" /> Webhook déclaré : renouvellements, échecs de paiement et résiliations sont suivis.
              </p>
            ) : (
              <p className="flex items-start gap-2 text-ink-300">
                <CircleAlert size={16} className="mt-0.5 shrink-0 text-claim" />
                <span>
                  Sans webhook, seule la première souscription est confirmée (au retour sur la page de remerciement) : les renouvellements, échecs et
                  résiliations faites chez Stripe ne seraient pas vus. Ajoute <code className="text-ink-100">{webhook}</code> et{" "}
                  <code className="text-ink-100">STRIPE_WEBHOOK_SECRET</code> avant d&apos;ouvrir la vente.
                </span>
              </p>
            )}
          </div>
        ) : (
          <div className="space-y-3 text-sm text-ink-300">
            <p className="flex items-center gap-2 text-ink-100">
              <CircleAlert size={17} className="text-claim" /> Pas de clé Stripe : rien n&apos;est en vente, la page des tarifs l&apos;annonce. Pour ouvrir la
              vente :
            </p>
            <ol className="list-decimal space-y-1.5 pl-5">
              <li>Crée un compte sur stripe.com (vérification d&apos;identité et RIB du vendeur).</li>
              <li>
                Dans Développeurs › Clés API, copie la clé secrète dans <code className="text-ink-100">STRIPE_SECRET_KEY</code> (commence par{" "}
                <code>sk_test_</code> pour tester, <code>sk_live_</code> pour vendre).
              </li>
              <li>
                Dans Développeurs › Webhooks, ajoute <code className="text-ink-100">{webhook}</code> avec les événements{" "}
                {EVENTS.map((e, i) => (
                  <span key={e}>
                    <code>{e}</code>
                    {i < EVENTS.length - 1 ? ", " : ""}
                  </span>
                ))}
                , puis copie son secret dans <code className="text-ink-100">STRIPE_WEBHOOK_SECRET</code>.
              </li>
              <li>Dans Paramètres › Facturation › Portail client, active le portail (carte bancaire, factures) puis enregistre.</li>
              <li>Redémarre Link by Unclaim : la vente est ouverte.</li>
            </ol>
          </div>
        )}
        {missing.length > 0 && (
          <p className="mt-3 flex items-center gap-2 text-sm text-claim">
            <CircleAlert size={16} /> {missing.length} information{missing.length > 1 ? "s" : ""} légale{missing.length > 1 ? "s" : ""} à compléter avant
            d&apos;ouvrir la vente.
          </p>
        )}
      </Panel>

      <PricingForm
        initial={{
          premiumName: settings.premiumName,
          premiumUrl: settings.premiumUrl,
          offers: settings.offers,
          legal: settings.legal,
        }}
      />
    </>
  );
}
