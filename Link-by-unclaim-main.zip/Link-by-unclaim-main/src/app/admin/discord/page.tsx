import { DiscordSync, type BadgeOption, type LinkRow } from "@/components/admin/DiscordSync";
import { PageTitle } from "@/components/admin/ui";
import { acceptsManualGrant, parseBadgeRule } from "@/lib/badges";
import { requireAdminPage } from "@/lib/server/admin";
import { badgeManageError, ensureSystemBadges, toPublicBadge } from "@/lib/server/badges";
import { prisma } from "@/lib/server/db";
import { getDiscordConfig, getDiscordStatus } from "@/lib/server/discord-sync";
import { env } from "@/lib/server/env";
import { hasStaffPermission } from "@/lib/server/staff";

export const metadata = { title: "Rôles Discord" };

export default async function AdminDiscord() {
  const admin = await requireAdminPage();
  await ensureSystemBadges();
  const [config, status, links, badges] = await Promise.all([
    getDiscordConfig(),
    getDiscordStatus(),
    prisma.discordRoleLink.findMany({ include: { badge: true }, orderBy: { createdAt: "asc" } }),
    prisma.badge.findMany({ where: { archivedAt: null }, orderBy: [{ position: "asc" }, { createdAt: "asc" }] }),
  ]);
  const options: BadgeOption[] = badges
    .filter((b) => acceptsManualGrant(parseBadgeRule(b.rule)) && badgeManageError(admin, b) === null)
    .map((b) => ({ ...toPublicBadge(b), id: b.id }));
  const rows: LinkRow[] = links.map((l) => ({ id: l.id, roleId: l.roleId, roleName: l.roleName, enabled: l.enabled, removeOnLoss: l.removeOnLoss, badge: { ...toPublicBadge(l.badge), id: l.badge.id } }));
  return (
    <>
      <PageTitle
        title="Rôles Discord"
        description="Les rôles du serveur Discord officiel attribuent automatiquement des badges (Administrateur, Développeur, Modérateur, Staff…)."
      />
      <DiscordSync config={config} status={status} botConfigured={env.discordBot.configured} links={rows} badges={options} allowed={hasStaffPermission(admin, "discord.manage")} />
    </>
  );
}
