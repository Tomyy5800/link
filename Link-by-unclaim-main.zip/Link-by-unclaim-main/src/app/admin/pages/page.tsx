import type { Prisma } from "@prisma/client";
import { PageActions } from "@/components/admin/actions";
import { Chip, PageTitle, Pager, Panel, SearchBox, formatDate, nf, pageNumber, str } from "@/components/admin/ui";
import { prisma } from "@/lib/server/db";

export const metadata = { title: "Pages" };

const PER_PAGE = 25;
const FILTERS = [
  ["", "Toutes"],
  ["reported", "Signalées"],
  ["suspended", "Suspendues"],
  ["featured", "Mises en avant"],
  ["private", "Privées"],
] as const;
const SORTS = [
  ["recent", "Récentes"],
  ["views", "Plus vues"],
  ["updated", "Modifiées"],
] as const;

type Search = { searchParams: Promise<Record<string, string | string[] | undefined>> };

export default async function AdminPages({ searchParams }: Search) {
  const params = await searchParams;
  const q = str(params.q);
  const filter = str(params.filter);
  const sort = str(params.sort) || "recent";
  const page = pageNumber(params.page);

  const where: Prisma.PageWhereInput = {
    ...(q ? { OR: [{ slug: { contains: q.toLowerCase() } }, { displayName: { contains: q } }, { user: { username: { contains: q } } }] } : {}),
    ...(filter === "reported" ? { reports: { some: { status: "open" } } } : {}),
    ...(filter === "suspended" ? { status: "suspended" } : {}),
    ...(filter === "featured" ? { featured: true } : {}),
    ...(filter === "private" ? { published: false } : {}),
  };
  const orderBy: Prisma.PageOrderByWithRelationInput = sort === "views" ? { views: "desc" } : sort === "updated" ? { updatedAt: "desc" } : { createdAt: "desc" };
  const [total, rows] = await Promise.all([
    prisma.page.count({ where }),
    prisma.page.findMany({
      where,
      orderBy,
      skip: (page - 1) * PER_PAGE,
      take: PER_PAGE,
      include: {
        user: { select: { username: true, suspendedAt: true } },
        _count: { select: { blocks: true, reports: { where: { status: "open" } } } },
      },
    }),
  ]);
  const pages = Math.max(1, Math.ceil(total / PER_PAGE));
  const href = (p: number, patch: Record<string, string> = {}) => {
    const next = { q, filter, sort, ...patch };
    return `/admin/pages?${new URLSearchParams(Object.entries({ ...next, page: p > 1 ? String(p) : "" }).filter(([, v]) => v && !(v === "recent")))}`;
  };

  return (
    <>
      <PageTitle
        title="Pages"
        description={`${nf.format(total)} page${total > 1 ? "s" : ""}. Suspends une page pour la masquer immédiatement : son propriétaire voit le motif dans l'éditeur.`}
        aside={<SearchBox placeholder="Adresse, nom, pseudo…" defaultValue={q} hidden={Object.fromEntries(Object.entries({ filter, sort }).filter(([, v]) => v))} />}
      />
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap gap-1.5">
          {FILTERS.map(([value, label]) => (
            <a
              key={value}
              href={href(1, { filter: value })}
              aria-current={filter === value ? "page" : undefined}
              className={`rounded-md border px-2.5 py-1 text-xs font-medium transition ${
                filter === value ? "border-brand-400 bg-brand-500/10 text-ink-100" : "border-ink-700 text-ink-400 hover:text-ink-200"
              }`}
            >
              {label}
            </a>
          ))}
        </div>
        <div className="flex gap-1 text-xs">
          {SORTS.map(([value, label]) => (
            <a key={value} href={href(1, { sort: value })} className={`rounded px-2 py-1 ${sort === value ? "text-ink-100" : "text-ink-500 hover:text-ink-300"}`}>
              {label}
            </a>
          ))}
        </div>
      </div>

      <Panel>
        <ul className="divide-y divide-ink-800">
          {rows.map((p) => (
            <li key={p.id} className="flex flex-col gap-3 py-3 lg:flex-row lg:items-center">
              <div className="min-w-0 flex-1">
                <p className="flex flex-wrap items-center gap-1.5 text-sm font-semibold text-ink-100">
                  <a href={`/${p.slug}`} target="_blank" rel="noopener noreferrer" className="hover:text-brand-300">
                    {p.displayName}
                  </a>
                  <span className="font-mono text-xs font-normal text-ink-400">/{p.slug}</span>
                  {p.status === "suspended" && <Chip tone="danger">suspendue</Chip>}
                  {p.user.suspendedAt && <Chip tone="danger">compte suspendu</Chip>}
                  {!p.published && <Chip>privée</Chip>}
                  {p.featured && <Chip tone="claim">en avant</Chip>}
                  {p._count.reports > 0 && <Chip tone="danger">{p._count.reports} signalement{p._count.reports > 1 ? "s" : ""}</Chip>}
                  {p.customCss && <Chip tone="brand">CSS</Chip>}
                </p>
                <p className="font-mono text-[11px] text-ink-500">
                  @{p.user.username} · {nf.format(p.views)} vues · {p._count.blocks} blocs · créée le {formatDate(p.createdAt)} · modifiée le {formatDate(p.updatedAt, true)}
                </p>
                {p.status === "suspended" && p.statusReason && <p className="mt-0.5 text-xs text-danger">Motif : {p.statusReason}</p>}
              </div>
              <PageActions page={{ id: p.id, slug: p.slug, suspended: p.status === "suspended", featured: p.featured }} />
            </li>
          ))}
          {rows.length === 0 && <li className="py-6 text-center text-sm text-ink-400">Aucune page ne correspond.</li>}
        </ul>
        <Pager page={page} pages={pages} href={(p) => href(p)} />
      </Panel>
    </>
  );
}
