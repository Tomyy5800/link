import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { BadgeEditor } from "@/components/admin/badges/BadgeEditor";
import { PageTitle } from "@/components/admin/ui";
import { requireAdminPage } from "@/lib/server/admin";
import { getSettings } from "@/lib/server/settings";
import { staffRights } from "@/lib/server/staff";

export const metadata = { title: "Nouveau badge" };

export default async function NewBadge() {
  const admin = await requireAdminPage();
  const settings = await getSettings();
  return (
    <>
      <Link href="/admin/badges" className="mb-3 inline-flex items-center gap-1.5 text-sm text-ink-400 transition-colors hover:text-ink-100">
        <ArrowLeft size={14} /> Badges
      </Link>
      <PageTitle title="Nouveau badge" description="Il pourra être validé officiellement une fois créé." />
      <BadgeEditor
        rights={staffRights(admin)!}
        premiumName={settings.premiumName}
        initial={{
          id: null,
          key: "",
          name: "",
          description: "",
          icon: "star",
          imageUrl: "",
          color: "#22c9e8",
          visibility: "public",
          staffOnly: false,
          restricted: false,
          rule: { type: "manual" },
          durationDays: null,
          active: true,
          position: 50,
          system: false,
          validated: false,
          archived: false,
          autoGranted: 0,
        }}
      />
    </>
  );
}
