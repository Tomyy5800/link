import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { BadgeEditor } from "@/components/admin/badges/BadgeEditor";
import { BadgeHolders, type HolderRow } from "@/components/admin/badges/BadgeHolders";
import { PageTitle, Panel, formatDate } from "@/components/admin/ui";
import { BADGE_ICONS, acceptsManualGrant, parseBadgeRule, type BadgeIconKey } from "@/lib/badges";
import { accountAvatarUrl } from "@/lib/discord-cdn";
import { requireAdminPage } from "@/lib/server/admin";
import { badgeManageError, holdersOf } from "@/lib/server/badges";
import { prisma } from "@/lib/server/db";
import { getSettings } from "@/lib/server/settings";
import { staffRights } from "@/lib/server/staff";

export const metadata = { title: "Badge" };

const ACTIONS: Record<string, string> = {
  "badge.create": "Badge créé",
  "badge.update": "Badge modifié",
  "badge.validate": "Sceau officiel posé",
  "badge.unvalidate": "Sceau officiel retiré",
  "badge.archive": "Badge archivé",
  "badge.restore": "Badge restauré",
  "badge.grant": "Attribué",
  "badge.revoke": "Retiré",
  "badge.auto": "Attribué (premiers comptes)",
  "badge.expire": "Attribution arrivée à échéance",
  "badge.backfill": "Places distribuées",
  "discord.link": "Rôle Discord associé",
  "discord.link.update": "Association Discord modifiée",
  "discord.unlink": "Rôle Discord dissocié",
};

export default async function AdminBadge({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ q?: string }> }) {
  const admin = await requireAdminPage();
  const badge = await prisma.badge.findUnique({ where: { id: (await params).id } });
  if (!badge) notFound();
  const q = ((await searchParams).q ?? "").slice(0, 60);
  const [settings, holders, history] = await Promise.all([
    getSettings(),
    holdersOf(badge, { take: 100, q: q || undefined }),
    prisma.auditLog.findMany({ where: { targetType: "badge", targetId: badge.id }, orderBy: { createdAt: "desc" }, take: 60 }),
  ]);
  const ids = new Set<string>();
  for (const h of history) {
    ids.add(h.actorId);
    const userId = (JSON.parse(h.details || "{}") as { userId?: string }).userId;
    if (userId) ids.add(userId);
  }
  const people = await prisma.user.findMany({ where: { id: { in: [...ids] } }, select: { id: true, username: true, globalName: true } });
  const nameOf = (id: string) => (id === "system" ? "automatique" : id === "discord-sync" ? "synchronisation Discord" : id.startsWith("order:") ? "achat" : (people.find((p) => p.id === id)?.globalName ?? people.find((p) => p.id === id)?.username ?? "compte supprimé"));
  const rule = parseBadgeRule(badge.rule);
  const rights = staffRights(admin)!;
  const canManage = badgeManageError(admin, badge) === null;
  const rows: HolderRow[] = holders.rows.map(({ user, grant }) => ({
    id: user.id,
    name: user.globalName ?? user.username,
    username: user.username,
    avatar: accountAvatarUrl({ ...user, bannerHash: null, accentColor: null }),
    source: grant?.source ?? null,
    since: grant?.createdAt.toISOString() ?? null,
    expiresAt: grant?.expiresAt?.toISOString() ?? null,
    note: grant?.note ?? "",
  }));

  return (
    <>
      <Link href="/admin/badges" className="mb-3 inline-flex items-center gap-1.5 text-sm text-ink-400 transition-colors hover:text-ink-100">
        <ArrowLeft size={14} /> Badges
      </Link>
      <PageTitle title={badge.name} description={canManage ? "Modifie le badge, ses titulaires et son sceau." : "Lecture seule : ce badge demande une permission que ton compte n'a pas."} />
      {canManage ? (
        <BadgeEditor
          rights={rights}
          premiumName={settings.premiumName}
          initial={{
            id: badge.id,
            key: badge.key,
            name: badge.name,
            description: badge.description,
            icon: (BADGE_ICONS as readonly string[]).includes(badge.icon) ? (badge.icon as BadgeIconKey) : "star",
            imageUrl: badge.imageUrl,
            color: badge.color,
            visibility: badge.visibility === "hidden" ? "hidden" : "public",
            staffOnly: badge.staffOnly,
            restricted: badge.restricted,
            rule,
            durationDays: badge.durationDays,
            active: badge.active,
            position: badge.position,
            system: badge.system,
            validated: badge.validated,
            archived: Boolean(badge.archivedAt),
            autoGranted: badge.autoGranted,
          }}
        />
      ) : null}
      <div className="mt-4 grid gap-4 xl:grid-cols-[1fr_380px]">
        <BadgeHolders badgeId={badge.id} manual={acceptsManualGrant(rule)} early={rule.type === "early"} canManage={canManage} holders={rows} total={holders.total} />
        <Panel title="Historique">
          {history.length === 0 ? (
            <p className="text-sm text-ink-400">Aucun événement.</p>
          ) : (
            <ol className="space-y-2 text-xs">
              {history.map((h) => {
                const details = JSON.parse(h.details || "{}") as { userId?: string; reason?: string; given?: number };
                return (
                  <li key={h.id} className="border-l border-ink-700 pl-3">
                    <p className="text-ink-200">
                      {ACTIONS[h.action] ?? h.action}
                      {details.userId && <span className="text-ink-400"> · {nameOf(details.userId)}</span>}
                      {details.given !== undefined && <span className="text-ink-400"> · {details.given}</span>}
                    </p>
                    <p className="font-mono text-[11px] text-ink-500">
                      {formatDate(h.createdAt, true)} · par {nameOf(h.actorId)}
                      {details.reason && ` · ${details.reason}`}
                    </p>
                  </li>
                );
              })}
            </ol>
          )}
        </Panel>
      </div>
    </>
  );
}
