import Link from "next/link";
import { Archive, EyeOff, Lock, Plus, Users } from "lucide-react";
import { OfficialBadge } from "@/components/badges/OfficialBadge";
import { Chip, PageTitle, Panel, nf } from "@/components/admin/ui";
import { RULE_LABELS, parseBadgeRule } from "@/lib/badges";
import { requireAdminPage } from "@/lib/server/admin";
import { ensureSystemBadges, holdersOf, toPublicBadge } from "@/lib/server/badges";
import { prisma } from "@/lib/server/db";
import { foundersDeclared } from "@/lib/server/staff";

export const metadata = { title: "Badges" };

// Badges officiels : liste, règles, titulaires, état (actif, validé, archivé).
export default async function AdminBadges() {
  await requireAdminPage();
  await ensureSystemBadges();
  const badges = await prisma.badge.findMany({ orderBy: [{ archivedAt: "asc" }, { position: "asc" }, { createdAt: "asc" }] });
  const counts = await Promise.all(badges.map((b) => holdersOf(b, { take: 0 }).then((r) => r.total).catch(() => 0)));

  return (
    <>
      <PageTitle
        title="Badges"
        description="Badges officiels affichés sur les profils : staff, partenaires, premiers comptes, formules… Le sceau officiel se pose depuis la fiche de chaque badge."
        aside={
          <Link href="/admin/badges/nouveau" className="inline-flex items-center gap-1.5 rounded-md bg-brand-500 px-3 py-2 text-sm font-semibold text-ink-950 transition-colors hover:bg-brand-400">
            <Plus size={15} /> Nouveau badge
          </Link>
        }
      />
      {!foundersDeclared() && (
        <p className="mb-4 rounded-md border border-claim/40 bg-claim/10 px-4 py-3 text-sm text-ink-100">
          Aucun fondateur déclaré : le badge « Fondateur » n&apos;est attribué à personne. Ajoute ton identifiant dans <code>FOUNDER_UNCLAIM_IDS</code> (ou{" "}
          <code>FOUNDER_DISCORD_IDS</code>) dans l&apos;environnement du serveur, puis redémarre.
        </p>
      )}
      <Panel>
        <ul className="divide-y divide-ink-800">
          {badges.map((badge, i) => {
            const rule = parseBadgeRule(badge.rule);
            return (
              <li key={badge.id} className={badge.archivedAt || !badge.active ? "opacity-60" : ""}>
                <Link href={`/admin/badges/${badge.id}`} className="flex flex-wrap items-center gap-3 px-1 py-3 transition-colors hover:bg-ink-850/60">
                  <span className="w-full shrink-0 sm:w-44">
                    <OfficialBadge badge={toPublicBadge(badge)} />
                  </span>
                  <span className="min-w-0 flex-1 text-sm text-ink-300">
                    <span className="block truncate">{badge.description || "Sans description"}</span>
                    <span className="mt-0.5 flex flex-wrap items-center gap-1.5">
                      <Chip>{RULE_LABELS[rule.type].label}{rule.type === "early" ? ` · ${badge.autoGranted}/${rule.limit}` : ""}</Chip>
                      {badge.staffOnly && <Chip tone="brand">staff</Chip>}
                      {badge.restricted && (
                        <Chip tone="claim">
                          <Lock size={10} aria-hidden="true" /> fondateurs
                        </Chip>
                      )}
                      {badge.validated && <Chip tone="claim">validé</Chip>}
                      {badge.visibility === "hidden" && (
                        <Chip>
                          <EyeOff size={10} aria-hidden="true" /> masqué
                        </Chip>
                      )}
                      {!badge.active && !badge.archivedAt && <Chip>désactivé</Chip>}
                      {badge.archivedAt && (
                        <Chip>
                          <Archive size={10} aria-hidden="true" /> archivé
                        </Chip>
                      )}
                      {badge.system && <Chip>intégré</Chip>}
                    </span>
                  </span>
                  <span className="inline-flex items-center gap-1.5 font-mono text-sm tabular-nums text-ink-200">
                    <Users size={14} className="text-ink-500" aria-hidden="true" /> {nf.format(counts[i] ?? 0)}
                  </span>
                </Link>
              </li>
            );
          })}
        </ul>
      </Panel>
    </>
  );
}
