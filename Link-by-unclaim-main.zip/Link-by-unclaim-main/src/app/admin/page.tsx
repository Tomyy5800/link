import Link from "next/link";
import { CircleAlert, CircleCheck, CircleDashed } from "lucide-react";
import { ClearCacheButton } from "@/components/admin/actions";
import { Chip, PageTitle, Panel, Stat, formatBytes, formatDate, nf } from "@/components/admin/ui";
import { formatPrice, missingLegal } from "@/lib/features";
import { ACTION_LABELS } from "@/lib/server/admin";
import { prisma } from "@/lib/server/db";
import { env } from "@/lib/server/env";
import { nationsGloryReady } from "@/lib/server/nationsglory";
import { todayKey } from "@/lib/server/pages";
import { getSettings } from "@/lib/server/settings";
import { storageUsage } from "@/lib/server/storage";

export const metadata = { title: "Vue d'ensemble" };

function Health({ state, label, detail }: { state: "ok" | "warn" | "off"; label: string; detail: React.ReactNode }) {
  const Icon = state === "ok" ? CircleCheck : state === "warn" ? CircleAlert : CircleDashed;
  const color = state === "ok" ? "text-mint" : state === "warn" ? "text-claim" : "text-ink-500";
  return (
    <li className="flex gap-3 py-2.5">
      <Icon size={17} className={`mt-0.5 shrink-0 ${color}`} aria-hidden="true" />
      <div className="min-w-0">
        <p className="text-sm font-medium text-ink-100">{label}</p>
        <p className="text-xs text-ink-400">{detail}</p>
      </div>
    </li>
  );
}

export default async function AdminOverview() {
  const now = new Date();
  const week = new Date(Date.now() - 7 * 86_400_000);
  const [users, newUsers, premium, suspendedUsers, pages, suspendedPages, viewsToday, views7, openReports, storage, activeCodes, redemptions, topPages, recent, settings] =
    await Promise.all([
      prisma.user.count(),
      prisma.user.count({ where: { createdAt: { gte: week } } }),
      prisma.user.count({ where: { OR: [{ plan: { not: "free" }, planExpiresAt: null }, { plan: { not: "free" }, planExpiresAt: { gt: now } }, { basePlan: { not: "free" } }] } }),
      prisma.user.count({ where: { suspendedAt: { not: null } } }),
      prisma.page.count(),
      prisma.page.count({ where: { status: "suspended" } }),
      prisma.pageView.count({ where: { day: todayKey() } }),
      prisma.pageView.count({ where: { day: { gte: todayKey(week) } } }),
      prisma.report.count({ where: { status: "open" } }),
      storageUsage(),
      prisma.premiumCode.count({ where: { disabled: false, OR: [{ expiresAt: null }, { expiresAt: { gt: now } }] } }),
      prisma.codeRedemption.count({ where: { createdAt: { gte: new Date(Date.now() - 30 * 86_400_000) } } }),
      prisma.page.findMany({ orderBy: { views: "desc" }, take: 6, select: { id: true, slug: true, displayName: true, views: true, status: true } }),
      prisma.auditLog.findMany({ orderBy: { createdAt: "desc" }, take: 8 }),
      getSettings(),
    ]);
  const [revenue, admins] = await Promise.all([
    prisma.order.aggregate({ where: { status: "paid", paidAt: { gte: new Date(Date.now() - 30 * 86_400_000) } }, _sum: { amountCents: true }, _count: { _all: true } }),
    prisma.user.count({ where: { role: "admin" } }),
  ]);
  const actors = new Map(
    (await prisma.user.findMany({ where: { id: { in: [...new Set(recent.map((r) => r.actorId))] } }, select: { id: true, username: true } })).map((u) => [u.id, u.username]),
  );
  const ng = nationsGloryReady();
  const premiumFeatures = Object.values(settings.features).filter((m) => m !== "all" && m !== "off").length;
  const missing = missingLegal(settings.legal);
  const secret = env.sessionSecret;
  const pricingLink = (
    <Link href="/admin/pricing" className="text-brand-300 hover:underline">
      Tarifs et vente
    </Link>
  );

  // Ce qui reste à faire avant d'ouvrir le service au public (et à la vente).
  const checks: { state: "ok" | "warn" | "off"; label: string; detail: React.ReactNode }[] = [
    {
      state: env.appUrl.startsWith("https://") ? "ok" : "warn",
      label: "Adresse publique en https",
      detail: env.appUrl.startsWith("https://") ? env.appUrl : `APP_URL vaut ${env.appUrl} : mets l'adresse https définitive.`,
    },
    {
      state: secret.length >= 32 && !secret.startsWith("change-moi") && secret !== "dev-only-insecure-secret" ? "ok" : "warn",
      label: "Secret de session",
      detail: "SESSION_SECRET : une valeur aléatoire d'au moins 32 caractères.",
    },
    {
      state: env.unclaim.configured ? "ok" : "warn",
      label: "Unclaim Auth",
      detail: env.unclaim.configured ? `Passerelle : ${env.unclaim.apiUrl}` : "Passerelle non configurée (UNCLAIM_API_URL, UNCLAIM_CLIENT_ID, UNCLAIM_CLIENT_SECRET).",
    },
    {
      state: env.devLoginEnabled ? "warn" : "ok",
      label: "Connexion de démonstration",
      detail: env.devLoginEnabled ? "Active (UNCLAIM_AUTH_DEV_LOGIN) : à couper avant la mise en ligne." : "Désactivée.",
    },
    {
      state: admins + env.adminDiscordIds.length + env.adminUnclaimIds.length > 0 ? "ok" : "warn",
      label: "Administrateur déclaré",
      detail: "ADMIN_UNCLAIM_IDS ou ADMIN_DISCORD_IDS, puis d'autres admins depuis Comptes.",
    },
    {
      state: ng === "live" ? "ok" : "warn",
      label: "API NationsGlory",
      detail:
        ng === "live"
          ? `Clé branchée · ${env.nationsglory.rateLimit} requêtes/min max · réponses en cache`
          : ng === "mock"
            ? "Mode démonstration : données fictives. Renseigne NATIONSGLORY_API_KEY et passe NATIONSGLORY_MOCK à false dès que la clé est disponible."
            : "Aucune clé : les blocs NationsGlory affichent « données indisponibles ». Renseigne NATIONSGLORY_API_KEY.",
    },
    {
      state: env.stripe.configured && !env.stripe.testMode && env.stripe.webhookConfigured ? "ok" : "off",
      label: "Paiement en ligne",
      detail: env.stripe.configured ? (
        env.stripe.testMode ? (
          <>Stripe en mode test : aucun vrai paiement. Passe aux clés live pour vendre.</>
        ) : env.stripe.webhookConfigured ? (
          <>Stripe branché, paiements réels, webhook déclaré.</>
        ) : (
          <>Stripe branché, mais sans webhook (STRIPE_WEBHOOK_SECRET) : à déclarer avant le lancement.</>
        )
      ) : (
        <>Pas de clé Stripe : rien n&apos;est à vendre, toutes les fonctions de {settings.premiumName} sont offertes à tous · {pricingLink}</>
      ),
    },
    {
      state: missing.length ? "warn" : "ok",
      label: "Informations légales",
      detail: missing.length ? <>{missing.length} champ{missing.length > 1 ? "s" : ""} à remplir (mentions légales, CGV) · {pricingLink}</> : "Mentions légales et CGV complètes.",
    },
    {
      state: env.uploadsDriver === "disk" ? "ok" : "off",
      label: "Stockage des fichiers",
      detail: env.uploadsDriver === "disk" ? "Sur disque (UPLOADS_DIR)." : "En base : suffisant au début, passe UPLOADS_DRIVER à disk avec l'audio et la vidéo.",
    },
    {
      state: "ok",
      label: "Fonctionnalités",
      detail: (
        <>
          {premiumFeatures} réservée{premiumFeatures > 1 ? "s" : ""} à {settings.premiumName} · création de pages {settings.registrationsOpen ? "ouverte" : "fermée"} ·{" "}
          <Link href="/admin/settings" className="text-brand-300 hover:underline">
            gérer
          </Link>
        </>
      ),
    },
  ];
  const done = checks.filter((c) => c.state === "ok").length;

  return (
    <>
      <PageTitle title="Vue d'ensemble" description="L'état de Link by Unclaim en un coup d'œil." />

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Comptes" value={nf.format(users)} hint={`+${nf.format(newUsers)} cette semaine`} />
        <Stat label="Pages" value={nf.format(pages)} hint={suspendedPages ? `${suspendedPages} suspendue${suspendedPages > 1 ? "s" : ""}` : "aucune suspendue"} />
        <Stat label={settings.premiumName} value={nf.format(premium)} tone="claim" hint={`${nf.format(redemptions)} code${redemptions > 1 ? "s" : ""} échangé${redemptions > 1 ? "s" : ""} (30 j)`} />
        <Stat label="Signalements" value={nf.format(openReports)} tone={openReports ? "danger" : "mint"} hint={openReports ? <Link href="/admin/reports" className="underline">à traiter</Link> : "rien à traiter"} />
        <Stat label="Vues aujourd'hui" value={nf.format(viewsToday)} hint={`${nf.format(views7)} sur 7 jours`} />
        <Stat label="Stockage" value={formatBytes(storage.bytes)} hint={`${nf.format(storage.files)} fichiers · ${env.uploadsDriver === "disk" ? "disque" : "base"}`} />
        <Stat
          label="Ventes (30 j)"
          value={formatPrice(revenue._sum.amountCents ?? 0)}
          tone="claim"
          hint={<Link href="/admin/sales" className="underline">{`${nf.format(revenue._count._all)} achat${revenue._count._all > 1 ? "s" : ""} · ${nf.format(activeCodes)} codes actifs`}</Link>}
        />
        <Stat label="Comptes suspendus" value={nf.format(suspendedUsers)} tone={suspendedUsers ? "danger" : undefined} />
      </div>

      <div className="mt-6 grid gap-6 xl:grid-cols-2">
        <Panel title="Prêt pour la mise en ligne" aside={<span className="font-mono text-xs text-ink-400">{done}/{checks.length}</span>}>
          <ul className="divide-y divide-ink-800">
            {checks.map((check) => (
              <Health key={check.label} state={check.state} label={check.label} detail={check.detail} />
            ))}
          </ul>
          <div className="mt-3 border-t border-ink-800 pt-3">
            <ClearCacheButton prefix="ng:" label="Vider le cache NationsGlory" />
          </div>
        </Panel>

        <Panel title="Pages les plus vues">
          <ul className="divide-y divide-ink-800">
            {topPages.map((p) => (
              <li key={p.id} className="flex items-center justify-between gap-3 py-2 text-sm">
                <a href={`/${p.slug}`} target="_blank" rel="noopener noreferrer" className="min-w-0 truncate text-ink-100 hover:text-brand-300">
                  {p.displayName} <span className="font-mono text-xs text-ink-400">/{p.slug}</span>
                </a>
                <span className="flex items-center gap-2">
                  {p.status === "suspended" && <Chip tone="danger">suspendue</Chip>}
                  <span className="font-mono text-xs text-ink-300 tabular-nums">{nf.format(p.views)}</span>
                </span>
              </li>
            ))}
            {topPages.length === 0 && <li className="py-2 text-sm text-ink-400">Aucune page pour le moment.</li>}
          </ul>
        </Panel>

        <Panel title="Dernières actions" className="xl:col-span-2" aside={<Link href="/admin/audit" className="text-xs text-brand-300 hover:underline">Tout le journal</Link>}>
          <ul className="divide-y divide-ink-800">
            {recent.map((r) => (
              <li key={r.id} className="flex flex-wrap items-baseline justify-between gap-2 py-2 text-sm">
                <span>
                  <span className="text-ink-100">{ACTION_LABELS[r.action] ?? r.action}</span>
                  <span className="text-ink-400"> · @{actors.get(r.actorId) ?? "?"}</span>
                </span>
                <span className="font-mono text-xs text-ink-500">{formatDate(r.createdAt, true)}</span>
              </li>
            ))}
            {recent.length === 0 && <li className="py-2 text-sm text-ink-400">Aucune action enregistrée.</li>}
          </ul>
        </Panel>
      </div>
    </>
  );
}
