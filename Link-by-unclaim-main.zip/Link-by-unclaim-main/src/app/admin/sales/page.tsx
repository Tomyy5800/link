import Link from "next/link";
import type { Prisma } from "@prisma/client";
import { OrderActions } from "@/components/admin/actions";
import { Chip, PageTitle, Pager, Panel, Stat, formatDate, nf, pageNumber, str } from "@/components/admin/ui";
import { formatPrice } from "@/lib/features";
import { prisma } from "@/lib/server/db";
import { env } from "@/lib/server/env";
import { getSettings } from "@/lib/server/settings";

export const metadata = { title: "Ventes" };

const PER_PAGE = 30;
const STATUS: Record<string, { label: string; tone: "mint" | "claim" | "danger" | "muted" }> = {
  paid: { label: "payée", tone: "mint" },
  pending: { label: "en attente", tone: "claim" },
  refunded: { label: "remboursée", tone: "danger" },
  failed: { label: "échouée", tone: "danger" },
  canceled: { label: "abandonnée", tone: "muted" },
};
const FILTERS = [
  ["", "Toutes"],
  ["paid", "Payées"],
  ["pending", "En attente"],
  ["refunded", "Remboursées"],
  ["canceled", "Abandonnées"],
] as const;

type Search = { searchParams: Promise<Record<string, string | string[] | undefined>> };

export default async function AdminSales({ searchParams }: Search) {
  const params = await searchParams;
  const status = str(params.status);
  const page = pageNumber(params.page);
  const since30 = new Date(Date.now() - 30 * 86_400_000);
  const where: Prisma.OrderWhereInput = status ? { status } : {};

  const [settings, total, orders, paid30, paidAll, refunded, byOffer] = await Promise.all([
    getSettings(),
    prisma.order.count({ where }),
    prisma.order.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * PER_PAGE,
      take: PER_PAGE,
      include: { user: { select: { username: true, globalName: true } } },
    }),
    prisma.order.aggregate({ where: { status: "paid", paidAt: { gte: since30 } }, _sum: { amountCents: true }, _count: { _all: true } }),
    prisma.order.aggregate({ where: { status: "paid" }, _sum: { amountCents: true }, _count: { _all: true } }),
    prisma.order.aggregate({ where: { status: "refunded" }, _sum: { amountCents: true }, _count: { _all: true } }),
    prisma.order.groupBy({ by: ["offerName"], where: { status: "paid" }, _sum: { amountCents: true }, _count: { _all: true } }),
  ]);
  const revenue30 = paid30._sum.amountCents ?? 0;
  const count30 = paid30._count._all;
  const maxOffer = Math.max(1, ...byOffer.map((o) => o._sum.amountCents ?? 0));

  return (
    <>
      <PageTitle
        title="Ventes"
        description={`Achats de ${settings.premiumName}. Montants TTC, avant les frais du prestataire de paiement.`}
        aside={
          env.stripe.configured ? (
            <a
              href="https://dashboard.stripe.com/payments"
              target="_blank"
              rel="noopener noreferrer"
              className="rounded-md border border-ink-600 px-3 py-1.5 text-sm text-ink-200 hover:border-ink-400"
            >
              Tableau de bord Stripe
            </a>
          ) : (
            <Link href="/admin/pricing" className="rounded-md border border-claim/50 px-3 py-1.5 text-sm text-claim hover:bg-claim/10">
              Ouvrir la vente en ligne
            </Link>
          )
        }
      />

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Chiffre d'affaires (30 j)" value={formatPrice(revenue30)} tone="claim" hint={`${nf.format(count30)} achat${count30 > 1 ? "s" : ""}`} />
        <Stat label="Panier moyen (30 j)" value={count30 ? formatPrice(Math.round(revenue30 / count30)) : "—"} />
        <Stat label="Total encaissé" value={formatPrice(paidAll._sum.amountCents ?? 0)} hint={`${nf.format(paidAll._count._all)} achats`} />
        <Stat
          label="Remboursé"
          value={formatPrice(refunded._sum.amountCents ?? 0)}
          tone={refunded._count._all ? "danger" : undefined}
          hint={`${nf.format(refunded._count._all)} commande${refunded._count._all > 1 ? "s" : ""}`}
        />
      </div>

      {byOffer.length > 0 && (
        <Panel title="Par offre" className="mt-6">
          <ul className="space-y-2">
            {[...byOffer]
              .sort((a, b) => (b._sum.amountCents ?? 0) - (a._sum.amountCents ?? 0))
              .map((o) => (
                <li key={o.offerName} className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span className="text-ink-200">{o.offerName}</span>
                    <span className="font-mono text-ink-300">
                      {formatPrice(o._sum.amountCents ?? 0)} · {o._count._all}
                    </span>
                  </div>
                  <div className="h-1.5 overflow-hidden rounded-full bg-ink-700">
                    <div className="h-full rounded-full bg-claim" style={{ width: `${((o._sum.amountCents ?? 0) / maxOffer) * 100}%` }} />
                  </div>
                </li>
              ))}
          </ul>
        </Panel>
      )}

      <div className="mt-6 mb-3 flex flex-wrap gap-1.5">
        {FILTERS.map(([value, label]) => (
          <a
            key={value}
            href={value ? `/admin/sales?status=${value}` : "/admin/sales"}
            aria-current={status === value ? "page" : undefined}
            className={`rounded-md border px-2.5 py-1 text-xs font-medium transition ${
              status === value ? "border-brand-400 bg-brand-500/10 text-ink-100" : "border-ink-700 text-ink-400 hover:text-ink-200"
            }`}
          >
            {label}
          </a>
        ))}
      </div>
      <Panel>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-sm">
            <thead>
              <tr className="text-left text-xs text-ink-400">
                <th className="py-2 font-medium">Date</th>
                <th className="py-2 font-medium">Compte</th>
                <th className="py-2 font-medium">Offre</th>
                <th className="py-2 font-medium">Montant</th>
                <th className="py-2 font-medium">État</th>
                <th className="py-2" />
              </tr>
            </thead>
            <tbody className="divide-y divide-ink-800">
              {orders.map((o) => {
                const s = STATUS[o.status] ?? { label: o.status, tone: "muted" as const };
                return (
                  <tr key={o.id}>
                    <td className="py-2 pr-3 font-mono text-xs text-ink-400">{formatDate(o.paidAt ?? o.createdAt, true)}</td>
                    <td className="py-2 pr-3">
                      <Link href={`/admin/users?q=${encodeURIComponent(o.user.username)}`} className="text-ink-100 hover:text-brand-300">
                        {o.user.globalName ?? o.user.username}
                      </Link>
                    </td>
                    <td className="py-2 pr-3 text-ink-200">
                      {o.offerName}
                      {o.gift && (
                        <span className="ml-1.5">
                          <Chip tone="brand">cadeau</Chip>
                        </span>
                      )}
                    </td>
                    <td className="py-2 pr-3 font-mono text-ink-100">{formatPrice(o.amountCents)}</td>
                    <td className="py-2 pr-3">
                      <Chip tone={s.tone}>{s.label}</Chip>
                    </td>
                    <td className="py-2 text-right">
                      <OrderActions order={{ id: o.id, status: o.status, online: Boolean(o.paymentRef) && env.stripe.configured }} />
                    </td>
                  </tr>
                );
              })}
              {orders.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-6 text-center text-ink-400">
                    Aucune commande pour le moment.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <Pager
          page={page}
          pages={Math.max(1, Math.ceil(total / PER_PAGE))}
          href={(p) => `/admin/sales?${new URLSearchParams({ ...(status ? { status } : {}), page: String(p) })}`}
        />
      </Panel>
    </>
  );
}
