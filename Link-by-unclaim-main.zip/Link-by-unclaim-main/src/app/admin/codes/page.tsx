import { CodeToggle } from "@/components/admin/actions";
import { CodeCreator } from "@/components/admin/CodeCreator";
import { Chip, PageTitle, Pager, Panel, formatDate, nf, pageNumber } from "@/components/admin/ui";
import { prisma } from "@/lib/server/db";
import { getSettings } from "@/lib/server/settings";

export const metadata = { title: "Codes" };

const PER_PAGE = 40;

type Search = { searchParams: Promise<Record<string, string | string[] | undefined>> };

export default async function AdminCodes({ searchParams }: Search) {
  const page = pageNumber((await searchParams).page);
  const now = new Date();
  const [settings, total, codes] = await Promise.all([
    getSettings(),
    prisma.premiumCode.count(),
    prisma.premiumCode.findMany({ orderBy: { createdAt: "desc" }, skip: (page - 1) * PER_PAGE, take: PER_PAGE }),
  ]);

  return (
    <>
      <PageTitle
        title={`Codes ${settings.premiumName}`}
        description="À vendre ou offrir en dehors de l'application. L'utilisateur l'échange dans Réglages, et son offre est prolongée d'autant."
      />
      <Panel title="Nouveau lot" className="mb-6">
        <CodeCreator premiumName={settings.premiumName} />
      </Panel>
      <Panel title={`${nf.format(total)} code${total > 1 ? "s" : ""}`}>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-sm">
            <thead>
              <tr className="text-left text-xs text-ink-400">
                <th className="py-2 font-medium">Code</th>
                <th className="py-2 font-medium">Durée</th>
                <th className="py-2 font-medium">Utilisations</th>
                <th className="py-2 font-medium">Validité</th>
                <th className="py-2 font-medium">Note</th>
                <th className="py-2 font-medium">Créé le</th>
                <th className="py-2" />
              </tr>
            </thead>
            <tbody className="divide-y divide-ink-800">
              {codes.map((c) => {
                const expired = c.expiresAt !== null && c.expiresAt < now;
                const used = c.uses >= c.maxUses;
                return (
                  <tr key={c.id} className={c.disabled || expired ? "opacity-60" : ""}>
                    <td className="py-2 pr-3 font-mono text-ink-200">LBU-…{c.hint}</td>
                    <td className="py-2 pr-3">{c.days === 0 ? "sans limite" : `${c.days} j`}</td>
                    <td className="py-2 pr-3 font-mono">
                      {c.uses}/{c.maxUses}
                    </td>
                    <td className="py-2 pr-3">
                      {c.disabled ? (
                        <Chip tone="danger">désactivé</Chip>
                      ) : expired ? (
                        <Chip>expiré</Chip>
                      ) : used ? (
                        <Chip tone="mint">épuisé</Chip>
                      ) : (
                        <Chip tone="claim">{c.expiresAt ? `jusqu'au ${formatDate(c.expiresAt)}` : "actif"}</Chip>
                      )}
                    </td>
                    <td className="max-w-48 truncate py-2 pr-3 text-ink-400">{c.note || "—"}</td>
                    <td className="py-2 pr-3 font-mono text-xs text-ink-500">{formatDate(c.createdAt)}</td>
                    <td className="py-2 text-right">{!used && !expired && <CodeToggle id={c.id} disabled={c.disabled} />}</td>
                  </tr>
                );
              })}
              {codes.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-6 text-center text-ink-400">
                    Aucun code pour le moment.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <Pager page={page} pages={Math.max(1, Math.ceil(total / PER_PAGE))} href={(p) => `/admin/codes?page=${p}`} />
      </Panel>
    </>
  );
}
