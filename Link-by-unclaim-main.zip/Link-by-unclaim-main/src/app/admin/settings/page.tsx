import { CriticalSettings, type CriticalEvent } from "@/components/admin/CriticalSettings";
import { SettingsForm } from "@/components/admin/SettingsForm";
import { PageTitle } from "@/components/admin/ui";
import { requireAdminPage } from "@/lib/server/admin";
import { prisma } from "@/lib/server/db";
import { getSettings } from "@/lib/server/settings";
import { hasStaffPermission } from "@/lib/server/staff";

export const metadata = { title: "Fonctionnalités" };

export default async function AdminSettings() {
  const admin = await requireAdminPage();
  const [settings, events] = await Promise.all([
    getSettings(),
    prisma.auditLog.findMany({ where: { action: "settings.critical" }, orderBy: { createdAt: "desc" }, take: 30 }),
  ]);
  const actors = await prisma.user.findMany({ where: { id: { in: [...new Set(events.map((e) => e.actorId))] } }, select: { id: true, username: true, globalName: true } });
  const names = new Map(actors.map((a) => [a.id, a.globalName ?? a.username]));
  const history: CriticalEvent[] = events.map((e) => {
    const details = JSON.parse(e.details || "{}") as { to?: boolean; reason?: string };
    return { id: e.id, key: e.targetId, to: Boolean(details.to), actor: names.get(e.actorId) ?? "compte supprimé", at: e.createdAt.toISOString(), reason: details.reason ?? "" };
  });
  return (
    <>
      <PageTitle
        title="Fonctionnalités et limites"
        description={`Choisis ce qui est gratuit, ce qui est réservé à ${settings.premiumName} et ce qui est coupé. Les changements s'appliquent sans redéploiement.`}
      />
      <div className="mb-6">
        <CriticalSettings
          values={{ personalShops: settings.personalShops, launchFreeAccess: settings.launchFreeAccess }}
          allowed={hasStaffPermission(admin, "platform.critical")}
          history={history}
        />
      </div>
      <SettingsForm initial={settings} />
    </>
  );
}
