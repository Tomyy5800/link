// Chargement d'un écran d'administration (la barre latérale reste affichée par la mise en page).
export default function AdminLoading() {
  const bar = "ui-skeleton rounded-md";
  return (
    <div aria-busy="true" aria-label="Chargement">
      <div className={`${bar} h-8 w-64`} />
      <div className={`${bar} mt-2 h-4 w-96 max-w-full`} />
      <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        {Array.from({ length: 4 }, (_, i) => (
          <div key={i} className={`${bar} h-24`} />
        ))}
      </div>
      <div className={`${bar} mt-6 h-72`} />
    </div>
  );
}
