import Link from "next/link";
import { Crown, ExternalLink } from "lucide-react";
import { BadgeList } from "@/components/badges/OfficialBadge";
import { StaffPermissions } from "@/components/admin/StaffPermissions";
import { Chip, PageTitle, Panel } from "@/components/admin/ui";
import { accountAvatarUrl } from "@/lib/discord-cdn";
import { STAFF_PERMISSIONS, STAFF_PERMISSION_KEYS, parseStaffPermissions } from "@/lib/staff";
import { requireAdminPage } from "@/lib/server/admin";
import { publicBadgesOf } from "@/lib/server/badges";
import { prisma } from "@/lib/server/db";
import { env } from "@/lib/server/env";
import { isAdmin } from "@/lib/server/entitlements";
import { foundersDeclared, isFounderLevel } from "@/lib/server/staff";

export const metadata = { title: "Staff et permissions" };

// Membres de l'administration : niveau, permissions sensibles (accordées par un fondateur) et badges.
export default async function AdminStaff() {
  const me = await requireAdminPage();
  const founder = isFounderLevel(me);
  const envIds = { discord: [...env.adminDiscordIds, ...env.founderDiscordIds], unclaim: [...env.adminUnclaimIds, ...env.founderUnclaimIds] };
  const candidates = await prisma.user.findMany({
    where: {
      deletedAt: null,
      OR: [{ role: "admin" }, ...(envIds.discord.length ? [{ discordId: { in: envIds.discord } }] : []), ...(envIds.unclaim.length ? [{ unclaimId: { in: envIds.unclaim } }] : [])],
    },
    orderBy: { createdAt: "asc" },
  });
  const staff = candidates.filter((u) => isAdmin(u));
  const badges = await Promise.all(staff.map((u) => publicBadgesOf(u)));

  return (
    <>
      <PageTitle
        title="Staff et permissions"
        description="Les fondateurs sont déclarés dans l'environnement du serveur ; eux seuls nomment les administrateurs et leur accordent les permissions sensibles."
        aside={
          <Link href="/staff" target="_blank" className="inline-flex items-center gap-1.5 rounded-md border border-ink-600 px-3 py-1.5 text-sm text-ink-200 hover:border-ink-400">
            Page Staff publique <ExternalLink size={13} />
          </Link>
        }
      />
      {!foundersDeclared() && (
        <p className="mb-4 rounded-md border border-claim/40 bg-claim/10 px-4 py-3 text-sm text-ink-100">
          Aucun fondateur déclaré (<code>FOUNDER_UNCLAIM_IDS</code>) : les administrateurs d&apos;office (<code>ADMIN_*</code>) ont le niveau fondateur en attendant.
        </p>
      )}
      <Panel title="Permissions sensibles" className="mb-4">
        <dl className="grid gap-2 text-xs sm:grid-cols-2">
          {STAFF_PERMISSION_KEYS.map((k) => (
            <div key={k}>
              <dt className="font-semibold text-ink-200">{STAFF_PERMISSIONS[k].label}</dt>
              <dd className="text-ink-400">{STAFF_PERMISSIONS[k].description}</dd>
            </div>
          ))}
        </dl>
      </Panel>
      <Panel>
        <ul className="divide-y divide-ink-800">
          {staff.map((u, i) => {
            const level = isFounderLevel(u) ? "founder" : "admin";
            return (
              <li key={u.id} className="flex flex-col gap-3 py-3 lg:flex-row lg:items-center">
                <div className="flex min-w-0 flex-1 items-center gap-3">
                  <img src={accountAvatarUrl(u)} alt="" className="h-9 w-9 shrink-0 rounded-full object-cover" />
                  <div className="min-w-0">
                    <p className="flex flex-wrap items-center gap-1.5 text-sm font-semibold text-ink-100">
                      {u.globalName ?? u.username}
                      {level === "founder" ? (
                        <Chip tone="claim">
                          <Crown size={10} aria-hidden="true" /> fondateur
                        </Chip>
                      ) : (
                        <Chip tone="brand">admin{u.role !== "admin" ? " (env)" : ""}</Chip>
                      )}
                      {u.id === me.id && <Chip>toi</Chip>}
                    </p>
                    <BadgeList badges={badges[i] ?? []} compact className="mt-1" />
                  </div>
                </div>
                {level === "founder" ? (
                  <p className="text-xs text-ink-400">Toutes les permissions.</p>
                ) : (
                  <StaffPermissions userId={u.id} initial={parseStaffPermissions(u.staffPermissions)} editable={founder} />
                )}
              </li>
            );
          })}
        </ul>
        {!founder && <p className="mt-3 text-xs text-ink-500">Seul un fondateur peut modifier ces permissions.</p>}
      </Panel>
    </>
  );
}
