import { ExternalLink } from "lucide-react";
import { ShopItemsEditor, type AdminShopItem } from "@/components/admin/ShopItemsEditor";
import { PageTitle } from "@/components/admin/ui";
import { BADGE_ICONS, acceptsManualGrant, parseBadgeRule, type BadgeIconKey } from "@/lib/badges";
import { SHOP_CATEGORY_KEYS, parsePerks, parseShopReward, type ShopCategory } from "@/lib/official-shop";
import { requireAdminPage } from "@/lib/server/admin";
import { prisma } from "@/lib/server/db";
import { env } from "@/lib/server/env";
import { hasStaffPermission } from "@/lib/server/staff";

export const metadata = { title: "Boutique officielle" };

// Boutique officielle Unclaim : articles (badges exclusifs, cadres de profil), prix et catégories.
export default async function AdminShop() {
  const admin = await requireAdminPage();
  const [items, badges, sales] = await Promise.all([
    prisma.shopItem.findMany({ orderBy: [{ position: "asc" }, { createdAt: "asc" }] }),
    prisma.badge.findMany({ where: { archivedAt: null, staffOnly: false, restricted: false }, orderBy: { position: "asc" } }),
    prisma.order.groupBy({ by: ["itemId"], where: { kind: "item", status: "paid" }, _count: { _all: true } }),
  ]);
  const sold = new Map(sales.map((s) => [s.itemId, s._count._all]));
  const rows: AdminShopItem[] = items.flatMap((item) => {
    const reward = parseShopReward(item.reward);
    if (!reward) return [];
    return [
      {
        id: item.id,
        slug: item.slug,
        category: (SHOP_CATEGORY_KEYS as readonly string[]).includes(item.category) ? (item.category as ShopCategory) : "profil",
        name: item.name,
        description: item.description,
        perks: parsePerks(item.perks),
        priceCents: item.priceCents,
        icon: (BADGE_ICONS as readonly string[]).includes(item.icon) ? (item.icon as BadgeIconKey) : "sparkles",
        imageUrl: item.imageUrl,
        color: item.color,
        reward,
        active: item.active,
        position: item.position,
        sold: sold.get(item.id) ?? 0,
      },
    ];
  });
  return (
    <>
      <PageTitle
        title="Boutique officielle"
        description="Personnalisations vendues à l'unité. Les abonnements (Link+, Pro, Équipe) se gèrent dans Tarifs et abonnements."
        aside={
          <a href="/boutique" target="_blank" className="inline-flex items-center gap-1.5 rounded-md border border-ink-600 px-3 py-1.5 text-sm text-ink-200 hover:border-ink-400">
            Voir la boutique <ExternalLink size={13} />
          </a>
        }
      />
      <ShopItemsEditor
        items={rows}
        badges={badges.filter((b) => acceptsManualGrant(parseBadgeRule(b.rule))).map((b) => ({ key: b.key, name: b.name }))}
        allowed={hasStaffPermission(admin, "platform.critical")}
        canSell={env.stripe.configured}
      />
    </>
  );
}
