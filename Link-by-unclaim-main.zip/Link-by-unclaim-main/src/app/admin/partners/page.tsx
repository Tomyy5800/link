import Link from "next/link";
import { ExternalLink } from "lucide-react";
import { PartnerApplicationActions, UserActions } from "@/components/admin/actions";
import { Chip, PageTitle, Panel, formatDate } from "@/components/admin/ui";
import { toOwnerProfile } from "@/lib/discord-cdn";
import { PARTNER_KINDS, PARTNER_STATUS_LABELS, type PartnerKind } from "@/lib/partners";
import { requireAdminPage } from "@/lib/server/admin";
import { isFounderLevel } from "@/lib/server/staff";
import { prisma } from "@/lib/server/db";
import { isPremium } from "@/lib/server/entitlements";

export const metadata = { title: "Partenaires" };

// Programme partenaires : candidatures à examiner, partenaires actuels, décisions récentes.
export default async function AdminPartnersPage() {
  const me = await requireAdminPage();
  const [pending, partners, reviewed] = await Promise.all([
    prisma.partnerApplication.findMany({
      where: { status: "pending" },
      orderBy: { createdAt: "asc" },
      include: { user: { include: { pages: { select: { slug: true, views: true }, orderBy: { createdAt: "asc" } } } } },
    }),
    prisma.user.findMany({ where: { partner: true }, orderBy: { partnerSince: "desc" }, include: { pages: { select: { slug: true }, orderBy: { createdAt: "asc" } } } }),
    prisma.partnerApplication.findMany({ where: { status: { not: "pending" } }, orderBy: { reviewedAt: "desc" }, take: 15, include: { user: true } }),
  ]);

  return (
    <>
      <PageTitle
        title="Partenaires"
        description="Candidatures au programme et partenaires officiels (badge, Link+ inclus, limites « partenaires » réglables dans Fonctionnalités)."
        aside={
          <Link href="/partenaires" target="_blank" className="inline-flex items-center gap-1.5 text-sm text-brand-300 hover:underline">
            Annuaire public <ExternalLink size={13} />
          </Link>
        }
      />

      <Panel title={`Candidatures à examiner (${pending.length})`}>
        {pending.length === 0 ? (
          <p className="text-sm text-ink-400">Aucune candidature en attente.</p>
        ) : (
          <ul className="divide-y divide-ink-800">
            {pending.map((a) => {
              const profile = toOwnerProfile(a.user);
              return (
                <li key={a.id} className="space-y-2 py-4 first:pt-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <img src={profile.avatarUrl} alt="" className="h-8 w-8 rounded-full object-cover" />
                    <span className="font-semibold text-ink-100">{a.name}</span>
                    <Chip tone="brand">{PARTNER_KINDS[a.kind as PartnerKind] ?? a.kind}</Chip>
                    <span className="text-xs text-ink-400">
                      par {profile.globalName ?? profile.username} · {formatDate(a.createdAt)}
                    </span>
                  </div>
                  <p className="whitespace-pre-wrap text-sm text-ink-300">{a.message}</p>
                  <p className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-ink-400">
                    {a.url && (
                      <a href={a.url} target="_blank" rel="noopener noreferrer nofollow" className="text-brand-300 hover:underline">
                        {a.url}
                      </a>
                    )}
                    {a.audience && <span>Communauté : {a.audience}</span>}
                    {a.user.pages.map((p) => (
                      <a key={p.slug} href={`/${p.slug}`} target="_blank" rel="noopener noreferrer" className="hover:text-ink-100">
                        /{p.slug} ({p.views} vues)
                      </a>
                    ))}
                  </p>
                  <PartnerApplicationActions id={a.id} />
                </li>
              );
            })}
          </ul>
        )}
      </Panel>

      <Panel title={`Partenaires officiels (${partners.length})`} className="mt-4">
        {partners.length === 0 ? (
          <p className="text-sm text-ink-400">Aucun partenaire pour l&apos;instant. Accepte une candidature, ou utilise « Partenariat » dans Comptes.</p>
        ) : (
          <ul className="divide-y divide-ink-800">
            {partners.map((u) => {
              const profile = toOwnerProfile(u);
              return (
                <li key={u.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
                  <div className="flex min-w-0 items-center gap-2.5">
                    <img src={profile.avatarUrl} alt="" className="h-8 w-8 rounded-full object-cover" />
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold">{profile.globalName ?? profile.username}</p>
                      <p className="truncate font-mono text-[11px] text-ink-500">
                        depuis le {formatDate(u.partnerSince)} · {u.pages.map((p) => `/${p.slug}`).join(" · ") || "aucune page"}
                      </p>
                    </div>
                  </div>
                  <UserActions
                    user={{
                      id: u.id,
                      plan: u.plan,
                      premiumActive: isPremium(u),
                      verified: u.verified,
                      partner: u.partner,
                      role: u.role,
                      suspended: Boolean(u.suspendedAt),
                      isSelf: u.id === me.id,
                      canPromote: isFounderLevel(me),
                    }}
                  />
                </li>
              );
            })}
          </ul>
        )}
      </Panel>

      {reviewed.length > 0 && (
        <Panel title="Décisions récentes" className="mt-4">
          <ul className="space-y-1.5 text-sm">
            {reviewed.map((a) => (
              <li key={a.id} className="flex flex-wrap items-center gap-2">
                <span className="text-ink-200">{a.name}</span>
                <span className="text-xs text-ink-500">
                  {a.user.globalName ?? a.user.username} · {formatDate(a.reviewedAt)}
                </span>
                <Chip tone={a.status === "accepted" ? "mint" : "danger"}>{PARTNER_STATUS_LABELS[a.status as keyof typeof PARTNER_STATUS_LABELS] ?? a.status}</Chip>
                {a.reviewNote && <span className="text-xs text-ink-400">« {a.reviewNote} »</span>}
              </li>
            ))}
          </ul>
        </Panel>
      )}
    </>
  );
}
