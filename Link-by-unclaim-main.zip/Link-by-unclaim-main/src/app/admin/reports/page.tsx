import { ReportActions } from "@/components/admin/actions";
import { Chip, PageTitle, Pager, Panel, formatDate, nf, pageNumber, str } from "@/components/admin/ui";
import { prisma } from "@/lib/server/db";

export const metadata = { title: "Signalements" };

const PER_PAGE = 30;
const REASONS: Record<string, string> = {
  inappropriate: "Contenu choquant",
  scam: "Arnaque / hameçonnage",
  impersonation: "Usurpation d'identité",
  harassment: "Harcèlement / haine",
  other: "Autre",
};
const TABS = [
  ["open", "À traiter"],
  ["resolved", "Traités"],
  ["dismissed", "Sans suite"],
] as const;

type Search = { searchParams: Promise<Record<string, string | string[] | undefined>> };

export default async function AdminReports({ searchParams }: Search) {
  const params = await searchParams;
  const status = (TABS.find(([v]) => v === str(params.status))?.[0] ?? "open") as (typeof TABS)[number][0];
  const page = pageNumber(params.page);

  const [counts, total, reports] = await Promise.all([
    prisma.report.groupBy({ by: ["status"], _count: { _all: true } }),
    prisma.report.count({ where: { status } }),
    prisma.report.findMany({
      where: { status },
      orderBy: { createdAt: status === "open" ? "asc" : "desc" },
      skip: (page - 1) * PER_PAGE,
      take: PER_PAGE,
      include: { page: { select: { slug: true, displayName: true, status: true, _count: { select: { reports: true } } } } },
    }),
  ]);
  const count = (s: string) => counts.find((c) => c.status === s)?._count._all ?? 0;
  const pages = Math.max(1, Math.ceil(total / PER_PAGE));

  return (
    <>
      <PageTitle title="Signalements" description="Envoyés par les visiteurs depuis le lien « Signaler » en bas de chaque page. Les plus anciens d'abord." />
      <div className="mb-4 flex gap-1.5">
        {TABS.map(([value, label]) => (
          <a
            key={value}
            href={`/admin/reports?status=${value}`}
            aria-current={status === value ? "page" : undefined}
            className={`rounded-md border px-2.5 py-1 text-xs font-medium transition ${
              status === value ? "border-brand-400 bg-brand-500/10 text-ink-100" : "border-ink-700 text-ink-400 hover:text-ink-200"
            }`}
          >
            {label} <span className="font-mono text-ink-500">{nf.format(count(value))}</span>
          </a>
        ))}
      </div>
      <Panel>
        <ul className="divide-y divide-ink-800">
          {reports.map((r) => (
            <li key={r.id} className="flex flex-col gap-3 py-3 lg:flex-row lg:items-start">
              <div className="min-w-0 flex-1">
                <p className="flex flex-wrap items-center gap-1.5 text-sm">
                  <Chip tone={r.reason === "scam" || r.reason === "harassment" ? "danger" : "claim"}>{REASONS[r.reason] ?? r.reason}</Chip>
                  <a href={`/${r.page.slug}`} target="_blank" rel="noopener noreferrer" className="font-semibold text-ink-100 hover:text-brand-300">
                    {r.page.displayName}
                  </a>
                  <span className="font-mono text-xs text-ink-400">/{r.page.slug}</span>
                  {r.page.status === "suspended" && <Chip tone="danger">page suspendue</Chip>}
                  {r.page._count.reports > 1 && <Chip>{r.page._count.reports} signalements au total</Chip>}
                </p>
                {r.message && <p className="mt-1.5 rounded-md border border-ink-800 bg-ink-950/60 px-3 py-2 text-sm whitespace-pre-line text-ink-200">{r.message}</p>}
                <p className="mt-1 font-mono text-[11px] text-ink-500">
                  {formatDate(r.createdAt, true)}
                  {r.handledAt && <> · traité le {formatDate(r.handledAt, true)}</>}
                </p>
              </div>
              <ReportActions report={{ id: r.id, status: r.status, pageSuspended: r.page.status === "suspended" }} />
            </li>
          ))}
          {reports.length === 0 && <li className="py-6 text-center text-sm text-ink-400">{status === "open" ? "Rien à traiter." : "Aucun signalement."}</li>}
        </ul>
        <Pager page={page} pages={pages} href={(p) => `/admin/reports?status=${status}&page=${p}`} />
      </Panel>
    </>
  );
}
