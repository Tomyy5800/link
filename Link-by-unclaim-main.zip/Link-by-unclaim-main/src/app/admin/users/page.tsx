import type { Prisma } from "@prisma/client";
import { UserActions } from "@/components/admin/actions";
import { Chip, PageTitle, Pager, Panel, SearchBox, formatDate, nf, pageNumber, str } from "@/components/admin/ui";
import { accountAvatarUrl } from "@/lib/discord-cdn";
import { providerMeta } from "@/lib/identity";
import { requireAdminPage } from "@/lib/server/admin";
import { prisma } from "@/lib/server/db";
import { activeTier, isAdmin, isPremium } from "@/lib/server/entitlements";
import { normalizeTier, tierName } from "@/lib/plans";
import { getSettings } from "@/lib/server/settings";
import { isFounderLevel } from "@/lib/server/staff";

export const metadata = { title: "Comptes" };

const PER_PAGE = 25;
const FILTERS = [
  ["", "Tous"],
  ["premium", "Abonnés"],
  ["admin", "Admins"],
  ["verified", "Vérifiés"],
  ["partner", "Partenaires"],
  ["suspended", "Suspendus"],
] as const;

type Search = { searchParams: Promise<Record<string, string | string[] | undefined>> };

export default async function AdminUsers({ searchParams }: Search) {
  const me = await requireAdminPage();
  const params = await searchParams;
  const q = str(params.q);
  const filter = str(params.filter);
  const page = pageNumber(params.page);
  const settings = await getSettings();
  const founder = isFounderLevel(me);

  const where: Prisma.UserWhereInput = {
    ...(q
      ? {
          OR: [
            { username: { contains: q } },
            { globalName: { contains: q } },
            { discordId: q },
            { unclaimId: q },
            { ngAccount: { contains: q } },
            { pages: { some: { slug: { contains: q.toLowerCase() } } } },
          ],
        }
      : {}),
    ...(filter === "premium"
      ? { AND: [{ OR: [{ plan: { not: "free" }, planExpiresAt: null }, { plan: { not: "free" }, planExpiresAt: { gt: new Date() } }, { basePlan: { not: "free" } }] }] }
      : {}),
    ...(filter === "admin" ? { role: "admin" } : {}),
    ...(filter === "verified" ? { verified: true } : {}),
    ...(filter === "partner" ? { partner: true } : {}),
    ...(filter === "suspended" ? { suspendedAt: { not: null } } : {}),
  };
  const [total, users] = await Promise.all([
    prisma.user.count({ where }),
    prisma.user.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * PER_PAGE,
      take: PER_PAGE,
      include: { pages: { select: { slug: true, status: true, views: true }, orderBy: { createdAt: "asc" } } },
    }),
  ]);
  const pages = Math.max(1, Math.ceil(total / PER_PAGE));
  const href = (p: number, f = filter) => `/admin/users?${new URLSearchParams({ ...(q ? { q } : {}), ...(f ? { filter: f } : {}), ...(p > 1 ? { page: String(p) } : {}) })}`;

  return (
    <>
      <PageTitle
        title="Comptes"
        description={`${nf.format(total)} compte${total > 1 ? "s" : ""}. Offre ${settings.premiumName}, badge vérifié, rôle et suspension.`}
        aside={<SearchBox placeholder="Pseudo, ID Discord, adresse…" defaultValue={q} hidden={filter ? { filter } : undefined} />}
      />
      <div className="mb-4 flex flex-wrap gap-1.5">
        {FILTERS.map(([value, label]) => (
          <a
            key={value}
            href={href(1, value)}
            aria-current={filter === value ? "page" : undefined}
            className={`rounded-md border px-2.5 py-1 text-xs font-medium transition ${
              filter === value ? "border-brand-400 bg-brand-500/10 text-ink-100" : "border-ink-700 text-ink-400 hover:text-ink-200"
            }`}
          >
            {label}
          </a>
        ))}
      </div>

      <Panel>
        <ul className="divide-y divide-ink-800">
          {users.map((u) => {
            const premium = isPremium(u);
            const admin = isAdmin(u);
            return (
              <li key={u.id} className="flex flex-col gap-3 py-3 lg:flex-row lg:items-center">
                <div className="flex min-w-0 flex-1 items-center gap-3">
                  <img src={accountAvatarUrl(u)} alt="" className="h-9 w-9 shrink-0 rounded-full object-cover" />
                  <div className="min-w-0">
                    <p className="flex flex-wrap items-center gap-1.5 text-sm font-semibold text-ink-100">
                      {u.globalName ?? u.username}
                      <span className="font-normal text-ink-400">@{u.username}</span>
                      {premium && (
                        <Chip tone="claim">
                          {tierName(activeTier(u), settings.premiumName)}
                          {normalizeTier(u.plan) === activeTier(u) && u.planExpiresAt ? ` → ${formatDate(u.planExpiresAt)}` : ""}
                        </Chip>
                      )}
                      {admin && <Chip tone="brand">admin{u.role !== "admin" ? " (env)" : ""}</Chip>}
                      {u.verified && <Chip tone="mint">vérifié</Chip>}
                      {u.partner && <Chip tone="brand">partenaire</Chip>}
                      {u.deletedAt && <Chip>supprimé</Chip>}
                      {u.suspendedAt && <Chip tone="danger">suspendu</Chip>}
                      {u.banned && <Chip tone="danger">bloqué Unclaim</Chip>}
                    </p>
                    <p className="truncate font-mono text-[11px] text-ink-500">
                      {providerMeta(u.provider).name} · {u.unclaimId ?? u.discordId ?? u.id}
                      {u.ngAccount && <> · NG {u.ngAccount}</>} · inscrit le {formatDate(u.createdAt)} · vu le {formatDate(u.lastLoginAt)}
                      {u.pages.map((p) => (
                        <span key={p.slug}>
                          {" · "}
                          <a href={`/${p.slug}`} target="_blank" rel="noopener noreferrer" className="text-brand-300 hover:underline">
                            /{p.slug}
                          </a>{" "}
                          ({nf.format(p.views)} vues)
                        </span>
                      ))}
                    </p>
                    {u.suspendedAt && u.suspendReason && <p className="mt-0.5 text-xs text-danger">Motif : {u.suspendReason}</p>}
                  </div>
                </div>
                <UserActions
                  user={{ id: u.id, plan: u.plan, premiumActive: premium, verified: u.verified, partner: u.partner, role: u.role, suspended: Boolean(u.suspendedAt), isSelf: u.id === me.id, canPromote: founder }}
                />
              </li>
            );
          })}
          {users.length === 0 && <li className="py-6 text-center text-sm text-ink-400">Aucun compte ne correspond.</li>}
        </ul>
        <Pager page={page} pages={pages} href={(p) => href(p)} />
      </Panel>
    </>
  );
}
