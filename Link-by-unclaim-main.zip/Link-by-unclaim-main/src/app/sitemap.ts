import type { MetadataRoute } from "next";
import { parsePageOptions } from "@/lib/page-schema";
import { prisma } from "@/lib/server/db";
import { env } from "@/lib/server/env";

// Plan du site pour les moteurs de recherche : pages vitrine et pages publiques indexables
// (publiées, actives, sans « masquer des moteurs » ni avertissement 18+).
// Calculé à la demande : les nouvelles pages y apparaissent tout de suite, et rien n'est figé au
// build (ni l'APP_URL ni la base de la machine de build). Les moteurs le lisent rarement.
export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = env.appUrl;
  const pages = await prisma.page
    .findMany({
      where: { published: true, status: "active", user: { banned: false, suspendedAt: null } },
      select: { slug: true, updatedAt: true, options: true },
      orderBy: { views: "desc" },
      take: 5000,
    })
    .catch(() => []);
  const now = new Date();
  return [
    { url: base, lastModified: now, changeFrequency: "weekly", priority: 1 },
    { url: `${base}/plus`, lastModified: now, changeFrequency: "monthly", priority: 0.6 },
    { url: `${base}/partenaires`, lastModified: now, changeFrequency: "weekly", priority: 0.6 },
    { url: `${base}/boutique`, lastModified: now, changeFrequency: "weekly", priority: 0.5 },
    { url: `${base}/staff`, lastModified: now, changeFrequency: "monthly", priority: 0.4 },
    ...["/cgu", "/cgv", "/mentions-legales", "/confidentialite"].map((path) => ({ url: `${base}${path}`, changeFrequency: "yearly" as const, priority: 0.2 })),
    ...pages
      .filter((p) => {
        const options = parsePageOptions(p.options);
        return !options.noindex && !options.ageGate;
      })
      .map((p) => ({ url: `${base}/${p.slug}`, lastModified: p.updatedAt, changeFrequency: "weekly" as const, priority: 0.5 })),
  ];
}
