import Link from "next/link";
import {
  ArrowRight,
  Bot,
  CalendarClock,
  Castle,
  ChartColumn,
  Gamepad2,
  Handshake,
  KeyRound,
  LayoutGrid,
  Mail,
  Palette,
  Plus,
  Radio,
  PackageCheck,
  ServerCog,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Timer,
  UsersRound,
  Zap,
} from "lucide-react";
import { ProviderButton, ProviderIcon } from "@/components/auth/ProviderButton";
import { PlusLogo } from "@/components/brand/Logo";
import { DiscordLogo } from "@/components/icons/SocialIcon";
import { BuildStory } from "@/components/landing/BuildStory";
import { ChunkField } from "@/components/landing/ChunkField";
import { ClaimBox } from "@/components/landing/ClaimBox";
import { DemoPlayground } from "@/components/landing/DemoPlayground";
import { FeatureVisual, type FeatureVisualKind } from "@/components/landing/FeatureVisuals";
import { HoloCard } from "@/components/landing/HoloCard";
import { IntegrationOrbit } from "@/components/landing/IntegrationOrbit";
import { JourneyRail } from "@/components/landing/JourneyRail";
import { MarketingHeader } from "@/components/site/MarketingHeader";
import { PlatformMarquee } from "@/components/landing/PlatformMarquee";
import { RotatingWord } from "@/components/landing/RotatingWord";
import { SplitWords } from "@/components/landing/SplitWords";
import { CursorGlow } from "@/components/landing/CursorGlow";
import { TemplateGallery } from "@/components/landing/TemplateGallery";
import { VoxelTerritory } from "@/components/landing/VoxelTerritory";
import { PageTransition } from "@/components/site/PageTransition";
import { SmoothScroll } from "@/components/site/SmoothScroll";
import { SiteFooter } from "@/components/site/SiteChrome";
import { CountUp } from "@/components/ui/CountUp";
import { demoPage } from "@/lib/demo";
import { toOwnerProfile } from "@/lib/discord-cdn";
import { formatPrice } from "@/lib/features";
import { providerMeta } from "@/lib/identity";
import { prisma } from "@/lib/server/db";
import { freeForAll } from "@/lib/server/entitlements";
import { env } from "@/lib/server/env";
import { getSettings } from "@/lib/server/settings";
import { getCurrentUser } from "@/lib/server/unclaim-auth";
import { availableProviders } from "@/lib/server/unclaim-auth/client";
import { templateShowcases } from "@/lib/showcase";
import { accentOnDark, parseTheme } from "@/lib/theme";

type Feature = { icon: React.ComponentType<{ size?: number; className?: string }>; title: string; text: string; visual: FeatureVisualKind; wide?: boolean };

// Mosaïque : deux grandes cartes en haut et en bas, huit petites au milieu.
const FEATURES: Feature[] = [
  {
    icon: Bot,
    title: "Créée en discutant",
    text: "Réponds à quelques questions : l'assistant compose ta page sous tes yeux. En ligne en moins de cinq minutes.",
    visual: "assistant",
    wide: true,
  },
  {
    icon: Zap,
    title: "Une page qui vit toute seule",
    text: "Automatisations : bandeau pendant tes lives, thème festif le jour de ton anniversaire, rendez-vous chaque semaine.",
    visual: "automations",
    wide: true,
  },
  {
    icon: ShoppingBag,
    title: "Ta boutique, sur ta page",
    text: "Merch, prints, commissions : photos, prix et promos, tailles, stock. Lien vers ta boutique ou panier qui t'envoie les commandes.",
    visual: "shop",
    wide: true,
  },
  {
    icon: UsersRound,
    title: "Plusieurs pages, en équipe",
    text: "Une page par projet, serveur ou partenariat. Invite tes collaborateurs comme éditeurs ou lecteurs.",
    visual: "team",
  },
  {
    icon: Gamepad2,
    title: "Tous tes jeux",
    text: "Minecraft, Steam, Roblox, Chess.com et Lichess en direct ; Paladium, Hypixel, Valorant… en carte de profil.",
    visual: "games",
  },
  {
    icon: Radio,
    title: "Radio en direct",
    text: "LyxiaRadio ou ta webradio, avec le titre en cours et la pochette. En bloc, ou en musique de fond.",
    visual: "radio",
  },
  {
    icon: DiscordLogo,
    title: "Ton Discord, intégré",
    text: "Statut en direct, carte de profil, invitation de serveur, dates et émojis Discord dans tes textes.",
    visual: "discord",
  },
  {
    icon: Castle,
    title: "NationsGlory et skin 3D",
    text: "Pays, rang et dernière connexion sur chaque serveur, et ton skin animé que les visiteurs font pivoter.",
    visual: "nationsglory",
  },
  {
    icon: Mail,
    title: "Formulaire de contact",
    text: "Tes visiteurs t'écrivent sans connaître ton e-mail ; les messages arrivent dans « Mon espace » et sur Discord.",
    visual: "contact",
  },
  {
    icon: PackageCheck,
    title: "Commandes suivies",
    text: "Chaque demande arrive dans « Mon espace › Commandes » et sur Discord : accepte, prépare, termine.",
    visual: "orders",
  },
  {
    icon: CalendarClock,
    title: "Agenda et anniversaire",
    text: "Tes prochains streams à l'heure de chaque visiteur, et un compte à rebours d'anniversaire avec confettis.",
    visual: "agenda",
  },
  {
    icon: LayoutGrid,
    title: "25 blocs à composer",
    text: "Liens, dossiers, réseaux, galerie, vidéos, musique, questions, badges… Ctrl+K et c'est ajouté.",
    visual: "blocks",
  },
  {
    icon: Timer,
    title: "Blocs programmés",
    text: "Une promo le week-end, un lien pendant le live : le bloc apparaît et disparaît tout seul aux dates choisies.",
    visual: "schedule",
  },
  {
    icon: Palette,
    title: "Ton style, en détail",
    text: "Douze thèmes, toutes les polices Google Fonts, effets, particules, CSS personnalisé, et une mosaïque sur grand écran.",
    visual: "style",
    wide: true,
  },
  {
    icon: ChartColumn,
    title: "Vues, clics et partage",
    text: "Combien de visiteurs, d'où ils viennent, quels liens ils ouvrent. Export tableur, QR code et bouton de partage inclus.",
    visual: "stats",
    wide: true,
  },
];

/** « Discord, Google et Microsoft » */
function listNames(ids: string[]): string {
  const names = ids.map((id) => providerMeta(id).name);
  if (names.length <= 1) return names[0] ?? "ton compte";
  return `${names.slice(0, -1).join(", ")} et ${names[names.length - 1]}`;
}

function SectionTitle({ kicker, title, text, tone = "brand" }: { kicker: string; title: string; text?: string; tone?: "brand" | "claim" }) {
  return (
    <div className="ui-reveal max-w-2xl">
      <p className={`hud-label ${tone === "claim" ? "text-claim" : "text-brand-300"}`}>{kicker}</p>
      <h2 className="mt-3 font-display text-3xl font-bold tracking-tight text-balance sm:text-[2.6rem] sm:leading-[1.08]">
        <SplitWords text={title} />
      </h2>
      {text && <p className="mt-3 text-ink-300">{text}</p>}
    </div>
  );
}

export default async function HomePage() {
  const [user, settings] = await Promise.all([getCurrentUser(), getSettings()]);
  // Boutiques personnelles fermées : la vitrine n'en montre pas (rien n'est promis qui ne soit ouvert).
  const shopsOpen = settings.personalShops;
  const withoutShop = <T extends { page: { blocks: { type: string }[] } }>(x: T): T =>
    shopsOpen ? x : { ...x, page: { ...x.page, blocks: x.page.blocks.filter((b) => b.type !== "shop") } };
  const demo = withoutShop(demoPage());
  const showcases = templateShowcases().map(withoutShop);
  const features = shopsOpen ? FEATURES : FEATURES.filter((f) => f.visual !== "shop" && f.visual !== "orders");
  const premiumName = settings.premiumName;
  const cheapest = settings.offers.filter((o) => o.active).sort((a, b) => a.priceCents - b.priceCents)[0];
  const plusFree = freeForAll(settings);
  // Moyens de connexion proposés par Unclaim Auth (Discord, Google, Microsoft…) : un clic mène directement au fournisseur.
  const providers = env.unclaim.configured ? await availableProviders() : [];
  const [featured, stats] = await Promise.all([
    // Pages mises en avant par l'administration (publiques, actives, comptes en règle).
    prisma.page
      .findMany({
        where: { featured: true, published: true, status: "active", user: { banned: false, suspendedAt: null } },
        orderBy: { views: "desc" },
        take: 6,
        select: { slug: true, displayName: true, theme: true, avatarSource: true, avatarUrl: true, user: true },
      })
      .catch(() => []),
    prisma.page.aggregate({ where: { published: true, status: "active" }, _count: { _all: true }, _sum: { views: true } }).catch(() => null),
  ]);
  const pageCount = stats?._count._all ?? 0;
  const viewCount = stats?._sum.views ?? 0;
  const host = new URL(env.appUrl).host;
  const loggedIn = Boolean(user);
  const assistantHref = user ? "/dashboard/assistant" : `/login?next=${encodeURIComponent("/dashboard/assistant")}`;

  const faq = [
    {
      q: "C'est gratuit ?",
      a: plusFree
        ? `Oui. Et pour le lancement, même les fonctions de ${premiumName} sont offertes à tout le monde.`
        : `Oui, la page et la plupart des blocs sont gratuits. ${premiumName}, en option, ajoute les effets, la musique, le CSS personnalisé et les statistiques détaillées.`,
    },
    {
      q: "Avec quel compte je me connecte ?",
      a: `Avec ${listNames(providers.length ? providers : ["discord"])}, grâce à Unclaim Auth : pas de mot de passe à créer, et le même compte Unclaim sur tous les sites Unclaim. D'autres comptes s'ajoutent au fil du temps.`,
    },
    {
      q: "Je ne joue pas à NationsGlory, c'est pour moi ?",
      a: "Oui. Les blocs NationsGlory sont facultatifs : liens, réseaux, radio, agenda, galerie, vidéos et profils d'autres jeux (Minecraft, Paladium, Steam, Roblox, Valorant…) suffisent à faire une page complète.",
    },
    {
      q: "Puis-je avoir plusieurs pages et les gérer à plusieurs ?",
      a: "Oui : une page par projet, serveur, équipe ou partenariat, selon ton offre. Depuis l'éditeur, invite tes collaborateurs par un lien, comme éditeurs ou comme lecteurs (statistiques et messages).",
    },
    {
      q: "Comment devenir partenaire ?",
      a: "Créateurs, serveurs, nations, équipes et associations peuvent candidater depuis « Mon espace › Partenariat ». Les partenaires ont un badge officiel, Link+ inclus, plus de pages et une place dans l'annuaire.",
    },
    {
      q: "Comment mettre mon lien dans ma bio Discord ?",
      a: "Dans Discord : Paramètres › Profils › À propos de moi, colle ton adresse. Elle s'affiche avec un aperçu aux couleurs de ta page.",
    },
    {
      q: "Que faites-vous de mes données ?",
      a: "Rien d'autre que faire fonctionner ta page. Pas de publicité, des statistiques anonymes sans adresse IP, et tu peux tout télécharger ou supprimer depuis « Mon espace ».",
    },
    {
      q: "Comment marche l'assistant de création ?",
      a: "Il te pose quelques questions (ton nom, ce que tu fais, tes liens, tes jeux, l'ambiance voulue) et construit ta page en direct. Tu vérifies l'aperçu, tu choisis ton adresse, c'est en ligne. Tout reste modifiable ensuite.",
    },
    {
      q: "Puis-je changer d'adresse ou de style plus tard ?",
      a: "À tout moment, depuis l'éditeur : adresse, thème, blocs et mise en page. Les changements sont enregistrés pendant que tu édites.",
    },
  ];

  return (
    <PageTransition>
      <div className="bg-hud relative overflow-x-clip">
        <MarketingHeader premiumName={premiumName} loggedIn={loggedIn} />

        <CursorGlow />
        <JourneyRail premiumName={premiumName} />
        <main className="relative isolate">
          <div className="pointer-events-none absolute inset-0 -z-10 overflow-hidden" aria-hidden="true">
            <span className="ui-ambient top-[16%] -left-40 h-[520px] w-[520px] bg-brand-500" />
            <span className="ui-ambient top-[34%] -right-40 h-[480px] w-[480px] bg-claim [animation-delay:-8s]" />
            <span className="ui-ambient top-[55%] left-[20%] h-[560px] w-[560px] bg-[#7c5cf5] [animation-delay:-14s]" />
            <span className="ui-ambient top-[78%] -right-32 h-[520px] w-[520px] bg-brand-600 [animation-delay:-4s]" />
          </div>
          {/* Hero */}
          <section id="accueil" className="relative">
            {/* Territoire 3D : se soulève sous le pointeur, se revendique d'un clic */}
            <VoxelTerritory hint className="[mask-image:radial-gradient(ellipse_85%_80%_at_55%_45%,#000_40%,transparent_88%)]" />
            {/* Voile de lecture : texte bien contrasté, relief visible à droite */}
            <div
              className="pointer-events-none absolute inset-0 bg-ink-950/70 lg:bg-[linear-gradient(90deg,rgba(2,6,24,0.92)_0%,rgba(2,6,24,0.72)_30%,rgba(2,6,24,0.08)_56%,rgba(2,6,24,0)_100%)]"
              aria-hidden="true"
            />
            <div className="pointer-events-none absolute inset-x-0 bottom-0 h-40 bg-gradient-to-b from-transparent to-ink-950" aria-hidden="true" />
            <div className="relative mx-auto grid max-w-6xl grid-cols-1 items-center gap-14 px-4 pt-24 pb-16 sm:px-6 lg:grid-cols-[1.1fr_0.9fr] lg:pt-30">
              <div className="ui-stagger">
                <a
                  href={assistantHref}
                  className="ui-press group inline-flex items-center gap-2 rounded-full border border-brand-500/40 bg-brand-500/10 py-1 pr-3 pl-1 text-xs font-medium text-brand-300 transition hover:border-brand-400 hover:bg-brand-500/15"
                >
                  <span className="inline-flex items-center gap-1 rounded-full bg-brand-500 px-2 py-0.5 font-semibold text-ink-950">
                    <Sparkles size={12} /> Nouveau
                  </span>
                  Crée ta page en discutant avec l&apos;assistant IA
                  <ArrowRight size={13} />
                </a>
                <h1 className="mt-6 font-display text-[2.8rem] leading-[1] font-bold tracking-tight sm:text-[4rem]">
                  <span className="sr-only">Un seul lien. Tout ton univers.</span>
                  <span aria-hidden="true">
                    Un seul lien.
                    <br />
                    <span className="ui-gradient-text">Tout</span> ton <RotatingWord words={["univers.", "serveur.", "stream.", "pays.", "équipe.", "projet."]} className="text-brand-300" />
                  </span>
                </h1>
                <p className="mt-6 max-w-xl text-lg leading-relaxed text-ink-300">
                  Transforme ta bio Discord, Twitch ou TikTok en vraie page de profil : liens, réseaux, radio en direct, agenda, profils de jeu, ton
                  pays NationsGlory et ton skin en 3D.
                </p>
                <div className="mt-8">
                  <ClaimBox host={host} loggedIn={loggedIn} />
                </div>
                <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 text-sm">
                  {user ? (
                    <Link href="/dashboard" className="inline-flex items-center gap-1.5 font-semibold text-ink-100 hover:text-white">
                      Ouvrir mon espace <ArrowRight size={15} />
                    </Link>
                  ) : null}
                  <a href="#demo" className="text-ink-300 underline-offset-4 hover:text-ink-100 hover:underline">
                    Voir un exemple
                  </a>
                  <a href="#modeles" className="text-ink-300 underline-offset-4 hover:text-ink-100 hover:underline">
                    Parcourir les modèles
                  </a>
                </div>
                {!user && providers.length > 0 && (
                  <p className="mt-6 flex flex-wrap items-center gap-2 text-sm text-ink-400">
                    Connexion en un clic avec
                    {providers.map((id) => (
                      <span key={id} className="inline-flex items-center gap-1.5 rounded-md border border-ink-700 bg-ink-900/70 px-2 py-1 text-ink-200" title={providerMeta(id).name}>
                        <ProviderIcon provider={id} size={14} /> {providerMeta(id).name}
                      </span>
                    ))}
                  </p>
                )}
              </div>

              {/* Démo : une vraie page rendue par le même moteur que les pages publiques */}
              <div id="demo" className="scroll-mt-24 animate-rise [animation-delay:150ms]">
                <DemoPlayground demo={demo} />
              </div>
            </div>
          </section>

          {/* Plateformes */}
          <section className="border-y border-white/5 bg-ink-950/40 py-6" aria-label="Plateformes">
            <p className="hud-label mb-4 text-center text-ink-500">Un seul lien pour tout ce que tu fais en ligne</p>
            <PlatformMarquee />
          </section>

          {/* Chiffres réels, affichés seulement quand ils parlent d'eux-mêmes */}
          {pageCount >= 25 && (
            <section className="mx-auto max-w-6xl px-4 pt-14 sm:px-6" aria-label="En chiffres">
              <dl className="ui-reveal grid grid-cols-2 divide-x divide-ink-700 rounded-lg border border-ink-700 bg-ink-900/80 text-center">
                <div className="p-6">
                  <dt className="hud-label text-ink-400">Pages en ligne</dt>
                  <dd className="mt-1 font-display text-4xl font-bold">
                    <CountUp value={pageCount} />
                  </dd>
                </div>
                <div className="p-6">
                  <dt className="hud-label text-ink-400">Visites</dt>
                  <dd className="mt-1 font-display text-4xl font-bold">
                    <CountUp value={viewCount} />
                  </dd>
                </div>
              </dl>
            </section>
          )}

          {/* Histoire au défilement : la page se construit dans le téléphone */}
          <BuildStory demo={demo} host={host} />

          {/* Fonctionnalités */}
          <section id="fonctionnalites" className="mx-auto max-w-6xl scroll-mt-20 px-4 py-24 sm:px-6">
            <SectionTitle kicker="Une vitrine, pas une liste" title="Tout ce que ta bio ne pouvait pas contenir." />
            <div className="mt-12 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {features.map(({ icon: Icon, title, text, visual, wide }) => (
                <article
                  key={title}
                  data-spotlight
                  className={`ui-spotlight ui-reveal rounded-lg border border-ink-700 bg-ink-900/80 p-4 ${wide ? "sm:col-span-2" : ""}`}
                >
                  <FeatureVisual kind={visual} />
                  <h3 className="mt-4 flex items-center gap-2 font-display text-lg font-semibold">
                    <Icon size={18} className="text-brand-300" /> {title}
                  </h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-ink-300">{text}</p>
                </article>
              ))}
            </div>
          </section>

          {/* Intégrations : les plateformes en orbite autour de Link */}
          <section id="integrations" className="relative mx-auto grid max-w-6xl grid-cols-1 items-center gap-10 overflow-hidden px-4 py-20 sm:px-6 lg:grid-cols-[0.9fr_1.1fr] lg:overflow-visible">
            <div>
              <SectionTitle
                kicker="Intégrations"
                title="Toutes tes plateformes gravitent autour d'un seul lien."
                text="Colle n'importe quelle adresse : Link reconnaît la plateforme, met la bonne icône et va chercher ce qui est vivant (statut Discord, live, radio, profils de jeu)."
              />
              <dl className="ui-reveal-children mt-8 grid grid-cols-2 gap-3">
                {[
                  ["27", "plateformes reconnues toutes seules"],
                  ["Direct", "statut Discord, lives, webradios"],
                  ["17 jeux", "profils et statistiques de jeu"],
                  ["0 clé", "dans ton navigateur : tout passe par le serveur"],
                ].map(([value, label]) => (
                  <div key={label} data-spotlight className="ui-spotlight rounded-xl border border-ink-700 bg-ink-900/80 p-4">
                    <dt className="font-display text-2xl font-bold text-brand-300">{value}</dt>
                    <dd className="mt-1 text-sm text-ink-300">{label}</dd>
                  </div>
                ))}
              </dl>
            </div>
            <IntegrationOrbit />
          </section>

          {/* Modèles */}
          <section id="modeles" className="mx-auto max-w-6xl scroll-mt-20 px-4 py-16 sm:px-6">
            <SectionTitle
              kicker="Jamais de page blanche"
              title="Pars d'un modèle."
              text="Chaque modèle place les bons blocs et un thème assorti. Clique pour voir une vraie page d'exemple, puis lance-toi."
            />
            <TemplateGallery showcases={showcases} owner={demo.owner} extras={demo.extras} loggedIn={loggedIn} />
          </section>

          {/* Pages à la une */}
          {featured.length > 0 && (
            <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
              <SectionTitle kicker="À la une" title="Elles ont revendiqué leur adresse." tone="claim" />
              <ul className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {featured.map((p) => {
                  const theme = parseTheme(p.theme);
                  const accent = accentOnDark(theme.accent);
                  const avatar = p.avatarSource === "custom" && p.avatarUrl ? p.avatarUrl : toOwnerProfile(p.user).avatarUrl;
                  return (
                    <li key={p.slug} className="ui-reveal">
                      <a
                        href={`/${p.slug}`}
                        data-spotlight
                        className="ui-spotlight ui-lift group flex items-center gap-3 rounded-lg border border-ink-700 bg-ink-900 p-3"
                        style={{ boxShadow: `inset 3px 0 0 ${accent}` }}
                      >
                        <img src={avatar} alt="" className="h-12 w-12 shrink-0 rounded-full object-cover transition-transform duration-500 group-hover:scale-110" loading="lazy" />
                        <span className="min-w-0 flex-1">
                          <span className="block truncate font-semibold text-ink-100 group-hover:text-white">{p.displayName}</span>
                          <span className="block truncate font-mono text-xs text-ink-400">
                            {host}/<span style={{ color: accent }}>{p.slug}</span>
                          </span>
                        </span>
                        <ArrowRight size={16} className="shrink-0 text-ink-500 opacity-0 transition-opacity group-hover:opacity-100" />
                      </a>
                    </li>
                  );
                })}
              </ul>
            </section>
          )}

          {/* Link+ : carte de membre holographique */}
          <section id="linkplus" className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
            <div className="ui-glow-border ui-reveal grid items-center gap-10 rounded-xl bg-[linear-gradient(150deg,rgba(255,194,71,0.1),rgba(2,6,24,0.6)_60%)] p-8 sm:p-10 lg:grid-cols-[1fr_auto]">
              <div>
                <PlusLogo size={44} name={premiumName} />
                <h2 className="mt-5 font-display text-3xl font-bold tracking-tight">{plusFree ? "Offert pour le lancement." : "Pour aller plus loin."}</h2>
                <p className="mt-2 max-w-xl text-ink-300">
                  Effets animés, musique et vidéo de fond, automatisations, CSS personnalisé, statistiques détaillées
                  {plusFree
                    ? " : tout est gratuit pour tout le monde, sans paiement ni code."
                    : `${cheapest ? `, dès ${formatPrice(cheapest.priceCents)} par mois` : ""}. Abonnement sans engagement, résiliable à tout moment.`}
                </p>
                <Link
                  href="/plus"
                  className="mt-6 inline-flex items-center justify-center gap-2 rounded-md bg-claim px-5 py-3 font-semibold text-ink-950 transition-[filter] duration-150 hover:brightness-110"
                >
                  {plusFree ? "Voir ce qui est inclus" : "Voir les offres"} <ArrowRight size={18} aria-hidden="true" />
                </Link>
              </div>
              <div className="mx-auto w-full max-w-[380px] lg:w-[380px]">
                <HoloCard name={premiumName} tagline={plusFree ? "Offert à tous pendant le lancement" : "Effets, musique, automatisations"} />
              </div>
            </div>
          </section>

          {/* Partenaires */}
          <section className="mx-auto max-w-6xl px-4 pb-4 sm:px-6">
            <div
              data-spotlight
              data-tone="claim"
              className="ui-spotlight ui-reveal flex flex-col items-start justify-between gap-6 rounded-xl border border-ink-700 bg-ink-900/80 p-8 sm:flex-row sm:items-center"
            >
              <div className="flex items-start gap-4">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg border border-claim/40 bg-claim/10 text-claim">
                  <Handshake size={24} />
                </span>
                <div>
                  <h2 className="font-display text-2xl font-bold tracking-tight">Créateur, serveur, nation, équipe ?</h2>
                  <p className="mt-1 max-w-xl text-ink-300">
                    Rejoins le programme partenaires : badge officiel, {premiumName} inclus, plus de pages et de collaborateurs, et une place dans
                    l&apos;annuaire.
                  </p>
                </div>
              </div>
              <Link
                href="/partenaires"
                className="inline-flex shrink-0 items-center gap-2 rounded-md border border-ink-500 px-4 py-2.5 font-semibold text-ink-100 transition-colors hover:border-claim hover:text-claim"
              >
                Le programme <ArrowRight size={16} aria-hidden="true" />
              </Link>
            </div>
          </section>

          {/* Confiance et sécurité */}
          <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
            <div className="ui-reveal grid gap-8 rounded-xl border border-ink-700 bg-ink-900 p-8 sm:p-12 lg:grid-cols-[1fr_1.2fr]">
              <div>
                <p className="hud-label text-brand-300">Sous le capot</p>
                <h2 className="mt-3 font-display text-3xl font-bold tracking-tight">Une identité Unclaim, des données qui restent au serveur.</h2>
              </div>
              <ul className="ui-reveal-children grid gap-6 text-sm leading-relaxed text-ink-300 sm:grid-cols-2">
                {[
                  {
                    icon: KeyRound,
                    title: "Unclaim Auth.",
                    text: "Une connexion avec ton compte existant (Discord, Google, Microsoft…), un même ID Unclaim sur tous les sites, et jamais de mot de passe chez nous.",
                  },
                  {
                    icon: ServerCog,
                    title: "API côté serveur.",
                    text: "NationsGlory, Discord et Lanyard passent par nos services : aucune clé n'arrive dans le navigateur.",
                  },
                  {
                    icon: LayoutGrid,
                    title: "Tes données t'appartiennent.",
                    text: "Enregistrement automatique, annuler et rétablir, export complet en un clic.",
                  },
                  {
                    icon: ShieldCheck,
                    title: "Statistiques anonymes.",
                    text: "Une visite par personne et par jour, des clics agrégés, aucune adresse IP stockée, aucune publicité.",
                  },
                ].map(({ icon: Icon, title, text }) => (
                  <li key={title} className="flex gap-3">
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md border border-ink-600 bg-ink-800 text-brand-300">
                      <Icon size={16} aria-hidden="true" />
                    </span>
                    <span>
                      <strong className="text-ink-100">{title}</strong> {text}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </section>

          {/* Questions */}
          <section id="questions" className="mx-auto max-w-3xl scroll-mt-20 px-4 py-16 sm:px-6">
            <SectionTitle kicker="Questions fréquentes" title="Tout ce que tu te demandes." />
            <div className="mt-8 divide-y divide-ink-800 overflow-hidden rounded-xl border border-ink-800 bg-ink-900/60">
              {faq.map((item) => (
                <details key={item.q} className="ui-accordion group px-5">
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-4 py-4 font-semibold text-ink-100 transition hover:text-white">
                    {item.q}
                    <span className="ui-accordion-icon flex h-7 w-7 shrink-0 items-center justify-center rounded-md border border-ink-700 text-claim group-hover:border-claim/50">
                      <Plus size={15} aria-hidden="true" />
                    </span>
                  </summary>
                  <p className="pb-5 text-sm leading-relaxed text-ink-300">{item.a}</p>
                </details>
              ))}
            </div>
          </section>

          {/* Appel final */}
          <section id="commencer" className="relative overflow-hidden">
            <ChunkField className="[mask-image:radial-gradient(ellipse_60%_80%_at_50%_60%,#000_10%,transparent_75%)]" />
            <div className="relative mx-auto flex max-w-6xl flex-col items-center px-4 pt-16 pb-28 text-center sm:px-6">
              <h2 className="ui-reveal mx-auto max-w-2xl font-display text-4xl font-bold tracking-tight text-balance sm:text-6xl">
                Revendique <span className="ui-gradient-text">ton adresse</span>.
              </h2>
              <p className="ui-reveal mx-auto mt-4 max-w-md text-ink-300">Ta page est prête en trois minutes, et ton lien tient dans n&apos;importe quelle bio.</p>
              <div className="ui-reveal mt-8 flex w-full justify-center">
                <ClaimBox host={host} loggedIn={loggedIn} size="md" />
              </div>
              {!user && providers.length > 0 && (
                <div className="ui-reveal mx-auto mt-6 flex max-w-xl flex-wrap justify-center gap-2.5">
                  {providers.map((provider) => (
                    <ProviderButton key={provider} provider={provider} compact />
                  ))}
                </div>
              )}
            </div>
          </section>
        </main>

        <SiteFooter premiumName={premiumName} />
        <SmoothScroll />
      </div>
    </PageTransition>
  );
}
