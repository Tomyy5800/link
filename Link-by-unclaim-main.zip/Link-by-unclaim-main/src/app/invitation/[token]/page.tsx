import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { CircleAlert, UserPlus } from "lucide-react";
import { InviteAccept } from "@/components/account/InviteAccept";
import { Logo } from "@/components/brand/Logo";
import { getSyncedUser, needsTerms } from "@/lib/server/access";
import { describeInvite } from "@/lib/server/invites";

export const metadata: Metadata = { title: "Invitation", robots: { index: false, follow: false } };

const ROLE_TEXT = {
  editor: "modifier ses blocs, son profil et son apparence",
  viewer: "consulter ses statistiques et ses messages",
} as const;

// Invitation à collaborer sur une page : description, puis acceptation (connexion requise).
export default async function InvitationPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const path = `/invitation/${token}`;
  const [invite, user] = await Promise.all([describeInvite(token), getSyncedUser()]);
  if (user && invite && needsTerms(user)) redirect(`/bienvenue?next=${encodeURIComponent(path)}`);

  return (
    <div className="bg-hud min-h-screen">
      <header className="mx-auto flex max-w-5xl items-center px-4 py-5">
        <Logo />
      </header>
      <main className="mx-auto max-w-md px-4 pt-10 pb-20 animate-rise">
        {!invite ? (
          <div className="hud-panel rounded-[2px] border border-ink-700 bg-ink-900/80 p-6 text-center">
            <CircleAlert size={28} className="mx-auto text-claim" />
            <h1 className="mt-3 font-display text-2xl font-bold">Invitation expirée</h1>
            <p className="mt-2 text-sm text-ink-300">Ce lien a déjà servi ou n&apos;est plus valable. Demande un nouveau lien à la personne qui t&apos;a invité·e.</p>
            <Link href="/dashboard" className="mt-5 inline-block text-sm text-brand-300 hover:underline">
              Aller à mon espace
            </Link>
          </div>
        ) : (
          <div className="hud-panel rounded-[2px] border border-ink-700 bg-ink-900/80 p-6 text-center">
            <img src={invite.ownerAvatar} alt="" className="mx-auto h-16 w-16 rounded-full object-cover ring-2 ring-ink-700" />
            <p className="hud-label mt-4 inline-flex items-center gap-1.5 text-brand-300">
              <UserPlus size={13} /> Invitation
            </p>
            <h1 className="mt-2 font-display text-2xl font-bold">
              Rejoins l&apos;équipe de « {invite.pageName} »
            </h1>
            <p className="mt-2 text-sm text-ink-300">
              {invite.ownerName} t&apos;invite comme <strong className="text-ink-100">{invite.role === "editor" ? "éditeur" : "lecteur"}</strong> de la page{" "}
              <span className="font-mono text-ink-100">/{invite.slug}</span> : tu pourras {ROLE_TEXT[invite.role]}.
            </p>
            <p className="mt-1 text-xs text-ink-500">
              Lien valable jusqu&apos;au {invite.expiresAt.toLocaleDateString("fr-FR", { day: "numeric", month: "long" })}.
            </p>
            <div className="mt-6">
              {user ? (
                <InviteAccept token={token} />
              ) : (
                <Link
                  href={`/login?next=${encodeURIComponent(path)}`}
                  className="inline-flex w-full items-center justify-center rounded-md bg-brand-500 px-5 py-3 font-semibold text-ink-950 transition hover:bg-brand-400"
                >
                  Se connecter pour accepter
                </Link>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
