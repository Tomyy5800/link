import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { Logo } from "@/components/brand/Logo";
import { ChunkField } from "@/components/landing/ChunkField";
import { ChunkGame, NotFoundClaim } from "@/components/site/NotFoundExtras";

export default function NotFound() {
  return (
    <div className="bg-hud relative flex min-h-screen flex-col items-center justify-center gap-8 overflow-hidden px-4 py-16 text-center">
      <ChunkField className="[mask-image:radial-gradient(ellipse_70%_60%_at_50%_45%,#000_15%,transparent_75%)]" />
      <div className="ui-stagger relative flex w-full flex-col items-center gap-6">
        <Logo />
        <div>
          <p className="font-mono text-sm tracking-[0.14em] text-claim">CHUNK NON REVENDIQUÉ · 404</p>
          <h1 className="mt-3 font-display text-3xl font-bold text-balance sm:text-4xl">Cette page n&apos;existe pas (encore)</h1>
          <p className="mx-auto mt-3 max-w-md text-ink-300">L&apos;adresse est peut-être libre : revendique-la avant quelqu&apos;un d&apos;autre.</p>
        </div>
        <NotFoundClaim />
        <ChunkGame />
        <Link
          href="/"
          className="ui-press inline-flex items-center gap-2 rounded-md border border-ink-500 px-5 py-2.5 font-semibold text-ink-200 transition hover:border-ink-300 hover:text-white"
        >
          <ArrowLeft size={16} /> Retour à l&apos;accueil
        </Link>
      </div>
    </div>
  );
}
