import type { Metadata, Viewport } from "next";
import {
  Chakra_Petch,
  Fraunces,
  Inter,
  JetBrains_Mono,
  Press_Start_2P,
  Space_Grotesk,
  Unbounded,
  VT323,
} from "next/font/google";
import { Suspense } from "react";
import { InteractionLayer } from "@/components/ui/InteractionLayer";
import { NavigationProgress } from "@/components/ui/NavigationProgress";
import { ConfirmHost } from "@/components/ui/ConfirmHost";
import { Toaster } from "@/components/ui/Toaster";
import "./globals.css";

// Polices de l'interface (charte : Chakra Petch, Inter, JetBrains Mono) et des thèmes de page.
const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });
const chakra = Chakra_Petch({ subsets: ["latin"], weight: ["500", "600", "700"], variable: "--font-chakra", display: "swap" });
const jetbrains = JetBrains_Mono({ subsets: ["latin"], variable: "--font-jetbrains", display: "swap" });
const grotesk = Space_Grotesk({ subsets: ["latin"], variable: "--font-grotesk", display: "swap" });
const unbounded = Unbounded({ subsets: ["latin"], variable: "--font-unbounded", display: "swap" });
const serif = Fraunces({ subsets: ["latin"], variable: "--font-serif", display: "swap" });
const pixel = VT323({ subsets: ["latin"], weight: "400", variable: "--font-pixel", display: "swap" });
const arcade = Press_Start_2P({ subsets: ["latin"], weight: "400", variable: "--font-arcade", display: "swap" });

export const metadata: Metadata = {
  metadataBase: new URL(process.env.APP_URL || "http://localhost:3000"),
  title: {
    default: "Link by Unclaim — un seul lien, tout ton univers",
    template: "%s · Link by Unclaim",
  },
  description:
    "Ta page de profil à partager partout : liens, réseaux, radio, agenda, profil NationsGlory et skin 3D. Connexion en un clic avec Discord, Google, Microsoft et plus via Unclaim Auth.",
  applicationName: "Link by Unclaim",
  openGraph: { type: "website", siteName: "Link by Unclaim", locale: "fr_FR" },
  twitter: { card: "summary_large_image" },
};

export const viewport: Viewport = {
  themeColor: "#020618",
  colorScheme: "dark",
};

const fontVars = [inter, chakra, jetbrains, grotesk, unbounded, serif, pixel, arcade].map((f) => f.variable).join(" ");

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr" className={`${fontVars} h-full`} data-scroll-behavior="smooth">
      <body className="min-h-full">
        <a href="#contenu" className="lbu-skip-link">
          Aller au contenu
        </a>
        <div id="contenu" className="contents">
          {children}
        </div>
        <Suspense fallback={null}>
          <NavigationProgress />
        </Suspense>
        <Toaster />
        <ConfirmHost />
        <InteractionLayer />
      </body>
    </html>
  );
}
