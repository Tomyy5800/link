import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { Store } from "lucide-react";
import { ItemOrderStatus } from "@/components/shop/ItemOrderStatus";
import { SiteFooter, SiteHeader } from "@/components/site/SiteChrome";
import { getSettings } from "@/lib/server/settings";
import { getCurrentUser } from "@/lib/server/unclaim-auth";

export const metadata: Metadata = { title: "Merci", robots: { index: false } };

// Retour après un achat dans la boutique officielle : l'article n'est livré qu'une fois le paiement confirmé par Stripe.
export default async function ShopThanks({ searchParams }: { searchParams: Promise<{ commande?: string }> }) {
  const [{ commande }, user, settings] = await Promise.all([searchParams, getCurrentUser(), getSettings()]);
  if (!user) redirect(`/login?next=${encodeURIComponent(`/boutique/merci?commande=${commande ?? ""}`)}`);
  return (
    <div className="bg-hud flex min-h-screen flex-col">
      <SiteHeader loggedIn premiumName={settings.premiumName} />
      <main className="mx-auto flex w-full max-w-lg flex-1 flex-col items-center px-4 py-16 text-center">
        <Store size={40} className="text-claim" aria-hidden="true" />
        <ItemOrderStatus orderId={commande && /^[a-z0-9]{10,40}$/.test(commande) ? commande : null} />
      </main>
      <SiteFooter premiumName={settings.premiumName} />
    </div>
  );
}
