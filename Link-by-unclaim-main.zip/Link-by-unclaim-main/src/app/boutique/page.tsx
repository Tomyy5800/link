import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Store } from "lucide-react";
import { PlusLogo } from "@/components/brand/Logo";
import { OfficialShop } from "@/components/shop/OfficialShop";
import { PageTransition } from "@/components/site/PageTransition";
import { SiteFooter, SiteHeader } from "@/components/site/SiteChrome";
import { formatPrice, monthlyCents } from "@/lib/features";
import { env } from "@/lib/server/env";
import { listShopItems } from "@/lib/server/official-shop";
import { getSettings } from "@/lib/server/settings";
import { getCurrentUser } from "@/lib/server/unclaim-auth";

export const metadata: Metadata = {
  title: "Boutique officielle",
  description: "La boutique officielle Unclaim : abonnements Link+, badges exclusifs et cadres de profil.",
};

// Boutique officielle Unclaim (distincte des boutiques personnelles des profils).
export default async function ShopPage({ searchParams }: { searchParams: Promise<{ annule?: string }> }) {
  const [{ annule }, user, settings] = await Promise.all([searchParams, getCurrentUser(), getSettings()]);
  const items = await listShopItems(user?.id ?? null);
  const cheapest = settings.offers.filter((o) => o.active).sort((a, b) => monthlyCents(a) - monthlyCents(b))[0];

  return (
    <PageTransition>
      <div className="bg-hud min-h-screen">
        <SiteHeader loggedIn={Boolean(user)} premiumName={settings.premiumName} />
        <main className="mx-auto max-w-6xl px-4 pt-14 pb-20 sm:px-6">
          <p className="hud-label inline-flex items-center gap-2 text-claim">
            <Store size={14} aria-hidden="true" /> Boutique officielle Unclaim
          </p>
          <h1 className="mt-3 max-w-3xl font-display text-4xl font-bold tracking-tight text-balance sm:text-5xl">De quoi rendre ta page unique.</h1>
          <p className="mt-4 max-w-2xl text-lg text-ink-300">
            Les personnalisations vendues ici sont ajoutées à ton compte par Link by Unclaim, après confirmation du paiement. C&apos;est la seule boutique officielle : les
            boutiques des profils appartiennent à leurs créateurs.
          </p>
          {annule && <p className="mt-4 text-sm text-ink-400">Paiement annulé : rien n&apos;a été débité.</p>}

          <section className="mt-10 flex flex-col gap-4 rounded-xl border border-claim/30 bg-[linear-gradient(150deg,rgba(255,194,71,0.08),transparent_60%)] p-6 sm:flex-row sm:items-center" aria-label="Abonnements">
            <PlusLogo size={40} name={settings.premiumName} />
            <div className="min-w-0 flex-1">
              <h2 className="font-display text-xl font-bold">Abonnements {settings.premiumName}</h2>
              <p className="text-sm text-ink-300">
                Effets, musique, rôles personnalisés, domaine personnel…{cheapest ? ` Dès ${formatPrice(monthlyCents(cheapest))} par mois,` : ""} sans engagement.
              </p>
            </div>
            <Link href="/plus" className="inline-flex shrink-0 items-center gap-1.5 rounded-md bg-claim px-4 py-2.5 text-sm font-semibold text-ink-950 transition-[filter] hover:brightness-110">
              Voir les formules <ArrowRight size={15} aria-hidden="true" />
            </Link>
          </section>

          <div className="mt-12">
            <OfficialShop items={items} loggedIn={Boolean(user)} canPay={env.stripe.configured} testMode={env.stripe.testMode} />
          </div>
        </main>
        <SiteFooter premiumName={settings.premiumName} />
      </div>
    </PageTransition>
  );
}
