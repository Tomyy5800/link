import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { Bot, CircleAlert, FlaskConical, ShieldCheck, Sparkles } from "lucide-react";
import { ProviderButton } from "@/components/auth/ProviderButton";
import { Logo } from "@/components/brand/Logo";
import { ChunkField } from "@/components/landing/ChunkField";
import { env } from "@/lib/server/env";
import { safeNextPath } from "@/lib/server/security";
import { getCurrentUser } from "@/lib/server/unclaim-auth";
import { availableProviders } from "@/lib/server/unclaim-auth/client";
import { validateSlug } from "@/lib/slug";

export const metadata: Metadata = { title: "Connexion", robots: { index: false } };

const ERRORS: Record<string, string> = {
  denied: "Connexion annulée.",
  state: "La connexion a expiré ou vient d'un autre navigateur. Réessaie.",
  oauth: "Unclaim Auth n'a pas pu confirmer ton identité. Réessaie dans un instant.",
  unavailable: "Unclaim Auth est momentanément injoignable. Réessaie dans un instant.",
  banned: "Ce compte est bloqué dans Unclaim Auth.",
  bot: "Les comptes bot ne peuvent pas se connecter.",
  provider: "Le service de connexion choisi a renvoyé une erreur. Réessaie, ou choisis-en un autre.",
  provider_unavailable: "Ce moyen de connexion n'est pas disponible pour le moment. Choisis-en un autre.",
  rate_limited: "Trop de tentatives. Patiente une minute.",
  not_configured: "Link by Unclaim n'est pas encore relié à ta passerelle Unclaim Auth (UNCLAIM_API_URL, UNCLAIM_CLIENT_ID, UNCLAIM_CLIENT_SECRET).",
};

/** Ce qui attend la personne après la connexion (adresse revendiquée, assistant…), pour le titre. */
function intent(nextPath: string): { title: string; detail?: string; icon?: "claim" | "assistant" } {
  const url = new URL(nextPath, "http://link.local");
  if (url.pathname === "/dashboard/nouvelle") {
    const slug = url.searchParams.get("adresse");
    const check = slug ? validateSlug(slug, { allowShort: true }) : null;
    if (check?.ok) return { title: "Ton adresse t'attend", detail: check.slug, icon: "claim" };
    return { title: "Connecte-toi pour créer ta page" };
  }
  if (url.pathname === "/dashboard/assistant") return { title: "L'assistant t'attend", icon: "assistant" };
  return { title: "Connecte-toi pour éditer ta page" };
}

// Choix du compte de connexion. Avec un seul fournisseur disponible, on part directement chez lui :
// la passerelle Unclaim Auth gère le reste (consentement, création de l'ID Unclaim).
export default async function LoginPage({ searchParams }: { searchParams: Promise<{ error?: string; next?: string }> }) {
  const { error, next } = await searchParams;
  const nextPath = safeNextPath(next);
  if (await getCurrentUser()) redirect(nextPath);

  const providers = env.unclaim.configured ? await availableProviders() : [];
  if (!error && providers.length === 1 && !env.devLoginEnabled) {
    redirect(`/api/auth/login?provider=${providers[0]}&next=${encodeURIComponent(nextPath)}`);
  }
  const message = error ? (ERRORS[error] ?? "La connexion a échoué.") : null;
  const goal = intent(nextPath);
  const host = new URL(env.appUrl).host;

  return (
    <div className="bg-hud relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-4 py-16">
      <ChunkField className="[mask-image:radial-gradient(ellipse_60%_60%_at_50%_50%,#000_20%,transparent_75%)]" />
      <div
        className="pointer-events-none absolute top-1/2 left-1/2 h-[520px] w-[520px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-brand-500/10 blur-3xl"
        aria-hidden="true"
      />
      <div className="relative w-full max-w-sm animate-rise">
        <div className="mb-8 flex justify-center">
          <Logo />
        </div>
        <div className="ui-glow-border rounded-xl bg-ink-850/95 p-7 shadow-[0_30px_60px_-24px_#000000dd] backdrop-blur [--glow-a:#22c9e8] [--glow-b:#ffc247]">
          <p className="hud-label text-brand-300">Unclaim Auth</p>
          <h1 className="mt-2 font-display text-2xl font-bold tracking-tight">{goal.title}</h1>
          {goal.icon === "claim" && goal.detail && (
            <p className="animate-pop mt-3 inline-flex max-w-full items-center gap-2 rounded-lg border border-claim/40 bg-claim/10 px-3 py-1.5 font-mono text-sm text-claim">
              <Sparkles size={14} className="shrink-0" />
              <span className="truncate">
                {host}/<strong>{goal.detail}</strong>
              </span>
            </p>
          )}
          {goal.icon === "assistant" && (
            <p className="mt-3 flex items-center gap-2 text-sm text-ink-300">
              <Bot size={16} className="text-brand-300" /> Ta page se construit en discutant, en moins de cinq minutes.
            </p>
          )}

          {message && (
            <p role="alert" className="animate-pop mt-5 flex gap-2 rounded-md border border-danger/40 bg-danger/10 p-3 text-sm text-red-100">
              <CircleAlert size={18} className="mt-px shrink-0 text-danger" aria-hidden="true" /> {message}
            </p>
          )}

          {providers.length > 0 && (
            <div className="ui-stagger mt-6 space-y-3">
              {providers.map((provider) => (
                <ProviderButton key={provider} provider={provider} next={nextPath} />
              ))}
            </div>
          )}

          {env.devLoginEnabled && (
            <form action="/api/auth/dev" method="post" className="mt-4">
              <button
                type="submit"
                className="ui-press flex w-full items-center justify-center gap-2 rounded-md border border-dashed border-ink-500 px-4 py-2.5 text-sm font-medium text-ink-300 transition hover:border-ink-300 hover:text-ink-100"
              >
                <FlaskConical size={16} aria-hidden="true" /> Connexion de démonstration (dev)
              </button>
            </form>
          )}

          <p className="mt-6 flex items-start gap-2 border-t border-ink-700 pt-4 text-xs leading-relaxed text-ink-400">
            <ShieldCheck size={15} className="mt-px shrink-0 text-mint" aria-hidden="true" />
            Link by Unclaim ne voit jamais ton mot de passe ni ton adresse e-mail : seuls ton nom et ton avatar sont transmis par Unclaim Auth.
          </p>
          <p className="mt-3 text-xs leading-relaxed text-ink-400">
            À ta première connexion, tu accepteras les{" "}
            <a href="/cgu" className="text-brand-300 hover:underline">
              conditions d&apos;utilisation
            </a>{" "}
            et la{" "}
            <a href="/confidentialite" className="text-brand-300 hover:underline">
              politique de confidentialité
            </a>
            .
          </p>
        </div>
      </div>
    </div>
  );
}
