import type { Metadata } from "next";
import Link from "next/link";
import { Fill, LegalPage, LegalSection } from "@/components/site/Legal";
import { MIN_AGE, TERMS_UPDATED } from "@/lib/legal";
import { getSettings } from "@/lib/server/settings";
import { getCurrentUser } from "@/lib/server/unclaim-auth";

export const metadata: Metadata = {
  title: "Conditions générales d'utilisation",
  description: "Les règles d'utilisation de Link by Unclaim : compte, contenus publiés, modération, collaboration et responsabilités.",
};

// Modèle de CGU d'un service d'hébergement de pages de profil, à faire relire avant la mise en ligne.
export default async function CguPage() {
  const [settings, user] = await Promise.all([getSettings(), getCurrentUser()]);
  const { legal, premiumName: name } = settings;

  return (
    <LegalPage title="Conditions générales d'utilisation" updated={TERMS_UPDATED} loggedIn={Boolean(user)} premiumName={name}>
      <LegalSection title="1. Objet">
        <p>
          Link by Unclaim permet de créer des pages de profil publiques (« pages ») réunissant liens, réseaux, contenus et informations de jeu, accessibles
          à une adresse personnalisée. Les présentes conditions régissent l&apos;utilisation du service par toute personne qui crée un compte ou une
          page. Elles sont acceptées à la création du compte, puis à chaque nouvelle version importante.
        </p>
        <p>
          Éditeur du service : <Fill value={legal.sellerName} label="Nom ou raison sociale" />, joignable à <Fill value={legal.email} label="E-mail de contact" />.
        </p>
      </LegalSection>

      <LegalSection title="2. Compte et connexion">
        <p>
          La connexion passe par Unclaim Auth, avec un compte existant (Discord, Google, Microsoft ou tout autre fournisseur proposé). Link by Unclaim ne
          reçoit ni ne conserve ton mot de passe. Tu es responsable de l&apos;accès à tes comptes de connexion et de ce qui est fait depuis ton compte.
        </p>
        <p>
          Il faut avoir au moins {MIN_AGE} ans pour créer un compte, ou l&apos;accord d&apos;un parent ou tuteur légal. Un compte est personnel : il ne
          peut être ni vendu ni cédé.
        </p>
      </LegalSection>

      <LegalSection title="3. Pages, équipes et partenaires">
        <p>
          Chaque compte peut créer le nombre de pages prévu par son offre. Le propriétaire d&apos;une page peut inviter des collaborateurs (éditeurs ou
          lecteurs) ; il reste responsable de la page et de ce que son équipe y publie, et peut leur retirer l&apos;accès à tout moment.
        </p>
        <p>
          Les adresses de pages sont attribuées selon le principe du premier arrivé. L&apos;équipe peut reprendre une adresse qui usurpe une marque, une
          personne ou une organisation, ou qui reste inutilisée de façon prolongée.
        </p>
        <p>
          Le statut de partenaire officiel est accordé par l&apos;équipe, sur candidature, et peut être retiré à tout moment, notamment en cas de
          manquement aux présentes conditions.
        </p>
      </LegalSection>

      <LegalSection title="4. Contenus publiés">
        <p>Tu restes propriétaire de ce que tu publies, et tu garantis en avoir le droit. Sont notamment interdits :</p>
        <ul className="list-disc space-y-1 pl-5">
          <li>les contenus illégaux, haineux, harcelants, violents ou discriminatoires ;</li>
          <li>les contenus sexuels explicites, et tout contenu sexualisant des mineurs ;</li>
          <li>l&apos;usurpation d&apos;identité et les pages trompeuses (faux concours, faux supports officiels, hameçonnage) ;</li>
          <li>les liens vers des logiciels malveillants, des triches, du piratage ou des ventes illicites ;</li>
          <li>la diffusion de données personnelles d&apos;autrui sans son accord ;</li>
          <li>le spam, la publicité abusive et la manipulation des statistiques.</li>
        </ul>
        <p>
          Tu accordes à Link by Unclaim une licence gratuite, non exclusive et limitée à la durée de publication pour héberger, afficher et adapter tes
          contenus aux écrans, à seule fin de faire fonctionner le service.
        </p>
      </LegalSection>

      <LegalSection title="5. Formulaire de contact et messages">
        <p>
          Les messages laissés par les visiteurs via le bloc « Formulaire de contact » sont transmis au propriétaire de la page et à son équipe. Celui qui
          les reçoit s&apos;engage à ne les utiliser que pour répondre à leur auteur, et à les supprimer quand ils ne sont plus utiles.
        </p>
      </LegalSection>

      <LegalSection title="6. Modération">
        <p>
          Tout visiteur peut signaler une page. L&apos;équipe peut masquer une page, retirer un contenu, suspendre un compte ou retirer un statut
          (vérifié, partenaire) en cas de manquement, avec ou sans signalement préalable. Le motif est indiqué dans l&apos;éditeur. Pour contester une
          décision, écris à <Fill value={legal.email} label="E-mail de contact" />.
        </p>
        <p>
          En tant qu&apos;hébergeur, Link by Unclaim retire promptement tout contenu manifestement illicite qui lui est notifié, et coopère avec les
          autorités sur réquisition.
        </p>
      </LegalSection>

      <LegalSection title="7. Services tiers">
        <p>
          Certains blocs affichent des données de services tiers (Discord, NationsGlory, Minecraft, Steam, Roblox, Chess.com, Lichess, plateformes
          vidéo et musicales…). Ces données peuvent être indisponibles, inexactes ou retardées ; Link by Unclaim n&apos;est affilié à aucun de ces
          services. L&apos;assistant de création peut s&apos;appuyer sur une intelligence artificielle (Claude, d&apos;Anthropic) : ses propositions sont
          à vérifier avant de publier ta page.
        </p>
      </LegalSection>

      <LegalSection title={`8. Offre ${name}`}>
        <p>
          Les fonctions payantes et leurs achats sont régis par les{" "}
          <Link href="/cgv" className="text-brand-300 hover:underline">
            conditions générales de vente
          </Link>
          .
        </p>
      </LegalSection>

      <LegalSection title="9. Données personnelles">
        <p>
          Le traitement de tes données est décrit dans la{" "}
          <Link href="/confidentialite" className="text-brand-300 hover:underline">
            politique de confidentialité
          </Link>
          . Tu peux exporter tes données et supprimer ton compte à tout moment depuis « Mon espace ».
        </p>
      </LegalSection>

      <LegalSection title="10. Disponibilité et responsabilité">
        <p>
          Le service est fourni en l&apos;état, avec le soin d&apos;un professionnel, sans garantie de disponibilité permanente. Link by Unclaim ne répond
          pas des contenus publiés par les utilisateurs ni des sites vers lesquels ils renvoient. Pense à garder une copie de tes contenus importants.
        </p>
      </LegalSection>

      <LegalSection title="11. Fin de l'utilisation">
        <p>
          Tu peux supprimer ton compte à tout moment depuis « Mon espace ». L&apos;équipe peut fermer un compte en cas de manquement grave ou répété, après
          suspension préalable sauf urgence.
        </p>
      </LegalSection>

      <LegalSection title="12. Modification et droit applicable">
        <p>
          Les conditions peuvent évoluer ; une nouvelle version importante doit être acceptée à la prochaine visite de « Mon espace ». Elles sont régies
          par le droit français ; en cas de litige, une solution amiable est recherchée avant toute action.
        </p>
      </LegalSection>
    </LegalPage>
  );
}
