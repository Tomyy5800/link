import type { MetadataRoute } from "next";
import { env } from "@/lib/server/env";

// Calculé à la demande : figé au build, il garderait l'APP_URL de la machine de build.
export const dynamic = "force-dynamic";

// Les espaces privés (éditeur, administration, API, connexion) ne sont pas indexés.
export default function robots(): MetadataRoute.Robots {
  return {
    rules: [{ userAgent: "*", allow: "/", disallow: ["/dashboard", "/admin", "/api/", "/login", "/plus/merci", "/bienvenue", "/invitation/"] }],
    sitemap: `${env.appUrl}/sitemap.xml`,
  };
}
