import type { Metadata } from "next";
import { Fill, LegalPage, LegalSection } from "@/components/site/Legal";
import { getSettings } from "@/lib/server/settings";
import { getCurrentUser } from "@/lib/server/unclaim-auth";

export const metadata: Metadata = { title: "Confidentialité" };

export default async function PrivacyPage() {
  const [settings, user] = await Promise.all([getSettings(), getCurrentUser()]);
  const { legal } = settings;
  return (
    <LegalPage title="Politique de confidentialité" updated="16 octobre 2026" loggedIn={Boolean(user)} premiumName={settings.premiumName}>
      <LegalSection title="Responsable du traitement">
        <p>
          <Fill value={legal.sellerName} label="Nom ou raison sociale" />, joignable à <Fill value={legal.email} label="E-mail de contact" />.
        </p>
      </LegalSection>
      <LegalSection title="Données traitées">
        <ul className="list-disc space-y-1 pl-5">
          <li>
            <strong className="text-ink-100">Compte</strong> : identifiant Unclaim, nom affiché, avatar et, s&apos;ils sont rattachés, pseudos Discord, Twitch
            et NationsGlory, transmis par Unclaim Auth. Aucune adresse e-mail ni aucun mot de passe ne sont conservés par Link by Unclaim.
          </li>
          <li>
            <strong className="text-ink-100">Pages</strong> : le contenu que tu publies (textes, liens, images, réglages), et les membres de
            l&apos;équipe de chaque page avec leur rôle.
          </li>
          <li>
            <strong className="text-ink-100">Messages de contact</strong> : nom, moyen de réponse facultatif et message laissés par un visiteur via
            le bloc « Formulaire de contact », transmis seulement au propriétaire de la page et à son équipe, avec une empreinte anonyme renouvelée
            chaque jour pour limiter le spam.
          </li>
          <li>
            <strong className="text-ink-100">Commandes de boutique</strong> : nom, moyen de réponse, articles choisis et précision laissés par un
            visiteur via le bloc « Boutique » d&apos;une page, transmis seulement au vendeur (le propriétaire de la page) et à son équipe, avec la même
            empreinte anonyme anti-spam. Aucun paiement ne passe par Link by Unclaim : il se règle entre le vendeur et l&apos;acheteur, qui restent
            responsables de leur vente.
          </li>
          <li>
            <strong className="text-ink-100">Partenariat</strong> : le contenu de ta candidature (projet, lien, communauté, présentation) et la
            décision de l&apos;équipe.
          </li>
          <li>
            <strong className="text-ink-100">Acceptation des conditions</strong> : version des CGU acceptée et date, conservées comme preuve.
          </li>
          <li>
            <strong className="text-ink-100">Statistiques</strong> : une empreinte anonyme de visite, renouvelée chaque jour, le domaine d&apos;origine et le
            type d&apos;appareil. Aucune adresse IP n&apos;est conservée.
          </li>
          <li>
            <strong className="text-ink-100">Abonnements et achats</strong> : formule, période, montant, date, statut et renouvellement ; articles de la
            boutique officielle. Le paiement est traité par Stripe, qui reçoit tes données de carte et ton e-mail de facturation ; Link by Unclaim n&apos;y a
            jamais accès et ne garde que la référence de ton client Stripe.
          </li>
          <li>
            <strong className="text-ink-100">Badges</strong> : badges attribués à ton compte (par l&apos;équipe, ta formule, les rôles du serveur Discord
            officiel ou un achat), leur date et tes choix d&apos;affichage. Si ton compte Discord est relié par Unclaim Auth, le bot du serveur officiel lit
            tes rôles sur ce serveur pour attribuer les badges du staff.
          </li>
          <li>
            <strong className="text-ink-100">Domaines personnels</strong> : nom de domaine relié à ta page et résultat des contrôles DNS et HTTPS.
          </li>
        </ul>
      </LegalSection>
      <LegalSection title="Finalités et bases légales">
        <p>
          Fournir le service et ta page (exécution du contrat), vendre et gérer {settings.premiumName} (exécution du contrat, obligations comptables),
          mesurer l&apos;audience de façon anonyme et modérer les contenus signalés (intérêt légitime).
        </p>
      </LegalSection>
      <LegalSection title="Durées de conservation">
        <p>
          Compte et pages : tant que le compte existe ; la suppression d&apos;une page efface ses blocs, fichiers, messages et statistiques. Visites
          détaillées : 120 jours. Messages de contact et commandes de boutique : un an au plus, ou jusqu&apos;à leur suppression. Factures d&apos;abonnement et achats : 10 ans (obligation comptable) ;
          en cas de suppression du compte, elles sont conservées sous forme anonymisée.
        </p>
      </LegalSection>
      <LegalSection title="Services tiers">
        <ul className="list-disc space-y-1 pl-5">
          <li>
            <strong className="text-ink-100">Assistant de création</strong> : si l&apos;assistant IA est activé, les messages que tu lui écris et le brouillon
            de ta page sont envoyés à Anthropic (Claude) pour rédiger les réponses. N&apos;y écris pas d&apos;informations personnelles sensibles. Sans
            assistant IA, l&apos;assistant guidé fonctionne entièrement sur nos serveurs.
          </li>
          <li>
            <strong className="text-ink-100">Polices Google Fonts</strong> : si une page utilise une police Google Fonts, le navigateur du visiteur la
            télécharge depuis les serveurs de Google, qui reçoivent alors son adresse IP.
          </li>
          <li>
            <strong className="text-ink-100">Notifications Discord</strong> : si tu relies un webhook Discord, les messages de contact, les commandes de
            boutique reçues et le bilan de la semaine sont envoyés sur ton serveur Discord.
          </li>
          <li>
            <strong className="text-ink-100">Profils de jeu et statut Discord</strong> : les pseudos indiqués sont envoyés aux services concernés
            (Mojang, Chess.com, Lichess, Steam, Roblox, Lanyard) pour afficher les données publiques.
          </li>
        </ul>
      </LegalSection>

      <LegalSection title="Cookies">
        <p>Un seul cookie technique de session, nécessaire à la connexion. Aucun cookie publicitaire ni de mesure d&apos;audience tiers.</p>
      </LegalSection>
      <LegalSection title="Tes droits">
        <p>
          Tu peux télécharger toutes tes données et supprimer ton compte à tout moment depuis « Mon espace › Compte et données ». Pour l&apos;accès,
          la rectification, l&apos;effacement, l&apos;opposition ou la portabilité, écris aussi à <Fill value={legal.email} label="E-mail de contact" />. Tu
          peux adresser une réclamation à la CNIL (cnil.fr).
        </p>
      </LegalSection>
    </LegalPage>
  );
}
