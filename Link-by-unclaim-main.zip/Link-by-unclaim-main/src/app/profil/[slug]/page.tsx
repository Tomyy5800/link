import { notFound, permanentRedirect } from "next/navigation";
import { prisma } from "@/lib/server/db";
import { resolveOldSlug } from "@/lib/server/slugs";
import { normalizeSlug } from "@/lib/slug";

// /profil/<adresse> : autre forme du lien d'une page (link.unclaim/<adresse> reste l'adresse
// principale). Les anciennes adresses suivent la page ; sinon, page « introuvable » claire.
export default async function ProfileAlias({ params }: { params: Promise<{ slug: string }> }) {
  const slug = normalizeSlug(decodeURIComponent((await params).slug));
  if (!/^[a-z0-9._-]{1,40}$/.test(slug)) notFound();
  const page = await prisma.page.findUnique({ where: { slug }, select: { slug: true } });
  if (page) permanentRedirect(`/${page.slug}`);
  const moved = await resolveOldSlug(slug);
  if (moved) permanentRedirect(`/${moved}`);
  notFound();
}
