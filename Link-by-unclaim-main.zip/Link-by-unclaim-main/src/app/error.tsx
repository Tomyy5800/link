"use client";

import { useEffect } from "react";
import Link from "next/link";
import { RotateCcw } from "lucide-react";
import { Logo } from "@/components/brand/Logo";

// Erreur inattendue dans une page : message clair, nouvel essai, retour à l'accueil.
export default function Error({ error, retry }: { error: Error & { digest?: string }; retry: () => void }) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <div className="bg-hud flex min-h-screen flex-col items-center justify-center gap-6 px-4 text-center">
      <Logo />
      <div className="max-w-md">
        <p className="font-mono text-sm tracking-[0.14em] text-claim">ERREUR INATTENDUE</p>
        <h1 className="mt-2 font-display text-2xl font-bold">Quelque chose s&apos;est mal passé</h1>
        <p className="mt-2 text-ink-300">Réessaie dans un instant. Si le problème persiste, signale-le avec l&apos;heure à laquelle il s&apos;est produit.</p>
        {error.digest && <p className="mt-3 font-mono text-xs text-ink-500">Référence : {error.digest}</p>}
      </div>
      <div className="flex flex-wrap justify-center gap-3">
        <button
          type="button"
          onClick={() => retry()}
          className="inline-flex items-center gap-2 rounded-md bg-brand-500 px-5 py-2.5 font-semibold text-ink-950 transition hover:bg-brand-400"
        >
          <RotateCcw size={16} aria-hidden="true" /> Réessayer
        </button>
        <Link href="/" className="rounded-md border border-ink-500 px-5 py-2.5 font-semibold text-ink-200 transition hover:border-ink-300">
          Accueil
        </Link>
      </div>
    </div>
  );
}
