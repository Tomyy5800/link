import type { Metadata } from "next";
import { headers } from "next/headers";
import { notFound } from "next/navigation";
import { Globe } from "lucide-react";
import { Logo } from "@/components/brand/Logo";
import { PublicPageView, loadPublicPage, publicMetadata } from "@/components/page/PublicPageView";
import { normalizeHostname } from "@/lib/domains";
import { activeDomain } from "@/lib/server/domains";
import { entitlementsFrom } from "@/lib/server/entitlements";
import { env } from "@/lib/server/env";
import { getSettings } from "@/lib/server/settings";

// Page servie sur un domaine personnel. Le proxy (src/proxy.ts) réécrit https://mondomaine.fr/
// vers cette route et pose l'en-tête x-lbu-domain ; sans lui (accès direct), rien n'est servi.

type Params = { params: Promise<{ host: string; rest?: string[] }> };

async function resolve(params: Params["params"]) {
  const { host, rest } = await params;
  const hostname = normalizeHostname(decodeURIComponent(host));
  const fromProxy = (await headers()).get("x-lbu-domain");
  if (!hostname || fromProxy !== hostname) return { kind: "invalid" as const };
  if (rest?.length) return { kind: "missing" as const, hostname };
  const domain = await activeDomain(hostname);
  if (!domain || !domain.page.published || domain.page.status !== "active") return { kind: "unlinked" as const, hostname };
  const data = await loadPublicPage(domain.page.slug);
  if (!data || !data.page.published) return { kind: "unlinked" as const, hostname };
  // Le propriétaire doit toujours avoir une formule qui comprend les domaines personnels.
  if (!entitlementsFrom(data.user, await getSettings()).features.customDomains) return { kind: "unlinked" as const, hostname };
  return { kind: "page" as const, hostname, data };
}

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const result = await resolve(params);
  if (result.kind !== "page") return { title: { absolute: "Link by Unclaim" }, robots: { index: false, follow: false } };
  return publicMetadata(result.data, { domain: result.hostname });
}

export default async function CustomDomainPage({ params }: Params) {
  const result = await resolve(params);
  if (result.kind === "invalid" || result.kind === "missing") notFound();
  if (result.kind === "unlinked") {
    return (
      <div className="bg-hud flex min-h-screen flex-col items-center justify-center gap-6 px-4 text-center">
        <Logo />
        <div className="max-w-md">
          <p className="inline-flex items-center gap-2 font-mono text-sm tracking-[0.14em] text-claim">
            <Globe size={15} aria-hidden="true" /> DOMAINE NON RELIÉ
          </p>
          <h1 className="mt-2 font-display text-2xl font-bold">{result.hostname} n&apos;affiche aucune page pour l&apos;instant</h1>
          <p className="mt-2 text-ink-300">Si c&apos;est ton domaine, termine sa configuration dans les réglages de ta page Link by Unclaim.</p>
        </div>
        <a href={env.appUrl} className="rounded-md border border-ink-500 px-5 py-2.5 font-semibold text-ink-200 transition hover:border-ink-300">
          Aller sur Link by Unclaim
        </a>
      </div>
    );
  }
  return <PublicPageView data={result.data} domain={result.hostname} />;
}
