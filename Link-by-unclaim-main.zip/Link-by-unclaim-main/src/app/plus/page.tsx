import type { Metadata } from "next";
import Link from "next/link";
import { ArrowDown, ArrowRight, Check, Gift, Infinity as InfinityIcon, Minus, Music, Plus, Repeat, Sparkles, Wand2 } from "lucide-react";
import { PlusLogo } from "@/components/brand/Logo";
import { HoloCard } from "@/components/landing/HoloCard";
import { SplitWords } from "@/components/landing/SplitWords";
import { PlanComparator, type ComparatorFeature, type ComparatorLimit } from "@/components/plus/PlanComparator";
import { PlusChapters } from "@/components/plus/PlusChapters";
import { PlusCheckout, type TierCard } from "@/components/plus/PlusCheckout";
import { SiteFooter, SiteHeader } from "@/components/site/SiteChrome";
import { PageTransition } from "@/components/site/PageTransition";
import { SmoothScroll } from "@/components/site/SmoothScroll";
import { FEATURES, FEATURE_KEYS, formatPrice, intervalLabel, modeTier, type PlanLimits, type PlatformSettings } from "@/lib/features";
import { TIERS, TIER_PITCH, TIER_RANK, tierName, type Tier } from "@/lib/plans";
import { activeTier, entitlementsFrom, freeForAll } from "@/lib/server/entitlements";
import { env } from "@/lib/server/env";
import { currentSubscription, subscriptionGivesAccess } from "@/lib/server/payments";
import { getSettings } from "@/lib/server/settings";
import { getCurrentUser } from "@/lib/server/unclaim-auth";

export async function generateMetadata(): Promise<Metadata> {
  const settings = await getSettings();
  const { premiumName, offers } = settings;
  if (freeForAll(settings)) {
    return {
      title: `${premiumName} offert`,
      description: `Pour le lancement, toutes les formules de ${premiumName} sont gratuites : effets, musique, polices, automatisations, CSS personnalisé, notifications Discord et kit de marque.`,
    };
  }
  const from = offers.filter((o) => o.active).sort((a, b) => a.priceCents - b.priceCents)[0];
  return {
    title: `Formules et tarifs`,
    description: `Gratuit, ${premiumName}, ${premiumName} Pro et ${premiumName} Équipe${from ? ` dès ${formatPrice(from.priceCents)} ${intervalLabel(from.interval)}` : ""}. Abonnement sans engagement, résiliable en deux clics.`,
  };
}

const LIMIT_ROWS: { key: keyof PlanLimits; label: string; unit: (v: number) => string }[] = [
  { key: "pages", label: "Pages", unit: (v) => String(v) },
  { key: "members", label: "Collaborateurs par page", unit: (v) => (v ? String(v) : "—") },
  { key: "blocks", label: "Blocs par page", unit: (v) => String(v) },
  { key: "uploads", label: "Fichiers importés", unit: (v) => String(v) },
  { key: "imageMb", label: "Taille d'une image", unit: (v) => `${v} Mo` },
  { key: "mediaMb", label: "Musique et vidéo importées", unit: (v) => (v > 0 ? `${v} Mo` : "—") },
  { key: "statsDays", label: "Historique des statistiques", unit: (v) => `${v} jours` },
  { key: "aiMessages", label: "Assistant IA (messages par jour)", unit: (v) => String(v) },
];

/** Rang de la première formule qui contient la fonction (0 : ouverte à tous). */
function featureRank(settings: PlatformSettings, key: (typeof FEATURE_KEYS)[number]): number {
  const needed = modeTier(settings.features[key]);
  return needed === null ? 0 : TIER_RANK[needed];
}

/** Disponible avec cette formule ? (ouvert à tous, ou formule au moins égale à celle exigée) */
function includes(settings: PlatformSettings, key: (typeof FEATURE_KEYS)[number], tier: Tier): boolean {
  return settings.features[key] !== "off" && TIER_RANK[tier] >= featureRank(settings, key);
}

/** Ce qu'une formule ajoute à la précédente : fonctions qui s'y débloquent et limites clés. */
function highlights(settings: PlatformSettings, tier: Tier): string[] {
  const l = settings.limits[tier];
  const name = settings.premiumName;
  if (tier === "free") {
    return [
      `${l.pages} page, ${l.blocks} blocs`,
      "Assistant IA de création",
      "Profils de jeu, contact, radio, agenda",
      `Statistiques sur ${l.statsDays} jours`,
    ];
  }
  const previous = TIERS[TIER_RANK[tier] - 1];
  const unlocked = FEATURE_KEYS.filter((k) => settings.features[k] === tier).map((k) => FEATURES[k].label);
  return [
    `Tout ${tierName(previous, name)}, plus :`,
    ...unlocked,
    `${l.pages} pages, ${l.members} collaborateur${l.members > 1 ? "s" : ""} par page`,
    `Statistiques sur ${l.statsDays} jours`,
  ];
}

const FAQ = [
  {
    q: "Comment fonctionne l'abonnement ?",
    a: "Tu choisis une formule, au mois ou à l'année. Elle se renouvelle automatiquement à chaque échéance, sans engagement : tu peux résilier quand tu veux depuis Mon espace › Offre, en deux clics.",
  },
  {
    q: "Que se passe-t-il si je résilie ?",
    a: "Tu gardes ta formule jusqu'à la fin de la période déjà payée, puis rien n'est plus prélevé. Tant que la période court, tu peux reprendre ton abonnement d'un clic.",
  },
  {
    q: "Et si je change de formule en cours de route ?",
    a: "Le changement est immédiat. La différence de prix pour la période en cours est calculée au prorata : tu paies seulement l'écart en passant à une formule supérieure, et l'écart t'est crédité dans l'autre sens.",
  },
  {
    q: "Que devient ma page à la fin de l'abonnement ?",
    a: "Elle reste en ligne. Les réglages réservés (effets, musique, CSS…) sont mis en veille et reviennent tels quels si tu te réabonnes.",
  },
  {
    q: "Pourquoi une formule Équipe ?",
    a: "Pour les serveurs, équipes e-sport, associations et marques : beaucoup de pages, gérées à plusieurs, avec le même thème partout. Le prix est partagé par toute l'équipe : avec 20 collaborateurs, moins de 35 centimes par personne et par mois.",
  },
  {
    q: "J'ai un code Link+, comment l'utiliser ?",
    a: "Les codes offerts lors d'un événement ou d'un partenariat s'activent dans Mon espace › Offre. Ils ajoutent une durée de formule, sans abonnement à payer.",
  },
  {
    q: "Et si je change d'avis ?",
    a: "L'accès est ouvert dès le paiement, à ta demande : le droit de rétractation de 14 jours ne s'applique donc plus. Tu peux en revanche résilier à tout moment pour la suite. En cas de problème technique qui t'empêche d'en profiter, écris-nous : on trouve une solution.",
  },
];

const PRICING_LOGIC = [
  ["Une entrée sous 2,50 €", "Un mois de Link+ coûte moins qu'un petit achat en jeu : on essaie sans réfléchir."],
  ["L'année vaut 8 mois", "Un tiers de remise sur la durée qui nous coûte le moins en frais de paiement, et qui te coûte le moins."],
  ["Chaque formule double la précédente", "Pro vise les créateurs qui vivent de leur audience, Équipe les collectifs qui partagent la facture."],
  ["Sans engagement", "Tu résilies quand tu veux, en ligne, et tu gardes ta formule jusqu'au bout de la période payée."],
  ["Changement au prorata", "Monter ou descendre de formule ne fait rien perdre : seule la différence est facturée ou créditée."],
  ["Prix garanti", "Le prix de ton abonnement ne change pas sans te prévenir avant l'échéance."],
] as const;

/** Petites étiquettes qui flottent autour de la carte de membre. */
const CARD_CHIPS = [
  { label: "Effets animés", icon: Sparkles, className: "-top-6 right-8", delay: "0.4s" },
  { label: "Musique de fond", icon: Music, className: "-right-12 top-[58%]", delay: "0.9s" },
  { label: "Automatisations", icon: Wand2, className: "-bottom-6 left-[38%]", delay: "1.4s" },
] as const;

const PROMISES = [
  { label: "Sans engagement", icon: Check },
  { label: "Mensuel ou annuel", icon: Repeat },
  { label: "Résiliable en 2 clics", icon: InfinityIcon },
] as const;

export default async function PlusPage({ searchParams }: { searchParams: Promise<{ annule?: string }> }) {
  const [{ annule }, settings, user] = await Promise.all([searchParams, getSettings(), getCurrentUser()]);
  const name = settings.premiumName;
  const rights = user ? entitlementsFrom(user, settings) : null;
  const visible = FEATURE_KEYS.filter((k) => settings.features[k] !== "off");
  // Accès offert à tous, seulement si l'administration l'a explicitement activé.
  const free = freeForAll(settings);
  const bought = user ? activeTier(user) : "free";
  const subscription = user ? await currentSubscription(user.id) : null;
  const subscriptionOffer = subscription && subscriptionGivesAccess(subscription) ? subscription.offerId : null;

  const cards: TierCard[] = TIERS.map((tier) => ({
    tier,
    name: tierName(tier, name),
    tagline: TIER_PITCH[tier].tagline,
    audience: TIER_PITCH[tier].audience,
    highlights: highlights(settings, tier),
    offers: tier === "free" ? [] : settings.offers.filter((o) => o.active && o.tier === tier),
    featured: tier === "pro",
  }));

  const comparatorFeatures: ComparatorFeature[] = visible
    .map((k) => ({ key: k, label: FEATURES[k].label, description: FEATURES[k].description, rank: featureRank(settings, k) }))
    .sort((a, b) => a.rank - b.rank);
  const comparatorLimits: ComparatorLimit[] = LIMIT_ROWS.map((row) => ({
    label: row.label,
    values: TIERS.map((t) => settings.limits[t][row.key]),
    display: TIERS.map((t) => row.unit(settings.limits[t][row.key])),
  }));

  const formules = (
    <>
      {free ? (
        <ul className="ui-stagger grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {cards.map((card) => (
            <li
              key={card.tier}
              data-spotlight
              data-tone={card.tier === "free" ? undefined : "claim"}
              className={`ui-spotlight ui-lift relative rounded-xl border bg-ink-900/90 p-6 ${card.featured ? "ui-glow-border border-transparent" : "border-ink-700"}`}
            >
              {card.featured && (
                <span className="absolute -top-3 left-6 rounded-full bg-claim px-2.5 py-0.5 text-[11px] font-bold text-ink-950 shadow-[0_0_20px_rgba(255,194,71,0.5)]">
                  Le plus complet
                </span>
              )}
              <p className="hud-label text-ink-400">{card.tagline}</p>
              <h2 className="mt-2 font-display text-2xl font-bold">{card.name}</h2>
              <p className="mt-1 text-xs text-ink-400">{card.audience}</p>
              <ul className="mt-5 space-y-2 text-sm">
                {card.highlights.map((h) => (
                  <li key={h} className="flex gap-2 text-ink-200">
                    <Check size={15} className="mt-0.5 shrink-0 text-mint" aria-hidden="true" />
                    {h}
                  </li>
                ))}
              </ul>
            </li>
          ))}
        </ul>
      ) : (
        <PlusCheckout
          cards={cards}
          loggedIn={Boolean(user)}
          canPay={env.stripe.configured}
          testMode={env.stripe.testMode}
          shopUrl={settings.premiumUrl}
          current={
            user && bought !== "free"
              ? {
                  tier: bought,
                  name: tierName(bought, name),
                  until: rights?.subscription?.until ?? rights?.premiumUntil ?? null,
                  subscribed: Boolean(rights?.subscription),
                  offerId: subscriptionOffer,
                }
              : null
          }
        />
      )}
      <p className="mt-6 text-center text-sm text-ink-400">
        {free ? (
          <Link href={user ? "/dashboard" : "/login"} className="font-semibold text-claim hover:underline">
            {user ? "Retour à mon espace" : "Créer ma page gratuitement"}
          </Link>
        ) : (
          <>
            <Gift size={14} className="mr-1 inline align-[-2px] text-claim" aria-hidden="true" />
            Tu as un code ?{" "}
            <Link href={user ? "/dashboard/abonnement" : "/login?next=/dashboard/abonnement"} className="text-brand-300 hover:underline">
              Active-le dans « Mon espace »
            </Link>
            .
          </>
        )}
      </p>
    </>
  );

  const table = (
    <>
      <div className="overflow-x-auto rounded-xl border border-ink-700 bg-ink-900/90">
        <table className="w-full min-w-[720px] text-sm">
          <thead>
            <tr className="border-b border-ink-700 text-left">
              <th className="p-4 font-medium text-ink-400">Fonction</th>
              {TIERS.map((t) => (
                <th key={t} className={`w-32 p-4 text-center font-semibold ${t === "free" ? "text-ink-300" : "text-claim"}`}>
                  {tierName(t, name)}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-ink-800">
            {visible.map((k) => (
              <tr key={k} className="transition-colors hover:bg-ink-850/70">
                <td className="p-4">
                  <span className="block font-medium text-ink-100">{FEATURES[k].label}</span>
                  <span className="block text-xs text-ink-400">{FEATURES[k].description}</span>
                </td>
                {TIERS.map((t) => (
                  <td key={t} className="p-4 text-center">
                    {includes(settings, k, t) ? (
                      <Check size={18} className="mx-auto text-mint" aria-label="Inclus" />
                    ) : (
                      <Minus size={18} className="mx-auto text-ink-600" aria-label="Non inclus" />
                    )}
                  </td>
                ))}
              </tr>
            ))}
            {LIMIT_ROWS.map((row) => (
              <tr key={row.key} className="transition-colors hover:bg-ink-850/70">
                <td className="p-4 font-medium text-ink-100">{row.label}</td>
                {TIERS.map((t) => (
                  <td key={t} className="p-4 text-center font-mono text-ink-200 tabular-nums">
                    {row.unit(settings.limits[t][row.key])}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-3 text-xs text-ink-400">
        Les partenaires officiels ont toutes les fonctions et leurs propres limites.{" "}
        <Link href="/partenaires" className="text-brand-300 hover:underline">
          Le programme partenaires
        </Link>
      </p>
    </>
  );

  const prix = (
    <ul className="ui-stagger mx-auto grid max-w-5xl gap-3 sm:grid-cols-2 lg:grid-cols-3">
      {PRICING_LOGIC.map(([title, text], index) => (
        <li key={title} data-spotlight data-tone="claim" className="ui-spotlight ui-lift relative overflow-hidden rounded-xl border border-ink-700 bg-ink-900/90 p-5">
          <span className="pointer-events-none absolute -top-3 -right-1 font-display text-6xl font-bold text-white/[0.04] select-none" aria-hidden="true">
            {String(index + 1).padStart(2, "0")}
          </span>
          <p className="font-semibold text-ink-100">{title}</p>
          <p className="mt-1 text-sm text-ink-300">{text}</p>
        </li>
      ))}
    </ul>
  );

  const questions = (
    <div className="mx-auto max-w-3xl divide-y divide-ink-800 overflow-hidden rounded-xl border border-ink-800 bg-ink-900/60">
      {FAQ.map((item) => (
        <details key={item.q} className="ui-accordion group px-5">
          <summary className="flex cursor-pointer list-none items-center justify-between gap-4 py-4 font-semibold text-ink-100 transition hover:text-white">
            {item.q}
            <span className="ui-accordion-icon flex h-7 w-7 shrink-0 items-center justify-center rounded-md border border-ink-700 text-claim group-hover:border-claim/50">
              <Plus size={15} aria-hidden="true" />
            </span>
          </summary>
          <p className="pb-5 text-sm leading-relaxed text-ink-300">{item.a}</p>
        </details>
      ))}
    </div>
  );

  return (
    <PageTransition>
      <div className="bg-hud relative isolate min-h-screen overflow-x-clip">
        <div className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[1100px] overflow-hidden" aria-hidden="true">
          <span className="ui-ambient top-[2%] -right-32 h-[520px] w-[520px] bg-claim" />
          <span className="ui-ambient top-[30%] -left-40 h-[480px] w-[480px] bg-brand-500 [animation-delay:-9s]" />
          <span className="ui-ambient top-[60%] right-[20%] h-[420px] w-[420px] bg-[#7c5cf5] [animation-delay:-15s]" />
        </div>
        <SiteHeader loggedIn={Boolean(user)} premiumName={name} />
        <main className="mx-auto max-w-7xl px-4 pt-8 pb-20 sm:px-6 lg:pt-14">
          <section className="grid items-center gap-12 lg:grid-cols-[1.15fr_0.85fr]" aria-label={name}>
            <div className="ui-stagger text-center lg:text-left">
              <div className="flex justify-center lg:justify-start">
                <span className="animate-float drop-shadow-[0_0_24px_rgba(255,194,71,0.35)]">
                  <PlusLogo size={48} name={name} />
                </span>
              </div>
              <p className="hud-label mt-6 text-claim">{free ? "Offert pour le lancement" : "Formules"}</p>
              <h1 className="mx-auto mt-3 max-w-2xl font-display text-4xl font-bold tracking-tight text-balance sm:text-5xl lg:mx-0 lg:text-6xl">
                <SplitWords text={free ? "Tout est gratuit, pour tout le monde." : "Une formule pour chaque ambition."} />
              </h1>
              <p className="mx-auto mt-5 max-w-xl text-lg text-ink-300 lg:mx-0">
                {free
                  ? `Pendant le lancement, les fonctions de ${name}, ${name} Pro et ${name} Équipe sont ouvertes à tous, sans paiement ni code. Voici ce que chaque formule contiendra.`
                  : "Commence gratuitement, abonne-toi à la formule qui te ressemble quand tu en as besoin. Au mois ou à l'année, sans engagement, résiliable à tout moment."}
              </p>
              {rights && !free && rights.tier !== "free" && (
                <p className="mx-auto mt-6 inline-flex rounded-md border border-mint/40 bg-mint/10 px-4 py-2 text-sm text-ink-100 lg:mx-0">
                  {rights.admin && bought === "free"
                    ? "Administrateur : toutes les fonctions sont débloquées."
                    : rights.partner
                      ? "Partenaire officiel : toutes les fonctions sont incluses."
                      : rights.subscription
                        ? `Abonnement ${tierName(rights.subscription.tier, name)} ${rights.subscription.renews ? "renouvelé le" : "actif jusqu'au"} ${new Date(rights.subscription.until).toLocaleDateString("fr-FR", { dateStyle: "long", timeZone: "Europe/Paris" })}.`
                        : rights.premiumUntil
                          ? `${tierName(bought, name)} est actif jusqu'au ${new Date(rights.premiumUntil).toLocaleDateString("fr-FR", { dateStyle: "long", timeZone: "Europe/Paris" })}.`
                          : `${tierName(bought, name)} est actif sans limite de durée sur ton compte.`}
                </p>
              )}
              {annule && <p className="mx-auto mt-6 max-w-md text-sm text-ink-400 lg:mx-0">Paiement annulé : rien n&apos;a été débité.</p>}
              <div className="mt-8 flex flex-wrap justify-center gap-3 lg:justify-start">
                <a
                  href="#parties"
                  className="ui-press ui-shine inline-flex items-center gap-2 rounded-xl bg-claim px-5 py-3 font-semibold text-ink-950 transition hover:brightness-110"
                >
                  {free ? "Voir ce qui est inclus" : "Voir les formules"} <ArrowDown size={18} aria-hidden="true" />
                </a>
                <Link
                  href={user ? "/dashboard" : "/login"}
                  className="ui-press inline-flex items-center gap-2 rounded-xl border border-ink-500 px-5 py-3 font-semibold text-ink-100 transition hover:border-ink-300 hover:bg-ink-800"
                >
                  {user ? "Ouvrir mon espace" : "Créer ma page"} <ArrowRight size={18} aria-hidden="true" />
                </Link>
              </div>
              <ul className="mt-8 flex flex-wrap justify-center gap-x-5 gap-y-2 text-sm text-ink-400 lg:justify-start">
                {PROMISES.map(({ label, icon: Icon }) => (
                  <li key={label} className="inline-flex items-center gap-1.5">
                    <Icon size={15} className="text-mint" aria-hidden="true" /> {label}
                  </li>
                ))}
              </ul>
            </div>

            <div className="relative mx-auto hidden w-full max-w-[380px] md:block">
              <div className="absolute -inset-12 -z-10 rounded-full bg-claim/20 blur-3xl" aria-hidden="true" />
              <HoloCard name={name} tagline={free ? "Offert à tous pendant le lancement" : "Effets, musique, automatisations"} />
              {CARD_CHIPS.map(({ label, icon: Icon, className, delay }) => (
                <span
                  key={label}
                  className={`ui-motion pointer-events-none absolute z-10 hidden items-center gap-2 rounded-xl border border-ink-600/80 bg-ink-850/90 px-3 py-2 text-xs font-medium text-ink-100 shadow-2xl shadow-black/50 backdrop-blur-md lg:flex ${className}`}
                  style={{ animation: `pop 0.6s var(--ease-spring) ${delay} both, float 6s ease-in-out calc(${delay} + 0.6s) infinite` }}
                  aria-hidden="true"
                >
                  <Icon size={14} className="text-claim" /> {label}
                </span>
              ))}
            </div>
          </section>

          <PlusChapters
            chapters={[
              {
                id: "formules",
                label: "Formules",
                short: "Formules",
                hint: free ? "Ce que chaque formule contiendra après le lancement." : "Choisis ta formule, au mois ou à l'année : sans engagement, résiliable à tout moment.",
                content: formules,
              },
              {
                id: "inclus",
                label: "Ce qui est inclus",
                short: "Inclus",
                hint: "Choisis une formule : ses fonctions s'allument, ses limites se remplissent.",
                content: (
                  <PlanComparator
                    tiers={TIERS.map((t) => ({ name: tierName(t, name), tagline: TIER_PITCH[t].promise }))}
                    features={comparatorFeatures}
                    limits={comparatorLimits}
                    initial={bought !== "free" ? TIER_RANK[bought] : 1}
                    table={table}
                  />
                ),
              },
              { id: "prix", label: "Nos prix", short: "Prix", hint: "Comment nous avons fixé nos prix, en six règles.", content: prix },
              { id: "questions", label: "Questions", short: "FAQ", hint: "Les réponses aux questions qu'on nous pose le plus.", content: questions },
            ]}
          />
        </main>
        <SiteFooter premiumName={name} />
        <SmoothScroll />
      </div>
    </PageTransition>
  );
}
