import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { PlusLogo } from "@/components/brand/Logo";
import { OrderStatus } from "@/components/plus/OrderStatus";
import { SubscriptionStatus } from "@/components/plus/SubscriptionStatus";
import { SiteFooter, SiteHeader } from "@/components/site/SiteChrome";
import { getSettings } from "@/lib/server/settings";
import { getCurrentUser } from "@/lib/server/unclaim-auth";

export const metadata: Metadata = { title: "Merci", robots: { index: false } };

// Retour après paiement : l'activation est vérifiée auprès de Stripe (webhook ou lecture de la
// session), cette page suit son état. ?session= : abonnement · ?commande= : ancien achat unique.
export default async function ThanksPage({ searchParams }: { searchParams: Promise<{ commande?: string; session?: string }> }) {
  const [{ commande, session }, user, settings] = await Promise.all([searchParams, getCurrentUser(), getSettings()]);
  if (!user) {
    const back = session ? `/plus/merci?session=${session}` : `/plus/merci?commande=${commande ?? ""}`;
    redirect(`/login?next=${encodeURIComponent(back)}`);
  }
  const sessionId = session && /^cs_[A-Za-z0-9_]{10,200}$/.test(session) ? session : null;
  return (
    <div className="bg-hud flex min-h-screen flex-col">
      <SiteHeader loggedIn premiumName={settings.premiumName} />
      <main className="mx-auto flex w-full max-w-lg flex-1 flex-col items-center px-4 py-16 text-center">
        <PlusLogo size={48} name={settings.premiumName} />
        {sessionId ? (
          <SubscriptionStatus sessionId={sessionId} premiumName={settings.premiumName} />
        ) : (
          <OrderStatus orderId={commande && /^[a-z0-9]{10,40}$/.test(commande) ? commande : null} premiumName={settings.premiumName} />
        )}
      </main>
      <SiteFooter premiumName={settings.premiumName} />
    </div>
  );
}
