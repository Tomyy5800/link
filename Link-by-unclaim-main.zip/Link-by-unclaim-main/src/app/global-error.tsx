"use client";

// Erreur dans la mise en page racine : page autonome (sans les styles globaux), aux couleurs de la charte.
export default function GlobalError({ error, retry }: { error: Error & { digest?: string }; retry: () => void }) {
  return (
    <html lang="fr">
      <body style={{ margin: 0, minHeight: "100vh", display: "grid", placeItems: "center", background: "#020618", color: "#f8fafc", fontFamily: "system-ui, sans-serif" }}>
        <title>Erreur · Link by Unclaim</title>
        <main style={{ textAlign: "center", padding: 24, maxWidth: 420 }}>
          <p style={{ fontFamily: "monospace", letterSpacing: "0.14em", color: "#ffc247", fontSize: 13 }}>ERREUR INATTENDUE</p>
          <h1 style={{ fontSize: 24, margin: "8px 0" }}>Link by Unclaim ne répond pas correctement</h1>
          <p style={{ color: "#b4c1d3" }}>Réessaie dans un instant.</p>
          {error.digest && <p style={{ fontFamily: "monospace", fontSize: 12, color: "#5d6d86" }}>Référence : {error.digest}</p>}
          <button
            type="button"
            onClick={() => retry()}
            style={{ marginTop: 16, padding: "10px 20px", borderRadius: 6, border: 0, background: "#22c9e8", color: "#021018", fontWeight: 600, cursor: "pointer" }}
          >
            Réessayer
          </button>
        </main>
      </body>
    </html>
  );
}
