import { ImageResponse } from "next/og";

// Image d'aperçu de l'accueil (liens partagés sur Discord, X, etc.), aux couleurs de la charte.
export const alt = "Link by Unclaim — un seul lien, tout ton univers";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function OpenGraphImage() {
  const chunk = (fill: string) => ({ width: 64, height: 64, borderRadius: 8, background: fill });
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: 80,
          background: "#020618",
          backgroundImage: "linear-gradient(rgba(34,201,232,0.07) 1px, transparent 1px), linear-gradient(90deg, rgba(34,201,232,0.07) 1px, transparent 1px)",
          backgroundSize: "64px 64px",
          color: "#f8fafc",
          fontFamily: "sans-serif",
        }}
      >
        <div style={{ display: "flex", flexDirection: "column", maxWidth: 720 }}>
          <div style={{ display: "flex", fontSize: 30, color: "#ffc247", letterSpacing: 6 }}>LINK BY UNCLAIM</div>
          <div style={{ display: "flex", fontSize: 76, fontWeight: 700, lineHeight: 1.05, marginTop: 24 }}>Un seul lien. Tout ton univers.</div>
          <div style={{ display: "flex", fontSize: 30, color: "#b4c1d3", marginTop: 28, lineHeight: 1.35 }}>
            Liens, réseaux, radio, agenda, NationsGlory et skin 3D, dans une page à ton image.
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <div style={{ display: "flex", gap: 12 }}>
            <div style={chunk("#ffc247")} />
            <div style={chunk("#ffc247")} />
            <div style={chunk("transparent")} />
          </div>
          <div style={{ display: "flex", gap: 12 }}>
            <div style={chunk("#ffc247")} />
            <div style={chunk("#22c9e8")} />
            <div style={chunk("#ffc247")} />
          </div>
          <div style={{ display: "flex", gap: 12 }}>
            <div style={chunk("transparent")} />
            <div style={chunk("#ffc247")} />
            <div style={chunk("#ffc247")} />
          </div>
        </div>
      </div>
    ),
    size,
  );
}
