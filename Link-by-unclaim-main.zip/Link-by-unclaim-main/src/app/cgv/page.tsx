import type { Metadata } from "next";
import { Fill, LegalPage, LegalSection } from "@/components/site/Legal";
import { formatPrice, intervalLabel } from "@/lib/features";
import { tierName } from "@/lib/plans";
import { getSettings } from "@/lib/server/settings";
import { getCurrentUser } from "@/lib/server/unclaim-auth";

export const metadata: Metadata = { title: "Conditions générales de vente" };

// Modèle de CGV pour la vente en ligne d'abonnements et d'articles numériques, à faire relire
// avant l'ouverture des ventes.
export default async function CgvPage() {
  const [settings, user] = await Promise.all([getSettings(), getCurrentUser()]);
  const { legal, premiumName: name } = settings;
  const offers = settings.offers.filter((o) => o.active);

  return (
    <LegalPage title="Conditions générales de vente" updated="19 octobre 2026" loggedIn={Boolean(user)} premiumName={name}>
      <LegalSection title="1. Objet">
        <p>
          Les présentes conditions encadrent les ventes de Link by Unclaim : les abonnements à {name} et à ses formules supérieures (accès à des
          fonctions supplémentaires de personnalisation, de gestion et de statistiques), et les articles numériques de la boutique officielle (badges,
          cadres de profil). Toute commande vaut acceptation des présentes conditions, sans réserve.
        </p>
      </LegalSection>

      <LegalSection title="2. Vendeur">
        <p>
          <Fill value={legal.sellerName} label="Nom ou raison sociale" />, <Fill value={legal.status} label="Statut juridique" />, immatriculé sous le numéro{" "}
          <Fill value={legal.siret} label="SIREN / SIRET" />, dont le siège est situé <Fill value={legal.address} label="Adresse" />. Contact :{" "}
          <Fill value={legal.email} label="E-mail de contact" />.
        </p>
      </LegalSection>

      <LegalSection title="3. Offres et prix">
        <p>Les prix sont indiqués en euros, toutes taxes comprises. {legal.vatMention && <>{legal.vatMention}.</>}</p>
        {offers.length > 0 && (
          <ul className="list-disc pl-5">
            {offers.map((o) => (
              <li key={o.id}>
                {tierName(o.tier, name)} {o.name.toLowerCase()} : {formatPrice(o.priceCents)} {intervalLabel(o.interval)}.
              </li>
            ))}
          </ul>
        )}
        <p>
          Les formules sont vendues par abonnement, mensuel ou annuel, sans durée minimale d&apos;engagement. Le prix applicable est celui affiché au
          moment de la souscription ; en cas de changement de tarif, l&apos;abonné est prévenu avant l&apos;échéance concernée et peut résilier avant
          qu&apos;il s&apos;applique. Les articles de la boutique officielle sont vendus à l&apos;unité, par un paiement unique, et restent acquis au
          compte qui les a achetés pour toute la durée d&apos;exploitation du service.
        </p>
      </LegalSection>

      <LegalSection title="4. Commande et paiement">
        <p>
          La commande se passe depuis la page {name} ou la boutique officielle, avec un compte connecté. Le paiement s&apos;effectue par carte
          bancaire via le prestataire Stripe ; le vendeur n&apos;a jamais accès aux données de carte. La commande est ferme à la confirmation du
          paiement par Stripe.
        </p>
      </LegalSection>

      <LegalSection title="5. Abonnement : renouvellement et résiliation">
        <p>
          L&apos;abonnement est renouvelé automatiquement à la fin de chaque période (mois ou année) et le montant de la période suivante est prélevé
          sur le moyen de paiement enregistré, jusqu&apos;à résiliation. L&apos;abonné peut résilier à tout moment, en ligne et en quelques clics,
          depuis Mon espace › Offre : la résiliation prend effet à la fin de la période déjà payée, pendant laquelle l&apos;accès est conservé. Aucun
          prélèvement n&apos;a lieu ensuite. Un abonnement résilié peut être repris tant que la période en cours n&apos;est pas terminée.
        </p>
        <p>
          Changement de formule : le passage à une formule supérieure ou inférieure s&apos;applique immédiatement ; la différence de prix pour la
          période en cours est facturée ou créditée au prorata. En cas d&apos;échec d&apos;un prélèvement, Stripe effectue de nouvelles tentatives
          pendant quelques jours ; sans paiement, l&apos;abonnement prend fin et la page repasse en offre gratuite (son contenu est conservé, les
          réglages réservés sont mis en veille).
        </p>
      </LegalSection>

      <LegalSection title="6. Accès au service">
        <p>
          L&apos;accès à la formule ou à l&apos;article acheté est ouvert dès la confirmation du paiement, sur le compte qui a passé commande. Les
          articles de la boutique officielle sont des personnalisations du profil : leur apparence peut évoluer avec le service sans que leur
          fonction ne change.
        </p>
      </LegalSection>

      <LegalSection title="7. Droit de rétractation">
        <p>
          Conformément à l&apos;article L221-28, 13° du Code de la consommation, le droit de rétractation ne peut être exercé pour un contenu
          numérique fourni sur un support immatériel dont l&apos;exécution a commencé après accord préalable exprès du consommateur et renoncement
          exprès à son droit de rétractation. Avant de payer, l&apos;acheteur demande l&apos;accès immédiat et reconnaît perdre ce droit en cochant
          la case prévue à cet effet.
        </p>
      </LegalSection>

      <LegalSection title="8. Remboursement et réclamations">
        <p>
          En cas de dysfonctionnement empêchant l&apos;utilisation de ce qui a été acheté, l&apos;acheteur peut écrire à{" "}
          <Fill value={legal.email} label="E-mail de contact" />. Le vendeur s&apos;engage à rétablir l&apos;accès ou, à défaut, à rembourser la
          période ou l&apos;article concerné. Un remboursement retire l&apos;accès correspondant (et met fin à l&apos;abonnement concerné).
        </p>
      </LegalSection>

      <LegalSection title="9. Mineurs">
        <p>Un achat ou un abonnement souscrit par une personne mineure suppose l&apos;accord de son représentant légal.</p>
      </LegalSection>

      <LegalSection title="10. Suspension">
        <p>
          Un compte qui enfreint les règles de Link by Unclaim (contenu illicite, arnaque, usurpation d&apos;identité, harcèlement) peut être suspendu
          par la modération. La suspension est motivée et le titulaire peut la contester par e-mail.
        </p>
      </LegalSection>

      <LegalSection title="11. Données personnelles">
        <p>
          Le traitement des données liées aux commandes et aux abonnements est décrit dans la{" "}
          <a href="/confidentialite" className="text-brand-300 underline">
            politique de confidentialité
          </a>
          .
        </p>
      </LegalSection>

      <LegalSection title="12. Médiation et droit applicable">
        <p>
          Les présentes conditions sont soumises au droit français. En cas de litige, le consommateur peut recourir gratuitement au médiateur de la
          consommation : <Fill value={legal.mediator} label="Médiateur de la consommation (nom, site)" />, après une réclamation écrite préalable
          auprès du vendeur.
        </p>
      </LegalSection>
    </LegalPage>
  );
}
