import type { NextRequest } from "next/server";

// Avatar par défaut (comptes sans photo) : une initiale sur un chunk aux couleurs de la charte.
const PALETTE = [
  ["#22c9e8", "#021018"],
  ["#ffc247", "#021018"],
  ["#8fe6f6", "#021018"],
  ["#00bc7d", "#021018"],
  ["#5865f2", "#ffffff"],
  ["#ff6467", "#021018"],
];

function hash(text: string): number {
  let h = 2166136261;
  for (const ch of text) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0;
  return h;
}

export function GET(request: NextRequest) {
  const seed = (request.nextUrl.searchParams.get("seed") ?? "").slice(0, 40);
  const raw = request.nextUrl.searchParams.get("l") ?? "?";
  const letter = /^[\p{L}\p{N}?]$/u.test(raw) ? raw.toUpperCase() : "?";
  const [bg, fg] = PALETTE[hash(seed) % PALETTE.length];
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128"><rect width="128" height="128" fill="#0f172b"/><rect x="18" y="18" width="92" height="92" rx="14" fill="${bg}"/><text x="64" y="64" dy=".35em" text-anchor="middle" font-family="Chakra Petch,system-ui,sans-serif" font-size="56" font-weight="700" fill="${fg}">${letter}</text></svg>`;
  return new Response(svg, {
    headers: {
      "Content-Type": "image/svg+xml; charset=utf-8",
      "Cache-Control": "public, max-age=604800, immutable",
      "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
