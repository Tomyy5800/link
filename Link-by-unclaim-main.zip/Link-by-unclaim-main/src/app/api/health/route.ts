import { NextResponse } from "next/server";
import { prisma } from "@/lib/server/db";

export const dynamic = "force-dynamic";

// Sonde de santé (Docker, répartiteur de charge) : l'application répond et la base est joignable.
export async function GET() {
  const started = Date.now();
  let database = true;
  try {
    await prisma.$queryRaw`SELECT 1`;
  } catch {
    database = false;
  }
  return NextResponse.json(
    { status: database ? "ok" : "degraded", database, latencyMs: Date.now() - started, time: new Date().toISOString() },
    { status: database ? 200 : 503, headers: { "Cache-Control": "no-store" } },
  );
}
