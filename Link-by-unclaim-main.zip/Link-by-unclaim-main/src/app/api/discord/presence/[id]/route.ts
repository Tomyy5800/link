import { NextResponse, type NextRequest } from "next/server";
import { offlinePresence } from "@/lib/presence";
import { prisma } from "@/lib/server/db";
import { guardRate } from "@/lib/server/http";
import { getPresence } from "@/lib/server/presence";

// Statut Discord en direct d'un membre de Link by Unclaim (relais Lanyard, cache 20 s).
// Limité aux comptes connus de l'application : ce n'est pas un relais ouvert.
export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const limited = guardRate(request, "presence", 90);
  if (limited) return limited;
  const { id } = await params;
  if (!/^\d{15,22}$/.test(id)) return NextResponse.json(offlinePresence(false), { status: 400 });

  const known = await prisma.user.findUnique({ where: { discordId: id }, select: { banned: true } });
  if (!known || known.banned) return NextResponse.json(offlinePresence(false), { status: 404 });

  const presence = await getPresence(id);
  return NextResponse.json(presence, { headers: { "Cache-Control": "no-store" } });
}
