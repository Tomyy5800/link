import { NextResponse, type NextRequest } from "next/server";
import { getDiscordInvite } from "@/lib/server/discord";
import { guardRate } from "@/lib/server/http";

// Informations publiques d'une invitation de serveur Discord (nom, icône, membres).
export async function GET(request: NextRequest, { params }: { params: Promise<{ code: string }> }) {
  const limited = guardRate(request, "discord-invite", 40);
  if (limited) return limited;
  const { code } = await params;
  const invite = await getDiscordInvite(code);
  return NextResponse.json(invite, {
    headers: { "Cache-Control": invite.status === "ok" ? "public, max-age=120, s-maxage=600" : "no-store" },
  });
}
