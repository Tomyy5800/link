import { type NextRequest } from "next/server";
import { guardRate } from "@/lib/server/http";
import { getSkinAsset, type SkinAsset } from "@/lib/server/skins";

const ASSETS = new Set<SkinAsset>(["skin", "face", "body"]);
const SIZES = new Set([16, 32, 64, 128, 256]);

// Sert la texture du skin (pour le rendu 3D) et les rendus 2D tête / corps.
// GET /api/skin/<pseudo>?type=skin|face|body&size=16|32|64|128|256
export async function GET(request: NextRequest, { params }: { params: Promise<{ username: string }> }) {
  const limited = guardRate(request, "skin", 120);
  if (limited) return limited;

  const { username } = await params;
  const search = request.nextUrl.searchParams;
  const type = (search.get("type") ?? "skin") as SkinAsset;
  const size = Number(search.get("size") ?? 128);
  if (!ASSETS.has(type) || !SIZES.has(size)) return new Response("Paramètres invalides.", { status: 400 });

  const image = await getSkinAsset(type, username, size);
  if (!image) return new Response("Skin introuvable.", { status: 404, headers: { "Cache-Control": "no-store" } });

  return new Response(new Blob([image as Uint8Array<ArrayBuffer>], { type: "image/png" }), {
    headers: {
      "Content-Type": "image/png",
      "Cache-Control": "public, max-age=3600, s-maxage=3600, stale-while-revalidate=86400",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
