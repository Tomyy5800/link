import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { audit, isResponse, requireAdminApi } from "@/lib/server/admin";
import { prisma } from "@/lib/server/db";
import { jsonError, readJson } from "@/lib/server/http";

// Désactivation (ou réactivation) d'un code Link+.
export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdminApi(request);
  if (isResponse(admin)) return admin;
  const { id } = await params;

  const parsed = z.object({ disabled: z.boolean() }).safeParse(await readJson(request, 1_000).catch(() => null));
  if (!parsed.success) return jsonError(400, "Données invalides.");
  if (!(await prisma.premiumCode.findUnique({ where: { id }, select: { id: true } }))) return jsonError(404, "Code introuvable.");

  await prisma.premiumCode.update({ where: { id }, data: { disabled: parsed.data.disabled } });
  await audit(admin.id, parsed.data.disabled ? "code.disable" : "code.enable", "code", id);
  return NextResponse.json({ ok: true });
}
