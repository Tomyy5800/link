import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { audit, isResponse, requireAdminApi } from "@/lib/server/admin";
import { prisma } from "@/lib/server/db";
import { jsonError, readJson } from "@/lib/server/http";
import { generateCode, hashCode, normalizeCode } from "@/lib/server/premium";

const createSchema = z.object({
  count: z.number().int().min(1).max(200),
  /** Durée de Link+ offerte, en jours (0 = sans limite). */
  days: z.number().int().min(0).max(3650),
  /** Formule offerte. */
  tier: z.enum(["plus", "pro", "team"]).default("plus"),
  maxUses: z.number().int().min(1).max(10_000).default(1),
  /** Date limite d'échange (ISO), facultative. */
  expiresAt: z.iso.datetime().nullable().default(null),
  note: z.string().trim().max(120).default(""),
});

// Création de codes Link+. Les codes en clair ne sont renvoyés qu'ici, une seule fois.
export async function POST(request: NextRequest) {
  const admin = await requireAdminApi(request);
  if (isResponse(admin)) return admin;

  const parsed = createSchema.safeParse(await readJson(request, 4_000).catch(() => null));
  if (!parsed.success) return jsonError(400, parsed.error.issues[0]?.message ?? "Données invalides.");
  const { count, days, tier, maxUses, expiresAt, note } = parsed.data;

  const codes = Array.from({ length: count }, generateCode);
  await prisma.premiumCode.createMany({
    data: codes.map((code) => ({
      codeHash: hashCode(code),
      hint: normalizeCode(code).slice(-4),
      days,
      tier,
      maxUses,
      expiresAt: expiresAt ? new Date(expiresAt) : null,
      note,
      createdById: admin.id,
    })),
  });
  await audit(admin.id, "codes.create", "code", "batch", { count, days, tier, maxUses, note });
  return NextResponse.json({ codes }, { status: 201 });
}
