import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { audit, isResponse, requireAdminApi } from "@/lib/server/admin";
import { prisma } from "@/lib/server/db";
import { jsonError, readJson } from "@/lib/server/http";
import { PaymentError, fulfillOrder, markRefunded, refundPayment } from "@/lib/server/payments";

const actionSchema = z.discriminatedUnion("action", [
  /** Rembourse chez Stripe (si possible) et retire l'accès. */
  z.object({ action: z.literal("refund"), online: z.boolean().default(true), revoke: z.boolean().default(true) }),
  /** Valide à la main un paiement reçu hors ligne ou dont la notification s'est perdue. */
  z.object({ action: z.literal("markPaid") }),
]);

// Actions sur une commande : remboursement, validation manuelle.
export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdminApi(request);
  if (isResponse(admin)) return admin;
  const { id } = await params;
  const parsed = actionSchema.safeParse(await readJson(request, 2_000).catch(() => null));
  if (!parsed.success) return jsonError(400, "Action invalide.");
  const order = await prisma.order.findUnique({ where: { id } });
  if (!order) return jsonError(404, "Commande introuvable.");

  if (parsed.data.action === "markPaid") {
    if (order.status === "paid") return jsonError(400, "Commande déjà payée.");
    const updated = await fulfillOrder(order.id, order.paymentRef);
    await audit(admin.id, "order.paid", "order", order.id, { manual: true });
    return NextResponse.json({ order: updated });
  }

  if (order.status !== "paid") return jsonError(400, "Seule une commande payée peut être remboursée.");
  try {
    if (parsed.data.online && order.paymentRef) await refundPayment(order);
  } catch (error) {
    if (error instanceof PaymentError) return jsonError(error.status, error.message);
    throw error;
  }
  const updated = await markRefunded(order.id, admin.id, parsed.data.revoke);
  return NextResponse.json({ order: updated });
}
