import { NextResponse, type NextRequest } from "next/server";
import { accountAvatarUrl } from "@/lib/discord-cdn";
import { isResponse, requireAdminApi } from "@/lib/server/admin";
import { prisma } from "@/lib/server/db";

// Recherche de comptes pour l'administration (attribution de badges, permissions) : pseudo,
// nom affiché, identifiant, ID Unclaim ou Discord, adresse de page.
export async function GET(request: NextRequest) {
  const admin = await requireAdminApi(request, { mutation: false });
  if (isResponse(admin)) return admin;
  const q = (request.nextUrl.searchParams.get("q") ?? "").trim().slice(0, 60);
  if (q.length < 2) return NextResponse.json({ users: [] });
  const users = await prisma.user.findMany({
    where: {
      deletedAt: null,
      OR: [
        { id: q },
        { unclaimId: q },
        { discordId: q },
        { username: { contains: q } },
        { globalName: { contains: q } },
        { pages: { some: { slug: { contains: q.toLowerCase() } } } },
      ],
    },
    take: 8,
    orderBy: { lastLoginAt: "desc" },
    select: { id: true, username: true, globalName: true, avatarUrl: true, avatarHash: true, bannerHash: true, accentColor: true, discordId: true, provider: true, pages: { select: { slug: true }, take: 1 } },
  });
  return NextResponse.json({
    users: users.map((u) => ({ id: u.id, name: u.globalName ?? u.username, username: u.username, avatar: accountAvatarUrl(u), slug: u.pages[0]?.slug ?? null })),
  });
}
