import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { audit, isResponse, requireAdminApi } from "@/lib/server/admin";
import { prisma } from "@/lib/server/db";
import { jsonError, readJson } from "@/lib/server/http";
import { paidTier } from "@/lib/plans";
import { isFounderLevel } from "@/lib/server/staff";
import { revokeSessions } from "@/lib/server/unclaim-auth";

const patchSchema = z.object({
  /** Offre : gratuite, ou Link+ pour N jours (0 = sans limite de durée). */
  plan: z
    .union([
      z.object({ plan: z.literal("free") }),
      z.object({ plan: z.enum(["plus", "pro", "team", "premium"]), days: z.number().int().min(0).max(3650) }),
    ])
    .optional(),
  verified: z.boolean().optional(),
  /** Partenaire officiel (badge, Link+ inclus, limites « partenaires »). */
  partner: z.boolean().optional(),
  role: z.enum(["user", "admin"]).optional(),
  /** null : lever la suspension. */
  suspend: z.object({ reason: z.string().trim().max(280) }).nullable().optional(),
});

// Modération et offre d'un compte.
export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdminApi(request);
  if (isResponse(admin)) return admin;
  const { id } = await params;

  const parsed = patchSchema.safeParse(await readJson(request, 4_000).catch(() => null));
  if (!parsed.success) return jsonError(400, parsed.error.issues[0]?.message ?? "Données invalides.");
  const target = await prisma.user.findUnique({ where: { id } });
  if (!target) return jsonError(404, "Compte introuvable.");
  const { plan, verified, partner, role, suspend } = parsed.data;

  if (role !== undefined && target.id === admin.id && role !== "admin") {
    return jsonError(400, "Tu ne peux pas retirer ton propre rôle d'administrateur.");
  }
  // Nommer ou retirer un administrateur : réservé aux fondateurs (configurés côté serveur).
  if (role !== undefined && role !== target.role && !isFounderLevel(admin)) return jsonError(403, "Seul un fondateur peut nommer ou retirer un administrateur.");
  if (role === "user" && isFounderLevel(target)) return jsonError(400, "Un fondateur est déclaré dans la configuration du serveur : son rôle ne se retire pas ici.");
  // Modération d'un fondateur par un simple administrateur : refusée.
  if (suspend && isFounderLevel(target) && !isFounderLevel(admin)) return jsonError(403, "Un administrateur ne peut pas suspendre un fondateur.");
  if (suspend && target.id === admin.id) return jsonError(400, "Tu ne peux pas suspendre ton propre compte.");

  const data: Parameters<typeof prisma.user.update>[0]["data"] = {};
  if (plan) {
    // Don d'un administrateur : la formule choisie remplace la formule en cours (pas de conversion).
    data.plan = plan.plan === "free" ? "free" : paidTier(plan.plan);
    data.planExpiresAt = plan.plan !== "free" && plan.days > 0 ? new Date(Date.now() + plan.days * 86_400_000) : null;
    if (plan.plan === "free") data.basePlan = "free";
  }
  if (verified !== undefined) data.verified = verified;
  if (partner !== undefined) {
    data.partner = partner;
    data.partnerSince = partner ? (target.partnerSince ?? new Date()) : null;
  }
  if (role !== undefined) {
    data.role = role;
    // Un administrateur retiré perd aussi ses permissions sensibles.
    if (role === "user") data.staffPermissions = "[]";
  }
  if (suspend !== undefined) {
    data.suspendedAt = suspend ? new Date() : null;
    data.suspendReason = suspend?.reason ?? "";
  }
  const user = await prisma.user.update({ where: { id }, data });
  if (suspend) await revokeSessions(id);

  if (plan) await audit(admin.id, "user.plan", "user", id, plan);
  if (verified !== undefined) await audit(admin.id, "user.verify", "user", id, { verified });
  if (partner !== undefined) await audit(admin.id, "user.partner", "user", id, { partner });
  if (role !== undefined) await audit(admin.id, "user.role", "user", id, { role });
  if (suspend !== undefined) await audit(admin.id, suspend ? "user.suspend" : "user.unsuspend", "user", id, suspend ?? {});

  return NextResponse.json({
    user: { id: user.id, plan: user.plan, planExpiresAt: user.planExpiresAt, verified: user.verified, partner: user.partner, role: user.role, suspendedAt: user.suspendedAt, suspendReason: user.suspendReason },
  });
}
