import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { STAFF_PERMISSION_KEYS, type StaffPermission } from "@/lib/staff";
import { audit, isResponse, requireAdminApi } from "@/lib/server/admin";
import { prisma } from "@/lib/server/db";
import { isAdmin } from "@/lib/server/entitlements";
import { jsonError, readJson } from "@/lib/server/http";
import { isFounderLevel, requireFounder } from "@/lib/server/staff";

const schema = z.object({ permissions: z.array(z.enum(STAFF_PERMISSION_KEYS as [StaffPermission, ...StaffPermission[]])).max(STAFF_PERMISSION_KEYS.length) });

// Permissions sensibles d'un administrateur : seul un fondateur les accorde ou les retire.
export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdminApi(request);
  if (isResponse(admin)) return admin;
  const denied = requireFounder(admin);
  if (denied) return denied;
  const target = await prisma.user.findUnique({ where: { id: (await params).id } });
  if (!target) return jsonError(404, "Compte introuvable.");
  if (!isAdmin(target)) return jsonError(400, "Ce compte n'est pas administrateur.");
  if (isFounderLevel(target)) return jsonError(400, "Un fondateur a déjà toutes les permissions.");
  const parsed = schema.safeParse(await readJson(request, 2_000).catch(() => null));
  if (!parsed.success) return jsonError(400, "Permissions invalides.");
  const permissions = [...new Set(parsed.data.permissions)];
  await prisma.user.update({ where: { id: target.id }, data: { staffPermissions: JSON.stringify(permissions) } });
  await audit(admin.id, "staff.permissions", "user", target.id, { permissions });
  return NextResponse.json({ permissions });
}
