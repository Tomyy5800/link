import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { audit, isResponse, requireAdminApi } from "@/lib/server/admin";
import { DiscordApiError, fetchGuild, getDiscordConfig, runDiscordSync } from "@/lib/server/discord-sync";
import { env } from "@/lib/server/env";
import { jsonError, readJson } from "@/lib/server/http";
import { requireStaffPermission } from "@/lib/server/staff";

const schema = z.object({ action: z.enum(["test", "sync"]) });

// « test » : vérifie le bot et lit les rôles du serveur · « sync » : synchronise maintenant.
// Rien n'est simulé : sans jeton de bot, la réponse le dit.
export async function POST(request: NextRequest) {
  const admin = await requireAdminApi(request);
  if (isResponse(admin)) return admin;
  const denied = requireStaffPermission(admin, "discord.manage");
  if (denied) return denied;
  const parsed = schema.safeParse(await readJson(request, 500).catch(() => null));
  if (!parsed.success) return jsonError(400, "Action invalide.");
  if (!env.discordBot.configured) return jsonError(503, "Bot non configuré : ajoute DISCORD_BOT_TOKEN dans l'environnement du serveur, puis redémarre.");
  const config = await getDiscordConfig();
  if (!config.guildId) return jsonError(400, "Renseigne d'abord l'identifiant du serveur Discord officiel.");

  if (parsed.data.action === "test") {
    try {
      const guild = await fetchGuild(config.guildId);
      return NextResponse.json({ guild: { name: guild.name }, roles: guild.roles.map((r) => ({ id: r.id, name: r.name, color: r.color })) });
    } catch (error) {
      return jsonError(error instanceof DiscordApiError && error.status ? 502 : 503, error instanceof Error ? error.message : "Connexion à Discord impossible.");
    }
  }
  const status = await runDiscordSync();
  await audit(admin.id, "discord.sync", "settings", "discord", { ok: status.ok, checked: status.checked, granted: status.granted, revoked: status.revoked });
  return NextResponse.json({ status });
}
