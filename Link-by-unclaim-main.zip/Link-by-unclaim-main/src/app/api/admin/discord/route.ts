import { NextResponse, type NextRequest } from "next/server";
import { audit, isResponse, requireAdminApi } from "@/lib/server/admin";
import { discordConfigSchema, getDiscordConfig, getDiscordStatus, saveDiscordConfig } from "@/lib/server/discord-sync";
import { env } from "@/lib/server/env";
import { jsonError, readJson } from "@/lib/server/http";
import { requireStaffPermission } from "@/lib/server/staff";

// Synchronisation des rôles Discord : configuration (serveur officiel, intervalle, activation).
export async function GET(request: NextRequest) {
  const admin = await requireAdminApi(request, { mutation: false });
  if (isResponse(admin)) return admin;
  const [config, status] = await Promise.all([getDiscordConfig(), getDiscordStatus()]);
  return NextResponse.json({ config, status, botConfigured: env.discordBot.configured });
}

export async function PUT(request: NextRequest) {
  const admin = await requireAdminApi(request);
  if (isResponse(admin)) return admin;
  const denied = requireStaffPermission(admin, "discord.manage");
  if (denied) return denied;
  const parsed = discordConfigSchema.safeParse(await readJson(request, 2_000).catch(() => null));
  if (!parsed.success) return jsonError(400, parsed.error.issues[0]?.message ?? "Configuration invalide.");
  const before = await getDiscordConfig();
  const config = await saveDiscordConfig(parsed.data);
  await audit(admin.id, "discord.config", "settings", "discord", { before, after: config });
  return NextResponse.json({ config });
}
