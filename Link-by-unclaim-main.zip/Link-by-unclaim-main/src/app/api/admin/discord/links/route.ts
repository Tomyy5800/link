import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { acceptsManualGrant, parseBadgeRule } from "@/lib/badges";
import { audit, isResponse, requireAdminApi } from "@/lib/server/admin";
import { badgeManageError } from "@/lib/server/badges";
import { prisma } from "@/lib/server/db";
import { jsonError, readJson } from "@/lib/server/http";
import { requireStaffPermission } from "@/lib/server/staff";

const schema = z.object({
  roleId: z.string().regex(/^\d{15,22}$/, "Identifiant de rôle invalide."),
  roleName: z.string().trim().max(100).default(""),
  badgeId: z.string().regex(/^[a-z0-9]{8,40}$/i),
  removeOnLoss: z.boolean().default(true),
  enabled: z.boolean().default(true),
});

// Associations rôle Discord → badge. Le badge doit être à règle manuelle, et l'administrateur
// doit pouvoir l'attribuer lui-même (badges du staff, badges réservés aux fondateurs).
export async function GET(request: NextRequest) {
  const admin = await requireAdminApi(request, { mutation: false });
  if (isResponse(admin)) return admin;
  const links = await prisma.discordRoleLink.findMany({ include: { badge: true }, orderBy: { createdAt: "asc" } });
  return NextResponse.json({ links });
}

export async function POST(request: NextRequest) {
  const admin = await requireAdminApi(request);
  if (isResponse(admin)) return admin;
  const denied = requireStaffPermission(admin, "discord.manage");
  if (denied) return denied;
  const parsed = schema.safeParse(await readJson(request, 2_000).catch(() => null));
  if (!parsed.success) return jsonError(400, parsed.error.issues[0]?.message ?? "Association invalide.");
  const badge = await prisma.badge.findUnique({ where: { id: parsed.data.badgeId } });
  if (!badge || badge.archivedAt) return jsonError(404, "Badge introuvable.");
  if (!acceptsManualGrant(parseBadgeRule(badge.rule))) return jsonError(400, "Seuls les badges à règle manuelle peuvent suivre un rôle Discord.");
  const forbidden = badgeManageError(admin, badge);
  if (forbidden) return jsonError(403, forbidden);
  try {
    const link = await prisma.discordRoleLink.create({ data: parsed.data, include: { badge: true } });
    await audit(admin.id, "discord.link", "badge", badge.id, { roleId: link.roleId, roleName: link.roleName, removeOnLoss: link.removeOnLoss });
    return NextResponse.json({ link }, { status: 201 });
  } catch {
    return jsonError(409, "Ce rôle est déjà associé à ce badge.");
  }
}
