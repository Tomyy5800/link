import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { audit, isResponse, requireAdminApi } from "@/lib/server/admin";
import { badgeManageError } from "@/lib/server/badges";
import { prisma } from "@/lib/server/db";
import { jsonError, readJson } from "@/lib/server/http";
import { requireStaffPermission } from "@/lib/server/staff";

type Ctx = { params: Promise<{ linkId: string }> };

const patchSchema = z.object({ enabled: z.boolean().optional(), removeOnLoss: z.boolean().optional() });

async function load(request: NextRequest, params: Ctx["params"]) {
  const admin = await requireAdminApi(request);
  if (isResponse(admin)) return admin;
  const denied = requireStaffPermission(admin, "discord.manage");
  if (denied) return denied;
  const link = await prisma.discordRoleLink.findUnique({ where: { id: (await params).linkId }, include: { badge: true } });
  if (!link) return jsonError(404, "Association introuvable.");
  const forbidden = badgeManageError(admin, link.badge);
  if (forbidden) return jsonError(403, forbidden);
  return { admin, link };
}

export async function PATCH(request: NextRequest, { params }: Ctx) {
  const ctx = await load(request, params);
  if (isResponse(ctx)) return ctx;
  const parsed = patchSchema.safeParse(await readJson(request, 500).catch(() => null));
  if (!parsed.success) return jsonError(400, "Demande invalide.");
  const link = await prisma.discordRoleLink.update({ where: { id: ctx.link.id }, data: parsed.data, include: { badge: true } });
  await audit(ctx.admin.id, "discord.link.update", "badge", link.badgeId, { roleId: link.roleId, ...parsed.data });
  return NextResponse.json({ link });
}

/** Supprimer l'association : les badges déjà donnés par la synchronisation restent jusqu'à leur retrait manuel. */
export async function DELETE(request: NextRequest, { params }: Ctx) {
  const ctx = await load(request, params);
  if (isResponse(ctx)) return ctx;
  await prisma.discordRoleLink.delete({ where: { id: ctx.link.id } });
  await audit(ctx.admin.id, "discord.unlink", "badge", ctx.link.badgeId, { roleId: ctx.link.roleId });
  return NextResponse.json({ ok: true });
}
