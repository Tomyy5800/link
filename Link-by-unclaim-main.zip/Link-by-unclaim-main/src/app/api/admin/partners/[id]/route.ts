import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { audit, isResponse, requireAdminApi } from "@/lib/server/admin";
import { prisma } from "@/lib/server/db";
import { jsonError, readJson } from "@/lib/server/http";

const schema = z.object({
  decision: z.enum(["accept", "refuse"]),
  /** Motif visible par la personne en cas de refus. */
  note: z.string().trim().max(400).default(""),
});

// Examen d'une candidature partenaire : acceptation (le compte devient partenaire) ou refus motivé.
export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdminApi(request);
  if (isResponse(admin)) return admin;
  const { id } = await params;
  const parsed = schema.safeParse(await readJson(request, 2_000).catch(() => null));
  if (!parsed.success) return jsonError(400, "Décision invalide.");

  const application = await prisma.partnerApplication.findUnique({ where: { id }, include: { user: { select: { partnerSince: true } } } });
  if (!application) return jsonError(404, "Candidature introuvable.");
  if (application.status !== "pending") return jsonError(409, "Cette candidature a déjà été examinée.");

  const accepted = parsed.data.decision === "accept";
  await prisma.$transaction([
    prisma.partnerApplication.update({
      where: { id },
      data: { status: accepted ? "accepted" : "refused", reviewNote: parsed.data.note, reviewedById: admin.id, reviewedAt: new Date() },
    }),
    ...(accepted
      ? [prisma.user.update({ where: { id: application.userId }, data: { partner: true, partnerSince: application.user.partnerSince ?? new Date() } })]
      : []),
  ]);
  await audit(admin.id, accepted ? "partner.accept" : "partner.refuse", "user", application.userId, { application: id, name: application.name });
  return NextResponse.json({ ok: true });
}
