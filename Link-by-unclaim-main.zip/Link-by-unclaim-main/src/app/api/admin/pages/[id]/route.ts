import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { audit, isResponse, requireAdminApi } from "@/lib/server/admin";
import { prisma } from "@/lib/server/db";
import { jsonError, readJson } from "@/lib/server/http";
import { deletePage } from "@/lib/server/pages";

const patchSchema = z.object({
  /** null : rétablir la page. */
  suspend: z.object({ reason: z.string().trim().max(280) }).nullable().optional(),
  featured: z.boolean().optional(),
});

// Modération d'une page : suspension, mise en avant.
export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdminApi(request);
  if (isResponse(admin)) return admin;
  const { id } = await params;

  const parsed = patchSchema.safeParse(await readJson(request, 4_000).catch(() => null));
  if (!parsed.success) return jsonError(400, "Données invalides.");
  if (!(await prisma.page.findUnique({ where: { id }, select: { id: true } }))) return jsonError(404, "Page introuvable.");

  const { suspend, featured } = parsed.data;
  const page = await prisma.page.update({
    where: { id },
    data: {
      ...(suspend !== undefined ? { status: suspend ? "suspended" : "active", statusReason: suspend?.reason ?? "" } : {}),
      ...(featured !== undefined ? { featured } : {}),
    },
    select: { id: true, status: true, statusReason: true, featured: true },
  });
  if (suspend !== undefined) await audit(admin.id, suspend ? "page.suspend" : "page.restore", "page", id, suspend ?? {});
  if (featured !== undefined) await audit(admin.id, "page.feature", "page", id, { featured });
  return NextResponse.json({ page });
}

// Suppression définitive d'une page (blocs, statistiques, fichiers). Le compte reste.
export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdminApi(request);
  if (isResponse(admin)) return admin;
  const { id } = await params;
  const page = await prisma.page.findUnique({ where: { id }, select: { id: true, slug: true, userId: true } });
  if (!page) return jsonError(404, "Page introuvable.");

  await deletePage(id);
  await audit(admin.id, "page.delete", "page", id, { slug: page.slug });
  return NextResponse.json({ ok: true });
}
