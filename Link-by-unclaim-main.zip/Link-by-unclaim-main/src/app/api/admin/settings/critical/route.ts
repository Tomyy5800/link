import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { audit, isResponse, requireAdminApi } from "@/lib/server/admin";
import { jsonError, readJson } from "@/lib/server/http";
import { getSettings, saveSettings } from "@/lib/server/settings";
import { requireStaffPermission } from "@/lib/server/staff";

const schema = z.object({
  key: z.enum(["personalShops", "launchFreeAccess"]),
  value: z.boolean(),
  /** Confirmation explicite : le texte affiché à l'administrateur a été validé. */
  confirm: z.literal(true, { error: "Confirmation requise." }),
  reason: z.string().trim().max(280).default(""),
});

// Réglages sensibles (boutiques personnelles, accès offert) : permission « platform.critical »,
// confirmation obligatoire, et chaque changement est conservé dans le journal.
export async function PUT(request: NextRequest) {
  const admin = await requireAdminApi(request);
  if (isResponse(admin)) return admin;
  const denied = requireStaffPermission(admin, "platform.critical");
  if (denied) return denied;
  const parsed = schema.safeParse(await readJson(request, 2_000).catch(() => null));
  if (!parsed.success) return jsonError(400, parsed.error.issues[0]?.message ?? "Demande invalide.");
  const before = await getSettings();
  const { key, value, reason } = parsed.data;
  if (before[key] === value) return NextResponse.json({ settings: before });
  const settings = await saveSettings({ ...before, [key]: value });
  await audit(admin.id, "settings.critical", "settings", key, { from: before[key], to: value, reason });
  return NextResponse.json({ settings });
}
