import { NextResponse, type NextRequest } from "next/server";
import { audit, isResponse, requireAdminApi } from "@/lib/server/admin";
import { jsonError, readJson } from "@/lib/server/http";
import { CRITICAL_SETTINGS, getSettings, saveSettings, settingsSchema } from "@/lib/server/settings";

// Réglages de la plateforme : fonctionnalités (tous / Link+ / désactivé), limites, domaines bloqués…
export async function GET(request: NextRequest) {
  const admin = await requireAdminApi(request, { mutation: false });
  if (isResponse(admin)) return admin;
  return NextResponse.json({ settings: await getSettings() });
}

export async function PUT(request: NextRequest) {
  const admin = await requireAdminApi(request);
  if (isResponse(admin)) return admin;

  // Chaque écran envoie sa partie des réglages : on la fusionne avec les réglages actuels.
  const body = await readJson(request, 64_000).catch(() => null);
  if (!body || typeof body !== "object" || Array.isArray(body)) return jsonError(400, "Réglages invalides.");
  const before = await getSettings();
  // Les réglages sensibles ont leur propre route (permission, confirmation, historique) : ignorés ici.
  const patch = Object.fromEntries(Object.entries(body).filter(([k]) => !(CRITICAL_SETTINGS as readonly string[]).includes(k)));
  const parsed = settingsSchema.safeParse({ ...before, ...patch });
  if (!parsed.success) {
    const issue = parsed.error.issues[0];
    return jsonError(400, issue ? `${issue.message}${issue.path.length ? ` (${issue.path.join(".")})` : ""}` : "Réglages invalides.");
  }
  const settings = await saveSettings(parsed.data);

  // Le journal garde seulement ce qui a changé.
  const changed = (Object.keys(settings) as (keyof typeof settings)[]).filter((k) => JSON.stringify(settings[k]) !== JSON.stringify(before[k]));
  if (changed.length) await audit(admin.id, "settings.update", "settings", "platform", { changed });
  return NextResponse.json({ settings });
}
