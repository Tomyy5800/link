import { NextResponse, type NextRequest } from "next/server";
import { audit, isResponse, requireAdminApi } from "@/lib/server/admin";
import { prisma } from "@/lib/server/db";

// Vide le cache des API externes (par exemple après le branchement de la clé NationsGlory).
// DELETE /api/admin/cache?prefix=ng:
export async function DELETE(request: NextRequest) {
  const admin = await requireAdminApi(request);
  if (isResponse(admin)) return admin;
  const prefix = (request.nextUrl.searchParams.get("prefix") ?? "").slice(0, 32);
  const { count } = await prisma.cacheEntry.deleteMany({ where: prefix ? { key: { startsWith: prefix } } : {} });
  await audit(admin.id, "cache.clear", "cache", prefix || "*", { count });
  return NextResponse.json({ cleared: count });
}
