import { NextResponse, type NextRequest } from "next/server";
import { badgeInputSchema } from "@/lib/badges";
import { isResponse, requireAdminApi } from "@/lib/server/admin";
import { badgeManageError, ensureSystemBadges, logBadge } from "@/lib/server/badges";
import { prisma } from "@/lib/server/db";
import { jsonError, readJson } from "@/lib/server/http";
import { isFounderLevel } from "@/lib/server/staff";

// Badges officiels : liste et création (administrateurs ; badges du staff et réservés selon les permissions).
export async function GET(request: NextRequest) {
  const admin = await requireAdminApi(request, { mutation: false });
  if (isResponse(admin)) return admin;
  await ensureSystemBadges();
  const badges = await prisma.badge.findMany({ orderBy: [{ position: "asc" }, { createdAt: "asc" }], include: { _count: { select: { holders: true } } } });
  return NextResponse.json({ badges });
}

export async function POST(request: NextRequest) {
  const admin = await requireAdminApi(request);
  if (isResponse(admin)) return admin;
  const parsed = badgeInputSchema.safeParse(await readJson(request, 8_000).catch(() => null));
  if (!parsed.success) return jsonError(400, parsed.error.issues[0]?.message ?? "Badge invalide.");
  const input = parsed.data;
  const denied = badgeManageError(admin, input);
  if (denied) return jsonError(403, denied);
  // La règle « Fondateur » ne dépend que de la configuration du serveur : un seul badge, intégré.
  if (input.rule.type === "founder" && !isFounderLevel(admin)) return jsonError(403, "Réservé aux fondateurs.");
  try {
    const badge = await prisma.badge.create({
      data: { ...input, rule: JSON.stringify(input.rule), validated: false },
    });
    await logBadge(prisma, admin.id, "badge.create", badge.id, { key: badge.key, name: badge.name });
    return NextResponse.json({ badge }, { status: 201 });
  } catch {
    return jsonError(409, "Un badge utilise déjà cet identifiant.");
  }
}
