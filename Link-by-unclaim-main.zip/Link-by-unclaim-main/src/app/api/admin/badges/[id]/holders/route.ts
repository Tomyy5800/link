import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { acceptsManualGrant, parseBadgeRule } from "@/lib/badges";
import { isResponse, requireAdminApi } from "@/lib/server/admin";
import { badgeManageError, grantBadge, revokeBadge } from "@/lib/server/badges";
import { prisma } from "@/lib/server/db";
import { jsonError, readJson } from "@/lib/server/http";

type Ctx = { params: Promise<{ id: string }> };

const grantSchema = z.object({
  userId: z.string().regex(/^[a-z0-9]{8,40}$/i),
  /** Date de fin (ISO) ; null : selon la durée du badge (ou permanent). */
  expiresAt: z.string().max(40).nullable().optional(),
  note: z.string().trim().max(140).default(""),
});

async function load(request: NextRequest, params: Ctx["params"]) {
  const admin = await requireAdminApi(request);
  if (isResponse(admin)) return admin;
  const badge = await prisma.badge.findUnique({ where: { id: (await params).id } });
  if (!badge) return jsonError(404, "Badge introuvable.");
  const denied = badgeManageError(admin, badge);
  if (denied) return jsonError(403, denied);
  return { admin, badge };
}

// Attribuer un badge à un compte (règle manuelle uniquement ; les badges calculés suivent leur condition).
export async function POST(request: NextRequest, { params }: Ctx) {
  const ctx = await load(request, params);
  if (isResponse(ctx)) return ctx;
  const { admin, badge } = ctx;
  if (!acceptsManualGrant(parseBadgeRule(badge.rule))) return jsonError(400, "Ce badge est attribué automatiquement selon sa règle.");
  if (!badge.active || badge.archivedAt) return jsonError(400, "Réactive ce badge avant de l'attribuer.");
  const parsed = grantSchema.safeParse(await readJson(request, 2_000).catch(() => null));
  if (!parsed.success) return jsonError(400, "Demande invalide.");
  const user = await prisma.user.findUnique({ where: { id: parsed.data.userId }, select: { id: true, deletedAt: true } });
  if (!user || user.deletedAt) return jsonError(404, "Compte introuvable.");
  let expiresAt: Date | null | undefined;
  if (parsed.data.expiresAt) {
    expiresAt = new Date(parsed.data.expiresAt);
    if (Number.isNaN(expiresAt.getTime()) || expiresAt.getTime() <= Date.now()) return jsonError(400, "La date de fin doit être dans le futur.");
  }
  const grant = await grantBadge(prisma, { badge, userId: user.id, actorId: admin.id, source: "manual", expiresAt, note: parsed.data.note });
  return NextResponse.json({ grant }, { status: 201 });
}

export async function DELETE(request: NextRequest, { params }: Ctx) {
  const ctx = await load(request, params);
  if (isResponse(ctx)) return ctx;
  const userId = request.nextUrl.searchParams.get("userId") ?? "";
  if (!/^[a-z0-9]{8,40}$/i.test(userId)) return jsonError(400, "Compte manquant.");
  const removed = await revokeBadge(prisma, { badge: ctx.badge, userId, actorId: ctx.admin.id, reason: request.nextUrl.searchParams.get("reason")?.slice(0, 140) ?? "" });
  return removed ? NextResponse.json({ ok: true }) : jsonError(404, "Ce compte n'a pas ce badge (ou il est calculé automatiquement).");
}
