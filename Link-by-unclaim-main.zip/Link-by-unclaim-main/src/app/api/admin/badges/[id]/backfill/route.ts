import { NextResponse, type NextRequest } from "next/server";
import { parseBadgeRule } from "@/lib/badges";
import { isResponse, requireAdminApi } from "@/lib/server/admin";
import { backfillEarly, badgeManageError, logBadge } from "@/lib/server/badges";
import { prisma } from "@/lib/server/db";
import { jsonError } from "@/lib/server/http";

// Règle « premiers comptes » : distribue maintenant les places restantes aux comptes éligibles les plus anciens.
export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdminApi(request);
  if (isResponse(admin)) return admin;
  const badge = await prisma.badge.findUnique({ where: { id: (await params).id } });
  if (!badge) return jsonError(404, "Badge introuvable.");
  const denied = badgeManageError(admin, badge);
  if (denied) return jsonError(403, denied);
  if (parseBadgeRule(badge.rule).type !== "early") return jsonError(400, "Ce badge n'utilise pas la règle « premiers comptes ».");
  const given = await backfillEarly(badge, 1000);
  await logBadge(prisma, admin.id, "badge.backfill", badge.id, { given });
  return NextResponse.json({ given });
}
