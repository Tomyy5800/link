import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { badgeInputSchema, parseBadgeRule } from "@/lib/badges";
import { isResponse, requireAdminApi } from "@/lib/server/admin";
import { badgeManageError, logBadge } from "@/lib/server/badges";
import { prisma } from "@/lib/server/db";
import { jsonError, readJson } from "@/lib/server/http";
import { hasStaffPermission, requireStaffPermission } from "@/lib/server/staff";

type Ctx = { params: Promise<{ id: string }> };

const actionSchema = z.discriminatedUnion("action", [
  z.object({ action: z.literal("update"), badge: badgeInputSchema }),
  /** Sceau officiel : permission « badges.validate ». */
  z.object({ action: z.literal("validate"), validated: z.boolean() }),
  z.object({ action: z.literal("archive") }),
  z.object({ action: z.literal("restore") }),
]);

/** Champs qui font l'identité d'un badge : les modifier retire le sceau, sauf à l'administrateur qui peut le reposer. */
const IDENTITY = ["name", "description", "icon", "imageUrl", "color"] as const;

export async function PATCH(request: NextRequest, { params }: Ctx) {
  const admin = await requireAdminApi(request);
  if (isResponse(admin)) return admin;
  const badge = await prisma.badge.findUnique({ where: { id: (await params).id } });
  if (!badge) return jsonError(404, "Badge introuvable.");
  const denied = badgeManageError(admin, badge);
  if (denied) return jsonError(403, denied);
  const parsed = actionSchema.safeParse(await readJson(request, 8_000).catch(() => null));
  if (!parsed.success) return jsonError(400, parsed.error.issues[0]?.message ?? "Demande invalide.");
  const body = parsed.data;

  if (body.action === "validate") {
    const blocked = requireStaffPermission(admin, "badges.validate");
    if (blocked) return blocked;
    const updated = await prisma.badge.update({
      where: { id: badge.id },
      data: body.validated ? { validated: true, validatedAt: new Date(), validatedById: admin.id } : { validated: false, validatedAt: null, validatedById: null },
    });
    await logBadge(prisma, admin.id, body.validated ? "badge.validate" : "badge.unvalidate", badge.id, {});
    return NextResponse.json({ badge: updated });
  }

  if (body.action === "archive" || body.action === "restore") {
    if (badge.system && body.action === "archive") return jsonError(400, "Un badge intégré ne s'archive pas : désactive-le plutôt.");
    const updated = await prisma.badge.update({ where: { id: badge.id }, data: { archivedAt: body.action === "archive" ? new Date() : null, active: body.action === "restore" ? badge.active : false } });
    await logBadge(prisma, admin.id, body.action === "archive" ? "badge.archive" : "badge.restore", badge.id, {});
    return NextResponse.json({ badge: updated });
  }

  const input = body.badge;
  // Nouvelles valeurs : mêmes règles d'accès que la création (on ne peut pas « promouvoir » un badge au-delà de ses droits).
  const deniedNext = badgeManageError(admin, input);
  if (deniedNext) return jsonError(403, deniedNext);
  const before = parseBadgeRule(badge.rule);
  if (badge.system) {
    // Badges intégrés : identifiant et type de règle fixes (la règle « Fondateur » reste liée à la configuration).
    if (input.key !== badge.key) return jsonError(400, "L'identifiant d'un badge intégré ne change pas.");
    if (input.rule.type !== before.type) return jsonError(400, "Le type de règle d'un badge intégré ne change pas (seuls ses réglages).");
  } else if (input.rule.type === "founder") {
    return jsonError(400, "La règle « Fondateur » est réservée au badge intégré.");
  }
  const identityChanged = IDENTITY.some((k) => input[k] !== badge[k]);
  const keepSeal = badge.validated && (!identityChanged || hasStaffPermission(admin, "badges.validate"));
  try {
    const updated = await prisma.badge.update({
      where: { id: badge.id },
      data: {
        ...input,
        rule: JSON.stringify(input.rule),
        ...(keepSeal ? {} : { validated: false, validatedAt: null, validatedById: null }),
      },
    });
    const changed = Object.keys(input).filter((k) => JSON.stringify((input as Record<string, unknown>)[k]) !== JSON.stringify(k === "rule" ? before : (badge as Record<string, unknown>)[k]));
    await logBadge(prisma, admin.id, "badge.update", badge.id, { changed, sealRemoved: badge.validated && !keepSeal });
    return NextResponse.json({ badge: updated, sealRemoved: badge.validated && !keepSeal });
  } catch {
    return jsonError(409, "Un badge utilise déjà cet identifiant.");
  }
}

/** Supprime un badge jamais attribué ; sinon il est archivé (historique conservé). */
export async function DELETE(request: NextRequest, { params }: Ctx) {
  const admin = await requireAdminApi(request);
  if (isResponse(admin)) return admin;
  const badge = await prisma.badge.findUnique({ where: { id: (await params).id } });
  if (!badge) return jsonError(404, "Badge introuvable.");
  const denied = badgeManageError(admin, badge);
  if (denied) return jsonError(403, denied);
  if (badge.system) return jsonError(400, "Un badge intégré ne peut pas être supprimé : désactive-le plutôt.");
  const [holders, granted, linked] = await Promise.all([
    prisma.userBadge.count({ where: { badgeId: badge.id, source: { not: "pref" } } }),
    prisma.auditLog.count({ where: { targetType: "badge", targetId: badge.id, action: { in: ["badge.grant", "badge.auto"] } } }),
    prisma.shopItem.count({ where: { reward: { contains: `"badgeKey":"${badge.key}"` } } }),
  ]);
  if (holders > 0 || granted > 0 || linked > 0) {
    await prisma.badge.update({ where: { id: badge.id }, data: { archivedAt: new Date(), active: false } });
    await logBadge(prisma, admin.id, "badge.archive", badge.id, { reason: "suppression demandée, badge déjà attribué" });
    return NextResponse.json({ archived: true });
  }
  await prisma.badge.delete({ where: { id: badge.id } });
  await logBadge(prisma, admin.id, "badge.delete", badge.id, { key: badge.key, name: badge.name });
  return NextResponse.json({ deleted: true });
}
