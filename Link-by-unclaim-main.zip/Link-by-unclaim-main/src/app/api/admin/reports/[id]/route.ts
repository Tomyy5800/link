import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { audit, isResponse, requireAdminApi } from "@/lib/server/admin";
import { prisma } from "@/lib/server/db";
import { jsonError, readJson } from "@/lib/server/http";

const patchSchema = z.object({
  status: z.enum(["open", "resolved", "dismissed"]),
  /** Suspendre la page signalée en même temps (motif affiché à son propriétaire). */
  suspendPage: z.object({ reason: z.string().trim().max(280) }).optional(),
});

// Traitement d'un signalement.
export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdminApi(request);
  if (isResponse(admin)) return admin;
  const { id } = await params;

  const parsed = patchSchema.safeParse(await readJson(request, 4_000).catch(() => null));
  if (!parsed.success) return jsonError(400, "Données invalides.");
  const report = await prisma.report.findUnique({ where: { id }, select: { id: true, pageId: true } });
  if (!report) return jsonError(404, "Signalement introuvable.");

  const { status, suspendPage } = parsed.data;
  await prisma.report.update({
    where: { id },
    data: { status, handledById: status === "open" ? null : admin.id, handledAt: status === "open" ? null : new Date() },
  });
  if (suspendPage) {
    await prisma.page.update({ where: { id: report.pageId }, data: { status: "suspended", statusReason: suspendPage.reason } });
    // Les autres signalements ouverts de la même page sont traités du même coup.
    await prisma.report.updateMany({
      where: { pageId: report.pageId, status: "open" },
      data: { status: "resolved", handledById: admin.id, handledAt: new Date() },
    });
    await audit(admin.id, "page.suspend", "page", report.pageId, { reason: suspendPage.reason, report: id });
  }
  if (status !== "open") await audit(admin.id, status === "resolved" ? "report.resolve" : "report.dismiss", "report", id);
  return NextResponse.json({ ok: true });
}
