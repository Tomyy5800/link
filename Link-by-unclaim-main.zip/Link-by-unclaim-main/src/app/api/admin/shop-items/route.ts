import { NextResponse, type NextRequest } from "next/server";
import { shopItemInputSchema } from "@/lib/official-shop";
import { audit, isResponse, requireAdminApi } from "@/lib/server/admin";
import { prisma } from "@/lib/server/db";
import { jsonError, readJson } from "@/lib/server/http";
import { rewardError } from "@/lib/server/official-shop";
import { requireStaffPermission } from "@/lib/server/staff";

// Articles de la boutique officielle (permission « Réglages sensibles »).
export async function GET(request: NextRequest) {
  const admin = await requireAdminApi(request, { mutation: false });
  if (isResponse(admin)) return admin;
  return NextResponse.json({ items: await prisma.shopItem.findMany({ orderBy: [{ position: "asc" }, { createdAt: "asc" }] }) });
}

export async function POST(request: NextRequest) {
  const admin = await requireAdminApi(request);
  if (isResponse(admin)) return admin;
  const denied = requireStaffPermission(admin, "platform.critical");
  if (denied) return denied;
  const parsed = shopItemInputSchema.safeParse(await readJson(request, 8_000).catch(() => null));
  if (!parsed.success) return jsonError(400, parsed.error.issues[0]?.message ?? "Article invalide.");
  const invalid = await rewardError(parsed.data);
  if (invalid) return jsonError(400, invalid);
  try {
    const item = await prisma.shopItem.create({ data: { ...parsed.data, perks: JSON.stringify(parsed.data.perks), reward: JSON.stringify(parsed.data.reward) } });
    await audit(admin.id, "shop.create", "shopItem", item.id, { slug: item.slug, priceCents: item.priceCents });
    return NextResponse.json({ item }, { status: 201 });
  } catch {
    return jsonError(409, "Un article utilise déjà cet identifiant.");
  }
}
