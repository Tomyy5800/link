import { NextResponse, type NextRequest } from "next/server";
import { shopItemInputSchema } from "@/lib/official-shop";
import { audit, isResponse, requireAdminApi } from "@/lib/server/admin";
import { prisma } from "@/lib/server/db";
import { jsonError, readJson } from "@/lib/server/http";
import { rewardError } from "@/lib/server/official-shop";
import { requireStaffPermission } from "@/lib/server/staff";

type Ctx = { params: Promise<{ id: string }> };

async function load(request: NextRequest, params: Ctx["params"]) {
  const admin = await requireAdminApi(request);
  if (isResponse(admin)) return admin;
  const denied = requireStaffPermission(admin, "platform.critical");
  if (denied) return denied;
  const item = await prisma.shopItem.findUnique({ where: { id: (await params).id } });
  if (!item) return jsonError(404, "Article introuvable.");
  return { admin, item };
}

export async function PATCH(request: NextRequest, { params }: Ctx) {
  const ctx = await load(request, params);
  if (isResponse(ctx)) return ctx;
  const parsed = shopItemInputSchema.safeParse(await readJson(request, 8_000).catch(() => null));
  if (!parsed.success) return jsonError(400, parsed.error.issues[0]?.message ?? "Article invalide.");
  const invalid = await rewardError(parsed.data);
  if (invalid) return jsonError(400, invalid);
  // La récompense d'un article déjà vendu ne change pas : les acheteurs gardent ce qu'ils ont payé.
  const sold = await prisma.order.count({ where: { kind: "item", itemId: ctx.item.id, status: "paid" } });
  if (sold > 0 && JSON.stringify(parsed.data.reward) !== JSON.stringify(JSON.parse(ctx.item.reward))) {
    return jsonError(400, "Cet article a déjà été vendu : crée un nouvel article pour une autre récompense.");
  }
  try {
    const item = await prisma.shopItem.update({
      where: { id: ctx.item.id },
      data: { ...parsed.data, perks: JSON.stringify(parsed.data.perks), reward: JSON.stringify(parsed.data.reward) },
    });
    await audit(ctx.admin.id, "shop.update", "shopItem", item.id, { slug: item.slug, priceCents: item.priceCents, active: item.active });
    return NextResponse.json({ item });
  } catch {
    return jsonError(409, "Un article utilise déjà cet identifiant.");
  }
}

/** Supprime un article jamais acheté ; sinon il est seulement retiré de la vente. */
export async function DELETE(request: NextRequest, { params }: Ctx) {
  const ctx = await load(request, params);
  if (isResponse(ctx)) return ctx;
  const orders = await prisma.order.count({ where: { kind: "item", itemId: ctx.item.id } });
  if (orders > 0) {
    await prisma.shopItem.update({ where: { id: ctx.item.id }, data: { active: false } });
    await audit(ctx.admin.id, "shop.disable", "shopItem", ctx.item.id, { reason: "suppression demandée, article déjà commandé" });
    return NextResponse.json({ disabled: true });
  }
  await prisma.shopItem.delete({ where: { id: ctx.item.id } });
  await audit(ctx.admin.id, "shop.delete", "shopItem", ctx.item.id, { slug: ctx.item.slug });
  return NextResponse.json({ deleted: true });
}
