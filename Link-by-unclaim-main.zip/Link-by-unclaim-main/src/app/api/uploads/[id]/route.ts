import { readUpload } from "@/lib/server/storage";

const ALLOWED = new Set([
  "image/png",
  "image/jpeg",
  "image/gif",
  "image/webp",
  "audio/mpeg",
  "audio/ogg",
  "audio/wav",
  "audio/mp4",
  "video/mp4",
  "video/webm",
]);

const baseHeaders = (mimeType: string) => ({
  "Content-Type": mimeType,
  "Cache-Control": "public, max-age=31536000, immutable",
  "X-Content-Type-Options": "nosniff",
  "Content-Security-Policy": "default-src 'none'; img-src 'self'; media-src 'self'; style-src 'unsafe-inline'",
  "Accept-Ranges": "bytes",
});

// Sert un fichier importé. Les identifiants sont immuables : cache long.
// Les requêtes partielles (Range) permettent l'avance rapide dans l'audio et la vidéo.
export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!/^[a-z0-9]{10,40}$/i.test(id)) return new Response("Introuvable.", { status: 404 });

  const file = await readUpload(id);
  if (!file || !ALLOWED.has(file.mimeType)) return new Response("Introuvable.", { status: 404 });

  const total = file.bytes.byteLength;
  const range = /^bytes=(\d*)-(\d*)$/.exec(request.headers.get("range") ?? "");
  if (range && (range[1] || range[2])) {
    let start = range[1] ? Number(range[1]) : Math.max(0, total - Number(range[2]));
    let end = range[1] && range[2] ? Number(range[2]) : total - 1;
    end = Math.min(end, total - 1);
    if (start > end || start >= total) {
      return new Response(null, { status: 416, headers: { "Content-Range": `bytes */${total}` } });
    }
    start = Math.max(0, start);
    return new Response(new Blob([file.bytes.slice(start, end + 1)], { type: file.mimeType }), {
      status: 206,
      headers: { ...baseHeaders(file.mimeType), "Content-Range": `bytes ${start}-${end}/${total}`, "Content-Length": String(end - start + 1) },
    });
  }

  return new Response(new Blob([file.bytes], { type: file.mimeType }), {
    headers: { ...baseHeaders(file.mimeType), "Content-Length": String(total) },
  });
}
