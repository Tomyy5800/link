import { NextResponse, type NextRequest } from "next/server";
import { prisma } from "@/lib/server/db";
import { entitlementsFrom, suspension } from "@/lib/server/entitlements";
import { guardMutation, guardRate, jsonError } from "@/lib/server/http";
import { getSettings } from "@/lib/server/settings";
import { saveUpload } from "@/lib/server/storage";
import { sniffMedia } from "@/lib/media";
import { getCurrentUser } from "@/lib/server/unclaim-auth";

// Import de fichier : image (avatar, bannière, fond, blocs), audio ou vidéo de fond (selon l'offre).
// Servi ensuite par /api/uploads/<id>.
export async function POST(request: NextRequest) {
  const blocked = guardMutation(request) ?? guardRate(request, "upload", 12);
  if (blocked) return blocked;
  const user = await getCurrentUser();
  if (!user) return jsonError(401, "Connexion requise.");
  if (suspension(user)) return jsonError(403, "Ton compte est suspendu.");

  const settings = await getSettings();
  const rights = entitlementsFrom(user, settings);
  const mediaAllowed = rights.features.backgroundMedia && rights.limits.mediaMb > 0;
  const maxMb = Math.max(rights.limits.imageMb, mediaAllowed ? rights.limits.mediaMb : 0);

  const length = Number(request.headers.get("content-length") ?? 0);
  if (length > maxMb * 1024 * 1024 + 64_000) return jsonError(413, `Fichier trop lourd (${maxMb} Mo maximum).`);

  let file: File | null = null;
  try {
    const form = await request.formData();
    const entry = form.get("file");
    file = entry instanceof File ? entry : null;
  } catch {
    return jsonError(400, "Formulaire invalide.");
  }
  if (!file) return jsonError(400, "Aucun fichier reçu.");

  const bytes = new Uint8Array(await file.arrayBuffer());
  const media = sniffMedia(bytes);
  if (!media) return jsonError(415, "Format non pris en charge (PNG, JPEG, GIF, WebP, MP3, OGG, WAV, M4A, MP4 ou WebM).");

  if (media.kind !== "image" && !mediaAllowed) {
    return jsonError(403, `L'import d'audio et de vidéo est réservé à ${settings.premiumName}.`);
  }
  const limitMb = media.kind === "image" ? rights.limits.imageMb : rights.limits.mediaMb;
  if (bytes.byteLength > limitMb * 1024 * 1024) {
    return jsonError(413, `${media.kind === "image" ? "Image" : "Fichier"} trop lourd (${limitMb} Mo maximum).`);
  }

  const count = await prisma.upload.count({ where: { userId: user.id } });
  if (count >= rights.limits.uploads) {
    return jsonError(409, "Limite de fichiers atteinte. Retire des fichiers inutilisés de ta page puis réessaie dans une heure.");
  }

  const id = await saveUpload({ userId: user.id, kind: media.kind, mimeType: media.mimeType, bytes });
  return NextResponse.json({ url: `/api/uploads/${id}`, kind: media.kind }, { status: 201 });
}
