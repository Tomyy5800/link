import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/server/db";
import { suspension } from "@/lib/server/entitlements";
import { guardMutation, guardRate, jsonError, readJson } from "@/lib/server/http";
import { PaymentError, changeSubscription, createItemCheckout, createSubscriptionCheckout, currentSubscription, subscriptionGivesAccess } from "@/lib/server/payments";
import { getSettings } from "@/lib/server/settings";
import { getCurrentUser } from "@/lib/server/unclaim-auth";

const checkoutSchema = z.discriminatedUnion("kind", [
  /** Abonnement à une formule (nouveau, ou changement de l'abonnement en cours). */
  z.object({
    kind: z.literal("subscription"),
    offerId: z.string().max(24),
    /** Case cochée : CGV acceptées, accès immédiat demandé, renonciation au droit de rétractation. */
    acceptTerms: z.literal(true, { error: "Coche la case d'acceptation pour continuer." }),
  }),
  /** Article de la boutique officielle. */
  z.object({
    kind: z.literal("item"),
    itemId: z.string().regex(/^[a-z0-9]{8,40}$/i),
    acceptTerms: z.literal(true, { error: "Coche la case d'acceptation pour continuer." }),
  }),
]);

// Démarre un paiement : renvoie l'adresse de la page de paiement Stripe (ou applique directement
// un changement de formule sur l'abonnement en cours). Prix et droits sont lus côté serveur :
// rien de ce que le navigateur envoie n'est cru, à part l'identifiant de l'offre choisie.
export async function POST(request: NextRequest) {
  const blocked = guardMutation(request) ?? guardRate(request, "checkout", 10, 10 * 60_000);
  if (blocked) return blocked;
  const user = await getCurrentUser();
  if (!user) return jsonError(401, "Connecte-toi pour continuer.");
  if (suspension(user)) return jsonError(403, "Ton compte est suspendu.");

  const raw = (await readJson(request, 2_000).catch(() => null)) as Record<string, unknown> | null;
  const parsed = checkoutSchema.safeParse(raw && !raw.kind ? { ...raw, kind: "subscription" } : raw);
  if (!parsed.success) return jsonError(400, parsed.error.issues[0]?.message ?? "Demande invalide.");
  const settings = await getSettings();

  try {
    if (parsed.data.kind === "item") {
      const item = await prisma.shopItem.findUnique({ where: { id: parsed.data.itemId } });
      if (!item || !item.active) return jsonError(404, "Cet article n'est plus disponible.");
      const { url } = await createItemCheckout({ user, item });
      return NextResponse.json({ url });
    }

    const offerId = parsed.data.offerId;
    const offer = settings.offers.find((o) => o.id === offerId && o.active);
    if (!offer) return jsonError(404, "Cette offre n'est plus disponible.");
    const current = await currentSubscription(user.id);
    if (current && subscriptionGivesAccess(current)) {
      await changeSubscription({ userId: user.id, offer, premiumName: settings.premiumName });
      return NextResponse.json({ changed: true });
    }
    const { url } = await createSubscriptionCheckout({ user, offer, premiumName: settings.premiumName });
    return NextResponse.json({ url });
  } catch (error) {
    if (error instanceof PaymentError) return jsonError(error.status, error.message);
    console.error("[paiement] échec de création", error);
    return jsonError(500, "Le paiement n'a pas pu être préparé.");
  }
}
