import { NextResponse, type NextRequest } from "next/server";
import { normalizeHostname } from "@/lib/domains";
import { probeSignature } from "@/lib/server/domains";

// Sonde des domaines personnels : prouve qu'une requête https://<domaine>/… arrive bien sur cette
// application (la signature dépend du secret du serveur et de l'hôte demandé).
export function GET(request: NextRequest) {
  const host = normalizeHostname(request.headers.get("x-forwarded-host") ?? request.headers.get("host") ?? "");
  return NextResponse.json({ service: "link-by-unclaim", signature: host ? probeSignature(host) : null }, { headers: { "Cache-Control": "no-store" } });
}
