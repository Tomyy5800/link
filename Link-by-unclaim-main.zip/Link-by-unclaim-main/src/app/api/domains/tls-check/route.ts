import { NextResponse, type NextRequest } from "next/server";
import { guardRate } from "@/lib/server/http";
import { tlsAllowed } from "@/lib/server/domains";

// Question du proxy inverse avant d'émettre un certificat (Caddy : on_demand_tls { ask … }).
// 200 : le propriétaire a prouvé la propriété du domaine · 404 : refusé.
export async function GET(request: NextRequest) {
  const limited = guardRate(request, "tls-check", 120);
  if (limited) return limited;
  const domain = request.nextUrl.searchParams.get("domain") ?? "";
  return (await tlsAllowed(domain)) ? new NextResponse("ok", { status: 200 }) : new NextResponse("unknown domain", { status: 404 });
}
