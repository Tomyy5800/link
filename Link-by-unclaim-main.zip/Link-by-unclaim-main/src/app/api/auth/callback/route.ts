import { after, NextResponse, type NextRequest } from "next/server";
import { evaluateEarlyBadges } from "@/lib/server/badges";
import { syncDiscordUser } from "@/lib/server/discord-sync";
import { env } from "@/lib/server/env";
import { rateLimit } from "@/lib/server/rate-limit";
import { clientIp, safeEqual } from "@/lib/server/security";
import { clearOAuthState, readOAuthState, startSession, upsertUnclaimUser } from "@/lib/server/unclaim-auth";
import { UnclaimError, exchangeCode, verifyAccessToken } from "@/lib/server/unclaim-auth/client";

/** Erreurs renvoyées par la passerelle sur notre redirect_uri → codes affichés par /login. */
const GATEWAY_ERRORS: Record<string, string> = {
  access_denied: "denied",
  account_banned: "banned",
  bot_account_refused: "bot",
  provider_error: "provider",
  provider_not_allowed: "provider_unavailable",
};

// Unclaim Auth · étape 2 : retour de la passerelle, vérification du state, échange du code.
export async function GET(request: NextRequest) {
  const params = request.nextUrl.searchParams;
  const fail = (code: string) => {
    const url = new URL("/login", env.appUrl);
    url.searchParams.set("error", code);
    const response = NextResponse.redirect(url);
    clearOAuthState(response);
    return response;
  };

  if (!rateLimit(`auth-callback:${clientIp(request.headers)}`, 20, 60_000).ok) return fail("rate_limited");

  const error = params.get("error");
  if (error) return fail(GATEWAY_ERRORS[error] ?? "oauth");

  const code = params.get("unclaim_code");
  const state = params.get("state");
  const saved = await readOAuthState();
  if (!code || !state || !saved || !safeEqual(state, saved.state)) return fail("state");

  try {
    const session = await exchangeCode(code, saved.verifier);

    // Défense en profondeur : le jeton doit être signé par la passerelle, nous être destiné
    // et désigner le même compte que la réponse.
    const payload = await verifyAccessToken(session.unclaim_token);
    if (!payload || payload.sub !== session.unclaim_id || session.user?.unclaim_id !== session.unclaim_id) {
      console.error("[unclaim-auth] jeton refusé à la vérification");
      return fail("oauth");
    }
    if (session.user.banned) return fail("banned");

    const user = await upsertUnclaimUser(session.user);
    // Après la réponse : badges « premiers comptes » et rôles du serveur Discord officiel.
    after(async () => {
      await evaluateEarlyBadges(user.id).catch(() => undefined);
      await syncDiscordUser(user).catch(() => undefined);
    });
    const response = NextResponse.redirect(new URL(saved.next, env.appUrl));
    clearOAuthState(response);
    await startSession(response, user.id, request.headers.get("user-agent"));
    return response;
  } catch (err) {
    if (err instanceof UnclaimError) {
      console.error(`[unclaim-auth] échange refusé : ${err.status} ${err.code ?? ""} ${err.message}`);
      if (err.code === "account_banned") return fail("banned");
      if (err.status >= 500) return fail("unavailable");
      return fail("oauth");
    }
    console.error("[unclaim-auth] échec du retour de connexion", err);
    return fail("oauth");
  }
}
