import { NextResponse, type NextRequest } from "next/server";
import { env } from "@/lib/server/env";
import { rateLimit } from "@/lib/server/rate-limit";
import { clientIp, safeNextPath } from "@/lib/server/security";
import { setOAuthState } from "@/lib/server/unclaim-auth";
import { PROVIDER_ID, availableProviders, startLogin } from "@/lib/server/unclaim-auth/client";

// Unclaim Auth · étape 1 : redirection directe vers le fournisseur choisi, via la passerelle
// (state + PKCE S256). Sans fournisseur précisé : s'il n'y en a qu'un, on y va directement ;
// sinon /login affiche le choix.
export async function GET(request: NextRequest) {
  const loginUrl = new URL("/login", env.appUrl);
  const next = safeNextPath(request.nextUrl.searchParams.get("next"));
  if (next !== "/dashboard") loginUrl.searchParams.set("next", next);

  if (!rateLimit(`auth-login:${clientIp(request.headers)}`, 20, 60_000).ok) {
    loginUrl.searchParams.set("error", "rate_limited");
    return NextResponse.redirect(loginUrl);
  }
  if (!env.unclaim.configured) {
    loginUrl.searchParams.set("error", "not_configured");
    return NextResponse.redirect(loginUrl);
  }

  const providers = await availableProviders();
  const asked = request.nextUrl.searchParams.get("provider") ?? "";
  let provider: string | null = null;
  if (asked && PROVIDER_ID.test(asked)) provider = providers.includes(asked) ? asked : null;
  else if (providers.length === 1) provider = providers[0];

  if (!provider) {
    if (asked) loginUrl.searchParams.set("error", "provider_unavailable");
    return NextResponse.redirect(loginUrl);
  }

  const { url, state, codeVerifier } = startLogin(provider);
  const response = NextResponse.redirect(url);
  setOAuthState(response, { state, verifier: codeVerifier, next });
  return response;
}
