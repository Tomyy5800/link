import { after, NextResponse, type NextRequest } from "next/server";
import { evaluateEarlyBadges } from "@/lib/server/badges";
import { env } from "@/lib/server/env";
import { guardMutation } from "@/lib/server/http";
import { startSession, upsertUnclaimUser } from "@/lib/server/unclaim-auth";

// Connexion de démonstration, pour développer sans passerelle Unclaim Auth.
// Désactivée en production et tant que UNCLAIM_AUTH_DEV_LOGIN n'est pas à "true".
export async function POST(request: NextRequest) {
  if (!env.devLoginEnabled) return NextResponse.json({ error: "Indisponible." }, { status: 404 });
  const blocked = guardMutation(request);
  if (blocked) return blocked;

  const user = await upsertUnclaimUser({
    unclaim_id: "uncl_DEMO0000000000000000000000",
    discord_id: "100000000000000001",
    username: "demo.unclaim",
    global_name: "Démo Unclaim",
    display_name: "Démo Unclaim",
    avatar: null,
    banner: null,
    accent_color: 0x22c9e8,
    banned: false,
  });
  after(() => evaluateEarlyBadges(user.id).catch(() => undefined));
  const response = NextResponse.redirect(new URL("/dashboard", env.appUrl), 303);
  await startSession(response, user.id, request.headers.get("user-agent"));
  return response;
}
