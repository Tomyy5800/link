import { NextResponse, type NextRequest } from "next/server";
import { env } from "@/lib/server/env";
import { guardMutation } from "@/lib/server/http";
import { endSession } from "@/lib/server/unclaim-auth";

export async function POST(request: NextRequest) {
  const blocked = guardMutation(request);
  if (blocked) return blocked;
  const response = NextResponse.redirect(new URL("/", env.appUrl), 303);
  await endSession(response);
  return response;
}
