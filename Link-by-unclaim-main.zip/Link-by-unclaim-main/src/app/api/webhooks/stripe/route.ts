import { NextResponse } from "next/server";
import { env } from "@/lib/server/env";
import { handleStripeEvent, verifyStripeSignature } from "@/lib/server/payments";

// Notifications Stripe (abonnements, factures, paiements de la boutique, remboursements). Le corps
// brut sert à vérifier la signature : il ne doit pas être réinterprété avant. À déclarer dans Stripe :
//   https://<ton-domaine>/api/webhooks/stripe — événements checkout.session.*, customer.subscription.*,
//   invoice.paid, invoice.payment_failed et charge.refunded (voir docs/CONFIGURATION.md).
export async function POST(request: Request) {
  if (!env.stripe.configured || !env.stripe.webhookConfigured) return NextResponse.json({ error: "Webhook non configuré." }, { status: 503 });
  const payload = await request.text();
  if (payload.length > 512_000) return NextResponse.json({ error: "Trop volumineux." }, { status: 413 });
  if (!verifyStripeSignature(payload, request.headers.get("stripe-signature"), env.stripe.webhookSecret)) {
    return NextResponse.json({ error: "Signature invalide." }, { status: 400 });
  }
  try {
    await handleStripeEvent(JSON.parse(payload));
  } catch (error) {
    // Erreur de notre côté : Stripe renverra l'événement plus tard.
    console.error("[paiement] webhook non traité", error);
    return NextResponse.json({ error: "Traitement impossible." }, { status: 500 });
  }
  return NextResponse.json({ received: true });
}
