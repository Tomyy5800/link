import { NextResponse, type NextRequest } from "next/server";
import { guardRate } from "@/lib/server/http";
import { entitlementsFrom } from "@/lib/server/entitlements";
import { getSettings } from "@/lib/server/settings";
import { availabilityError, slugAvailability } from "@/lib/server/slugs";
import { getCurrentUser } from "@/lib/server/unclaim-auth";
import { validateSlug } from "@/lib/slug";

// Vérifie en direct qu'une adresse personnalisée est libre (règles, pages existantes, anciennes
// adresses encore réservées à leur propriétaire).
export async function GET(request: NextRequest) {
  const limited = guardRate(request, "slug-check", 60);
  if (limited) return limited;
  const [user, settings] = await Promise.all([getCurrentUser(), getSettings()]);
  const rights = user ? entitlementsFrom(user, settings) : null;
  const check = validateSlug(request.nextUrl.searchParams.get("slug") ?? "", {
    allowShort: rights?.features.shortSlug ?? false,
    premiumName: settings.premiumName,
    allowOfficial: rights?.admin ?? false,
  });
  if (!check.ok) return NextResponse.json({ available: false, error: check.error });

  const result = await slugAvailability(check.slug, user?.id ?? null);
  return NextResponse.json({ available: result.available, slug: check.slug, error: availabilityError(result) ?? undefined });
}
