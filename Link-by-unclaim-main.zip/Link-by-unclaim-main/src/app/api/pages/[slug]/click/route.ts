import { NextResponse, type NextRequest } from "next/server";
import { prisma } from "@/lib/server/db";
import { guardRate } from "@/lib/server/http";
import { todayKey } from "@/lib/server/pages";
import { getCurrentUser } from "@/lib/server/unclaim-auth";
import { normalizeSlug } from "@/lib/slug";

const BOT_UA = /bot|crawler|spider|preview|discord|embed|slack|facebookexternalhit|whatsapp|telegram/i;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

// Clic sur un lien d'une page publique (envoyé par navigator.sendBeacon) : agrégé par bloc et par jour.
export async function POST(request: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const limited = guardRate(request, "click", 60);
  if (limited) return limited;

  const userAgent = request.headers.get("user-agent") ?? "";
  if (!userAgent || BOT_UA.test(userAgent)) return new NextResponse(null, { status: 204 });

  let blockId = "";
  try {
    const body = JSON.parse((await request.text()).slice(0, 200)) as { b?: unknown };
    blockId = typeof body.b === "string" ? body.b : "";
  } catch {
    return new NextResponse(null, { status: 400 });
  }
  if (!UUID.test(blockId)) return new NextResponse(null, { status: 400 });

  const { slug } = await params;
  const page = await prisma.page.findUnique({ where: { slug: normalizeSlug(slug) }, select: { id: true, userId: true, published: true } });
  if (!page || !page.published) return new NextResponse(null, { status: 404 });

  const viewer = await getCurrentUser();
  if (viewer?.id === page.userId) return new NextResponse(null, { status: 204 });

  const block = await prisma.block.findFirst({ where: { id: blockId, pageId: page.id }, select: { id: true } });
  if (!block) return new NextResponse(null, { status: 404 });

  const day = todayKey();
  await prisma.linkClick.upsert({
    where: { pageId_blockId_day: { pageId: page.id, blockId, day } },
    create: { pageId: page.id, blockId, day, count: 1 },
    update: { count: { increment: 1 } },
  });
  return new NextResponse(null, { status: 204 });
}
