import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/server/db";
import { guardMutation, guardRate, jsonError, readJson } from "@/lib/server/http";
import { clientIp, visitorHash } from "@/lib/server/security";
import { normalizeSlug } from "@/lib/slug";

const reportSchema = z.object({
  reason: z.enum(["inappropriate", "scam", "impersonation", "harassment", "other"]),
  message: z.string().trim().max(500).default(""),
});

// Signalement d'une page par un visiteur. Un même visiteur ne signale une page qu'une fois par jour.
export async function POST(request: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const blocked = guardMutation(request) ?? guardRate(request, "report", 5, 10 * 60_000);
  if (blocked) return blocked;

  const parsed = reportSchema.safeParse(await readJson(request, 4_000).catch(() => null));
  if (!parsed.success) return jsonError(400, "Signalement invalide.");

  const { slug } = await params;
  const page = await prisma.page.findUnique({ where: { slug: normalizeSlug(slug) }, select: { id: true } });
  if (!page) return jsonError(404, "Page introuvable.");

  const day = new Date().toISOString().slice(0, 10);
  const reporterHash = visitorHash(clientIp(request.headers), request.headers.get("user-agent") ?? "", day);
  const duplicate = await prisma.report.findFirst({
    where: { pageId: page.id, reporterHash, createdAt: { gte: new Date(Date.now() - 86_400_000) } },
    select: { id: true },
  });
  if (!duplicate) {
    await prisma.report.create({ data: { pageId: page.id, reason: parsed.data.reason, message: parsed.data.message, reporterHash } });
  }
  return NextResponse.json({ ok: true }, { status: 201 });
}
