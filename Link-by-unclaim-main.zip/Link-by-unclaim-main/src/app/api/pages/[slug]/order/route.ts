import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { isWithinSchedule, parseStoredBlock } from "@/lib/blocks";
import { MAX_CART_LINES, MAX_QUANTITY, orderTotal, resolveCart } from "@/lib/shop";
import { prisma } from "@/lib/server/db";
import { entitlementsFrom } from "@/lib/server/entitlements";
import { notifyNewOrder } from "@/lib/server/notifications";
import { guardMutation, guardRate, jsonError, readJson } from "@/lib/server/http";
import { clientIp, visitorHash } from "@/lib/server/security";
import { getSettings } from "@/lib/server/settings";
import { normalizeSlug } from "@/lib/slug";

const schema = z.object({
  b: z.uuid(),
  items: z
    .array(z.object({ p: z.string().min(1).max(40), o: z.string().max(32).default(""), q: z.number().int().min(1).max(MAX_QUANTITY) }))
    .min(1, "Ton panier est vide.")
    .max(MAX_CART_LINES),
  name: z.string().trim().min(2, "Indique ton nom ou pseudo.").max(60),
  contact: z.string().trim().min(3, "Indique comment le vendeur peut te répondre.").max(120),
  note: z.string().trim().max(600).default(""),
  /** Champ invisible : rempli seulement par les robots. */
  website: z.string().max(200).default(""),
});

/** Commandes par visiteur, par page et par jour. */
const DAILY_LIMIT = 5;

// Demande de commande envoyée par le panier du bloc « Boutique » d'une page publique. Aucun
// paiement ici : la demande arrive dans « Mon espace › Commandes » du vendeur, qui recontacte
// l'acheteur. Les prix sont relus dans le bloc, jamais pris dans la requête.
export async function POST(request: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const blocked = guardMutation(request) ?? guardRate(request, "order", 6, 10 * 60_000);
  if (blocked) return blocked;
  const parsed = schema.safeParse(await readJson(request, 12_000).catch(() => null));
  if (!parsed.success) return jsonError(400, parsed.error.issues[0]?.message ?? "Commande invalide.");
  const { b, items, name, contact, note, website } = parsed.data;
  // Robot : on fait comme si tout s'était bien passé, sans rien enregistrer.
  if (website) return NextResponse.json({ ok: true }, { status: 201 });

  const { slug } = await params;
  const page = await prisma.page.findUnique({
    where: { slug: normalizeSlug(slug) },
    select: { id: true, published: true, status: true, user: true, blocks: { where: { id: b } } },
  });
  if (!page || !page.published || page.status !== "active" || page.user.banned || page.user.suspendedAt) return jsonError(404, "Page introuvable.");
  if (!entitlementsFrom(page.user, await getSettings()).features.shop) return jsonError(404, "Cette boutique est fermée.");
  const block = page.blocks[0] ? parseStoredBlock(page.blocks[0]) : null;
  if (!block || block.type !== "shop" || !block.visible || !isWithinSchedule(block)) return jsonError(404, "Cette boutique est fermée.");

  const cart = resolveCart(
    block.data.products,
    items.map((i) => ({ productId: i.p, option: i.o, quantity: i.q })),
  );
  if ("error" in cart) return jsonError(409, cart.error);

  const day = new Date().toISOString().slice(0, 10);
  const senderHash = visitorHash(clientIp(request.headers), request.headers.get("user-agent") ?? "", day);
  const sent = await prisma.shopOrder.count({ where: { pageId: page.id, senderHash, createdAt: { gte: new Date(Date.now() - 86_400_000) } } });
  if (sent >= DAILY_LIMIT) return jsonError(429, "Tu as déjà envoyé plusieurs commandes aujourd'hui : réessaie demain.");

  const total = orderTotal(cart.items);
  const currency = block.data.currency;
  const order = await prisma.shopOrder.create({
    data: { pageId: page.id, blockId: b, items: JSON.stringify(cart.items), total, currency, name, contact, note, senderHash },
    select: { id: true },
  });
  // Notification Discord (si réglée) : un échec n'empêche jamais l'enregistrement de la commande.
  await notifyNewOrder(page.id, { name, contact, note, items: cart.items, total, currency }).catch(() => undefined);
  // Les commandes de plus d'un an sont effacées (voir la politique de confidentialité).
  if (Math.random() < 0.02) {
    await prisma.shopOrder.deleteMany({ where: { createdAt: { lt: new Date(Date.now() - 365 * 86_400_000) } } }).catch(() => undefined);
  }
  // Référence courte, à rappeler au vendeur.
  return NextResponse.json({ ok: true, reference: order.id.slice(-6).toUpperCase(), total }, { status: 201 });
}
