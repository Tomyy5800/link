import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { isWithinSchedule, parseStoredBlock } from "@/lib/blocks";
import { prisma } from "@/lib/server/db";
import { notifyNewMessage } from "@/lib/server/notifications";
import { guardMutation, guardRate, jsonError, readJson } from "@/lib/server/http";
import { clientIp, visitorHash } from "@/lib/server/security";
import { normalizeSlug } from "@/lib/slug";

const schema = z.object({
  b: z.uuid(),
  name: z.string().trim().min(2, "Indique ton nom ou pseudo.").max(60),
  contact: z.string().trim().max(120).default(""),
  message: z.string().trim().min(5, "Ton message est trop court.").max(2000),
  /** Champ invisible : rempli seulement par les robots. */
  website: z.string().max(200).default(""),
});

/** Messages par visiteur, par page et par jour. */
const DAILY_LIMIT = 5;

// Envoi d'un message via le bloc « Formulaire de contact » d'une page publique.
export async function POST(request: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const blocked = guardMutation(request) ?? guardRate(request, "contact", 6, 10 * 60_000);
  if (blocked) return blocked;
  const parsed = schema.safeParse(await readJson(request, 8_000).catch(() => null));
  if (!parsed.success) return jsonError(400, parsed.error.issues[0]?.message ?? "Message invalide.");
  const { b, name, contact, message, website } = parsed.data;
  // Robot : on fait comme si tout s'était bien passé, sans rien enregistrer.
  if (website) return NextResponse.json({ ok: true }, { status: 201 });

  const { slug } = await params;
  const page = await prisma.page.findUnique({
    where: { slug: normalizeSlug(slug) },
    select: { id: true, published: true, status: true, user: { select: { banned: true, suspendedAt: true } }, blocks: { where: { id: b } } },
  });
  if (!page || !page.published || page.status !== "active" || page.user.banned || page.user.suspendedAt) return jsonError(404, "Page introuvable.");
  const block = page.blocks[0] ? parseStoredBlock(page.blocks[0]) : null;
  if (!block || block.type !== "contact" || !block.visible || !isWithinSchedule(block)) return jsonError(404, "Ce formulaire n'est plus disponible.");
  if (block.data.contactField === "required" && contact.length < 3) return jsonError(400, "Indique comment te répondre.");

  const day = new Date().toISOString().slice(0, 10);
  const senderHash = visitorHash(clientIp(request.headers), request.headers.get("user-agent") ?? "", day);
  const sent = await prisma.contactMessage.count({ where: { pageId: page.id, senderHash, createdAt: { gte: new Date(Date.now() - 86_400_000) } } });
  if (sent >= DAILY_LIMIT) return jsonError(429, "Tu as déjà envoyé plusieurs messages aujourd'hui : réessaie demain.");

  const saved = { name, contact: block.data.contactField === "hidden" ? "" : contact, message };
  await prisma.contactMessage.create({ data: { pageId: page.id, blockId: b, ...saved, senderHash } });
  // Notification Discord (si réglée) : un échec n'empêche jamais l'enregistrement du message.
  await notifyNewMessage(page.id, saved).catch(() => undefined);
  // Les messages de plus d'un an sont effacés (voir la politique de confidentialité).
  if (Math.random() < 0.02) {
    await prisma.contactMessage.deleteMany({ where: { createdAt: { lt: new Date(Date.now() - 365 * 86_400_000) } } }).catch(() => undefined);
  }
  return NextResponse.json({ ok: true }, { status: 201 });
}
