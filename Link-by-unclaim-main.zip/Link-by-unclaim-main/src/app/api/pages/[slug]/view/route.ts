import { NextResponse, type NextRequest } from "next/server";
import { prisma } from "@/lib/server/db";
import { maybeWeeklyDigest } from "@/lib/server/notifications";
import { env } from "@/lib/server/env";
import { guardRate, readJson } from "@/lib/server/http";
import { recordView } from "@/lib/server/pages";
import { clientIp, visitorHash } from "@/lib/server/security";
import { getCurrentUser } from "@/lib/server/unclaim-auth";
import { normalizeSlug } from "@/lib/slug";

const BOT_UA = /bot|crawler|spider|preview|discord|embed|slack|facebookexternalhit|whatsapp|telegram/i;

/** Domaine d'origine de la visite (sans chemin), ou null pour un accès direct ou interne. */
function referrerHost(raw: unknown): string | null {
  if (typeof raw !== "string" || !raw) return null;
  try {
    const host = new URL(raw).hostname.toLowerCase().replace(/^www\./, "");
    if (!host || host === new URL(env.appUrl).hostname.replace(/^www\./, "")) return null;
    return host.slice(0, 120);
  } catch {
    return null;
  }
}

function deviceOf(userAgent: string): "mobile" | "tablet" | "desktop" {
  if (/iPad|Tablet|PlayBook|Silk|Android(?!.*Mobile)/i.test(userAgent)) return "tablet";
  if (/Mobi|iPhone|iPod|Android/i.test(userAgent)) return "mobile";
  return "desktop";
}

// Compteur de vues : une vue par visiteur et par jour, le propriétaire et les robots exclus.
// Pour les statistiques avancées : domaine d'origine et type d'appareil (aucune donnée personnelle).
export async function POST(request: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const limited = guardRate(request, "view", 60);
  if (limited) return limited;

  const { slug } = await params;
  const userAgent = request.headers.get("user-agent") ?? "";
  if (!userAgent || BOT_UA.test(userAgent)) return NextResponse.json({ counted: false });

  const page = await prisma.page.findUnique({
    where: { slug: normalizeSlug(slug) },
    select: { id: true, userId: true, published: true, status: true },
  });
  if (!page || !page.published || page.status !== "active") return NextResponse.json({ counted: false }, { status: 404 });

  const viewer = await getCurrentUser();
  if (viewer?.id === page.userId) return NextResponse.json({ counted: false });

  const body = (await readJson(request, 1_000).catch(() => ({}))) as { referrer?: unknown };
  const day = new Date().toISOString().slice(0, 10);
  const counted = await recordView(page.id, visitorHash(clientIp(request.headers), userAgent, day), {
    referrer: referrerHost(body?.referrer),
    device: deviceOf(userAgent),
  });
  // Bilan hebdomadaire Discord : vérifié à l'occasion d'une nouvelle visite (au plus une fois par semaine).
  if (counted) await maybeWeeklyDigest(page.id).catch(() => undefined);
  return NextResponse.json({ counted });
}
