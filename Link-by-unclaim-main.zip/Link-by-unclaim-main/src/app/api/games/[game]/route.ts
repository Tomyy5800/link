import { NextResponse, type NextRequest } from "next/server";
import { GAMES, cleanGameId, type GameId } from "@/lib/games";
import { getGameProfile } from "@/lib/server/games";
import { guardRate, jsonError } from "@/lib/server/http";

// Profil public d'un joueur pour le bloc « Profil de jeu » (jeux avec API publique uniquement).
// GET /api/games/<jeu>?id=<pseudo>
export async function GET(request: NextRequest, { params }: { params: Promise<{ game: string }> }) {
  const limited = guardRate(request, "games", 60);
  if (limited) return limited;
  const { game } = await params;
  if (!Object.prototype.hasOwnProperty.call(GAMES, game) || !GAMES[game as GameId].live) return jsonError(404, "Jeu non pris en charge.");
  const id = cleanGameId(game as GameId, request.nextUrl.searchParams.get("id") ?? "");
  if (!id) return jsonError(400, "Identifiant invalide.");

  try {
    const profile = await getGameProfile(game as GameId, id);
    if (!profile) return jsonError(404, "Joueur introuvable.");
    return NextResponse.json({ profile }, { headers: { "Cache-Control": "public, max-age=300, stale-while-revalidate=900" } });
  } catch {
    return jsonError(503, "Le service du jeu ne répond pas pour le moment.");
  }
}
