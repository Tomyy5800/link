import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { TERMS_VERSION } from "@/lib/legal";
import { isResponse } from "@/lib/server/admin";
import { requireAccountApi } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { jsonError, readJson } from "@/lib/server/http";

// Acceptation des conditions générales d'utilisation (à la création du compte, puis à chaque
// nouvelle version). La version et la date sont conservées comme preuve.
const schema = z.object({
  terms: z.literal(true, "Accepte les conditions d'utilisation pour continuer."),
  age: z.literal(true, "Confirme ton âge pour continuer."),
});

export async function POST(request: NextRequest) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["terms", 20], terms: false });
  if (isResponse(user)) return user;
  const parsed = schema.safeParse(await readJson(request, 1_000).catch(() => null));
  if (!parsed.success) return jsonError(400, parsed.error.issues[0]?.message ?? "Acceptation requise.");
  await prisma.user.update({ where: { id: user.id }, data: { termsVersion: TERMS_VERSION, termsAcceptedAt: new Date() } });
  return NextResponse.json({ ok: true, version: TERMS_VERSION });
}
