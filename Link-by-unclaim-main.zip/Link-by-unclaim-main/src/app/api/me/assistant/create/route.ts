import { after, NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { buildPageFromDraft, sanitizeDraft } from "@/lib/assistant";
import { evaluateEarlyBadges } from "@/lib/server/badges";
import { availabilityError, releaseRedirect, slugAvailability } from "@/lib/server/slugs";
import { blockSchema } from "@/lib/blocks";
import { isResponse } from "@/lib/server/admin";
import { ownedPageCount, requireAccountApi } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { entitlementsFrom, suspension } from "@/lib/server/entitlements";
import { jsonError, readJson } from "@/lib/server/http";
import { createPage } from "@/lib/server/pages";
import { getSettings } from "@/lib/server/settings";
import { validateSlug } from "@/lib/slug";
import { themeSchema } from "@/lib/theme";

const schema = z.object({
  slug: z.string().max(64),
  label: z.string().trim().max(40).default(""),
  draft: z.unknown(),
});

// Crée la page composée avec l'assistant (mêmes règles que la création classique).
export async function POST(request: NextRequest) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["page-create", 10] });
  if (isResponse(user)) return user;
  const parsed = schema.safeParse(await readJson(request, 60_000).catch(() => null));
  if (!parsed.success) return jsonError(400, "Demande invalide.");

  const settings = await getSettings();
  const rights = entitlementsFrom(user, settings);
  if (!settings.registrationsOpen && !rights.admin) return jsonError(403, "La création de nouvelles pages est momentanément fermée.");
  if (suspension(user)) return jsonError(403, "Ton compte est suspendu.");
  if ((await ownedPageCount(user.id)) >= rights.limits.pages) {
    return jsonError(403, `Tu as atteint la limite de ${rights.limits.pages} page${rights.limits.pages > 1 ? "s" : ""} de ta formule.`, { code: "page_limit" });
  }

  const slug = validateSlug(parsed.data.slug, { allowShort: rights.features.shortSlug, premiumName: settings.premiumName, allowOfficial: rights.admin });
  if (!slug.ok) return jsonError(400, slug.error);
  const availability = await slugAvailability(slug.slug, user.id);
  if (!availability.available) return jsonError(409, availabilityError(availability) ?? "Cette adresse est déjà prise.");

  const draft = sanitizeDraft(parsed.data.draft);
  if (!draft.displayName) return jsonError(400, "Le nom affiché est obligatoire.");
  const built = buildPageFromDraft(draft, { hasDiscord: Boolean(user.discordId) });
  // Dernière vérification avec les schémas de l'éditeur : seul ce qui est valide est enregistré.
  const blocks = built.blocks.filter((b) => blockSchema.safeParse(b).success).slice(0, rights.limits.blocks);
  const theme = themeSchema.safeParse(built.theme);
  if (!theme.success) return jsonError(400, "Thème invalide.");

  try {
    const { id } = await createPage({
      user,
      slug: slug.slug,
      displayName: draft.displayName,
      label: parsed.data.label,
      ngUsername: draft.ngUsername,
      ngServer: "blue",
      preset: draft.preset,
      content: { bio: draft.bio, pronouns: draft.pronouns, theme: theme.data, blocks },
    });
    await releaseRedirect(slug.slug);
    after(() => evaluateEarlyBadges(user.id).catch(() => undefined));
    return NextResponse.json({ id, slug: slug.slug }, { status: 201 });
  } catch {
    return jsonError(409, "Cette adresse vient d'être prise, choisis-en une autre.");
  }
}
