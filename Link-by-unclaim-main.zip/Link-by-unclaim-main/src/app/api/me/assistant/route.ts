import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { MAX_ASSISTANT_CHARS, MAX_ASSISTANT_MESSAGES, sanitizeDraft } from "@/lib/assistant";
import { isResponse } from "@/lib/server/admin";
import { requireAccountApi } from "@/lib/server/access";
import { assistantTurn } from "@/lib/server/assistant";
import { entitlementsFrom } from "@/lib/server/entitlements";
import { jsonError, readJson } from "@/lib/server/http";
import { getSettings } from "@/lib/server/settings";

const schema = z.object({
  messages: z
    .array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().trim().min(1).max(MAX_ASSISTANT_CHARS) }))
    .max(MAX_ASSISTANT_MESSAGES, "La conversation est trop longue : crée ta page, tu pourras la compléter dans l'éditeur."),
  draft: z.unknown().optional(),
});

// Un tour de l'assistant de création : renvoie la réponse, des réponses rapides et le brouillon de page.
export async function POST(request: NextRequest) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["assistant", 30] });
  if (isResponse(user)) return user;
  const parsed = schema.safeParse(await readJson(request, 60_000).catch(() => null));
  if (!parsed.success) return jsonError(400, parsed.error.issues[0]?.message ?? "Message invalide.");
  const { messages } = parsed.data;
  if (messages.length && messages[messages.length - 1].role !== "user") return jsonError(400, "Le dernier message doit venir de toi.");

  const limits = entitlementsFrom(user, await getSettings()).limits;
  const turn = await assistantTurn(messages, sanitizeDraft(parsed.data.draft), {
    userId: user.id,
    name: user.globalName ?? user.username,
    dailyLimit: limits.aiMessages,
  });
  return NextResponse.json(turn);
}
