import { NextResponse, type NextRequest } from "next/server";
import { jsonError } from "@/lib/server/http";
import { syncSubscriptionCheckout } from "@/lib/server/payments";
import { getCurrentUser } from "@/lib/server/unclaim-auth";

// Page de retour d'une souscription : état de l'abonnement du compte connecté, vérifié chez Stripe.
export async function GET(request: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return jsonError(401, "Connexion requise.");
  const session = request.nextUrl.searchParams.get("session") ?? "";
  const state = await syncSubscriptionCheckout(session, user.id);
  return NextResponse.json(state, { headers: { "Cache-Control": "no-store" } });
}
