import { after, NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { isResponse } from "@/lib/server/admin";
import { evaluateEarlyBadges } from "@/lib/server/badges";
import { availabilityError, releaseRedirect, slugAvailability } from "@/lib/server/slugs";
import { listAccountPages, ownedPageCount, requireAccountApi } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { jsonError, readJson, zodDetails } from "@/lib/server/http";
import { entitlementsFrom, suspension } from "@/lib/server/entitlements";
import { createPage } from "@/lib/server/pages";
import { getSettings } from "@/lib/server/settings";
import { validateSlug } from "@/lib/slug";
import { MC_USERNAME } from "@/lib/urls";

// Pages du compte connecté : liste (les siennes et celles où il collabore) et création.

export async function GET(request: NextRequest) {
  const user = await requireAccountApi(request, { terms: false });
  if (isResponse(user)) return user;
  return NextResponse.json({ pages: await listAccountPages(user.id) });
}

const createSchema = z.object({
  slug: z.string().max(64),
  displayName: z.string().trim().min(1, "Le nom affiché est obligatoire.").max(48),
  label: z.string().trim().max(40).default(""),
  ngUsername: z
    .string()
    .trim()
    .max(16)
    .refine((v) => v === "" || MC_USERNAME.test(v), "Pseudo NationsGlory invalide.")
    .default(""),
  ngServer: z.string().regex(/^[a-z0-9-]{2,24}$/, "Serveur invalide.").default("blue"),
  preset: z.string().max(32).default("unclaim"),
  template: z.string().max(24).default(""),
});

export async function POST(request: NextRequest) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["page-create", 10] });
  if (isResponse(user)) return user;

  const parsed = createSchema.safeParse(await readJson(request, 8_000).catch(() => null));
  if (!parsed.success) return jsonError(400, parsed.error.issues[0]?.message ?? "Données invalides.", zodDetails(parsed.error));

  const settings = await getSettings();
  const rights = entitlementsFrom(user, settings);
  if (!settings.registrationsOpen && !rights.admin) {
    return jsonError(403, "La création de nouvelles pages est momentanément fermée.");
  }
  if (suspension(user)) return jsonError(403, "Ton compte est suspendu.");

  const owned = await ownedPageCount(user.id);
  if (owned >= rights.limits.pages) {
    return jsonError(
      403,
      rights.limits.pages === 1
        ? `Ton offre permet une seule page. ${rights.premium ? "" : `Passe à ${settings.premiumName} pour en créer d'autres.`}`.trim()
        : `Tu as atteint la limite de ${rights.limits.pages} pages de ton offre.`,
      { code: "page_limit" },
    );
  }

  const slug = validateSlug(parsed.data.slug, { allowShort: rights.features.shortSlug, premiumName: settings.premiumName, allowOfficial: rights.admin });
  if (!slug.ok) return jsonError(400, slug.error);
  const availability = await slugAvailability(slug.slug, user.id);
  if (!availability.available) return jsonError(409, availabilityError(availability) ?? "Cette adresse est déjà prise.");

  try {
    const { displayName, label, ngUsername, ngServer, preset, template } = parsed.data;
    const { id } = await createPage({ user, slug: slug.slug, displayName, label, ngUsername, ngServer, preset, template });
    await releaseRedirect(slug.slug);
    // Première page publiée : badge « premiers comptes » si une place reste.
    after(() => evaluateEarlyBadges(user.id).catch(() => undefined));
    return NextResponse.json({ id, slug: slug.slug }, { status: 201 });
  } catch {
    return jsonError(409, "Cette adresse vient d'être prise, choisis-en une autre.");
  }
}
