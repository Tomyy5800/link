import { NextResponse, type NextRequest } from "next/server";
import { isResponse } from "@/lib/server/admin";
import { requireAccountApi, requirePageApi } from "@/lib/server/access";
import { entitlementsFrom } from "@/lib/server/entitlements";
import { VIEW_RETENTION_DAYS, audience, clicksByBlock, viewsByDay } from "@/lib/server/pages";
import { getSettings } from "@/lib/server/settings";

// Statistiques d'une page : vues uniques, clics par lien et (statistiques avancées) sources de
// trafic et appareils. Profondeur selon l'offre du propriétaire. ?format=csv : export tableur.
// GET /api/me/pages/:id/stats?days=30
export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await requireAccountApi(request);
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "stats");
  if (isResponse(access)) return access;
  const page = access.page;

  const rights = entitlementsFrom(page.user, await getSettings());
  const maxDays = Math.min(VIEW_RETENTION_DAYS, rights.limits.statsDays);
  const asked = Number(request.nextUrl.searchParams.get("days") ?? 14);
  const days = Math.max(7, Math.min(maxDays, Number.isFinite(asked) ? Math.trunc(asked) : 14));
  const advanced = rights.features.advancedStats;

  const [series, clicks, sources] = await Promise.all([
    viewsByDay(page.id, days),
    clicksByBlock(page.id, days),
    advanced ? audience(page.id, days) : Promise.resolve(null),
  ]);

  if (request.nextUrl.searchParams.get("format") === "csv") {
    if (!rights.features.statsExport) return NextResponse.json({ error: "L'export des statistiques fait partie d'une formule supérieure." }, { status: 403 });
    // Une ligne par jour : date, vues uniques (séparateur « ; » pour Excel en français).
    const lines = ["date;vues", ...series.map((d) => `${d.day};${d.count}`)];
    return new NextResponse(`﻿${lines.join("\r\n")}\r\n`, {
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="statistiques-${page.slug}-${days}j.csv"`,
        "Cache-Control": "no-store",
      },
    });
  }
  return NextResponse.json({ total: page.views, period: days, maxDays, days: series, clicks, audience: sources });
}
