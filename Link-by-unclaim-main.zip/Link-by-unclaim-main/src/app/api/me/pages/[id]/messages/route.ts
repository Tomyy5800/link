import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { isResponse } from "@/lib/server/admin";
import { requireAccountApi, requirePageApi } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { jsonError, readJson } from "@/lib/server/http";

// Messages reçus par le bloc « Formulaire de contact » d'une page : lecture, marquage, suppression.
type Ctx = { params: Promise<{ id: string }> };

export async function GET(request: NextRequest, { params }: Ctx) {
  const user = await requireAccountApi(request);
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "messages.read");
  if (isResponse(access)) return access;
  const messages = await prisma.contactMessage.findMany({
    where: { pageId: access.page.id },
    orderBy: { createdAt: "desc" },
    take: 200,
    select: { id: true, name: true, contact: true, message: true, read: true, createdAt: true },
  });
  return NextResponse.json({ messages });
}

const patchSchema = z.object({ ids: z.array(z.string().max(40)).min(1).max(200), read: z.boolean() });

export async function PATCH(request: NextRequest, { params }: Ctx) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["messages", 60] });
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "messages.read");
  if (isResponse(access)) return access;
  const parsed = patchSchema.safeParse(await readJson(request, 10_000).catch(() => null));
  if (!parsed.success) return jsonError(400, "Requête invalide.");
  await prisma.contactMessage.updateMany({ where: { pageId: access.page.id, id: { in: parsed.data.ids } }, data: { read: parsed.data.read } });
  return NextResponse.json({ ok: true });
}

export async function DELETE(request: NextRequest, { params }: Ctx) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["messages", 60], terms: false });
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "messages.manage");
  if (isResponse(access)) return access;
  const id = request.nextUrl.searchParams.get("messageId");
  if (!id) return jsonError(400, "Message manquant.");
  await prisma.contactMessage.deleteMany({ where: { id, pageId: access.page.id } });
  return NextResponse.json({ ok: true });
}
