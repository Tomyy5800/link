import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { pageSaveSchema } from "@/lib/page-schema";
import { isResponse } from "@/lib/server/admin";
import { requireAccountApi, requirePageApi } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { jsonError, readJson, zodDetails } from "@/lib/server/http";
import { entitlementsFrom, suspension } from "@/lib/server/entitlements";
import { SaveError, deletePage, getEditorPage, savePage } from "@/lib/server/pages";
import { getSettings } from "@/lib/server/settings";

// Une page du compte : lecture, sauvegarde (éditeurs), nom interne et suppression (propriétaire).
type Ctx = { params: Promise<{ id: string }> };

export async function GET(request: NextRequest, { params }: Ctx) {
  const user = await requireAccountApi(request);
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "view");
  if (isResponse(access)) return access;
  const page = await getEditorPage(access.page.id);
  return page ? NextResponse.json({ page, role: access.role }) : jsonError(404, "Page introuvable.");
}

export async function PUT(request: NextRequest, { params }: Ctx) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["page-save", 120] });
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "edit");
  if (isResponse(access)) return access;

  let body: unknown;
  try {
    body = await readJson(request, 400_000);
  } catch {
    return jsonError(413, "Page trop volumineuse ou JSON invalide.");
  }
  const parsed = pageSaveSchema.safeParse(body);
  if (!parsed.success) {
    const first = parsed.error.issues[0];
    return jsonError(400, first ? `${first.message}${first.path.length ? ` (${first.path.join(".")})` : ""}` : "Données invalides.", zodDetails(parsed.error));
  }

  // Les droits (fonctions, limites) sont ceux du propriétaire de la page, quel que soit l'éditeur.
  const owner = access.page.user;
  if (suspension(owner) || suspension(user)) return jsonError(403, "Compte suspendu : la page ne peut plus être modifiée.");
  const rights = entitlementsFrom(owner, await getSettings());

  try {
    const { updatedAt } = await savePage(access.page.id, parsed.data, rights.limits, user.id);
    return NextResponse.json({ ok: true, updatedAt });
  } catch (error) {
    if (error instanceof SaveError) return jsonError(error.status, error.message);
    console.error("[pages] échec de sauvegarde", error);
    return jsonError(500, "La sauvegarde a échoué.");
  }
}

const patchSchema = z.object({ label: z.string().trim().max(40) });

/** Nom interne de la page dans « Mon espace ». */
export async function PATCH(request: NextRequest, { params }: Ctx) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["page-label", 30] });
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "edit");
  if (isResponse(access)) return access;
  const parsed = patchSchema.safeParse(await readJson(request, 2_000).catch(() => null));
  if (!parsed.success) return jsonError(400, "Nom invalide (40 caractères au maximum).");
  await prisma.page.update({ where: { id: access.page.id }, data: { label: parsed.data.label } });
  return NextResponse.json({ ok: true, label: parsed.data.label });
}

export async function DELETE(request: NextRequest, { params }: Ctx) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["page-delete", 10], terms: false });
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "own");
  if (isResponse(access)) return access;
  await deletePage(access.page.id);
  return NextResponse.json({ ok: true });
}
