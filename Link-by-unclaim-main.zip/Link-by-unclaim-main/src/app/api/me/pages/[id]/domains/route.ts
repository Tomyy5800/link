import { NextResponse, type NextRequest } from "next/server";
import { audit, isResponse } from "@/lib/server/admin";
import { requireAccountApi, requirePageApi } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { domainView, newDomainToken, validateHostname } from "@/lib/server/domains";
import { entitlementsFrom } from "@/lib/server/entitlements";
import { jsonError, readJson } from "@/lib/server/http";
import { getSettings } from "@/lib/server/settings";

// Domaines personnels d'une page (propriétaire uniquement, formule Pro ou Équipe).
export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await requireAccountApi(request);
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "own");
  if (isResponse(access)) return access;
  const domains = await prisma.customDomain.findMany({ where: { pageId: access.page.id }, orderBy: { createdAt: "asc" } });
  return NextResponse.json({ domains: domains.map(domainView) });
}

export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["domains", 10] });
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "own");
  if (isResponse(access)) return access;

  const settings = await getSettings();
  const rights = entitlementsFrom(user, settings);
  if (!rights.features.customDomains) return jsonError(403, "Les domaines personnels sont réservés aux formules Pro et Équipe.", { code: "feature_locked" });
  const owned = await prisma.customDomain.count({ where: { userId: user.id } });
  if (owned >= rights.limits.domains) {
    return jsonError(403, rights.limits.domains === 0 ? "Ta formule ne comprend pas de domaine personnel." : `Ta formule permet ${rights.limits.domains} domaine${rights.limits.domains > 1 ? "s" : ""}.`, { code: "domain_limit" });
  }

  const body = (await readJson(request, 1_000).catch(() => null)) as { hostname?: unknown } | null;
  const check = validateHostname(typeof body?.hostname === "string" ? body.hostname : "");
  if (!check.ok) return jsonError(400, check.error);
  try {
    const domain = await prisma.customDomain.create({ data: { hostname: check.hostname, pageId: access.page.id, userId: user.id, token: newDomainToken() } });
    await audit(user.id, "domain.add", "domain", domain.id, { hostname: domain.hostname, pageId: access.page.id });
    return NextResponse.json({ domain: domainView(domain) }, { status: 201 });
  } catch {
    return jsonError(409, "Ce domaine est déjà relié à une page Link by Unclaim.");
  }
}
