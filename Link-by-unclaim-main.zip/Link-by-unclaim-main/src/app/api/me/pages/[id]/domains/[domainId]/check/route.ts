import { NextResponse, type NextRequest } from "next/server";
import { isResponse } from "@/lib/server/admin";
import { requireAccountApi, requirePageApi } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { domainView, recheckDomain } from "@/lib/server/domains";
import { entitlementsFrom } from "@/lib/server/entitlements";
import { jsonError } from "@/lib/server/http";
import { getSettings } from "@/lib/server/settings";

// Vérifie maintenant la configuration DNS et HTTPS d'un domaine (résultat enregistré).
export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string; domainId: string }> }) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["domain-check", 12] });
  if (isResponse(user)) return user;
  const { id, domainId } = await params;
  const access = await requirePageApi(user, id, "own");
  if (isResponse(access)) return access;
  const rights = entitlementsFrom(user, await getSettings());
  if (!rights.features.customDomains) return jsonError(403, "Les domaines personnels sont réservés aux formules Pro et Équipe.", { code: "feature_locked" });
  const domain = await prisma.customDomain.findFirst({ where: { id: domainId, pageId: access.page.id } });
  if (!domain) return jsonError(404, "Domaine introuvable.");
  const updated = await recheckDomain(domain);
  return NextResponse.json({ domain: domainView(updated) });
}
