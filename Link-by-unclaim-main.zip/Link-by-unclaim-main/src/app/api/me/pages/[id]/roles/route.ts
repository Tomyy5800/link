import { NextResponse, type NextRequest } from "next/server";
import { memberRoleInputSchema } from "@/lib/member-roles";
import { audit, isResponse } from "@/lib/server/admin";
import { requireAccountApi, requirePageApi } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { entitlementsFrom } from "@/lib/server/entitlements";
import { jsonError, readJson } from "@/lib/server/http";
import { listPageRoles, toRoleView } from "@/lib/server/member-roles";
import { getSettings } from "@/lib/server/settings";

// Rôles personnalisés d'une page (Link+ et plus) : lecture par les membres, gestion par le propriétaire.
type Ctx = { params: Promise<{ id: string }> };

export async function GET(request: NextRequest, { params }: Ctx) {
  const user = await requireAccountApi(request);
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "view");
  if (isResponse(access)) return access;
  const rights = entitlementsFrom(access.page.user, await getSettings());
  return NextResponse.json({ roles: await listPageRoles(access.page.id), enabled: rights.features.customRoles, limit: rights.limits.roles });
}

export async function POST(request: NextRequest, { params }: Ctx) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["page-roles", 30] });
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "own");
  if (isResponse(access)) return access;
  const rights = entitlementsFrom(user, await getSettings());
  if (!rights.features.customRoles) return jsonError(403, `Les rôles personnalisés sont réservés à ${rights.premiumName} et aux formules supérieures.`, { code: "feature_locked" });
  const count = await prisma.memberRole.count({ where: { pageId: access.page.id } });
  if (count >= rights.limits.roles) return jsonError(403, `Ta formule permet ${rights.limits.roles} rôle${rights.limits.roles > 1 ? "s" : ""} par page.`, { code: "role_limit" });

  const parsed = memberRoleInputSchema.safeParse(await readJson(request, 4_000).catch(() => null));
  if (!parsed.success) return jsonError(400, parsed.error.issues[0]?.message ?? "Rôle invalide.");
  const role = await prisma.memberRole.create({
    data: { ...parsed.data, permissions: JSON.stringify(parsed.data.permissions), pageId: access.page.id, position: count },
  });
  await audit(user.id, "role.create", "page", access.page.id, { roleId: role.id, name: role.name });
  return NextResponse.json({ role: toRoleView(role) }, { status: 201 });
}
