import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { toOwnerProfile } from "@/lib/discord-cdn";
import { audit, isResponse } from "@/lib/server/admin";
import { requireAccountApi, requirePageApi } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { env } from "@/lib/server/env";
import { jsonError, readJson } from "@/lib/server/http";
import { entitlementsFrom } from "@/lib/server/entitlements";
import { randomToken, sha256 } from "@/lib/server/security";
import { getSettings } from "@/lib/server/settings";

// Équipe d'une page : collaborateurs et invitations par lien (gérées par le propriétaire).
// Un collaborateur peut aussi quitter la page (DELETE ?memberId=<le sien>).
type Ctx = { params: Promise<{ id: string }> };

const INVITE_DAYS = 7;

export async function GET(request: NextRequest, { params }: Ctx) {
  const user = await requireAccountApi(request);
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "view");
  if (isResponse(access)) return access;

  const [members, invites, settings] = await Promise.all([
    prisma.pageMember.findMany({ where: { pageId: access.page.id }, include: { user: true }, orderBy: { createdAt: "asc" } }),
    access.role === "owner"
      ? prisma.pageInvite.findMany({
          where: { pageId: access.page.id, usedAt: null, expiresAt: { gt: new Date() } },
          orderBy: { createdAt: "desc" },
          select: { id: true, role: true, expiresAt: true, createdAt: true },
        })
      : Promise.resolve([]),
    getSettings(),
  ]);
  const owner = toOwnerProfile(access.page.user);
  return NextResponse.json({
    role: access.role,
    limit: entitlementsFrom(access.page.user, settings).limits.members,
    owner: { name: owner.globalName ?? owner.username, avatar: owner.avatarUrl, self: access.page.userId === user.id },
    members: members.map((m) => {
      const profile = toOwnerProfile(m.user);
      return {
        id: m.id,
        role: m.role,
        customRoleId: m.customRoleId,
        name: profile.globalName ?? profile.username,
        avatar: profile.avatarUrl,
        self: m.userId === user.id,
        since: m.createdAt,
      };
    }),
    invites,
  });
}

const inviteSchema = z.object({ role: z.enum(["editor", "viewer"]).default("editor") });

/** Crée un lien d'invitation (valable 7 jours, à usage unique). Le jeton n'est montré qu'une fois. */
export async function POST(request: NextRequest, { params }: Ctx) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["page-invite", 20] });
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "own");
  if (isResponse(access)) return access;
  const parsed = inviteSchema.safeParse(await readJson(request, 1_000).catch(() => ({})));
  if (!parsed.success) return jsonError(400, "Rôle invalide.");

  const limit = entitlementsFrom(user, await getSettings()).limits.members;
  const [members, pending] = await Promise.all([
    prisma.pageMember.count({ where: { pageId: access.page.id } }),
    prisma.pageInvite.count({ where: { pageId: access.page.id, usedAt: null, expiresAt: { gt: new Date() } } }),
  ]);
  if (members + pending >= limit) {
    return jsonError(403, limit === 0 ? "Ton offre ne permet pas d'inviter des collaborateurs." : `Ton offre permet ${limit} collaborateur(s) par page (invitations en attente comprises).`);
  }

  const token = randomToken(24);
  const invite = await prisma.pageInvite.create({
    data: {
      pageId: access.page.id,
      tokenHash: sha256(token),
      role: parsed.data.role,
      createdById: user.id,
      expiresAt: new Date(Date.now() + INVITE_DAYS * 86_400_000),
    },
    select: { id: true, role: true, expiresAt: true, createdAt: true },
  });
  return NextResponse.json({ invite, url: `${env.appUrl}/invitation/${token}` }, { status: 201 });
}

const patchSchema = z.object({
  memberId: z.string().max(40),
  role: z.enum(["editor", "viewer"]).optional(),
  /** Rôle personnalisé de la page (null : aucun, le rôle de base s'applique). */
  customRoleId: z.string().max(40).nullable().optional(),
});

/** Change le rôle d'un collaborateur (rôle de base et, avec Link+ ou plus, rôle personnalisé). */
export async function PATCH(request: NextRequest, { params }: Ctx) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["page-members", 30] });
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "own");
  if (isResponse(access)) return access;
  const parsed = patchSchema.safeParse(await readJson(request, 1_000).catch(() => null));
  if (!parsed.success || (parsed.data.role === undefined && parsed.data.customRoleId === undefined)) return jsonError(400, "Requête invalide.");
  const { memberId, role, customRoleId } = parsed.data;
  if (customRoleId) {
    if (!entitlementsFrom(user, await getSettings()).features.customRoles) {
      return jsonError(403, "Les rôles personnalisés sont réservés à Link+ et aux formules supérieures.", { code: "feature_locked" });
    }
    // Le rôle doit appartenir à cette page : pas question d'emprunter celui d'une autre.
    const exists = await prisma.memberRole.findFirst({ where: { id: customRoleId, pageId: access.page.id }, select: { id: true } });
    if (!exists) return jsonError(404, "Rôle introuvable.");
  }
  const { count } = await prisma.pageMember.updateMany({
    where: { id: memberId, pageId: access.page.id },
    data: { ...(role ? { role } : {}), ...(customRoleId !== undefined ? { customRoleId } : {}) },
  });
  if (!count) return jsonError(404, "Collaborateur introuvable.");
  if (customRoleId !== undefined) await audit(user.id, "role.assign", "page", access.page.id, { memberId, customRoleId });
  return NextResponse.json({ ok: true });
}

/** Retire un collaborateur (propriétaire, ou le collaborateur lui-même) ou annule une invitation. */
export async function DELETE(request: NextRequest, { params }: Ctx) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["page-members", 30], terms: false });
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "view");
  if (isResponse(access)) return access;
  const memberId = request.nextUrl.searchParams.get("memberId");
  const inviteId = request.nextUrl.searchParams.get("inviteId");

  if (inviteId) {
    if (access.role !== "owner") return jsonError(403, "Réservé au propriétaire de la page.");
    await prisma.pageInvite.deleteMany({ where: { id: inviteId, pageId: access.page.id } });
    return NextResponse.json({ ok: true });
  }
  if (!memberId) return jsonError(400, "Collaborateur manquant.");
  const member = await prisma.pageMember.findFirst({ where: { id: memberId, pageId: access.page.id }, select: { id: true, userId: true } });
  if (!member) return jsonError(404, "Collaborateur introuvable.");
  if (access.role !== "owner" && member.userId !== user.id) return jsonError(403, "Réservé au propriétaire de la page.");
  await prisma.pageMember.delete({ where: { id: member.id } });
  return NextResponse.json({ ok: true });
}
