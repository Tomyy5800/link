import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { isResponse } from "@/lib/server/admin";
import { requireAccountApi, requirePageApi } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { entitlementsFrom } from "@/lib/server/entitlements";
import { jsonError, readJson } from "@/lib/server/http";
import { getSettings } from "@/lib/server/settings";

const schema = z.object({ includeCss: z.boolean().default(false) });

// Kit de marque : applique le thème enregistré de cette page (et, au choix, son CSS) à toutes les
// autres pages du propriétaire. Contenu, blocs et adresses ne changent pas.
export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["brand-kit", 10] });
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "own");
  if (isResponse(access)) return access;
  if (!entitlementsFrom(user, await getSettings()).features.brandKit) return jsonError(403, "Le kit de marque fait partie de la formule Équipe.");
  const parsed = schema.safeParse(await readJson(request, 500).catch(() => ({})));
  if (!parsed.success) return jsonError(400, "Demande invalide.");

  const { count } = await prisma.page.updateMany({
    where: { userId: user.id, id: { not: access.page.id } },
    data: { theme: access.page.theme, ...(parsed.data.includeCss ? { customCss: access.page.customCss } : {}) },
  });
  return NextResponse.json({ ok: true, count });
}
