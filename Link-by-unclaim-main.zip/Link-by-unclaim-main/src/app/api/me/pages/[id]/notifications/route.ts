import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { DISCORD_WEBHOOK, maskWebhook, parseNotifications, type StoredNotifications } from "@/lib/notifications";
import { isResponse } from "@/lib/server/admin";
import { requireAccountApi, requirePageApi } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { entitlementsFrom } from "@/lib/server/entitlements";
import { jsonError, readJson } from "@/lib/server/http";
import { sendTestNotification } from "@/lib/server/notifications";
import { getSettings } from "@/lib/server/settings";

// Notifications Discord d'une page : lecture (adresse masquée), réglage et message de test.
type Ctx = { params: Promise<{ id: string }> };

function view(n: StoredNotifications, allowed: boolean) {
  return { allowed, configured: Boolean(n.discordWebhook), masked: n.discordWebhook ? maskWebhook(n.discordWebhook) : "", onMessage: n.onMessage, onOrder: n.onOrder, weekly: n.weekly };
}

export async function GET(request: NextRequest, { params }: Ctx) {
  const user = await requireAccountApi(request);
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "edit");
  if (isResponse(access)) return access;
  const allowed = entitlementsFrom(access.page.user, await getSettings()).features.webhooks;
  return NextResponse.json(view(parseNotifications(access.page.notifications), allowed));
}

const putSchema = z.object({
  /** Nouvelle adresse ; null : retirer le webhook ; absent : inchangé. */
  discordWebhook: z
    .string()
    .trim()
    .max(200)
    .refine((v) => DISCORD_WEBHOOK.test(v), "Adresse de webhook Discord invalide.")
    .nullable()
    .optional(),
  onMessage: z.boolean(),
  onOrder: z.boolean().optional(),
  weekly: z.boolean(),
});

export async function PUT(request: NextRequest, { params }: Ctx) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["notifications", 20] });
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "edit");
  if (isResponse(access)) return access;
  const allowed = entitlementsFrom(access.page.user, await getSettings()).features.webhooks;
  if (!allowed) return jsonError(403, "Les notifications Discord ne sont pas incluses dans la formule du propriétaire de la page.");
  const parsed = putSchema.safeParse(await readJson(request, 2_000).catch(() => null));
  if (!parsed.success) return jsonError(400, parsed.error.issues[0]?.message ?? "Réglages invalides.");

  const current = parseNotifications(access.page.notifications);
  const next: StoredNotifications = {
    ...current,
    discordWebhook: parsed.data.discordWebhook === undefined ? current.discordWebhook : (parsed.data.discordWebhook ?? ""),
    onMessage: parsed.data.onMessage,
    onOrder: parsed.data.onOrder ?? current.onOrder,
    weekly: parsed.data.weekly,
  };
  await prisma.page.update({ where: { id: access.page.id }, data: { notifications: JSON.stringify(next) } });
  return NextResponse.json(view(next, allowed));
}

/** Envoie un message de test sur le webhook enregistré. */
export async function POST(request: NextRequest, { params }: Ctx) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["notifications-test", 5] });
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "edit");
  if (isResponse(access)) return access;
  const n = parseNotifications(access.page.notifications);
  if (!n.discordWebhook) return jsonError(400, "Enregistre d'abord l'adresse du webhook.");
  const ok = await sendTestNotification(n.discordWebhook, access.page);
  return ok ? NextResponse.json({ ok: true }) : jsonError(502, "Discord a refusé le message : vérifie que le webhook existe toujours.");
}
