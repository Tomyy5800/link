import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { isResponse } from "@/lib/server/admin";
import { requireAccountApi, requirePageApi } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { jsonError, readJson } from "@/lib/server/http";
import { ORDER_STATUSES } from "@/lib/shop";

// Commandes reçues par le bloc « Boutique » d'une page : suivi (statut) et suppression.
type Ctx = { params: Promise<{ id: string }> };

const patchSchema = z.object({ ids: z.array(z.string().max(40)).min(1).max(200), status: z.enum(ORDER_STATUSES) });

export async function PATCH(request: NextRequest, { params }: Ctx) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["orders", 60] });
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "orders");
  if (isResponse(access)) return access;
  const parsed = patchSchema.safeParse(await readJson(request, 10_000).catch(() => null));
  if (!parsed.success) return jsonError(400, "Requête invalide.");
  await prisma.shopOrder.updateMany({ where: { pageId: access.page.id, id: { in: parsed.data.ids } }, data: { status: parsed.data.status } });
  return NextResponse.json({ ok: true });
}

export async function DELETE(request: NextRequest, { params }: Ctx) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["orders", 60], terms: false });
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "orders");
  if (isResponse(access)) return access;
  const id = request.nextUrl.searchParams.get("orderId");
  if (!id) return jsonError(400, "Commande manquante.");
  await prisma.shopOrder.deleteMany({ where: { id, pageId: access.page.id } });
  return NextResponse.json({ ok: true });
}
