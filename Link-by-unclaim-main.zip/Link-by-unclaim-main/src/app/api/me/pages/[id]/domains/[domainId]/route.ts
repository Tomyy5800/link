import { NextResponse, type NextRequest } from "next/server";
import { audit, isResponse } from "@/lib/server/admin";
import { requireAccountApi, requirePageApi } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { domainView, newDomainToken, validateHostname } from "@/lib/server/domains";
import { entitlementsFrom } from "@/lib/server/entitlements";
import { jsonError, readJson } from "@/lib/server/http";
import { getSettings } from "@/lib/server/settings";

type Params = { params: Promise<{ id: string; domainId: string }> };

async function load(request: NextRequest, params: Params["params"], mutation: boolean) {
  const user = await requireAccountApi(request, mutation ? { mutation: true, rate: ["domains", 20] } : {});
  if (isResponse(user)) return user;
  const { id, domainId } = await params;
  const access = await requirePageApi(user, id, "own");
  if (isResponse(access)) return access;
  const domain = await prisma.customDomain.findFirst({ where: { id: domainId, pageId: access.page.id } });
  if (!domain) return jsonError(404, "Domaine introuvable.");
  return { user, access, domain };
}

// Remplacer le domaine (nouvelle vérification complète, nouveau jeton).
export async function PATCH(request: NextRequest, { params }: Params) {
  const ctx = await load(request, params, true);
  if (isResponse(ctx)) return ctx;
  const rights = entitlementsFrom(ctx.user, await getSettings());
  if (!rights.features.customDomains) return jsonError(403, "Les domaines personnels sont réservés aux formules Pro et Équipe.", { code: "feature_locked" });
  const body = (await readJson(request, 1_000).catch(() => null)) as { hostname?: unknown } | null;
  const check = validateHostname(typeof body?.hostname === "string" ? body.hostname : "");
  if (!check.ok) return jsonError(400, check.error);
  if (check.hostname === ctx.domain.hostname) return NextResponse.json({ domain: domainView(ctx.domain) });
  try {
    const domain = await prisma.customDomain.update({
      where: { id: ctx.domain.id },
      data: { hostname: check.hostname, token: newDomainToken(), status: "pending", verifiedAt: null, lastCheck: "{}", lastCheckAt: null },
    });
    await audit(ctx.user.id, "domain.replace", "domain", domain.id, { from: ctx.domain.hostname, to: domain.hostname });
    return NextResponse.json({ domain: domainView(domain) });
  } catch {
    return jsonError(409, "Ce domaine est déjà relié à une page Link by Unclaim.");
  }
}

export async function DELETE(request: NextRequest, { params }: Params) {
  const ctx = await load(request, params, true);
  if (isResponse(ctx)) return ctx;
  await prisma.customDomain.delete({ where: { id: ctx.domain.id } });
  await audit(ctx.user.id, "domain.remove", "domain", ctx.domain.id, { hostname: ctx.domain.hostname });
  return NextResponse.json({ ok: true });
}
