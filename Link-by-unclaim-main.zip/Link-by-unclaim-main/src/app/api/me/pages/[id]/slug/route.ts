import { NextResponse, type NextRequest } from "next/server";
import { isResponse } from "@/lib/server/admin";
import { requireAccountApi, requirePageApi } from "@/lib/server/access";
import { jsonError, readJson } from "@/lib/server/http";
import { entitlementsFrom } from "@/lib/server/entitlements";
import { getSettings } from "@/lib/server/settings";
import { changePageSlug } from "@/lib/server/slugs";
import { validateSlug } from "@/lib/slug";

// Changement de l'adresse personnalisée d'une page (propriétaire uniquement). L'ancienne adresse
// redirige vers la nouvelle et reste réservée 30 jours à son propriétaire.
export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["slug-change", 10] });
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "own");
  if (isResponse(access)) return access;

  const body = (await readJson(request, 2_000).catch(() => null)) as { slug?: unknown } | null;
  const settings = await getSettings();
  const rights = entitlementsFrom(user, settings);
  const check = validateSlug(typeof body?.slug === "string" ? body.slug : "", {
    allowShort: rights.features.shortSlug,
    premiumName: settings.premiumName,
    allowOfficial: rights.admin,
  });
  if (!check.ok) return jsonError(400, check.error);
  if (access.page.slug === check.slug) return NextResponse.json({ slug: check.slug });

  const error = await changePageSlug(access.page, check.slug);
  if (error) return jsonError(409, error);
  return NextResponse.json({ slug: check.slug, previous: access.page.slug });
}
