import { NextResponse, type NextRequest } from "next/server";
import { memberRoleInputSchema } from "@/lib/member-roles";
import { audit, isResponse } from "@/lib/server/admin";
import { requireAccountApi, requirePageApi } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { entitlementsFrom } from "@/lib/server/entitlements";
import { jsonError, readJson } from "@/lib/server/http";
import { toRoleView } from "@/lib/server/member-roles";
import { getSettings } from "@/lib/server/settings";

type Ctx = { params: Promise<{ id: string; roleId: string }> };

async function load(request: NextRequest, params: Ctx["params"]) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["page-roles", 30] });
  if (isResponse(user)) return user;
  const { id, roleId } = await params;
  const access = await requirePageApi(user, id, "own");
  if (isResponse(access)) return access;
  const role = await prisma.memberRole.findFirst({ where: { id: roleId, pageId: access.page.id } });
  if (!role) return jsonError(404, "Rôle introuvable.");
  return { user, access, role };
}

// Modifier un rôle personnalisé (propriétaire, formule qui comprend les rôles personnalisés).
export async function PATCH(request: NextRequest, { params }: Ctx) {
  const ctx = await load(request, params);
  if (isResponse(ctx)) return ctx;
  const rights = entitlementsFrom(ctx.user, await getSettings());
  if (!rights.features.customRoles) return jsonError(403, `Les rôles personnalisés sont réservés à ${rights.premiumName} et aux formules supérieures.`, { code: "feature_locked" });
  const parsed = memberRoleInputSchema.safeParse(await readJson(request, 4_000).catch(() => null));
  if (!parsed.success) return jsonError(400, parsed.error.issues[0]?.message ?? "Rôle invalide.");
  const role = await prisma.memberRole.update({
    where: { id: ctx.role.id },
    data: { ...parsed.data, permissions: JSON.stringify(parsed.data.permissions) },
    include: { _count: { select: { members: true } } },
  });
  await audit(ctx.user.id, "role.update", "page", ctx.access.page.id, { roleId: role.id, name: role.name, permissions: parsed.data.permissions });
  return NextResponse.json({ role: toRoleView(role) });
}

// Supprimer un rôle : ses membres reviennent à leur rôle de base (Éditeur ou Lecteur). Toujours permis.
export async function DELETE(request: NextRequest, { params }: Ctx) {
  const ctx = await load(request, params);
  if (isResponse(ctx)) return ctx;
  await prisma.memberRole.delete({ where: { id: ctx.role.id } });
  await audit(ctx.user.id, "role.delete", "page", ctx.access.page.id, { roleId: ctx.role.id, name: ctx.role.name });
  return NextResponse.json({ ok: true });
}
