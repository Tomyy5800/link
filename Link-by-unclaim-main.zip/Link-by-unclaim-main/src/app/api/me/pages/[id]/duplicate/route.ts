import { randomUUID } from "node:crypto";
import { NextResponse, type NextRequest } from "next/server";
import { isResponse } from "@/lib/server/admin";
import { ownedPageCount, requireAccountApi, requirePageApi } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { entitlementsFrom, suspension } from "@/lib/server/entitlements";
import { jsonError } from "@/lib/server/http";
import { getSettings } from "@/lib/server/settings";
import { releaseRedirect, slugAvailability } from "@/lib/server/slugs";
import { validateSlug } from "@/lib/slug";

/** Première adresse libre de la forme « base-copie », « base-copie-2 »… */
async function freeSlug(base: string, opts: { premiumName: string; userId: string; allowOfficial: boolean }): Promise<string | null> {
  const stem = base.slice(0, 22);
  for (let i = 1; i <= 20; i++) {
    const candidate = i === 1 ? `${stem}-copie` : `${stem}-copie-${i}`;
    const check = validateSlug(candidate, { allowShort: true, premiumName: opts.premiumName, allowOfficial: opts.allowOfficial });
    if (!check.ok) continue;
    if ((await slugAvailability(check.slug, opts.userId)).available) return check.slug;
  }
  return null;
}

// Duplique une page du compte (blocs, profil, thème, options), en privé, sous une nouvelle adresse.
export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["page-duplicate", 10] });
  if (isResponse(user)) return user;
  const access = await requirePageApi(user, (await params).id, "own");
  if (isResponse(access)) return access;

  const settings = await getSettings();
  const rights = entitlementsFrom(user, settings);
  if (suspension(user)) return jsonError(403, "Ton compte est suspendu.");
  if ((await ownedPageCount(user.id)) >= rights.limits.pages) {
    return jsonError(403, `Ta formule permet ${rights.limits.pages} page${rights.limits.pages > 1 ? "s" : ""}.`, { code: "page_limit" });
  }
  const slug = await freeSlug(access.page.slug, { premiumName: settings.premiumName, userId: user.id, allowOfficial: rights.admin });
  if (!slug) return jsonError(409, "Impossible de trouver une adresse libre pour la copie.");

  const source = await prisma.page.findUniqueOrThrow({ where: { id: access.page.id }, include: { blocks: true } });
  // Nouveaux identifiants de blocs, reportés dans les options (automatisations qui visent un bloc).
  const ids = new Map(source.blocks.map((b) => [b.id, randomUUID()]));
  let options = source.options;
  for (const [from, to] of ids) options = options.split(from).join(to);
  const copy = await prisma.page.create({
    data: {
      slug,
      userId: user.id,
      label: `Copie de ${source.label || source.displayName}`.slice(0, 40),
      displayName: source.displayName,
      pronouns: source.pronouns,
      bio: source.bio,
      avatarSource: source.avatarSource,
      avatarUrl: source.avatarUrl,
      bannerUrl: source.bannerUrl,
      ngUsername: source.ngUsername,
      ngServer: source.ngServer,
      theme: source.theme,
      customCss: source.customCss,
      options,
      // Une copie commence en privé : on la publie quand elle est prête.
      published: false,
      blocks: {
        create: source.blocks.map((b) => ({
          id: ids.get(b.id)!,
          type: b.type,
          position: b.position,
          width: b.width,
          colSpan: b.colSpan,
          rowSpan: b.rowSpan,
          style: b.style,
          visible: b.visible,
          startsAt: b.startsAt,
          endsAt: b.endsAt,
          data: b.data,
        })),
      },
    },
    select: { id: true, slug: true },
  });
  await releaseRedirect(copy.slug);
  return NextResponse.json(copy, { status: 201 });
}
