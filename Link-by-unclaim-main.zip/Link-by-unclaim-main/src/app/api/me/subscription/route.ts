import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { audit, isResponse } from "@/lib/server/admin";
import { requireAccountApi } from "@/lib/server/access";
import { jsonError, readJson } from "@/lib/server/http";
import { PaymentError, billingPortalUrl, setCancelAtPeriodEnd } from "@/lib/server/payments";

const actionSchema = z.object({ action: z.enum(["cancel", "resume", "portal"]) });

// Gestion de l'abonnement par son titulaire : résiliation (à la fin de la période payée),
// reprise d'un abonnement résilié, portail de facturation Stripe (carte, factures).
export async function POST(request: NextRequest) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["subscription", 10] });
  if (isResponse(user)) return user;
  const parsed = actionSchema.safeParse(await readJson(request, 500).catch(() => null));
  if (!parsed.success) return jsonError(400, "Action invalide.");
  try {
    if (parsed.data.action === "portal") return NextResponse.json({ url: await billingPortalUrl(user) });
    const cancel = parsed.data.action === "cancel";
    const sub = await setCancelAtPeriodEnd(user.id, cancel);
    await audit(user.id, cancel ? "subscription.cancel" : "subscription.resume", "subscription", sub?.providerRef ?? "", {});
    return NextResponse.json({ subscription: sub ? { status: sub.status, cancelAtPeriodEnd: sub.cancelAtPeriodEnd, currentPeriodEnd: sub.currentPeriodEnd } : null });
  } catch (error) {
    if (error instanceof PaymentError) return jsonError(error.status, error.message);
    console.error("[paiement] gestion de l'abonnement impossible", error);
    return jsonError(500, "L'action n'a pas pu aboutir. Réessaie dans un instant.");
  }
}
