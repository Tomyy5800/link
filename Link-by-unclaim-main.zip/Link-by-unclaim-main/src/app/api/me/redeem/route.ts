import { NextResponse, type NextRequest } from "next/server";
import { guardMutation, guardRate, jsonError, readJson } from "@/lib/server/http";
import { redeemCode } from "@/lib/server/premium";
import { getCurrentUser } from "@/lib/server/unclaim-auth";

// Échange d'un code Link+ (essais limités pour empêcher de deviner des codes).
export async function POST(request: NextRequest) {
  const blocked = guardMutation(request) ?? guardRate(request, "redeem", 8, 15 * 60_000);
  if (blocked) return blocked;
  const user = await getCurrentUser();
  if (!user) return jsonError(401, "Connexion requise.");

  const body = (await readJson(request, 1_000).catch(() => null)) as { code?: unknown } | null;
  if (typeof body?.code !== "string") return jsonError(400, "Code manquant.");

  const result = await redeemCode(user.id, body.code);
  if (!result.ok) return jsonError(400, result.error);
  return NextResponse.json({ ok: true, plan: result.plan, planExpiresAt: result.planExpiresAt, days: result.days });
}
