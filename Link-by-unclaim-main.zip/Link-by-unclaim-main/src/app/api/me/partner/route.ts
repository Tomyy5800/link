import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { PARTNER_KIND_KEYS } from "@/lib/partners";
import { isResponse } from "@/lib/server/admin";
import { requireAccountApi } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { jsonError, readJson, zodDetails } from "@/lib/server/http";
import { normalizeUrl } from "@/lib/urls";

// Candidature au programme partenaires (une seule à la fois, examinée par l'administration).
const schema = z.object({
  kind: z.enum(PARTNER_KIND_KEYS as [string, ...string[]], "Choisis un type de partenariat."),
  name: z.string().trim().min(2, "Indique le nom du projet.").max(60),
  url: z
    .string()
    .trim()
    .max(300)
    .transform((v) => (v ? (normalizeUrl(v) ?? "") : ""))
    .default(""),
  audience: z.string().trim().max(120).default(""),
  message: z.string().trim().min(20, "Présente ton projet en quelques phrases (20 caractères au moins).").max(1500),
});

export async function POST(request: NextRequest) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["partner-apply", 5] });
  if (isResponse(user)) return user;
  if (user.partner) return jsonError(409, "Tu es déjà partenaire officiel.");
  const parsed = schema.safeParse(await readJson(request, 8_000).catch(() => null));
  if (!parsed.success) return jsonError(400, parsed.error.issues[0]?.message ?? "Candidature invalide.", zodDetails(parsed.error));

  const pending = await prisma.partnerApplication.findFirst({ where: { userId: user.id, status: "pending" }, select: { id: true } });
  if (pending) return jsonError(409, "Ta candidature est déjà en cours d'examen.");

  const application = await prisma.partnerApplication.create({
    data: { userId: user.id, ...parsed.data },
    select: { id: true, status: true, createdAt: true },
  });
  return NextResponse.json({ application }, { status: 201 });
}
