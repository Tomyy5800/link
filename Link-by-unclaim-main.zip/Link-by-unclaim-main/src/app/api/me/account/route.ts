import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { isResponse } from "@/lib/server/admin";
import { requireAccountApi } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { jsonError, readJson } from "@/lib/server/http";
import { deletePage } from "@/lib/server/pages";
import { deleteUploads } from "@/lib/server/storage";
import { endSession } from "@/lib/server/unclaim-auth";

// Suppression du compte (droit à l'effacement) : pages, fichiers, collaborations, candidatures et
// sessions sont effacés. Les commandes sont conservées 10 ans (obligation comptable) : le compte
// est alors anonymisé au lieu d'être supprimé. Le compte Unclaim Auth, lui, n'est pas touché.
const schema = z.object({ confirm: z.literal("SUPPRIMER", "Tape SUPPRIMER pour confirmer.") });

export async function DELETE(request: NextRequest) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["account-delete", 5], terms: false });
  if (isResponse(user)) return user;
  const parsed = schema.safeParse(await readJson(request, 1_000).catch(() => null));
  if (!parsed.success) return jsonError(400, parsed.error.issues[0]?.message ?? "Confirmation requise.");

  const pages = await prisma.page.findMany({ where: { userId: user.id }, select: { id: true } });
  for (const page of pages) await deletePage(page.id);
  const uploads = await prisma.upload.findMany({ where: { userId: user.id }, select: { id: true } });
  await deleteUploads(uploads.map((u) => u.id), user.id);

  const orders = await prisma.order.count({ where: { userId: user.id } });
  if (orders > 0) {
    await prisma.$transaction([
      prisma.pageMember.deleteMany({ where: { userId: user.id } }),
      prisma.partnerApplication.deleteMany({ where: { userId: user.id } }),
      prisma.session.deleteMany({ where: { userId: user.id } }),
      prisma.user.update({
        where: { id: user.id },
        data: {
          unclaimId: null,
          discordId: null,
          username: "compte-supprime",
          globalName: null,
          avatarUrl: null,
          avatarHash: null,
          bannerHash: null,
          accentColor: null,
          identities: "[]",
          ngAccount: null,
          role: "user",
          verified: false,
          partner: false,
          deletedAt: new Date(),
        },
      }),
    ]);
  } else {
    await prisma.user.delete({ where: { id: user.id } });
  }

  const response = NextResponse.json({ ok: true });
  await endSession(response);
  return response;
}
