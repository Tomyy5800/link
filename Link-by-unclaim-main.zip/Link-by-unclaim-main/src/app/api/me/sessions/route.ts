import { cookies } from "next/headers";
import { NextResponse, type NextRequest } from "next/server";
import { isResponse } from "@/lib/server/admin";
import { requireAccountApi } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { sha256 } from "@/lib/server/security";
import { SESSION_COOKIE } from "@/lib/server/unclaim-auth";

// Sessions ouvertes du compte : déconnexion de tous les autres appareils.
export async function DELETE(request: NextRequest) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["sessions", 10], terms: false });
  if (isResponse(user)) return user;
  const token = (await cookies()).get(SESSION_COOKIE)?.value ?? "";
  const { count } = await prisma.session.deleteMany({ where: { userId: user.id, id: { not: sha256(token) } } });
  return NextResponse.json({ ok: true, closed: count });
}
