import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { isResponse } from "@/lib/server/admin";
import { requireAccountApi } from "@/lib/server/access";
import { PREF_SOURCE, badgesOf } from "@/lib/server/badges";
import { prisma } from "@/lib/server/db";
import { jsonError, readJson } from "@/lib/server/http";

const schema = z.object({ badgeId: z.string().regex(/^[a-z0-9]{8,40}$/i), hidden: z.boolean() });

// Affichage de ses propres badges sur ses pages : on peut masquer (ou réafficher) un badge qu'on
// possède. Rien ici ne permet d'obtenir un badge : seul le serveur décide de qui possède quoi.
export async function PATCH(request: NextRequest) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["my-badges", 30] });
  if (isResponse(user)) return user;
  const parsed = schema.safeParse(await readJson(request, 500).catch(() => null));
  if (!parsed.success) return jsonError(400, "Demande invalide.");
  const owned = (await badgesOf(user)).find((o) => o.badge.id === parsed.data.badgeId);
  if (!owned) return jsonError(404, "Tu n'as pas ce badge.");
  if (owned.grant) {
    await prisma.userBadge.update({ where: { id: owned.grant.id }, data: { hidden: parsed.data.hidden } });
  } else {
    // Badge calculé (formule, ancienneté…) : on enregistre seulement la préférence d'affichage.
    await prisma.userBadge.upsert({
      where: { userId_badgeId: { userId: user.id, badgeId: owned.badge.id } },
      create: { userId: user.id, badgeId: owned.badge.id, source: PREF_SOURCE, hidden: parsed.data.hidden },
      update: { hidden: parsed.data.hidden },
    });
  }
  return NextResponse.json({ ok: true, hidden: parsed.data.hidden });
}
