import { NextResponse } from "next/server";
import { parseIdentities } from "@/lib/identity";
import { prisma } from "@/lib/server/db";
import { guardRate, jsonError } from "@/lib/server/http";
import { toPageView, viewsByDay } from "@/lib/server/pages";
import { parseOrderItems } from "@/lib/shop";
import { getCurrentUser } from "@/lib/server/unclaim-auth";

// Export de ses données (droit d'accès et de portabilité, RGPD) : compte, pages, collaborations,
// messages reçus, commandes de la boutique, statistiques, candidatures et achats.
// Les empreintes de visiteurs, jetons et sessions ne sont jamais exportés.
export async function GET(request: Request) {
  const limited = guardRate(request, "export", 5, 10 * 60_000);
  if (limited) return limited;
  const user = await getCurrentUser();
  if (!user) return jsonError(401, "Connexion requise.");

  const [pages, memberships, orders, redemptions, applications, badges, subscriptions, unlocks, domains] = await Promise.all([
    prisma.page.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "asc" },
      include: {
        blocks: true,
        members: { select: { role: true, createdAt: true, user: { select: { username: true, globalName: true } } } },
        messages: { orderBy: { createdAt: "asc" }, select: { name: true, contact: true, message: true, createdAt: true } },
        shopOrders: { orderBy: { createdAt: "asc" }, select: { items: true, total: true, currency: true, name: true, contact: true, note: true, status: true, createdAt: true } },
      },
    }),
    prisma.pageMember.findMany({ where: { userId: user.id }, select: { role: true, createdAt: true, page: { select: { slug: true } } } }),
    prisma.order.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "asc" },
      select: { offerName: true, days: true, amountCents: true, currency: true, status: true, gift: true, createdAt: true, paidAt: true, refundedAt: true },
    }),
    prisma.codeRedemption.count({ where: { userId: user.id } }),
    prisma.partnerApplication.findMany({
      where: { userId: user.id },
      select: { kind: true, name: true, url: true, audience: true, message: true, status: true, createdAt: true, reviewedAt: true },
    }),
    prisma.userBadge.findMany({ where: { userId: user.id }, select: { source: true, hidden: true, expiresAt: true, createdAt: true, badge: { select: { key: true, name: true } } } }),
    prisma.subscription.findMany({
      where: { userId: user.id },
      select: { tier: true, interval: true, amountCents: true, currency: true, status: true, currentPeriodEnd: true, cancelAtPeriodEnd: true, canceledAt: true, createdAt: true },
    }),
    prisma.userUnlock.findMany({ where: { userId: user.id }, select: { kind: true, key: true, createdAt: true } }),
    prisma.customDomain.findMany({ where: { userId: user.id }, select: { hostname: true, status: true, verifiedAt: true, createdAt: true, page: { select: { slug: true } } } }),
  ]);

  const data = {
    format: "link-by-unclaim/export@2",
    exportedAt: new Date().toISOString(),
    account: {
      id: user.id,
      unclaimId: user.unclaimId,
      provider: user.provider,
      username: user.username,
      displayName: user.globalName,
      discordId: user.discordId,
      linkedAccounts: parseIdentities(user.identities),
      nationsGloryAccount: user.ngAccount,
      plan: user.plan,
      planExpiresAt: user.planExpiresAt,
      verified: user.verified,
      partner: user.partner,
      termsVersion: user.termsVersion,
      termsAcceptedAt: user.termsAcceptedAt,
      createdAt: user.createdAt,
      lastLoginAt: user.lastLoginAt,
      redeemedCodes: redemptions,
    },
    pages: await Promise.all(
      pages.map(async (row) => ({
        ...toPageView(row),
        label: row.label,
        createdAt: row.createdAt,
        updatedAt: row.updatedAt,
        collaborators: row.members.map((m) => ({ name: m.user.globalName ?? m.user.username, role: m.role, since: m.createdAt })),
        contactMessages: row.messages,
        shopOrders: row.shopOrders.map((o) => ({ ...o, items: parseOrderItems(o.items) })),
        statistics: { totalViews: row.views, last120Days: await viewsByDay(row.id, 120) },
      })),
    ),
    collaborations: memberships.map((m) => ({ page: m.page.slug, role: m.role, since: m.createdAt })),
    partnerApplications: applications,
    orders,
    subscriptions,
    badges: badges.map((b) => ({ badge: b.badge.name, key: b.badge.key, source: b.source, hidden: b.hidden, expiresAt: b.expiresAt, since: b.createdAt })),
    unlocks,
    customDomains: domains.map((d) => ({ hostname: d.hostname, page: d.page.slug, status: d.status, verifiedAt: d.verifiedAt, createdAt: d.createdAt })),
  };

  const name = `link-by-unclaim-${user.username.replace(/[^a-z0-9_-]/gi, "") || "compte"}-${new Date().toISOString().slice(0, 10)}.json`;
  return new NextResponse(JSON.stringify(data, null, 2), {
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Content-Disposition": `attachment; filename="${name}"`,
      "Cache-Control": "no-store",
    },
  });
}
