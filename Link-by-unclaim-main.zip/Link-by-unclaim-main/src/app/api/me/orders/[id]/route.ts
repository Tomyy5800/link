import { NextResponse } from "next/server";
import { prisma } from "@/lib/server/db";
import { syncCheckout } from "@/lib/server/payments";
import { jsonError } from "@/lib/server/http";
import { getCurrentUser } from "@/lib/server/unclaim-auth";

// État d'une commande de l'utilisateur connecté (page de retour après paiement).
export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return jsonError(401, "Connexion requise.");
  const { id } = await params;
  const select = { id: true, status: true, offerName: true, days: true, amountCents: true, gift: true, giftCode: true, paidAt: true } as const;
  let order = await prisma.order.findFirst({ where: { id, userId: user.id }, select: { ...select, providerRef: true } });
  if (!order) return jsonError(404, "Commande introuvable.");
  // Paiement pas encore confirmé par le webhook : on demande directement à Stripe.
  if (order.status === "pending" && (await syncCheckout(order))) {
    order = await prisma.order.findFirst({ where: { id, userId: user.id }, select: { ...select, providerRef: true } });
    if (!order) return jsonError(404, "Commande introuvable.");
  }
  const { providerRef: _ref, ...publicOrder } = order;
  const fresh = await prisma.user.findUnique({ where: { id: user.id }, select: { plan: true, planExpiresAt: true } });
  return NextResponse.json({ order: publicOrder, plan: fresh }, { headers: { "Cache-Control": "no-store" } });
}
