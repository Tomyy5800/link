import { NextResponse, type NextRequest } from "next/server";
import { toOwnerProfile } from "@/lib/discord-cdn";
import { env } from "@/lib/server/env";
import { guardMutation, guardRate, jsonError } from "@/lib/server/http";
import { getCurrentUser } from "@/lib/server/unclaim-auth";
import { syncFromUnclaim } from "@/lib/server/unclaim-auth/sync";

// Resynchronise le profil du compte depuis Unclaim Auth (nom, avatar, comptes rattachés).
export async function POST(request: NextRequest) {
  const blocked = guardMutation(request) ?? guardRate(request, "profile-sync", 5);
  if (blocked) return blocked;
  const user = await getCurrentUser();
  if (!user) return jsonError(401, "Connexion requise.");
  if (!env.unclaim.configured || !user.unclaimId) {
    return jsonError(400, "Synchronisation indisponible : reconnecte-toi pour mettre à jour ton profil.");
  }
  const updated = await syncFromUnclaim(user, { force: true });
  if (updated.banned) return jsonError(403, "Ce compte est bloqué dans Unclaim Auth.");
  return NextResponse.json({ owner: toOwnerProfile(updated) });
}
