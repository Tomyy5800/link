import { NextResponse, type NextRequest } from "next/server";
import { isResponse } from "@/lib/server/admin";
import { requireAccountApi } from "@/lib/server/access";
import { jsonError } from "@/lib/server/http";
import { InviteError, acceptInvite } from "@/lib/server/invites";

// Acceptation d'une invitation à collaborer sur une page.
export async function POST(request: NextRequest, { params }: { params: Promise<{ token: string }> }) {
  const user = await requireAccountApi(request, { mutation: true, rate: ["invite-accept", 20] });
  if (isResponse(user)) return user;
  try {
    const pageId = await acceptInvite(user, (await params).token);
    return NextResponse.json({ pageId });
  } catch (error) {
    if (error instanceof InviteError) return jsonError(410, error.message);
    throw error;
  }
}
