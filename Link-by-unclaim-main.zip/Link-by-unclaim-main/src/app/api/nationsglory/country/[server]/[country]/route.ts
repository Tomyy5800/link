import { NextResponse, type NextRequest } from "next/server";
import { guardRate } from "@/lib/server/http";
import { getNgCountry } from "@/lib/server/nationsglory";

// Fiche d'un pays NationsGlory (par country_id, ou par nom pour les anciens blocs).
export async function GET(request: NextRequest, { params }: { params: Promise<{ server: string; country: string }> }) {
  const limited = guardRate(request, "ng-country", 40);
  if (limited) return limited;
  const { server, country } = await params;
  let id = country;
  try {
    id = decodeURIComponent(country);
  } catch {
    // déjà décodé : la validation s'en charge
  }
  const result = await getNgCountry(server, id);
  return NextResponse.json(result, {
    status: result.status === "invalid" ? 400 : 200,
    headers: { "Cache-Control": result.status === "ok" ? "public, max-age=60, s-maxage=300" : "no-store" },
  });
}
