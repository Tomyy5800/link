import { NextResponse } from "next/server";
import { getNgServers, nationsGloryReady } from "@/lib/server/nationsglory";

// Serveurs NationsGlory qui publient des données (liste de l'API v1, en cache 6 h).
export async function GET() {
  const servers = await getNgServers();
  return NextResponse.json({ servers, mode: nationsGloryReady() }, { headers: { "Cache-Control": "public, max-age=600" } });
}
