import { NextResponse, type NextRequest } from "next/server";
import { guardRate } from "@/lib/server/http";
import { getNationsGloryProfile } from "@/lib/server/nationsglory";

// Proxy serveur vers l'API NationsGlory v1 : la clé d'API ne quitte jamais le serveur.
// GET /api/nationsglory/user/<pseudo>?servers=blue,coral
export async function GET(request: NextRequest, { params }: { params: Promise<{ username: string }> }) {
  const limited = guardRate(request, "ng-user", 40);
  if (limited) return limited;
  const { username } = await params;
  const servers = (request.nextUrl.searchParams.get("servers") ?? "blue").split(",").slice(0, 3);
  const profile = await getNationsGloryProfile(username, servers);
  return NextResponse.json(profile, {
    status: profile.status === "invalid" ? 400 : 200,
    headers: { "Cache-Control": profile.status === "ok" ? "public, max-age=60, s-maxage=300" : "no-store" },
  });
}
