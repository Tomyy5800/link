import { NextResponse, type NextRequest } from "next/server";
import { guardRate, jsonError } from "@/lib/server/http";
import { listNgCountries, nationsGloryReady } from "@/lib/server/nationsglory";
import { getCurrentUser } from "@/lib/server/unclaim-auth";

function fold(text: string): string {
  return text.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
}

// Recherche de pays pour le sélecteur de l'éditeur (connexion requise, liste en cache 30 min).
// GET /api/nationsglory/countries/<serveur>?q=fra
export async function GET(request: NextRequest, { params }: { params: Promise<{ server: string }> }) {
  const limited = guardRate(request, "ng-countries", 60);
  if (limited) return limited;
  if (!(await getCurrentUser())) return jsonError(401, "Connexion requise.");
  const { server } = await params;
  const q = fold((request.nextUrl.searchParams.get("q") ?? "").trim()).slice(0, 64);
  const all = await listNgCountries(server);
  const results = (q ? all.filter((c) => fold(c.name).includes(q)) : all).slice(0, 20);
  return NextResponse.json({ results, total: all.length, mode: nationsGloryReady() });
}
