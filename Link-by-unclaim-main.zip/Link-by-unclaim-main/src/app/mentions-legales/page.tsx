import type { Metadata } from "next";
import { Fill, LegalPage, LegalSection } from "@/components/site/Legal";
import { getSettings } from "@/lib/server/settings";
import { getCurrentUser } from "@/lib/server/unclaim-auth";

export const metadata: Metadata = { title: "Mentions légales" };

export default async function LegalNoticePage() {
  const [settings, user] = await Promise.all([getSettings(), getCurrentUser()]);
  const { legal } = settings;
  return (
    <LegalPage title="Mentions légales" updated="15 octobre 2026" loggedIn={Boolean(user)} premiumName={settings.premiumName}>
      <LegalSection title="Éditeur">
        <p>
          <Fill value={legal.sellerName} label="Nom ou raison sociale" />
          <br />
          <Fill value={legal.status} label="Statut juridique" />
          <br />
          <Fill value={legal.address} label="Adresse" />
          <br />
          SIREN / SIRET : <Fill value={legal.siret} label="Numéro" />
          <br />
          Contact : <Fill value={legal.email} label="E-mail" />
          {legal.vatMention && (
            <>
              <br />
              {legal.vatMention}
            </>
          )}
        </p>
        <p>
          Directeur de la publication : <Fill value={legal.publisher} label="Nom" />
        </p>
      </LegalSection>
      <LegalSection title="Hébergement">
        <p>
          <Fill value={legal.host} label="Hébergeur (nom, adresse, téléphone)" />
        </p>
      </LegalSection>
      <LegalSection title="Contenus des utilisateurs">
        <p>
          Les pages publiques sont créées par leurs titulaires, seuls responsables de leur contenu. Link by Unclaim agit en hébergeur : tout contenu
          manifestement illicite peut être signalé avec le lien « Signaler » présent en bas de chaque page, ou par e-mail.
        </p>
      </LegalSection>
      <LegalSection title="Marques">
        <p>
          Link by Unclaim est un projet indépendant, non affilié à Discord, NationsGlory, Google, Microsoft, Apple ni Twitch. Les noms et logos de ces
          services appartiennent à leurs propriétaires.
        </p>
      </LegalSection>
    </LegalPage>
  );
}
