import type { MetadataRoute } from "next";

// Manifeste web : nom, couleurs et icône quand la page est ajoutée à l'écran d'accueil d'un téléphone.
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Link by Unclaim",
    short_name: "Link",
    description: "Ta page de profil : liens, réseaux, radio, NationsGlory et skin 3D, en un seul lien.",
    start_url: "/dashboard",
    display: "standalone",
    background_color: "#020618",
    theme_color: "#020618",
    lang: "fr",
    icons: [{ src: "/icon.svg", sizes: "any", type: "image/svg+xml" }],
  };
}
