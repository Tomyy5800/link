import type { Metadata, Viewport } from "next";
import { notFound, permanentRedirect } from "next/navigation";
import { after } from "next/server";
import { PublicPageView, canViewPrivate, loadPublicPage, publicMetadata } from "@/components/page/PublicPageView";
import { maybeRunJobs } from "@/lib/server/jobs";
import { resolveOldSlug } from "@/lib/server/slugs";

type Params = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { slug } = await params;
  return publicMetadata(await loadPublicPage(slug));
}

// Discord colore l'aperçu du lien avec theme-color : on reprend l'accent de la page.
export async function generateViewport({ params }: Params): Promise<Viewport> {
  const { slug } = await params;
  const data = await loadPublicPage(slug);
  return { themeColor: data && !data.suspended ? data.page.theme.accent : "#020618" };
}

export default async function PublicPage({ params }: Params) {
  const { slug } = await params;
  after(() => maybeRunJobs().catch(() => undefined));
  const data = await loadPublicPage(slug);
  if (!data) {
    // Ancienne adresse d'une page qui a changé d'adresse : redirection permanente.
    const moved = await resolveOldSlug(decodeURIComponent(slug).toLowerCase());
    if (moved) permanentRedirect(`/${moved}`);
    notFound();
  }
  if (!data.page.published && !(await canViewPrivate(data))) notFound();
  return <PublicPageView data={data} />;
}
