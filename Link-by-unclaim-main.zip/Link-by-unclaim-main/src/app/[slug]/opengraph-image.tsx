import { ImageResponse } from "next/og";
import { discordAvatarPngUrl } from "@/lib/discord-cdn";
import { getPageBySlug } from "@/lib/server/pages";
import { env } from "@/lib/server/env";
import { plainText } from "@/lib/text";
import { readableOn } from "@/lib/theme";

// Image d'aperçu (Discord, X, etc.) générée à partir du thème de la page.
export const alt = "Page Link by Unclaim";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default async function OpenGraphImage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const data = await getPageBySlug(slug);

  if (!data || !data.page.published) {
    return new ImageResponse(
      (
        <div style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", background: "#0b0b12", color: "#ececf3", fontSize: 56 }}>
          Link by Unclaim
        </div>
      ),
      size,
    );
  }

  const { page, user } = data;
  const { theme, profile } = page;
  // Les GIF et images importées ne sont pas pris en charge par le moteur de rendu : avatar PNG/JPEG uniquement.
  const avatar =
    profile.avatarSource === "nationsglory" && profile.ngUsername
      ? `${env.nationsglory.skinsUrl}/face/${encodeURIComponent(profile.ngUsername)}/128`
      : user.discordId
        ? discordAvatarPngUrl(user.discordId, user.avatarHash, 256)
        : user.avatarUrl && /^https:\/\//.test(user.avatarUrl)
          ? user.avatarUrl
          : null;
  const radius = theme.avatarShape === "circle" ? 999 : theme.avatarShape === "rounded" ? 56 : 0;
  const background =
    theme.bgType === "gradient"
      ? `linear-gradient(${theme.bgAngle}deg, ${theme.bgColor}, ${theme.bgColor2})`
      : theme.bgColor;
  const bio = plainText(profile.bio).slice(0, 140);
  const address = `${new URL(env.appUrl).host}/${page.slug}`;

  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", display: "flex", background, color: theme.text, padding: 72, fontFamily: "sans-serif" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 56, width: "100%" }}>
          {avatar ? (
            <img src={avatar} width={240} height={240} alt="" style={{ borderRadius: radius, border: `8px solid ${theme.accent}` }} />
          ) : (
            <div
              style={{
                width: 240,
                height: 240,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                borderRadius: radius,
                border: `8px solid ${theme.accent}`,
                background: theme.accent,
                color: readableOn(theme.accent),
                fontSize: 120,
                fontWeight: 700,
              }}
            >
              {(profile.displayName.trim()[0] ?? "?").toUpperCase()}
            </div>
          )}
          <div style={{ display: "flex", flexDirection: "column", flex: 1, gap: 18 }}>
            <div style={{ fontSize: 76, fontWeight: 700, lineHeight: 1.05 }}>{profile.displayName.slice(0, 32)}</div>
            {bio && <div style={{ fontSize: 32, opacity: 0.78, lineHeight: 1.3 }}>{bio}</div>}
            <div style={{ display: "flex", marginTop: 18 }}>
              <div
                style={{
                  display: "flex",
                  background: theme.accent,
                  color: readableOn(theme.accent),
                  borderRadius: 999,
                  padding: "10px 26px",
                  fontSize: 28,
                  fontWeight: 700,
                }}
              >
                {address}
              </div>
            </div>
          </div>
        </div>
      </div>
    ),
    size,
  );
}
