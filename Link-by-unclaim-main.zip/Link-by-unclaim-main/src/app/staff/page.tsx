import type { Metadata } from "next";
import Link from "next/link";
import { ArrowUpRight, ShieldCheck } from "lucide-react";
import { BadgeList, OfficialSeal } from "@/components/badges/OfficialBadge";
import { PageTransition } from "@/components/site/PageTransition";
import { SiteFooter, SiteHeader } from "@/components/site/SiteChrome";
import { parseBadgeRule } from "@/lib/badges";
import { toOwnerProfile } from "@/lib/discord-cdn";
import { computedWhere, ensureSystemBadges, PREF_SOURCE, publicBadgesOf } from "@/lib/server/badges";
import { prisma } from "@/lib/server/db";
import { getSettings } from "@/lib/server/settings";
import { getCurrentUser } from "@/lib/server/unclaim-auth";

export const metadata: Metadata = {
  title: "L'équipe Unclaim",
  description: "Les membres officiels de l'équipe Unclaim : fondateurs, administrateurs, développeurs, modérateurs et staff.",
};

// Page staff : les comptes qui portent un badge du staff (visible), avec leurs badges officiels.
export default async function StaffPage() {
  const [viewer, settings] = await Promise.all([getCurrentUser(), getSettings()]);
  await ensureSystemBadges();
  const staffBadges = await prisma.badge.findMany({ where: { staffOnly: true, active: true, archivedAt: null, visibility: "public" }, orderBy: { position: "asc" } });

  // Titulaires : attributions enregistrées (non expirées, non masquées) et badges calculés (Fondateur).
  const now = new Date();
  const ids = new Map<string, number>();
  for (const badge of staffBadges) {
    const rule = parseBadgeRule(badge.rule);
    const computed = computedWhere(rule, now);
    const users = computed
      ? await prisma.user.findMany({ where: { deletedAt: null, banned: false, suspendedAt: null, AND: [computed] }, select: { id: true, badges: { where: { badgeId: badge.id, hidden: true }, select: { id: true } } } })
      : (
          await prisma.userBadge.findMany({
            where: { badgeId: badge.id, hidden: false, source: { not: PREF_SOURCE }, OR: [{ expiresAt: null }, { expiresAt: { gt: now } }], user: { deletedAt: null, banned: false, suspendedAt: null } },
            select: { userId: true },
          })
        ).map((g) => ({ id: g.userId, badges: [] }));
    for (const u of users) if (!u.badges.length && !ids.has(u.id)) ids.set(u.id, badge.position);
  }
  const accounts = await prisma.user.findMany({
    where: { id: { in: [...ids.keys()] } },
    include: { pages: { where: { published: true, status: "active" }, orderBy: { createdAt: "asc" }, take: 1, select: { slug: true } } },
  });
  accounts.sort((a, b) => (ids.get(a.id) ?? 0) - (ids.get(b.id) ?? 0));
  const members = await Promise.all(accounts.map(async (u) => ({ user: u, profile: toOwnerProfile(u), badges: await publicBadgesOf(u) })));

  return (
    <PageTransition>
      <div className="bg-hud min-h-screen">
        <SiteHeader loggedIn={Boolean(viewer)} premiumName={settings.premiumName} />
        <main className="mx-auto max-w-6xl px-4 pt-14 pb-20 sm:px-6">
          <p className="hud-label inline-flex items-center gap-2 text-claim">
            <ShieldCheck size={14} aria-hidden="true" /> Équipe officielle
          </p>
          <h1 className="mt-3 max-w-3xl font-display text-4xl font-bold tracking-tight text-balance sm:text-5xl">Les personnes derrière Unclaim.</h1>
          <p className="mt-4 max-w-2xl text-lg text-ink-300">
            Seuls les comptes listés ici font partie de l&apos;équipe. Leurs badges sont attribués par l&apos;administration (ou par leurs rôles sur le serveur Discord officiel) et ne
            peuvent pas être obtenus autrement.
          </p>
          <p className="mt-3 inline-flex items-center gap-2 text-sm text-ink-400">
            <OfficialSeal size={14} /> Le sceau doré signale un badge validé officiellement par Unclaim.
          </p>

          {members.length === 0 ? (
            <div className="mt-12 rounded-xl border border-dashed border-ink-600 p-10 text-center">
              <p className="font-semibold text-ink-200">L&apos;équipe se présente bientôt.</p>
              <p className="mt-1 text-sm text-ink-400">Aucun badge du staff n&apos;est encore attribué.</p>
            </div>
          ) : (
            <ul className="ui-stagger mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {members.map(({ user, profile, badges }) => {
                const slug = user.pages[0]?.slug;
                const card = (
                  <>
                    <div className="flex items-center gap-3">
                      <img src={profile.avatarUrl} alt="" className="h-14 w-14 shrink-0 rounded-full object-cover ring-2 ring-white/10" loading="lazy" />
                      <div className="min-w-0">
                        <p className="truncate font-display text-lg font-bold text-ink-100">{profile.globalName ?? profile.username}</p>
                        {slug && <p className="truncate font-mono text-xs text-ink-400">/{slug}</p>}
                      </div>
                      {slug && <ArrowUpRight size={16} className="ml-auto shrink-0 text-ink-500 transition-colors group-hover:text-ink-200" aria-hidden="true" />}
                    </div>
                    <BadgeList badges={badges} className="mt-4" />
                  </>
                );
                return (
                  <li key={user.id}>
                    {slug ? (
                      <Link href={`/${slug}`} className="group block h-full rounded-xl border border-ink-700 bg-ink-900/80 p-5 transition-colors duration-200 hover:border-ink-500">
                        {card}
                      </Link>
                    ) : (
                      <div className="h-full rounded-xl border border-ink-700 bg-ink-900/80 p-5">{card}</div>
                    )}
                  </li>
                );
              })}
            </ul>
          )}
        </main>
        <SiteFooter premiumName={settings.premiumName} />
      </div>
    </PageTransition>
  );
}
