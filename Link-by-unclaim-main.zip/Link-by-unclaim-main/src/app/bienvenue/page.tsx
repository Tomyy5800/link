import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { TermsGate } from "@/components/account/TermsGate";
import { toOwnerProfile } from "@/lib/discord-cdn";
import { MIN_AGE, TERMS_SUMMARY, TERMS_UPDATED } from "@/lib/legal";
import { getSyncedUser, needsTerms } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { safeNextPath } from "@/lib/server/security";

export const metadata: Metadata = { title: "Bienvenue", robots: { index: false } };

// Acceptation des CGU : à la création du compte, puis à chaque nouvelle version.
export default async function WelcomePage({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const next = safeNextPath((await searchParams).next);
  const user = await getSyncedUser();
  if (!user) redirect(`/login?next=${encodeURIComponent(`/bienvenue?next=${next}`)}`);
  if (user.banned) redirect("/login?error=banned");
  if (!needsTerms(user)) redirect(next);

  const profile = toOwnerProfile(user);
  // Compte existant (version précédente acceptée, ou pages créées avant les CGU) : écran « mise à jour ».
  const existing = Boolean(user.termsVersion) || (await prisma.page.count({ where: { userId: user.id } })) > 0;
  return (
    <TermsGate
      next={next}
      name={profile.globalName ?? profile.username}
      avatar={profile.avatarUrl}
      update={existing}
      summary={TERMS_SUMMARY}
      updated={TERMS_UPDATED}
      minAge={MIN_AGE}
    />
  );
}
