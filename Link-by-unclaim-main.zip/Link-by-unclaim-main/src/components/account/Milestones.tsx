"use client";

import { useEffect, useState } from "react";
import { PartyPopper, X } from "lucide-react";
import { celebrate } from "@/lib/confetti";

const STEPS = [10, 50, 100, 250, 500, 1000, 2500, 5000, 10000, 25000, 50000, 100000];
const nf = new Intl.NumberFormat("fr-FR");

type Reached = { id: string; name: string; slug: string; step: number };

function storageKey(id: string) {
  return `lbu:milestone:${id}`;
}

/** Fête les caps de vues franchis depuis la dernière visite (une fois par cap et par page). */
export function Milestones({ pages }: { pages: { id: string; name: string; slug: string; views: number }[] }) {
  const [reached, setReached] = useState<Reached | null>(null);

  useEffect(() => {
    for (const p of pages) {
      const step = [...STEPS].reverse().find((s) => p.views >= s);
      if (!step) continue;
      let seen = 0;
      try {
        seen = Number(localStorage.getItem(storageKey(p.id)) ?? 0);
      } catch {
        return;
      }
      if (step > seen) {
        setReached({ id: p.id, name: p.name, slug: p.slug, step });
        window.setTimeout(celebrate, 400);
        return;
      }
    }
  }, [pages]);

  if (!reached) return null;
  const close = () => {
    try {
      localStorage.setItem(storageKey(reached.id), String(reached.step));
    } catch {
      // stockage indisponible : la fête reviendra, tant pis
    }
    setReached(null);
  };

  return (
    <div role="status" className="relative mb-5 overflow-hidden rounded-[2px] border border-claim/50 bg-[linear-gradient(120deg,rgba(255,194,71,0.16),rgba(34,201,232,0.12))] p-4">
      <div className="lbu-confetti" aria-hidden="true">
        {["🎉", "✨", "🎊", "⭐", "🎈", "✨", "🎉", "💫"].map((e, i) => (
          <span key={i} style={{ left: `${6 + i * 12}%`, animationDelay: `${(i % 4) * 0.6}s` }}>
            {e}
          </span>
        ))}
      </div>
      <div className="relative flex items-start gap-3">
        <PartyPopper size={22} className="mt-0.5 shrink-0 text-claim" aria-hidden="true" />
        <div className="min-w-0 flex-1">
          <p className="font-display text-lg font-bold">
            {reached.name} a passé les {nf.format(reached.step)} vues !
          </p>
          <p className="mt-0.5 text-sm text-ink-300">Bravo. Partage la nouvelle, ou profites-en pour soigner ta page : c&apos;est le moment où elle compte.</p>
        </div>
        <button type="button" onClick={close} className="rounded p-1 text-ink-300 hover:text-ink-100" aria-label="Fermer">
          <X size={16} />
        </button>
      </div>
    </div>
  );
}
