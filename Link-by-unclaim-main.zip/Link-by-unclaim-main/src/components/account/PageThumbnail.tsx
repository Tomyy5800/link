import type { CSSProperties } from "react";
import { BLOCK_META, type BlockType } from "@/lib/blocks";
import { FONT_STACKS, backgroundStyle, rgba, type Theme } from "@/lib/theme";

type ThumbBlock = { type: string; width: string };

const RADIUS: Record<Theme["radius"], number> = { none: 1, sm: 3, md: 5, lg: 8, full: 999 };

/**
 * Miniature d'une page dans « Mon espace » : son fond, sa carte d'en-tête, son nom dans sa police,
 * et ses premiers blocs dessinés à leur forme (boutons, icônes de réseaux, cartes). Aucun script :
 * c'est un dessin, pas la page elle-même.
 */
export function PageThumbnail({ theme, avatar, name, hasBio, blocks }: { theme: Theme; avatar: string; name: string; hasBio: boolean; blocks: ThumbBlock[] }) {
  const radius = RADIUS[theme.radius];
  const cardBg = theme.cardStyle === "glass" ? rgba("#ffffff", 0.1) : theme.cardStyle === "solid" ? theme.cardColor : "transparent";
  const cardBorder = theme.cardStyle === "outline" ? `1px solid ${rgba(theme.accent, 0.6)}` : theme.cardStyle === "flat" ? "none" : `1px solid ${rgba(theme.text, 0.08)}`;
  const button = (key: number): CSSProperties => ({
    height: 13,
    borderRadius: Math.min(radius, 7),
    background: theme.buttonFill === "solid" ? theme.accent : theme.buttonFill === "soft" ? rgba(theme.accent, 0.25) : "transparent",
    border: theme.buttonFill === "outline" ? `1px solid ${theme.accent}` : "none",
    opacity: 1 - key * 0.06,
  });
  const card: CSSProperties = { background: cardBg, border: cardBorder, borderRadius: Math.min(radius, 8) };
  const avatarRadius = theme.avatarShape === "circle" ? 999 : theme.avatarShape === "square" ? 2 : 8;
  const shown = blocks.slice(0, 6);

  return (
    <div className="absolute inset-0" style={backgroundStyle(theme)} aria-hidden="true">
      <div className="mx-auto flex w-[64%] flex-col gap-1.5 pt-4 transition-transform duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:-translate-y-8">
        {/* En-tête */}
        <div className="flex flex-col items-center gap-1 px-2 pt-3 pb-2.5" style={card}>
          <img src={avatar} alt="" className="h-8 w-8 object-cover shadow" style={{ borderRadius: avatarRadius, boxShadow: `0 0 0 2px ${theme.accent}` }} />
          <span
            className="max-w-full truncate text-[10px] leading-tight font-bold"
            style={{ color: theme.text, fontFamily: FONT_STACKS[theme.headingFont ?? theme.font] }}
          >
            {name}
          </span>
          {hasBio && (
            <>
              <span className="h-1 w-3/4 rounded-full" style={{ background: rgba(theme.text, 0.35) }} />
              <span className="h-1 w-1/2 rounded-full" style={{ background: rgba(theme.text, 0.25) }} />
            </>
          )}
        </div>
        {/* Blocs : deux demi-largeurs se partagent une ligne */}
        <div className="flex flex-wrap gap-1.5">
          {shown.map((block, i) => {
            const half = block.width === "half";
            const width = half ? "calc(50% - 3px)" : "100%";
            if (block.type === "link" || block.type === "collection" || block.type === "discordServer") {
              return <span key={i} style={{ ...button(i), width }} />;
            }
            if (block.type === "socials") {
              return (
                <span key={i} className="flex justify-center gap-1" style={{ width }}>
                  {[0, 1, 2, 3].map((d) => (
                    <span key={d} className="h-3 w-3" style={{ borderRadius: Math.min(radius, 4), background: rgba(theme.text, 0.18) }} />
                  ))}
                </span>
              );
            }
            if (block.type === "shop") {
              // Vitrine : trois vignettes de produits, la première à la couleur du thème.
              return (
                <span key={i} className="grid grid-cols-3 gap-1 p-1" style={{ ...card, width }} title={BLOCK_META.shop.label}>
                  {[0, 1, 2].map((d) => (
                    <span key={d} className="aspect-square" style={{ borderRadius: Math.min(radius, 4), background: d === 0 ? rgba(theme.accent, 0.55) : rgba(theme.text, 0.14) }} />
                  ))}
                </span>
              );
            }
            const tall = ["image", "gallery", "embed", "skin", "discord", "nationsglory", "game"].includes(block.type);
            return (
              <span key={i} className="flex items-center gap-1 px-1.5" style={{ ...card, width, height: tall ? 30 : 18 }} title={BLOCK_META[block.type as BlockType]?.label}>
                <span className="h-1 w-1/2 rounded-full" style={{ background: rgba(theme.text, 0.3) }} />
              </span>
            );
          })}
        </div>
      </div>
    </div>
  );
}
