import Link from "next/link";
import { ArrowLeft, ExternalLink, Inbox, ShoppingBag } from "lucide-react";
import { Panel, Stat, nf } from "@/components/admin/ui";
import { Logo } from "@/components/brand/Logo";
import { blockSummary, parseStoredBlock } from "@/lib/blocks";
import type { PagePermission } from "@/lib/member-roles";
import { hasPagePermission, type PageAccess } from "@/lib/server/access";
import { prisma } from "@/lib/server/db";
import { entitlementsFrom } from "@/lib/server/entitlements";
import { clicksByBlock, viewsByDay } from "@/lib/server/pages";
import { getSettings } from "@/lib/server/settings";

/** Page vue par un collaborateur sans droit de modification : ce que son rôle lui ouvre (statistiques, messages, commandes). */
export async function PageInsights({ access }: { access: PageAccess }) {
  const page = access.page;
  const can = (p: PagePermission) => hasPagePermission(access, p);
  const settings = await getSettings();
  const days = Math.min(30, entitlementsFrom(page.user, settings).limits.statsDays);
  const [series, clicks, blocks, unread] = await Promise.all([
    viewsByDay(page.id, days),
    clicksByBlock(page.id, days),
    prisma.block.findMany({ where: { pageId: page.id } }),
    prisma.contactMessage.count({ where: { pageId: page.id, read: false } }),
  ]);
  const byId = new Map(blocks.map((b) => [b.id, parseStoredBlock(b)]));
  const max = Math.max(1, ...series.map((d) => d.count));
  const total = series.reduce((n, d) => n + d.count, 0);
  const totalClicks = clicks.reduce((n, c) => n + c.count, 0);

  return (
    <div className="bg-hud min-h-screen">
      <header className="border-b border-ink-800 bg-ink-950/90">
        <div className="mx-auto flex h-14 max-w-5xl items-center gap-3 px-4">
          <Logo />
          <Link href="/dashboard" className="ml-auto inline-flex items-center gap-1.5 text-sm text-ink-300 hover:text-ink-100">
            <ArrowLeft size={15} /> Mon espace
          </Link>
        </div>
      </header>
      <main className="mx-auto max-w-5xl space-y-4 px-4 py-6">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="hud-label text-ink-400">
              {access.customRole ? (
                <span className="inline-flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full" style={{ background: access.customRole.color }} aria-hidden="true" /> Rôle : {access.customRole.name}
                </span>
              ) : (
                "Accès en lecture"
              )}
            </p>
            <h1 className="font-display text-2xl font-bold">{page.label || page.displayName}</h1>
          </div>
          <a href={`/${page.slug}`} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 text-sm text-brand-300 hover:underline">
            /{page.slug} <ExternalLink size={13} />
          </a>
        </div>
        {!can("stats") && (
          <Panel>
            <p className="text-sm text-ink-300">Ton rôle sur cette page ne donne pas accès aux statistiques.</p>
          </Panel>
        )}
        {can("stats") && (
          <>
        <div className="grid gap-3 sm:grid-cols-3">
          <Stat label={`Vues uniques · ${days} j`} value={nf.format(total)} />
          <Stat label={`Clics · ${days} j`} value={nf.format(totalClicks)} />
          <Stat label="Vues depuis la création" value={nf.format(page.views)} />
        </div>
        <Panel title="Vues par jour">
          <div className="flex h-36 items-end gap-[3px]" role="img" aria-label={`${total} vues sur ${days} jours`}>
            {series.map((d) => (
              <div key={d.day} className="flex-1 rounded-t-[2px] bg-brand-500/80" style={{ height: `${Math.max(2, (d.count / max) * 100)}%` }} title={`${d.day} : ${d.count}`} />
            ))}
          </div>
        </Panel>
        <Panel title="Liens les plus cliqués">
          {clicks.length === 0 ? (
            <p className="text-sm text-ink-400">Aucun clic sur la période.</p>
          ) : (
            <ul className="space-y-2">
              {clicks.slice(0, 10).map((c) => {
                const block = byId.get(c.blockId);
                return (
                  <li key={c.blockId} className="flex items-center justify-between gap-3 text-sm">
                    <span className="min-w-0 truncate text-ink-200">{block ? blockSummary(block) : "Bloc supprimé"}</span>
                    <span className="font-mono tabular-nums text-ink-300">{nf.format(c.count)}</span>
                  </li>
                );
              })}
            </ul>
          )}
        </Panel>
          </>
        )}
        <div className="flex flex-wrap gap-4">
          {can("messages.read") && (
            <Link href={`/dashboard/messages?page=${page.id}`} className="inline-flex items-center gap-2 text-sm text-brand-300 hover:underline">
              <Inbox size={15} /> Messages de cette page{unread ? ` (${unread} non lu${unread > 1 ? "s" : ""})` : ""}
            </Link>
          )}
          {can("orders") && (
            <Link href={`/dashboard/commandes?page=${page.id}`} className="inline-flex items-center gap-2 text-sm text-brand-300 hover:underline">
              <ShoppingBag size={15} /> Commandes de cette page
            </Link>
          )}
        </div>
      </main>
    </div>
  );
}
