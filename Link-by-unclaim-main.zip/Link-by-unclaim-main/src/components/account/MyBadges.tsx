"use client";

import { useState } from "react";
import { Eye, EyeOff, LoaderCircle } from "lucide-react";
import { OfficialBadge } from "@/components/badges/OfficialBadge";
import type { PublicBadge } from "@/lib/badges";
import { toast } from "@/lib/toast";

export type MyBadge = { id: string; badge: PublicBadge; hidden: boolean; visibility: "public" | "hidden"; until: string | null };

const day = (iso: string) => new Date(iso).toLocaleDateString("fr-FR", { dateStyle: "medium", timeZone: "Europe/Paris" });

/** Badges du compte : affichés ou masqués sur ses pages (on ne peut pas s'en attribuer). */
export function MyBadges({ initial }: { initial: MyBadge[] }) {
  const [badges, setBadges] = useState(initial);
  const [busy, setBusy] = useState<string | null>(null);

  async function toggle(b: MyBadge) {
    setBusy(b.id);
    const res = await fetch("/api/me/badges", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ badgeId: b.id, hidden: !b.hidden }) }).catch(() => null);
    setBusy(null);
    if (!res?.ok) {
      toast("Modification impossible, réessaie.", { tone: "error" });
      return;
    }
    setBadges((list) => list.map((x) => (x.id === b.id ? { ...x, hidden: !b.hidden } : x)));
  }

  if (!badges.length) {
    return <p className="text-sm text-ink-400">Aucun badge pour l&apos;instant. Ils sont attribués par l&apos;équipe Unclaim, par ta formule ou par la boutique officielle.</p>;
  }
  return (
    <ul className="space-y-2">
      {badges.map((b) => (
        <li key={b.id} className="flex items-center gap-3">
          <span className={`min-w-0 flex-1 transition-opacity ${b.hidden ? "opacity-50" : ""}`}>
            <OfficialBadge badge={b.badge} />
            {b.until && <span className="ml-2 text-xs text-ink-500">jusqu&apos;au {day(b.until)}</span>}
          </span>
          {b.visibility === "hidden" ? (
            <span className="text-xs text-ink-500">interne</span>
          ) : (
            <button
              type="button"
              onClick={() => void toggle(b)}
              disabled={busy !== null}
              aria-pressed={!b.hidden}
              className="inline-flex items-center gap-1.5 rounded-md border border-ink-700 px-2 py-1 text-xs text-ink-300 transition-colors hover:border-ink-500 hover:text-ink-100 disabled:opacity-50"
            >
              {busy === b.id ? <LoaderCircle size={13} className="animate-spin" /> : b.hidden ? <EyeOff size={13} /> : <Eye size={13} />}
              {b.hidden ? "Masqué" : "Affiché"}
            </button>
          )}
        </li>
      ))}
    </ul>
  );
}
