"use client";

import { useLayoutEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Bot, Handshake, Inbox, LayoutGrid, ShoppingBag, Sparkles, UserRound } from "lucide-react";

const ITEMS: { href: string; label: string; icon: typeof Inbox; badge?: "messages" | "orders" }[] = [
  { href: "/dashboard", label: "Mes pages", icon: LayoutGrid },
  { href: "/dashboard/assistant", label: "Assistant IA", icon: Bot },
  { href: "/dashboard/messages", label: "Messages", icon: Inbox, badge: "messages" },
  { href: "/dashboard/commandes", label: "Commandes", icon: ShoppingBag, badge: "orders" },
  { href: "/dashboard/compte", label: "Compte et données", icon: UserRound },
  { href: "/dashboard/abonnement", label: "Offre", icon: Sparkles },
  { href: "/dashboard/partenariat", label: "Partenariat", icon: Handshake },
];

type Pill = { x: number; y: number; w: number; h: number };

/**
 * Menu de « Mon espace » (colonne sur ordinateur, barre défilante sur mobile). Le fond de
 * l'entrée active glisse d'une section à l'autre ; les liens portent le type de transition
 * « ui-nav » qui déclenche le fondu du contenu (voir le layout).
 */
export function AccountNav({ unread, orders = 0, premiumName }: { unread: number; orders?: number; premiumName: string }) {
  const pathname = usePathname();
  const navRef = useRef<HTMLElement>(null);
  const [pill, setPill] = useState<Pill | null>(null);

  useLayoutEffect(() => {
    const nav = navRef.current;
    const active = nav?.querySelector<HTMLElement>('[aria-current="page"]');
    if (!nav || !active) {
      setPill(null);
      return;
    }
    const measure = () => setPill({ x: active.offsetLeft, y: active.offsetTop, w: active.offsetWidth, h: active.offsetHeight });
    measure();
    active.scrollIntoView({ block: "nearest", inline: "nearest" });
    const observer = new ResizeObserver(measure);
    observer.observe(nav);
    return () => observer.disconnect();
  }, [pathname]);

  return (
    <nav ref={navRef} aria-label="Mon espace" className="scrollbar-thin relative flex gap-1 overflow-x-auto lg:flex-col lg:overflow-visible">
      {pill && (
        <span
          className="pointer-events-none absolute top-0 left-0 rounded-md bg-ink-800 shadow-[inset_0_0_0_1px_rgb(255_255_255/0.04)] transition-[transform,width,height] duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]"
          style={{ transform: `translate(${pill.x}px, ${pill.y}px)`, width: pill.w, height: pill.h }}
          aria-hidden="true"
        >
          <span className="absolute top-1/2 left-0 hidden h-5 w-[3px] -translate-y-1/2 rounded-r-full bg-brand-400 shadow-[0_0_10px_#22c9e8] lg:block" />
        </span>
      )}
      {ITEMS.map(({ href, label, icon: Icon, badge }) => {
        const active = href === "/dashboard" ? pathname === href : pathname.startsWith(href);
        const count = badge === "messages" ? unread : badge === "orders" ? orders : 0;
        return (
          <Link
            key={href}
            href={href}
            transitionTypes={["ui-nav"]}
            aria-current={active ? "page" : undefined}
            className={`group relative flex shrink-0 items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium transition-colors ${
              active ? "text-ink-100" : "text-ink-400 hover:bg-ink-850/70 hover:text-ink-200"
            }`}
          >
            <Icon size={16} className={`${active ? "text-brand-400" : ""}`} />
            {href === "/dashboard/abonnement" ? premiumName : label}
            {count > 0 && (
              <span
                className={`ml-auto animate-pop rounded-sm px-1.5 font-mono text-[11px] font-semibold text-ink-950 ${badge === "orders" ? "bg-pink-400" : "bg-brand-500"}`}
                aria-label={badge === "orders" ? `${count} nouvelle(s) commande(s)` : `${count} non lu(s)`}
              >
                {count}
              </span>
            )}
          </Link>
        );
      })}
    </nav>
  );
}
