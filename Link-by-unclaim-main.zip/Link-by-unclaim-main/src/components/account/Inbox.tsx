"use client";

import { useState } from "react";
import { Check, Copy, Mail, MailOpen, Trash2 } from "lucide-react";
import { confirmDialog } from "@/lib/confirm";
import { toast } from "@/lib/toast";

type Message = {
  id: string;
  pageId: string;
  pageName: string;
  pageSlug: string;
  name: string;
  contact: string;
  message: string;
  read: boolean;
  createdAt: string;
  canDelete: boolean;
};

// Fuseau fixe : le serveur (souvent en UTC) et le navigateur écrivent la même heure.
const fmt = new Intl.DateTimeFormat("fr-FR", { dateStyle: "medium", timeStyle: "short", timeZone: "Europe/Paris" });

/** Boîte de réception : lecture, marquage lu / non lu, réponse rapide, suppression. */
export function Inbox({ initial, showPage }: { initial: Message[]; showPage: boolean }) {
  const [messages, setMessages] = useState(initial);
  const [open, setOpen] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  async function setRead(m: Message, read: boolean) {
    setMessages((list) => list.map((x) => (x.id === m.id ? { ...x, read } : x)));
    await fetch(`/api/me/pages/${m.pageId}/messages`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ids: [m.id], read }),
    }).catch(() => undefined);
  }

  async function remove(m: Message) {
    const ok = await confirmDialog({ title: "Supprimer ce message ?", message: "Il sera effacé définitivement.", confirmLabel: "Supprimer", tone: "danger" });
    if (!ok) return;
    const res = await fetch(`/api/me/pages/${m.pageId}/messages?messageId=${m.id}`, { method: "DELETE" }).catch(() => null);
    if (res?.ok) {
      setMessages((list) => list.filter((x) => x.id !== m.id));
      toast("Message supprimé", { tone: "success" });
    } else {
      toast("La suppression a échoué, réessaie.", { tone: "error" });
    }
  }

  function toggle(m: Message) {
    setOpen(open === m.id ? null : m.id);
    if (!m.read) void setRead(m, true);
  }

  const isEmail = (v: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);

  return (
    <ul className="divide-y divide-ink-800 overflow-hidden rounded-[2px] border border-ink-700 bg-ink-900/80">
      {messages.map((m) => {
        const expanded = open === m.id;
        return (
          <li key={m.id} className={m.read ? "" : "bg-brand-500/5"}>
            <button type="button" onClick={() => toggle(m)} aria-expanded={expanded} className="flex w-full items-start gap-3 px-4 py-3 text-left">
              <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${m.read ? "bg-transparent" : "bg-brand-400"}`} aria-hidden="true" />
              <span className="min-w-0 flex-1">
                <span className="flex flex-wrap items-baseline gap-x-2">
                  <span className={`truncate ${m.read ? "text-ink-200" : "font-semibold text-ink-100"}`}>{m.name}</span>
                  {m.contact && <span className="truncate text-xs text-ink-400">{m.contact}</span>}
                  <span className="ml-auto shrink-0 text-xs text-ink-500">{fmt.format(new Date(m.createdAt))}</span>
                </span>
                {showPage && <span className="block font-mono text-[11px] text-ink-500">/{m.pageSlug}</span>}
                <span className={`mt-0.5 block text-sm text-ink-300 ${expanded ? "whitespace-pre-wrap" : "truncate"}`}>{m.message}</span>
              </span>
            </button>
            {expanded && (
              <div className="flex flex-wrap items-center gap-2 px-4 pb-3 pl-9">
                {m.contact && isEmail(m.contact) && (
                  <a
                    href={`mailto:${m.contact}?subject=${encodeURIComponent(`Re: ton message sur ${m.pageName}`)}`}
                    className="inline-flex items-center gap-1.5 rounded-md bg-brand-500 px-2.5 py-1.5 text-xs font-semibold text-ink-950 hover:bg-brand-400"
                  >
                    <Mail size={13} /> Répondre
                  </a>
                )}
                {m.contact && !isEmail(m.contact) && (
                  <button
                    type="button"
                    onClick={() =>
                      void navigator.clipboard.writeText(m.contact).then(() => {
                        setCopied(m.id);
                        setTimeout(() => setCopied(null), 1500);
                      })
                    }
                    className="inline-flex items-center gap-1.5 rounded-md border border-ink-600 px-2.5 py-1.5 text-xs text-ink-200 hover:border-ink-400"
                  >
                    {copied === m.id ? <Check size={13} /> : <Copy size={13} />} Copier le contact
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => void setRead(m, !m.read)}
                  className="inline-flex items-center gap-1.5 rounded-md border border-ink-600 px-2.5 py-1.5 text-xs text-ink-200 hover:border-ink-400"
                >
                  <MailOpen size={13} /> Marquer comme {m.read ? "non lu" : "lu"}
                </button>
                {m.canDelete && (
                  <button
                    type="button"
                    onClick={() => void remove(m)}
                    className="inline-flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs text-ink-400 hover:text-danger"
                  >
                    <Trash2 size={13} /> Supprimer
                  </button>
                )}
              </div>
            )}
          </li>
        );
      })}
    </ul>
  );
}
