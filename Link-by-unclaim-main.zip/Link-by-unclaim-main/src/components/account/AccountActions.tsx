"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { LoaderCircle, LogOut, RefreshCw, TriangleAlert } from "lucide-react";

const btn =
  "inline-flex items-center gap-2 rounded-md border border-ink-700 px-3 py-1.5 text-sm font-medium text-ink-200 transition hover:border-ink-500 disabled:opacity-40";

/** Resynchronise nom, avatar et comptes reliés depuis Unclaim Auth. */
export function SyncButton() {
  const router = useRouter();
  const [state, setState] = useState<{ busy: boolean; text?: string }>({ busy: false });
  return (
    <div className="flex flex-wrap items-center gap-3">
      <button
        type="button"
        className={btn}
        disabled={state.busy}
        onClick={async () => {
          setState({ busy: true });
          const res = await fetch("/api/me/sync", { method: "POST" }).catch(() => null);
          const json = (await res?.json().catch(() => ({}))) as { error?: string };
          setState({ busy: false, text: res?.ok ? "Profil synchronisé." : (json.error ?? "Synchronisation impossible.") });
          if (res?.ok) router.refresh();
        }}
      >
        <RefreshCw size={15} className={state.busy ? "animate-spin" : ""} /> Resynchroniser
      </button>
      {state.text && <span className="text-xs text-ink-300">{state.text}</span>}
    </div>
  );
}

/** Ferme toutes les sessions sauf celle-ci. */
export function SignOutOthers({ others }: { others: number }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<number | null>(null);
  return (
    <div className="flex flex-wrap items-center gap-3">
      <button
        type="button"
        className={btn}
        disabled={busy || others === 0}
        onClick={async () => {
          setBusy(true);
          const res = await fetch("/api/me/sessions", { method: "DELETE" }).catch(() => null);
          const json = (await res?.json().catch(() => ({}))) as { closed?: number };
          setBusy(false);
          setDone(json.closed ?? 0);
          router.refresh();
        }}
      >
        {busy ? <LoaderCircle size={15} className="animate-spin" /> : <LogOut size={15} />} Déconnecter les autres appareils
      </button>
      {done !== null && <span className="text-xs text-ink-300">{done ? `${done} session(s) fermée(s).` : "Aucune autre session ouverte."}</span>}
    </div>
  );
}

/** Suppression définitive du compte, après confirmation écrite. */
export function DeleteAccount({ pages }: { pages: number }) {
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  return (
    <div className="space-y-3">
      <p className="flex gap-2 text-sm leading-relaxed text-ink-300">
        <TriangleAlert size={16} className="mt-0.5 shrink-0 text-danger" />
        <span>
          Efface définitivement {pages ? `tes ${pages} page(s), leurs blocs, images, messages et statistiques,` : "ton compte,"} tes collaborations et tes
          candidatures. Les achats restent archivés de façon anonyme (obligation comptable). Ton compte Unclaim Auth n&apos;est pas supprimé.
        </span>
      </p>
      <label className="block text-[0.8rem] font-medium text-ink-200" htmlFor="confirm-delete">
        Tape SUPPRIMER pour confirmer
      </label>
      <div className="flex flex-wrap gap-2">
        <input id="confirm-delete" className="field !w-48 font-mono" value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="off" />
        <button
          type="button"
          disabled={confirm !== "SUPPRIMER" || busy}
          onClick={async () => {
            setBusy(true);
            setError(null);
            const res = await fetch("/api/me/account", {
              method: "DELETE",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ confirm }),
            }).catch(() => null);
            if (res?.ok) {
              window.location.assign("/?compte=supprime");
              return;
            }
            const json = (await res?.json().catch(() => ({}))) as { error?: string };
            setError(json.error ?? "Suppression impossible, réessaie.");
            setBusy(false);
          }}
          className="rounded-md bg-danger/90 px-3 py-2 text-sm font-semibold text-white transition hover:bg-danger disabled:opacity-30"
        >
          {busy ? "Suppression…" : "Supprimer mon compte"}
        </button>
      </div>
      {error && <p className="text-xs text-danger">{error}</p>}
    </div>
  );
}
