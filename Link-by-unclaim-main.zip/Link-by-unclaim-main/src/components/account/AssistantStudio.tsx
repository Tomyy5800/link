"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, ArrowRight, Bot, Check, Eye, LoaderCircle, MessageSquare, Send, Sparkles, Timer, X } from "lucide-react";
import { EMPTY_DRAFT, buildPageFromDraft, describeDraft, type AssistantDraft, type ChatMessage } from "@/lib/assistant";
import type { FeatureFlags } from "@/lib/features";
import { DEFAULT_PAGE_OPTIONS, type OwnerProfile, type PageView } from "@/lib/page-schema";
import { suggestSlug, validateSlug } from "@/lib/slug";
import { Logo } from "@/components/brand/Logo";
import { PageRenderer } from "@/components/page/PageRenderer";

type Props = {
  owner: OwnerProfile;
  host: string;
  features: FeatureFlags;
  allowShortSlug: boolean;
  premiumName: string;
  /** Pages déjà créées (lien de retour vers « Mon espace »). */
  existingPages: number;
  /** Limite de pages atteinte : la création est bloquée. */
  limitReached: boolean;
};

type Turn = { reply: string; quickReplies: string[]; draft: AssistantDraft; ready: boolean; engine: "claude" | "local"; remaining: number | null; error?: string };
type Availability = { state: "idle" | "checking" | "free" | "taken"; message?: string };

function elapsedLabel(ms: number): string {
  const s = Math.floor(ms / 1000);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

/** Assistant de création : une conversation, un aperçu en direct, une page créée en un clic. */
export function AssistantStudio({ owner, host, features, allowShortSlug, premiumName, existingPages, limitReached }: Props) {
  const router = useRouter();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [draft, setDraft] = useState<AssistantDraft>({ ...EMPTY_DRAFT, links: [], socials: [], games: [], displayName: owner.globalName ?? owner.username });
  const [quickReplies, setQuickReplies] = useState<string[]>([]);
  const [ready, setReady] = useState(false);
  const [engine, setEngine] = useState<"claude" | "local" | null>(null);
  const [remaining, setRemaining] = useState<number | null>(null);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [slug, setSlug] = useState("");
  const [slugTouched, setSlugTouched] = useState(false);
  const [availability, setAvailability] = useState<Availability>({ state: "idle" });
  const [creating, setCreating] = useState(false);
  const [view, setView] = useState<"chat" | "preview">("chat");
  /** Incrémenté à chaque réponse : une onde parcourt l'aperçu mis à jour. */
  const [pulse, setPulse] = useState(0);
  const [startedAt] = useState(() => Date.now());
  const [now, setNow] = useState(() => Date.now());
  const listRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const started = useRef(false);

  useEffect(() => {
    const t = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(t);
  }, []);

  async function send(history: ChatMessage[], currentDraft: AssistantDraft) {
    setThinking(true);
    setError(null);
    const res = await fetch("/api/me/assistant", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: history, draft: currentDraft }),
    }).catch(() => null);
    const json = (await res?.json().catch(() => null)) as (Turn & { error?: string }) | null;
    setThinking(false);
    if (!res?.ok || !json || json.error) {
      setError(json?.error ?? "L'assistant ne répond pas. Réessaie dans un instant.");
      return;
    }
    setMessages([...history, { role: "assistant", content: json.reply }]);
    setDraft(json.draft);
    if (history.length) setPulse((n) => n + 1);
    setQuickReplies(json.quickReplies);
    setReady(json.ready);
    setEngine(json.engine);
    setRemaining(json.remaining);
    requestAnimationFrame(() => inputRef.current?.focus());
  }

  // Message d'accueil.
  useEffect(() => {
    if (started.current) return;
    started.current = true;
    void send([], draft);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, thinking]);

  // Adresse proposée à partir du brouillon, tant qu'elle n'a pas été modifiée à la main.
  useEffect(() => {
    if (slugTouched) return;
    setSlug(draft.slug || suggestSlug(draft.displayName || owner.username));
  }, [draft.slug, draft.displayName, slugTouched, owner.username]);

  const local = validateSlug(slug, { allowShort: allowShortSlug, premiumName });
  useEffect(() => {
    if (!local.ok) return;
    const controller = new AbortController();
    setAvailability({ state: "checking" });
    const timer = setTimeout(() => {
      fetch(`/api/slugs/check?slug=${encodeURIComponent(local.slug)}`, { signal: controller.signal })
        .then((r) => r.json() as Promise<{ available: boolean; error?: string }>)
        .then((json) => setAvailability(json.available ? { state: "free" } : { state: "taken", message: json.error }))
        .catch(() => undefined);
    }, 350);
    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [local.ok, local.ok ? local.slug : null]);

  function submit(text: string) {
    const content = text.trim();
    if (!content || thinking) return;
    const history: ChatMessage[] = [...messages, { role: "user", content }];
    setMessages(history);
    setInput("");
    setQuickReplies([]);
    void send(history, draft);
  }

  async function create() {
    if (!local.ok || availability.state !== "free" || creating) return;
    setCreating(true);
    setError(null);
    const res = await fetch("/api/me/assistant/create", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ slug: local.slug, draft }),
    }).catch(() => null);
    const json = (await res?.json().catch(() => ({}))) as { id?: string; error?: string };
    if (res?.ok && json.id) {
      router.push(`/dashboard/pages/${json.id}?bienvenue=1`);
      return;
    }
    setError(json.error ?? "La création a échoué. Réessaie.");
    setCreating(false);
  }

  // Identifiants stables dans l'aperçu : même rendu côté serveur et navigateur.
  const built = useMemo(() => {
    const page = buildPageFromDraft(draft, { hasDiscord: Boolean(owner.discordId) });
    return { ...page, blocks: page.blocks.map((b, i) => ({ ...b, id: `00000000-0000-4000-8000-${String(i).padStart(12, "0")}` })) };
  }, [draft, owner.discordId]);
  const preview: PageView = {
    slug: local.ok ? local.slug : "ta-page",
    published: true,
    views: 0,
    theme: built.theme,
    customCss: "",
    options: DEFAULT_PAGE_OPTIONS,
    blocks: built.blocks,
    profile: {
      displayName: built.displayName || "Ton nom",
      pronouns: built.pronouns,
      bio: built.bio,
      avatarSource: "discord",
      avatarUrl: "",
      bannerUrl: "",
      ngUsername: draft.ngUsername,
      ngServer: "blue",
    },
  };
  const summary = describeDraft(draft);
  const elapsed = now - startedAt;
  const canCreate = ready && Boolean(draft.displayName) && local.ok && availability.state === "free" && !limitReached;
  const userTurns = messages.filter((m) => m.role === "user").length;

  return (
    <div className="flex h-dvh flex-col bg-ink-950">
      <header className="flex h-14 shrink-0 items-center gap-3 border-b border-ink-800 px-3 sm:px-4">
        <div className="hidden sm:block">
          <Logo href="/dashboard" />
        </div>
        <span className="inline-flex items-center gap-1.5 rounded-sm border border-brand-500/40 px-2 py-0.5 font-mono text-[11px] font-semibold text-brand-300">
          <Sparkles size={12} aria-hidden="true" /> ASSISTANT
        </span>
        {engine && (
          <span className="hidden text-xs text-ink-400 md:inline" title={engine === "claude" ? "Réponses rédigées par Claude (Anthropic)" : "Questions guidées, sans IA externe"}>
            {engine === "claude" ? `IA Claude${remaining !== null ? ` · ${remaining} message${remaining > 1 ? "s" : ""} restant${remaining > 1 ? "s" : ""} aujourd'hui` : ""}` : "Mode guidé"}
          </span>
        )}
        <span
          className={`ml-auto inline-flex items-center gap-1.5 font-mono text-xs tabular-nums ${elapsed > 5 * 60_000 ? "text-claim" : "text-ink-300"}`}
          title="Objectif : ta page en moins de cinq minutes"
          suppressHydrationWarning
        >
          <Timer size={14} aria-hidden="true" /> {elapsedLabel(elapsed)} <span className="hidden text-ink-500 sm:inline">/ 5:00</span>
        </span>
        <a href="/dashboard/nouvelle" className="hidden text-xs text-ink-400 hover:text-ink-100 sm:inline">
          Formulaire classique
        </a>
        {existingPages > 0 && (
          <a href="/dashboard" className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-sm text-ink-300 hover:bg-ink-800 hover:text-ink-100" aria-label="Mon espace">
            <ArrowLeft size={15} /> <span className="hidden sm:inline">Mon espace</span>
          </a>
        )}
      </header>

      <div className="flex shrink-0 gap-1 border-b border-ink-800 p-1 lg:hidden" role="tablist">
        {(
          [
            ["chat", MessageSquare, "Discussion"],
            ["preview", Eye, "Aperçu"],
          ] as const
        ).map(([key, Icon, label]) => (
          <button
            key={key}
            type="button"
            role="tab"
            aria-selected={view === key}
            onClick={() => setView(key)}
            className={`flex flex-1 items-center justify-center gap-1.5 rounded-md py-2 text-sm font-medium ${view === key ? "bg-ink-800 text-ink-100" : "text-ink-400"}`}
          >
            <Icon size={15} /> {label}
          </button>
        ))}
      </div>

      <div className="flex min-h-0 flex-1">
        {/* Discussion */}
        <section className={`${view === "chat" ? "flex" : "hidden"} min-w-0 flex-1 flex-col lg:flex lg:max-w-[560px] lg:border-r lg:border-ink-800`} aria-label="Discussion avec l'assistant">
          <div ref={listRef} className="scrollbar-thin min-h-0 flex-1 space-y-3 overflow-y-auto p-4" aria-live="polite">
            {messages.map((m, i) => (
              <div key={i} className={`flex animate-rise ${m.role === "user" ? "justify-end" : "justify-start"} gap-2`}>
                {m.role === "assistant" && (
                  <span className="mt-1 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-brand-500/15 text-brand-300" aria-hidden="true">
                    <Bot size={15} />
                  </span>
                )}
                <p
                  className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed ${
                    m.role === "user" ? "rounded-br-sm bg-brand-500 text-ink-950" : "rounded-bl-sm bg-ink-850 text-ink-100"
                  }`}
                >
                  {m.content}
                </p>
              </div>
            ))}
            {thinking && (
              <div className="flex animate-fade items-center gap-2 text-sm text-ink-400">
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-brand-500/15 text-brand-300" aria-hidden="true">
                  <Bot size={15} />
                </span>
                <span className="ui-typing rounded-2xl rounded-bl-sm bg-ink-850 px-3.5 py-3 text-ink-400" aria-label="L'assistant écrit">
                  <span />
                  <span />
                  <span />
                </span>
              </div>
            )}
            {error && (
              <p role="alert" className="flex items-center gap-2 rounded-md border border-danger/30 bg-danger/10 px-3 py-2 text-sm text-red-100">
                <X size={14} className="shrink-0 text-danger" /> {error}
              </p>
            )}
          </div>

          {ready && (
            <div className="shrink-0 border-t border-ink-800 bg-ink-900/80 p-3 lg:hidden">
              <button
                type="button"
                onClick={() => setView("preview")}
                className="ui-press flex w-full items-center justify-center gap-2 rounded-md bg-claim px-4 py-2.5 text-sm font-semibold text-ink-950"
              >
                <Eye size={15} /> Voir l&apos;aperçu et créer ma page
              </button>
            </div>
          )}

          <div className="shrink-0 border-t border-ink-800 p-3">
            {quickReplies.length > 0 && (
              <div className="mb-2 flex flex-wrap gap-1.5">
                {quickReplies.map((q, i) => (
                  <button
                    key={q}
                    style={{ animation: `rise 0.45s var(--ease-out-expo) ${i * 50}ms both` }}
                    type="button"
                    disabled={thinking}
                    onClick={() => (q.endsWith("…") ? (setInput(q.replace(/…$/, "")), inputRef.current?.focus()) : submit(q))}
                    className="ui-press rounded-full border border-ink-600 px-3 py-1 text-xs text-ink-200 transition hover:border-brand-400 hover:bg-brand-500/10 hover:text-white disabled:opacity-40"
                  >
                    {q}
                  </button>
                ))}
              </div>
            )}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                submit(input);
              }}
              className="flex items-end gap-2"
            >
              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
                    e.preventDefault();
                    submit(input);
                  }
                }}
                rows={Math.min(5, Math.max(1, input.split("\n").length))}
                maxLength={1500}
                placeholder={userTurns === 0 ? "Écris ta réponse…" : "Réponds, ou demande un changement…"}
                aria-label="Ton message"
                className="field min-h-10 flex-1 resize-none py-2"
              />
              <button
                type="submit"
                disabled={!input.trim() || thinking}
                className="ui-press flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-brand-500 text-ink-950 transition hover:bg-brand-400 disabled:opacity-40"
                aria-label="Envoyer"
              >
                {thinking ? <LoaderCircle size={17} className="animate-spin" /> : <Send size={16} />}
              </button>
            </form>
            <p className="mt-1.5 text-[11px] text-ink-500">Entrée pour envoyer · Maj+Entrée pour aller à la ligne. Ne partage ni mot de passe ni e-mail.</p>
          </div>
        </section>

        {/* Aperçu et création */}
        <section className={`${view === "preview" ? "flex" : "hidden"} min-w-0 flex-1 flex-col lg:flex`} aria-label="Aperçu de ta page">
          <div className="scrollbar-thin min-h-0 flex-1 overflow-y-auto bg-[radial-gradient(circle_at_50%_0%,#1b1b28,transparent_60%)] p-4">
            <div className="relative mx-auto w-full max-w-[400px] overflow-hidden rounded-[2rem] border border-ink-700 bg-ink-900 p-2 shadow-2xl shadow-black/50">
              {pulse > 0 && <span key={pulse} className="ui-ring pointer-events-none absolute inset-0 z-10 rounded-[2rem]" aria-hidden="true" />}
              <div className="overflow-hidden rounded-[1.6rem]">
                <PageRenderer page={preview} owner={owner} context={{ features, verified: false, blockedDomains: [] }} mode="preview" premiumName={premiumName} bare />
              </div>
            </div>
          </div>

          <div className="shrink-0 border-t border-ink-800 bg-ink-900/80 p-4">
            {summary.length > 0 && (
              <p className="mb-3 flex flex-wrap gap-1.5 text-xs text-ink-300">
                {summary.map((s) => (
                  <span key={s} className="inline-flex items-center gap-1 rounded-full border border-ink-700 px-2 py-0.5">
                    <Check size={11} className="text-mint" /> {s}
                  </span>
                ))}
              </p>
            )}
            {limitReached ? (
              <p className="text-sm text-claim">Tu as atteint le nombre de pages de ta formule. <a href="/plus" className="underline">Voir les formules</a></p>
            ) : (
              <div className="flex flex-wrap items-start gap-2">
                <label className="min-w-0 flex-1">
                  <span className="sr-only">Adresse de ta page</span>
                  <span className="flex items-center rounded-md border border-ink-700 bg-ink-950 pl-3 focus-within:border-brand-400">
                    <span className="shrink-0 font-mono text-xs text-ink-400">{host}/</span>
                    <input
                      value={slug}
                      onChange={(e) => {
                        setSlugTouched(true);
                        setSlug(e.target.value.toLowerCase().replace(/\s+/g, "-"));
                      }}
                      maxLength={30}
                      className="min-w-0 flex-1 bg-transparent py-2 pr-2 font-mono text-sm text-ink-100 outline-none"
                      aria-describedby="slug-status"
                    />
                  </span>
                  <span id="slug-status" className={`mt-1 block text-xs ${!local.ok || availability.state === "taken" ? "text-danger" : availability.state === "free" ? "text-mint" : "text-ink-400"}`}>
                    {!slug ? "Choisis ton adresse." : !local.ok ? local.error : availability.state === "checking" ? "Vérification…" : availability.state === "taken" ? (availability.message ?? "Adresse déjà prise.") : availability.state === "free" ? "Adresse disponible !" : ""}
                  </span>
                </label>
                <button
                  type="button"
                  onClick={create}
                  disabled={!canCreate || creating}
                  className={`ui-press ui-shine inline-flex h-10 items-center gap-2 rounded-md bg-claim px-4 text-sm font-semibold text-ink-950 transition hover:brightness-110 disabled:opacity-40`}
                  title={ready ? undefined : "Réponds encore à une ou deux questions"}
                >
                  {creating ? <LoaderCircle size={16} className="animate-spin" /> : <Sparkles size={15} />} Créer ma page <ArrowRight size={15} />
                </button>
              </div>
            )}
            {!ready && !limitReached && <p className="mt-2 text-xs text-ink-400">Encore une ou deux réponses et ta page est prête à être créée.</p>}
          </div>
        </section>
      </div>
    </div>
  );
}
