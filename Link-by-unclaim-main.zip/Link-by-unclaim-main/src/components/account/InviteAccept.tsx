"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { LoaderCircle } from "lucide-react";

/** Accepte une invitation à collaborer, puis ouvre la page dans l'éditeur. */
export function InviteAccept({ token }: { token: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  return (
    <>
      <button
        type="button"
        disabled={busy}
        onClick={async () => {
          setBusy(true);
          setError(null);
          const res = await fetch(`/api/invitations/${encodeURIComponent(token)}`, { method: "POST" }).catch(() => null);
          const json = (await res?.json().catch(() => ({}))) as { pageId?: string; error?: string };
          if (res?.ok && json.pageId) {
            router.push(`/dashboard/pages/${json.pageId}`);
            return;
          }
          setError(json.error ?? "Impossible de rejoindre la page, réessaie.");
          setBusy(false);
        }}
        className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-brand-500 px-5 py-3 font-semibold text-ink-950 transition hover:bg-brand-400 disabled:opacity-50"
      >
        {busy && <LoaderCircle size={18} className="animate-spin" />} Rejoindre l&apos;équipe
      </button>
      {error && <p className="mt-3 text-sm text-danger">{error}</p>}
    </>
  );
}
