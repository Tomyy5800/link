"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { LoaderCircle, Send } from "lucide-react";
import { PARTNER_KINDS, PARTNER_KIND_KEYS, type PartnerKind } from "@/lib/partners";
import { Select, TextArea, TextField } from "@/components/ui/controls";

/** Candidature au programme partenaires. */
export function PartnerForm() {
  const router = useRouter();
  const [kind, setKind] = useState<PartnerKind>("createur");
  const [name, setName] = useState("");
  const [url, setUrl] = useState("");
  const [audience, setAudience] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    const res = await fetch("/api/me/partner", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ kind, name, url, audience, message }),
    }).catch(() => null);
    if (res?.ok) {
      router.refresh();
      return;
    }
    const json = (await res?.json().catch(() => ({}))) as { error?: string };
    setError(json.error ?? "Envoi impossible, réessaie.");
    setBusy(false);
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <Select label="Tu es" value={kind} onChange={(v) => setKind(v as PartnerKind)} options={PARTNER_KIND_KEYS.map((k) => ({ value: k, label: PARTNER_KINDS[k] }))} />
        <TextField label="Nom du projet" value={name} maxLength={60} onChange={setName} placeholder="Ma chaîne, mon serveur, ma nation…" />
        <TextField label="Lien principal" value={url} maxLength={300} inputMode="url" onChange={setUrl} placeholder="https://twitch.tv/…" />
        <TextField label="Communauté (facultatif)" value={audience} maxLength={120} onChange={setAudience} placeholder="12 000 abonnés, 800 membres Discord…" />
      </div>
      <TextArea
        label="Présente ton projet"
        value={message}
        maxLength={1500}
        rows={5}
        onChange={setMessage}
        placeholder="Ce que tu fais, ce que tu aimerais construire avec Link by Unclaim, tes événements à venir…"
      />
      {error && <p className="text-sm text-danger">{error}</p>}
      <button
        type="submit"
        disabled={busy || name.trim().length < 2 || message.trim().length < 20}
        className="inline-flex items-center gap-2 rounded-md bg-brand-500 px-4 py-2 text-sm font-semibold text-ink-950 transition hover:bg-brand-400 disabled:opacity-40"
      >
        {busy ? <LoaderCircle size={15} className="animate-spin" /> : <Send size={15} />} Envoyer ma candidature
      </button>
      <p className="text-xs text-ink-400">L&apos;équipe répond en général sous une semaine. Ta candidature est visible uniquement par l&apos;administration.</p>
    </form>
  );
}
