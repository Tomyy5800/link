"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowRight, Check, LoaderCircle, LogOut, ScrollText } from "lucide-react";
import { Logo } from "@/components/brand/Logo";

type Props = {
  next: string;
  name: string;
  avatar: string;
  /** Le compte avait accepté une version précédente. */
  update: boolean;
  summary: string[];
  updated: string;
  minAge: number;
};

function Checkbox({ checked, onChange, children }: { checked: boolean; onChange: (v: boolean) => void; children: React.ReactNode }) {
  return (
    <label className="flex cursor-pointer items-start gap-3 rounded-md border border-ink-700 bg-ink-900/70 p-3 text-sm text-ink-200 transition hover:border-ink-500">
      <input type="checkbox" className="peer sr-only" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      <span
        className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded border transition peer-focus-visible:ring-2 peer-focus-visible:ring-brand-400 ${
          checked ? "border-brand-400 bg-brand-500 text-ink-950" : "border-ink-500"
        }`}
        aria-hidden="true"
      >
        {checked && <Check size={14} strokeWidth={3} />}
      </span>
      <span>{children}</span>
    </label>
  );
}

/** Écran d'accueil : résumé des CGU, acceptation explicite et confirmation de l'âge. */
export function TermsGate({ next, name, avatar, update, summary, updated, minAge }: Props) {
  const router = useRouter();
  const [terms, setTerms] = useState(false);
  const [age, setAge] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function accept() {
    setBusy(true);
    setError(null);
    const res = await fetch("/api/me/terms", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ terms, age }),
    }).catch(() => null);
    if (res?.ok) {
      router.replace(next);
      router.refresh();
      return;
    }
    const json = (await res?.json().catch(() => ({}))) as { error?: string };
    setError(json.error ?? "Impossible d'enregistrer ton choix, réessaie.");
    setBusy(false);
  }

  return (
    <div className="bg-hud min-h-screen">
      <header className="mx-auto flex max-w-5xl items-center justify-between px-4 py-5">
        <Logo />
        <form action="/api/auth/logout" method="post">
          <button type="submit" className="inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm text-ink-400 transition hover:text-ink-100">
            <LogOut size={15} /> Déconnexion
          </button>
        </form>
      </header>
      <main className="mx-auto max-w-xl px-4 pt-6 pb-20 animate-rise">
        <div className="flex items-center gap-3">
          <img src={avatar} alt="" className="h-12 w-12 rounded-full ring-2 ring-ink-700" />
          <p className="text-sm text-ink-400">
            {update ? "Content de te revoir," : "Bienvenue,"} <span className="font-semibold text-ink-100">{name}</span>
          </p>
        </div>
        <h1 className="mt-6 font-display text-3xl font-bold tracking-tight">{update ? "Nos conditions ont évolué" : "Avant de commencer"}</h1>
        <p className="mt-2 text-ink-300">
          {update
            ? `Les conditions d'utilisation ont été mises à jour le ${updated}. Prends une minute pour les relire.`
            : "Voici l'essentiel des règles de Link by Unclaim. Elles protègent ta page, tes visiteurs et la communauté."}
        </p>

        <section className="hud-panel mt-6 rounded-[2px] border border-ink-700 bg-ink-900/80 p-5" aria-label="Résumé des conditions">
          <p className="hud-label flex items-center gap-2 text-ink-400">
            <ScrollText size={14} /> L&apos;essentiel
          </p>
          <ul className="mt-3 space-y-2.5 text-sm leading-relaxed text-ink-200">
            {summary.map((line) => (
              <li key={line} className="flex gap-2.5">
                <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-[1px] bg-claim" aria-hidden="true" />
                {line}
              </li>
            ))}
          </ul>
          <p className="mt-4 text-sm">
            <a href="/cgu" target="_blank" rel="noopener" className="text-brand-300 hover:underline">
              Lire les conditions complètes
            </a>
            <span className="text-ink-500"> · </span>
            <a href="/confidentialite" target="_blank" rel="noopener" className="text-brand-300 hover:underline">
              Politique de confidentialité
            </a>
          </p>
        </section>

        <div className="mt-6 space-y-2.5">
          <Checkbox checked={terms} onChange={setTerms}>
            J&apos;ai lu et j&apos;accepte les conditions générales d&apos;utilisation et la politique de confidentialité.
          </Checkbox>
          <Checkbox checked={age} onChange={setAge}>
            J&apos;ai au moins {minAge} ans, ou l&apos;accord d&apos;un parent ou tuteur légal.
          </Checkbox>
        </div>

        {error && (
          <p role="alert" className="mt-4 text-sm text-danger">
            {error}
          </p>
        )}

        <button
          type="button"
          onClick={accept}
          disabled={!terms || !age || busy}
          className="group mt-6 flex w-full items-center justify-center gap-2 rounded-md bg-brand-500 px-5 py-3 font-semibold text-ink-950 transition hover:bg-brand-400 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {busy && <LoaderCircle size={18} className="animate-spin" />}
          {update ? "Accepter et continuer" : "Accepter et créer mon espace"}
          {!busy && <ArrowRight size={18} />}
        </button>
        <p className="mt-3 text-center text-xs text-ink-400">Tu peux refuser en te déconnectant : aucune page ne sera créée.</p>
      </main>
    </div>
  );
}
