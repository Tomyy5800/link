"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { CreditCard, LoaderCircle, RotateCcw, XCircle } from "lucide-react";
import { confirmDialog } from "@/lib/confirm";
import { toast } from "@/lib/toast";

/** Actions de l'abonné : résilier (fin de période), reprendre, portail de facturation Stripe. */
export function SubscriptionManager({ renews, until, portal }: { renews: boolean; until: string; portal: boolean }) {
  const router = useRouter();
  const [busy, setBusy] = useState<string | null>(null);
  const date = new Date(until).toLocaleDateString("fr-FR", { dateStyle: "long", timeZone: "Europe/Paris" });

  async function act(action: "cancel" | "resume" | "portal") {
    if (action === "cancel") {
      const ok = await confirmDialog({
        title: "Résilier l'abonnement ?",
        message: `Tu gardes toutes tes fonctions jusqu'au ${date}, puis rien ne sera plus prélevé. Tu pourras reprendre l'abonnement d'ici là.`,
        confirmLabel: "Résilier",
        tone: "danger",
      });
      if (!ok) return;
    }
    setBusy(action);
    const res = await fetch("/api/me/subscription", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action }) }).catch(() => null);
    const json = (await res?.json().catch(() => ({}))) as { url?: string; error?: string } | undefined;
    setBusy(null);
    if (!res?.ok) {
      toast(json?.error ?? "L'action n'a pas abouti, réessaie.", { tone: "error" });
      return;
    }
    if (action === "portal" && json?.url) {
      window.location.href = json.url;
      return;
    }
    toast(action === "cancel" ? `Abonnement résilié : actif jusqu'au ${date}.` : "Abonnement repris : il sera renouvelé normalement.", { tone: "success" });
    router.refresh();
  }

  const btn = "inline-flex items-center gap-1.5 rounded-md border px-3 py-2 text-sm font-medium transition-colors disabled:opacity-50";
  return (
    <div className="flex flex-wrap gap-2">
      {renews ? (
        <button type="button" disabled={busy !== null} onClick={() => void act("cancel")} className={`${btn} border-ink-600 text-ink-200 hover:border-danger/60 hover:text-danger`}>
          {busy === "cancel" ? <LoaderCircle size={15} className="animate-spin" /> : <XCircle size={15} />} Résilier
        </button>
      ) : (
        <button type="button" disabled={busy !== null} onClick={() => void act("resume")} className={`${btn} border-mint/50 text-mint hover:bg-mint/10`}>
          {busy === "resume" ? <LoaderCircle size={15} className="animate-spin" /> : <RotateCcw size={15} />} Reprendre l&apos;abonnement
        </button>
      )}
      {portal && (
        <button type="button" disabled={busy !== null} onClick={() => void act("portal")} className={`${btn} border-ink-600 text-ink-200 hover:border-ink-400`}>
          {busy === "portal" ? <LoaderCircle size={15} className="animate-spin" /> : <CreditCard size={15} />} Carte et factures
        </button>
      )}
    </div>
  );
}
