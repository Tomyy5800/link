"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { CopyPlus, LoaderCircle } from "lucide-react";
import { toast } from "@/lib/toast";

/** Duplique une page (privée, nouvelle adresse) puis l'ouvre dans l'éditeur. */
export function DuplicateButton({ pageId, name }: { pageId: string; name: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  return (
    <button
      type="button"
      disabled={busy}
      onClick={async () => {
        setBusy(true);
        const res = await fetch(`/api/me/pages/${pageId}/duplicate`, { method: "POST" }).catch(() => null);
        const json = (await res?.json().catch(() => ({}))) as { id?: string; error?: string };
        if (res?.ok && json.id) {
          toast(`Copie de « ${name} » créée`, { tone: "success", description: "Elle reste privée tant que tu ne la publies pas." });
          router.push(`/dashboard/pages/${json.id}`);
          return;
        }
        toast(json.error ?? "La copie a échoué, réessaie.", { tone: "error" });
        setBusy(false);
      }}
      className="ui-press inline-flex items-center justify-center rounded-md border border-ink-600 px-2.5 py-2 text-ink-300 transition hover:border-ink-400 hover:text-ink-100 disabled:opacity-40"
      title={`Dupliquer « ${name} »`}
      aria-label={`Dupliquer « ${name} »`}
    >
      {busy ? <LoaderCircle size={15} className="animate-spin" /> : <CopyPlus size={15} />}
    </button>
  );
}
