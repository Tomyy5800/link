"use client";

import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Check, CircleCheckBig, Copy, Mail, PackageCheck, RotateCcw, ShoppingBag, Trash2, X } from "lucide-react";
import { confirmDialog } from "@/lib/confirm";
import { celebrate } from "@/lib/confetti";
import { ORDER_STATUS_LABEL, formatMoney, type OrderItem, type OrderStatus } from "@/lib/shop";
import { toast } from "@/lib/toast";

export type OrderRow = {
  id: string;
  pageId: string;
  pageName: string;
  pageSlug: string;
  reference: string;
  items: OrderItem[];
  total: number | null;
  currency: string;
  name: string;
  contact: string;
  note: string;
  status: OrderStatus;
  createdAt: string;
  canEdit: boolean;
};

const FILTERS: { key: OrderStatus | "all"; label: string }[] = [
  { key: "all", label: "Toutes" },
  { key: "new", label: "Nouvelles" },
  { key: "accepted", label: "Acceptées" },
  { key: "done", label: "Terminées" },
  { key: "cancelled", label: "Annulées" },
];

const STATUS_STYLE: Record<OrderStatus, string> = {
  new: "border-brand-400/50 bg-brand-500/15 text-brand-200",
  accepted: "border-claim/50 bg-claim/15 text-claim",
  done: "border-mint/50 bg-mint/15 text-mint",
  cancelled: "border-ink-600 bg-ink-800 text-ink-400",
};

// Fuseau fixe : le serveur et le navigateur écrivent la même date (pas d'écart à l'hydratation).
const fmt = new Intl.DateTimeFormat("fr-FR", { dateStyle: "medium", timeStyle: "short", timeZone: "Europe/Paris" });
const isEmail = (v: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);

/** « il y a 5 min » une fois la page affichée ; la date complète avant (rendu serveur). */
function since(iso: string, now: number | null): string {
  if (now === null) return fmt.format(new Date(iso));
  const minutes = Math.round((now - Date.parse(iso)) / 60_000);
  if (minutes < 1) return "à l'instant";
  if (minutes < 60) return `il y a ${minutes} min`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `il y a ${hours} h`;
  const days = Math.round(hours / 24);
  return days < 30 ? `il y a ${days} j` : fmt.format(new Date(iso));
}

/** Somme par devise, pour les commandes à prix connu. */
function sumByCurrency(orders: OrderRow[]): string {
  const sums = new Map<string, number>();
  for (const o of orders) if (o.total !== null) sums.set(o.currency, (sums.get(o.currency) ?? 0) + o.total);
  if (!sums.size) return "—";
  return [...sums.entries()].map(([currency, cents]) => formatMoney(cents, currency)).join(" + ");
}

/**
 * Commandes de la boutique : chiffres du moment, filtres par statut (pastille qui glisse),
 * cartes de commande avec articles, total et réponse rapide. Le suivi se fait en un clic :
 * accepter, terminer, annuler, rouvrir.
 */
export function OrdersBoard({ initial, showPage }: { initial: OrderRow[]; showPage: boolean }) {
  const [orders, setOrders] = useState(initial);
  const [filter, setFilter] = useState<OrderStatus | "all">(initial.some((o) => o.status === "new") ? "new" : "all");
  const [flash, setFlash] = useState<string | null>(null);
  const tabsRef = useRef<HTMLDivElement>(null);
  const [pill, setPill] = useState<{ left: number; width: number } | null>(null);
  const [now, setNow] = useState<number | null>(null);

  // Temps relatif calculé dans le navigateur, et tenu à jour chaque minute.
  useEffect(() => {
    setNow(Date.now());
    const timer = window.setInterval(() => setNow(Date.now()), 60_000);
    return () => window.clearInterval(timer);
  }, []);

  useLayoutEffect(() => {
    const active = tabsRef.current?.querySelector<HTMLElement>('[aria-selected="true"]');
    if (active) setPill({ left: active.offsetLeft, width: active.offsetWidth });
  }, [filter, orders.length]);

  const counts = useMemo(() => {
    const c: Record<OrderStatus | "all", number> = { all: orders.length, new: 0, accepted: 0, done: 0, cancelled: 0 };
    for (const o of orders) c[o.status] += 1;
    return c;
  }, [orders]);
  const shown = filter === "all" ? orders : orders.filter((o) => o.status === filter);

  async function setStatus(order: OrderRow, status: OrderStatus) {
    const previous = order.status;
    setOrders((list) => list.map((o) => (o.id === order.id ? { ...o, status } : o)));
    setFlash(order.id);
    window.setTimeout(() => setFlash(null), 900);
    const res = await fetch(`/api/me/pages/${order.pageId}/orders`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ids: [order.id], status }),
    }).catch(() => null);
    if (!res?.ok) {
      setOrders((list) => list.map((o) => (o.id === order.id ? { ...o, status: previous } : o)));
      toast("Le changement n'a pas été enregistré, réessaie.", { tone: "error" });
      return;
    }
    if (status === "done") {
      celebrate();
      toast("Commande terminée : bravo !", { tone: "success" });
    } else {
      toast(`Commande ${ORDER_STATUS_LABEL[status].toLowerCase()}`, {
        tone: "success",
        action: { label: "Annuler", onClick: () => void setStatus({ ...order, status }, previous) },
      });
    }
  }

  async function remove(order: OrderRow) {
    const ok = await confirmDialog({ title: "Supprimer cette commande ?", message: "Elle sera effacée définitivement.", confirmLabel: "Supprimer", tone: "danger" });
    if (!ok) return;
    const res = await fetch(`/api/me/pages/${order.pageId}/orders?orderId=${order.id}`, { method: "DELETE" }).catch(() => null);
    if (res?.ok) {
      setOrders((list) => list.filter((o) => o.id !== order.id));
      toast("Commande supprimée", { tone: "success" });
    } else {
      toast("La suppression a échoué, réessaie.", { tone: "error" });
    }
  }

  const replyHref = (o: OrderRow) => {
    const lines = o.items.map((i) => `- ${i.quantity} × ${i.name}${i.option ? ` (${i.option})` : ""}`).join("\n");
    const total = o.total !== null ? `\nTotal : ${formatMoney(o.total, o.currency)}` : "";
    const body = `Bonjour ${o.name},\n\nMerci pour ta commande n° ${o.reference} sur ${o.pageName} :\n${lines}${total}\n\n`;
    return `mailto:${o.contact}?subject=${encodeURIComponent(`Ta commande ${o.reference} · ${o.pageName}`)}&body=${encodeURIComponent(body)}`;
  };

  return (
    <div>
      <ul className="ui-stagger grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[
          { label: "Nouvelles", value: String(counts.new), tone: "text-brand-300", icon: ShoppingBag },
          { label: "En préparation", value: String(counts.accepted), tone: "text-claim", icon: PackageCheck },
          { label: "À encaisser", value: sumByCurrency(orders.filter((o) => o.status === "new" || o.status === "accepted")), tone: "text-ink-50", icon: CircleCheckBig },
          { label: "Terminées", value: String(counts.done), tone: "text-mint", icon: Check },
        ].map(({ label, value, tone, icon: Icon }) => (
          <li key={label} data-spotlight className="ui-spotlight ui-lift rounded-xl border border-ink-700 bg-ink-900/80 p-4">
            <p className="hud-label flex items-center gap-1.5 text-ink-400">
              <Icon size={12} aria-hidden="true" /> {label}
            </p>
            <p className={`mt-1 truncate font-display text-2xl font-bold tabular-nums ${tone}`}>{value}</p>
          </li>
        ))}
      </ul>

      <div ref={tabsRef} role="tablist" aria-label="Filtrer les commandes" className="scrollbar-none relative mt-6 flex gap-1 overflow-x-auto rounded-xl border border-ink-700 bg-ink-900/70 p-1">
        {pill && (
          <span
            className="pointer-events-none absolute inset-y-1 rounded-lg bg-ink-750 ring-1 ring-white/10 transition-[left,width] duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]"
            style={{ left: pill.left, width: pill.width }}
            aria-hidden="true"
          />
        )}
        {FILTERS.map(({ key, label }) => (
          <button
            key={key}
            type="button"
            role="tab"
            aria-selected={filter === key}
            onClick={() => setFilter(key)}
            className={`relative z-10 flex shrink-0 items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-semibold transition-colors ${filter === key ? "text-ink-50" : "text-ink-400 hover:text-ink-200"}`}
          >
            {label}
            <span className={`rounded-md px-1.5 font-mono text-[11px] ${key === "new" && counts.new ? "bg-brand-500 text-ink-950" : "bg-ink-800 text-ink-400"}`}>{counts[key]}</span>
          </button>
        ))}
      </div>

      {shown.length === 0 ? (
        <p className="mt-10 text-center text-sm text-ink-400">Aucune commande dans cette catégorie.</p>
      ) : (
        <ul key={filter} className="ui-stagger mt-4 space-y-3">
          {shown.map((o) => (
            <li
              key={o.id}
              className={`rounded-xl border bg-ink-900/85 p-4 transition-[border-color,box-shadow] duration-500 ${
                flash === o.id ? "border-brand-400 shadow-[0_0_0_4px_rgba(34,201,232,0.15)]" : o.status === "new" ? "border-brand-500/40" : "border-ink-700"
              } ${o.status === "cancelled" ? "opacity-60" : ""}`}
            >
              <div className="flex flex-wrap items-start gap-x-3 gap-y-1">
                <div className="min-w-0 flex-1">
                  <p className="flex flex-wrap items-baseline gap-x-2">
                    <span className="font-semibold text-ink-50">{o.name}</span>
                    <span className="truncate text-xs text-ink-400">{o.contact}</span>
                  </p>
                  <p className="mt-0.5 font-mono text-[11px] text-ink-500">
                    n° {o.reference} · {since(o.createdAt, now)}
                    {showPage && ` · /${o.pageSlug}`}
                  </p>
                </div>
                <span key={o.status} className={`animate-pop rounded-full border px-2.5 py-0.5 text-xs font-semibold ${STATUS_STYLE[o.status]}`}>{ORDER_STATUS_LABEL[o.status]}</span>
              </div>

              <ul className="mt-3 divide-y divide-ink-800 rounded-lg border border-ink-800 bg-ink-950/40">
                {o.items.map((item, i) => (
                  <li key={i} className="flex items-center gap-3 px-3 py-2 text-sm">
                    <span className="flex h-6 min-w-6 items-center justify-center rounded-md bg-ink-800 px-1.5 font-mono text-xs text-ink-200">{item.quantity}×</span>
                    <span className="min-w-0 flex-1 truncate text-ink-100">
                      {item.name}
                      {item.option && <span className="text-ink-400"> · {item.option}</span>}
                    </span>
                    <span className="shrink-0 font-mono text-ink-300 tabular-nums">{item.price === null ? "libre" : formatMoney(item.price * item.quantity, o.currency)}</span>
                  </li>
                ))}
                <li className="flex items-center justify-between px-3 py-2 text-sm font-semibold">
                  <span className="text-ink-300">Total</span>
                  <span className="font-mono text-ink-50 tabular-nums">{o.total === null ? "À convenir" : formatMoney(o.total, o.currency)}</span>
                </li>
              </ul>
              {o.note && <p className="mt-2 border-l-2 border-ink-600 pl-3 text-sm whitespace-pre-wrap text-ink-300">{o.note}</p>}

              <div className="mt-3 flex flex-wrap items-center gap-2">
                {o.canEdit && o.status === "new" && (
                  <button type="button" onClick={() => void setStatus(o, "accepted")} className="ui-press inline-flex items-center gap-1.5 rounded-md bg-brand-500 px-3 py-1.5 text-xs font-semibold text-ink-950 hover:bg-brand-400">
                    <Check size={13} /> Accepter
                  </button>
                )}
                {o.canEdit && o.status === "accepted" && (
                  <button type="button" onClick={() => void setStatus(o, "done")} className="ui-press inline-flex items-center gap-1.5 rounded-md bg-mint px-3 py-1.5 text-xs font-semibold text-ink-950 hover:brightness-110">
                    <PackageCheck size={13} /> Marquer terminée
                  </button>
                )}
                {isEmail(o.contact) ? (
                  <a href={replyHref(o)} className="ui-press inline-flex items-center gap-1.5 rounded-md border border-ink-600 px-3 py-1.5 text-xs text-ink-200 hover:border-ink-400">
                    <Mail size={13} /> Répondre
                  </a>
                ) : (
                  <button
                    type="button"
                    onClick={() => void navigator.clipboard.writeText(o.contact).then(() => toast("Contact copié", { tone: "success" }))}
                    className="ui-press inline-flex items-center gap-1.5 rounded-md border border-ink-600 px-3 py-1.5 text-xs text-ink-200 hover:border-ink-400"
                  >
                    <Copy size={13} /> Copier le contact
                  </button>
                )}
                {o.canEdit && (o.status === "new" || o.status === "accepted") && (
                  <button type="button" onClick={() => void setStatus(o, "cancelled")} className="inline-flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs text-ink-400 hover:text-ink-100">
                    <X size={13} /> Annuler
                  </button>
                )}
                {o.canEdit && (o.status === "done" || o.status === "cancelled") && (
                  <button type="button" onClick={() => void setStatus(o, "new")} className="inline-flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs text-ink-400 hover:text-ink-100">
                    <RotateCcw size={13} /> Rouvrir
                  </button>
                )}
                {o.canEdit && (
                  <button type="button" onClick={() => void remove(o)} className="ml-auto inline-flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs text-ink-500 hover:text-danger">
                    <Trash2 size={13} /> Supprimer
                  </button>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
