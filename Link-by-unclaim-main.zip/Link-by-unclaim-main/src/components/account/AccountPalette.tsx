"use client";

import { useMemo } from "react";
import { useRouter } from "next/navigation";
import { Bot, ExternalLink, Handshake, Inbox, LayoutGrid, LogOut, Pencil, Plus, Shield, Sparkles, UserRound } from "lucide-react";
import { CommandPalette, type Command } from "@/components/ui/CommandPalette";

type PageItem = { id: string; name: string; slug: string };

/** Palette de commandes de « Mon espace » : sections, pages, création. */
export function AccountPalette({ pages, admin }: { pages: PageItem[]; admin: boolean }) {
  const router = useRouter();
  const commands = useMemo<Command[]>(() => {
    const go = (href: string) => () => router.push(href);
    return [
      { id: "new", group: "Créer", label: "Nouvelle page avec l'assistant", icon: Bot, keywords: "ia creer ajouter", run: go("/dashboard/assistant") },
      { id: "new-form", group: "Créer", label: "Nouvelle page (formulaire)", icon: Plus, keywords: "creer ajouter", run: go("/dashboard/nouvelle") },
      ...pages.map((p) => ({ id: `edit-${p.id}`, group: "Mes pages", label: `Modifier ${p.name}`, hint: `/${p.slug}`, icon: Pencil, keywords: p.slug, run: go(`/dashboard/pages/${p.id}`) })),
      ...pages.map((p) => ({ id: `view-${p.id}`, group: "Mes pages", label: `Voir ${p.name}`, hint: `/${p.slug}`, icon: ExternalLink, keywords: `${p.slug} publique ouvrir`, run: () => window.open(`/${p.slug}`, "_blank") })),
      { id: "home", group: "Aller à", label: "Mes pages", icon: LayoutGrid, run: go("/dashboard") },
      { id: "messages", group: "Aller à", label: "Messages", icon: Inbox, keywords: "contact boite reception", run: go("/dashboard/messages") },
      { id: "account", group: "Aller à", label: "Compte et données", icon: UserRound, keywords: "export suppression appareils", run: go("/dashboard/compte") },
      { id: "plan", group: "Aller à", label: "Offre et formules", icon: Sparkles, keywords: "link+ pro equipe abonnement code", run: go("/dashboard/abonnement") },
      { id: "partner", group: "Aller à", label: "Partenariat", icon: Handshake, run: go("/dashboard/partenariat") },
      ...(admin ? [{ id: "admin", group: "Aller à", label: "Administration", icon: Shield, run: go("/admin") }] : []),
      {
        id: "logout",
        group: "Compte",
        label: "Se déconnecter",
        icon: LogOut,
        run: () => {
          const form = document.createElement("form");
          form.method = "post";
          form.action = "/api/auth/logout";
          document.body.appendChild(form);
          form.submit();
        },
      },
    ];
  }, [pages, admin, router]);
  return <CommandPalette commands={commands} />;
}
