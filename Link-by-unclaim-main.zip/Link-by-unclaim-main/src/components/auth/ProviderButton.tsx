"use client";

import { useEffect, useState } from "react";
import { Castle, History, KeyRound, LoaderCircle } from "lucide-react";
import { BRAND_ICONS } from "@/components/icons/brand-paths";
import { providerMeta } from "@/lib/identity";

const LAST_KEY = "lbu:last-provider";

/** Logo d'un fournisseur de connexion (marques simple-icons, Microsoft dessiné, NationsGlory par un château). */
export function ProviderIcon({ provider, size = 18 }: { provider: string; size?: number }) {
  if (provider === "microsoft") {
    return (
      <svg viewBox="0 0 24 24" width={size} height={size} aria-hidden="true">
        <rect x="2" y="2" width="9.5" height="9.5" fill="#f25022" />
        <rect x="12.5" y="2" width="9.5" height="9.5" fill="#7fba00" />
        <rect x="2" y="12.5" width="9.5" height="9.5" fill="#00a4ef" />
        <rect x="12.5" y="12.5" width="9.5" height="9.5" fill="#ffb900" />
      </svg>
    );
  }
  if (provider === "nationsglory") return <Castle size={size} aria-hidden="true" />;
  if (provider === "google") {
    // Logo « G » aux couleurs de Google (bouton blanc).
    return (
      <svg viewBox="0 0 48 48" width={size} height={size} aria-hidden="true">
        <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
        <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
        <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
        <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
      </svg>
    );
  }
  const brand = BRAND_ICONS[provider as keyof typeof BRAND_ICONS];
  if (!brand) return <KeyRound size={size} aria-hidden="true" />;
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} fill="currentColor" aria-hidden="true">
      <path d={brand.path} />
    </svg>
  );
}

/**
 * Bouton « Continuer avec … » : envoie directement chez le fournisseur via Unclaim Auth, sans
 * écran intermédiaire. Pendant la redirection, le bouton l'annonce ; le dernier moyen utilisé
 * sur cet appareil est signalé.
 */
export function ProviderButton({ provider, next, compact = false }: { provider: string; next?: string; compact?: boolean }) {
  const meta = providerMeta(provider);
  const href = `/api/auth/login?provider=${encodeURIComponent(provider)}${next ? `&next=${encodeURIComponent(next)}` : ""}`;
  const [going, setGoing] = useState(false);
  const [last, setLast] = useState(false);

  useEffect(() => {
    try {
      setLast(localStorage.getItem(LAST_KEY) === provider);
    } catch {
      // stockage indisponible : pas de rappel
    }
    // Retour arrière depuis le fournisseur : le bouton redevient cliquable.
    const reset = () => setGoing(false);
    window.addEventListener("pageshow", reset);
    return () => window.removeEventListener("pageshow", reset);
  }, [provider]);

  return (
    <a
      href={href}
      onClick={() => {
        setGoing(true);
        try {
          localStorage.setItem(LAST_KEY, provider);
        } catch {
          // stockage indisponible : on se connecte quand même
        }
      }}
      aria-busy={going || undefined}
      className={`ui-press ui-shine relative flex items-center justify-center gap-2.5 rounded-md font-semibold transition hover:brightness-110 hover:shadow-[0_10px_30px_-12px_var(--glow)] ${
        compact ? "px-3.5 py-2 text-sm" : "w-full px-4 py-3"
      } ${provider === "google" || provider === "apple" ? "ring-1 ring-inset ring-black/10" : ""}`}
      style={{ background: meta.color, color: meta.text, "--glow": meta.color } as React.CSSProperties}
    >
      {going ? <LoaderCircle size={compact ? 16 : 20} className="animate-spin" /> : <ProviderIcon provider={provider} size={compact ? 16 : 20} />}
      {going ? `Connexion à ${meta.name}…` : compact ? meta.name : `Continuer avec ${meta.name}`}
      {last && !compact && !going && (
        <span className="absolute -top-2 right-3 inline-flex items-center gap-1 rounded-full bg-ink-100 px-2 py-0.5 text-[10px] font-semibold text-ink-950 shadow">
          <History size={10} /> Dernière utilisée
        </span>
      )}
    </a>
  );
}
