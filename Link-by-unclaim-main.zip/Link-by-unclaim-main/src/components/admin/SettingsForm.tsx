"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Check, LoaderCircle, Save } from "lucide-react";
import { FEATURES, FEATURE_KEYS, type FeatureMode, type LimitTier, type PlanLimits, type PlatformSettings } from "@/lib/features";
import { Toggle } from "@/components/ui/controls";

const MODES: { value: FeatureMode; label: string }[] = [
  { value: "all", label: "Tous" },
  { value: "plus", label: "Link+" },
  { value: "pro", label: "Pro" },
  { value: "team", label: "Équipe" },
  { value: "off", label: "Coupé" },
];

const LIMIT_COLUMNS: { tier: LimitTier; label: (premiumName: string) => string; tone: string }[] = [
  { tier: "free", label: () => "Gratuit", tone: "" },
  { tier: "plus", label: (n) => n, tone: "text-claim" },
  { tier: "pro", label: (n) => `${n} Pro`, tone: "text-claim" },
  { tier: "team", label: (n) => `${n} Équipe`, tone: "text-claim" },
  { tier: "partner", label: () => "Partenaires", tone: "text-brand-300" },
];

const LIMITS: { key: keyof PlanLimits; label: string; unit: string; max: number; min: number }[] = [
  { key: "pages", label: "Pages par compte", unit: "", min: 1, max: 100 },
  { key: "members", label: "Collaborateurs par page", unit: "", min: 0, max: 100 },
  { key: "blocks", label: "Blocs par page", unit: "", min: 1, max: 120 },
  { key: "uploads", label: "Fichiers importés", unit: "", min: 0, max: 5000 },
  { key: "imageMb", label: "Taille d'une image", unit: "Mo", min: 1, max: 20 },
  { key: "mediaMb", label: "Taille audio / vidéo", unit: "Mo", min: 0, max: 50 },
  { key: "statsDays", label: "Historique des stats", unit: "jours", min: 7, max: 120 },
  { key: "aiMessages", label: "Messages à l'assistant IA", unit: "par jour", min: 0, max: 2000 },
  { key: "roles", label: "Rôles personnalisés", unit: "par page", min: 0, max: 50 },
  { key: "domains", label: "Domaines personnels", unit: "par compte", min: 0, max: 20 },
];

function Section({ title, description, children }: { title: string; description?: string; children: React.ReactNode }) {
  return (
    <section className="hud-panel space-y-4 rounded-[2px] border border-ink-700 bg-ink-900/80 p-4">
      <div>
        <h2 className="hud-label text-ink-400">{title}</h2>
        {description && <p className="mt-1 text-xs text-ink-400">{description}</p>}
      </div>
      {children}
    </section>
  );
}

/** Réglages de la plateforme : qui a accès à quoi, limites par offre, domaines bloqués, annonces. */
export function SettingsForm({ initial }: { initial: PlatformSettings }) {
  const router = useRouter();
  const [settings, setSettings] = useState(initial);
  const [domains, setDomains] = useState(initial.blockedDomains.join("\n"));
  const [state, setState] = useState<{ status: "idle" | "saving" | "saved" | "error"; message?: string }>({ status: "idle" });
  const set = (patch: Partial<PlatformSettings>) => {
    setSettings((s) => ({ ...s, ...patch }));
    setState({ status: "idle" });
  };

  async function save(event: React.FormEvent) {
    event.preventDefault();
    setState({ status: "saving" });
    const blockedDomains = [...new Set(domains.split(/[\s,]+/).map((d) => d.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, "")).filter(Boolean))];
    const res = await fetch("/api/admin/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      // Seulement les réglages de cet écran : les tarifs et les infos légales ont leur propre page.
      body: JSON.stringify({
        features: settings.features,
        limits: settings.limits,
        blockedDomains,
        registrationsOpen: settings.registrationsOpen,
        announcement: settings.announcement,
      }),
    }).catch(() => null);
    const json = (await res?.json().catch(() => ({}))) as { error?: string; settings?: PlatformSettings } | undefined;
    if (!res?.ok || !json?.settings) {
      setState({ status: "error", message: json?.error ?? "Enregistrement impossible." });
      return;
    }
    setSettings(json.settings);
    setDomains(json.settings.blockedDomains.join("\n"));
    setState({ status: "saved" });
    router.refresh();
  }

  const setLimit = (plan: LimitTier, key: keyof PlanLimits, value: number) =>
    set({ limits: { ...settings.limits, [plan]: { ...settings.limits[plan], [key]: value } } });

  return (
    <form onSubmit={save} className="space-y-6">
      <Section
        title="Fonctionnalités"
        description={`« Tous » : ouverte à chaque compte · « ${settings.premiumName} », « Pro », « Équipe » : réservée à partir de cette formule (les formules supérieures, les partenaires et les admins l'ont aussi) · « Coupé » : masquée partout, y compris sur les pages existantes.`}
      >
        <ul className="divide-y divide-ink-800">
          {FEATURE_KEYS.map((key) => (
            <li key={key} className="flex flex-col gap-2 py-3 sm:flex-row sm:items-center">
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-ink-100">{FEATURES[key].label}</p>
                <p className="text-xs text-ink-400">{FEATURES[key].description}</p>
              </div>
              <div role="radiogroup" aria-label={FEATURES[key].label} className="flex shrink-0 rounded-md border border-ink-700 bg-ink-950 p-0.5">
                {MODES.map((mode) => {
                  const active = settings.features[key] === mode.value;
                  const tone = mode.value === "off" ? "bg-danger/80 text-ink-950" : mode.value === "all" ? "bg-brand-500 text-ink-950" : "bg-claim text-ink-950";
                  return (
                    <button
                      key={mode.value}
                      type="button"
                      role="radio"
                      aria-checked={active}
                      onClick={() => set({ features: { ...settings.features, [key]: mode.value } })}
                      className={`min-w-12 rounded-[4px] px-2 py-1 text-xs font-semibold transition ${active ? tone : "text-ink-400 hover:text-ink-200"}`}
                    >
                      {mode.label}
                    </button>
                  );
                })}
              </div>
            </li>
          ))}
        </ul>
      </Section>

      <Section title="Limites par offre" description="Appliquées à l'enregistrement et à l'import. Une page existante au-delà de la limite reste affichée mais ne peut plus grandir.">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-sm">
            <thead>
              <tr className="text-left text-xs text-ink-400">
                <th className="py-2 font-medium">Limite</th>
                {LIMIT_COLUMNS.map((col) => (
                  <th key={col.tier} className={`py-2 font-medium ${col.tone}`}>
                    {col.label(settings.premiumName)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-ink-800">
              {LIMITS.map((limit) => (
                <tr key={limit.key}>
                  <td className="py-2 pr-3 text-ink-200">
                    {limit.label}
                    {limit.unit && <span className="text-xs text-ink-500"> ({limit.unit})</span>}
                  </td>
                  {LIMIT_COLUMNS.map(({ tier: plan }) => (
                    <td key={plan} className="py-2 pr-3">
                      <input
                        type="number"
                        className="field !h-8 !w-20 font-mono"
                        min={limit.min}
                        max={limit.max}
                        value={settings.limits[plan][limit.key]}
                        onChange={(e) => setLimit(plan, limit.key, Math.max(limit.min, Math.min(limit.max, Math.trunc(Number(e.target.value) || 0))))}
                        aria-label={`${limit.label} (${LIMIT_COLUMNS.find((c) => c.tier === plan)!.label(settings.premiumName)})`}
                      />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="text-xs text-ink-400">Audio et vidéo de fond : mets 0 Mo pour interdire l&apos;import sur une offre.</p>
      </Section>

      <Section title="Plateforme">
        <Toggle
          label="Création de nouvelles pages"
          description="Coupe-la en cas d'abus ou de maintenance : les pages existantes restent en ligne."
          checked={settings.registrationsOpen}
          onChange={(registrationsOpen) => set({ registrationsOpen })}
        />
        <label className="block space-y-1.5">
          <span className="text-[0.8rem] font-medium text-ink-200">Annonce dans l&apos;éditeur</span>
          <textarea
            className="field"
            rows={2}
            maxLength={280}
            value={settings.announcement}
            placeholder="Ex. : maintenance prévue dimanche à 22 h."
            onChange={(e) => set({ announcement: e.target.value })}
          />
          <span className="text-xs text-ink-400">Vide : aucune annonce. Affichée en haut de l&apos;éditeur de chaque utilisateur.</span>
        </label>
        <label className="block space-y-1.5">
          <span className="text-[0.8rem] font-medium text-ink-200">Domaines bloqués</span>
          <textarea
            className="field font-mono text-xs"
            rows={5}
            value={domains}
            placeholder={"exemple-arnaque.com\n*.domaine-interdit.net"}
            onChange={(e) => {
              setDomains(e.target.value);
              setState({ status: "idle" });
            }}
          />
          <span className="text-xs text-ink-400">Un domaine par ligne, sous-domaines compris. Les intégrations vers ces sites sont masquées sur toutes les pages.</span>
        </label>
      </Section>

      <div className="sticky bottom-4 z-10 flex items-center justify-end gap-3 rounded-md border border-ink-700 bg-ink-900/95 p-3 shadow-2xl shadow-black/50 backdrop-blur">
        {state.status === "error" && (
          <p className="mr-auto text-sm text-danger" role="alert">
            {state.message}
          </p>
        )}
        {state.status === "saved" && (
          <p className="mr-auto inline-flex items-center gap-1.5 text-sm text-mint" role="status">
            <Check size={15} /> Enregistré : appliqué partout sous 30 secondes.
          </p>
        )}
        <button
          type="submit"
          disabled={state.status === "saving"}
          className="inline-flex items-center gap-2 rounded-md bg-brand-500 px-4 py-2 text-sm font-semibold text-ink-950 transition hover:bg-brand-400 disabled:opacity-50"
        >
          {state.status === "saving" ? <LoaderCircle size={16} className="animate-spin" /> : <Save size={16} />} Enregistrer
        </button>
      </div>
    </form>
  );
}
