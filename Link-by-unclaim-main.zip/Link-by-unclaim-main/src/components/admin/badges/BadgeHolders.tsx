"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { LoaderCircle, Search, Sparkles, UserMinus, UserPlus } from "lucide-react";
import { confirmDialog } from "@/lib/confirm";
import { toast } from "@/lib/toast";

type Found = { id: string; name: string; username: string; avatar: string; slug: string | null };

export type HolderRow = {
  id: string;
  name: string;
  username: string;
  avatar: string;
  source: string | null;
  since: string | null;
  expiresAt: string | null;
  note: string;
};

const SOURCES: Record<string, string> = { manual: "à la main", auto: "premiers comptes", discord: "rôle Discord", purchase: "achat" };
const fmt = new Intl.DateTimeFormat("fr-FR", { dateStyle: "medium", timeZone: "Europe/Paris" });

/** Titulaires d'un badge : recherche d'un compte, attribution (date de fin facultative), retrait. */
export function BadgeHolders({
  badgeId,
  manual,
  early,
  canManage,
  holders,
  total,
}: {
  badgeId: string;
  manual: boolean;
  early: boolean;
  canManage: boolean;
  holders: HolderRow[];
  total: number;
}) {
  const router = useRouter();
  const [q, setQ] = useState("");
  const [found, setFound] = useState<Found[]>([]);
  const [searching, setSearching] = useState(false);
  const [target, setTarget] = useState<Found | null>(null);
  const [until, setUntil] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState<string | null>(null);

  useEffect(() => {
    if (q.trim().length < 2) {
      setFound([]);
      return;
    }
    setSearching(true);
    const timer = setTimeout(async () => {
      const res = await fetch(`/api/admin/users/search?q=${encodeURIComponent(q.trim())}`).catch(() => null);
      const json = (await res?.json().catch(() => ({}))) as { users?: Found[] };
      setFound(json.users ?? []);
      setSearching(false);
    }, 250);
    return () => clearTimeout(timer);
  }, [q]);

  async function grant() {
    if (!target) return;
    setBusy("grant");
    const res = await fetch(`/api/admin/badges/${badgeId}/holders`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId: target.id, expiresAt: until ? new Date(`${until}T23:59:59`).toISOString() : null, note }),
    }).catch(() => null);
    const json = (await res?.json().catch(() => ({}))) as { error?: string };
    setBusy(null);
    if (!res?.ok) {
      toast(json.error ?? "Attribution impossible.", { tone: "error" });
      return;
    }
    toast(`Badge attribué à ${target.name}`, { tone: "success" });
    setTarget(null);
    setQ("");
    setUntil("");
    setNote("");
    router.refresh();
  }

  async function revoke(holder: HolderRow) {
    const ok = await confirmDialog({ title: `Retirer le badge à ${holder.name} ?`, message: "Le retrait est noté dans l'historique du badge.", confirmLabel: "Retirer", tone: "danger" });
    if (!ok) return;
    setBusy(holder.id);
    const res = await fetch(`/api/admin/badges/${badgeId}/holders?userId=${holder.id}`, { method: "DELETE" }).catch(() => null);
    const json = (await res?.json().catch(() => ({}))) as { error?: string };
    setBusy(null);
    if (!res?.ok) {
      toast(json.error ?? "Retrait impossible.", { tone: "error" });
      return;
    }
    toast("Badge retiré", { tone: "success" });
    router.refresh();
  }

  async function backfill() {
    setBusy("backfill");
    const res = await fetch(`/api/admin/badges/${badgeId}/backfill`, { method: "POST" }).catch(() => null);
    const json = (await res?.json().catch(() => ({}))) as { given?: number; error?: string };
    setBusy(null);
    if (!res?.ok) {
      toast(json.error ?? "Distribution impossible.", { tone: "error" });
      return;
    }
    toast(json.given ? `${json.given} place${json.given > 1 ? "s" : ""} attribuée${json.given > 1 ? "s" : ""}` : "Aucun compte éligible en attente", { tone: "success" });
    router.refresh();
  }

  return (
    <section className="hud-panel space-y-4 rounded-[2px] border border-ink-700 bg-ink-900/80 p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="hud-label text-ink-400">Titulaires ({total})</h2>
        {early && canManage && (
          <button
            type="button"
            onClick={() => void backfill()}
            disabled={busy !== null}
            className="inline-flex items-center gap-1.5 rounded-md border border-ink-600 px-2.5 py-1.5 text-xs font-medium text-ink-200 transition-colors hover:border-ink-400 disabled:opacity-50"
          >
            {busy === "backfill" ? <LoaderCircle size={13} className="animate-spin" /> : <Sparkles size={13} />} Distribuer les places restantes
          </button>
        )}
      </div>

      {manual && canManage && (
        <div className="space-y-2 rounded-md border border-ink-800 bg-ink-950/40 p-3">
          <label className="relative block">
            <Search size={14} className="pointer-events-none absolute top-1/2 left-2.5 -translate-y-1/2 text-ink-500" aria-hidden="true" />
            <input className="field !pl-8" value={q} placeholder="Attribuer à… (pseudo, identifiant, adresse de page)" onChange={(e) => setQ(e.target.value)} aria-label="Rechercher un compte" />
            {searching && <LoaderCircle size={14} className="absolute top-1/2 right-2.5 -translate-y-1/2 animate-spin text-ink-500" aria-hidden="true" />}
          </label>
          {found.length > 0 && !target && (
            <ul className="ui-panel-in divide-y divide-ink-800 rounded-md border border-ink-700 bg-ink-900">
              {found.map((u) => (
                <li key={u.id}>
                  <button type="button" onClick={() => setTarget(u)} className="flex w-full items-center gap-2.5 px-3 py-2 text-left text-sm transition-colors hover:bg-ink-850">
                    <img src={u.avatar} alt="" className="h-7 w-7 rounded-full object-cover" />
                    <span className="min-w-0 flex-1 truncate text-ink-100">
                      {u.name} <span className="text-ink-400">@{u.username}</span>
                    </span>
                    {u.slug && <span className="font-mono text-[11px] text-ink-500">/{u.slug}</span>}
                  </button>
                </li>
              ))}
            </ul>
          )}
          {target && (
            <div className="ui-panel-in flex flex-wrap items-end gap-2">
              <p className="flex w-full min-w-0 items-center gap-2 text-sm text-ink-100">
                <img src={target.avatar} alt="" className="h-7 w-7 rounded-full object-cover" /> <span className="truncate">{target.name}</span>
              </p>
              <label className="space-y-1">
                <span className="block text-xs text-ink-400">Jusqu&apos;au (facultatif)</span>
                <input type="date" className="field !h-8 !w-40 text-xs" value={until} onChange={(e) => setUntil(e.target.value)} />
              </label>
              <label className="space-y-1">
                <span className="block text-xs text-ink-400">Note interne</span>
                <input className="field !h-8 !w-48 text-xs" value={note} maxLength={140} onChange={(e) => setNote(e.target.value)} />
              </label>
              <button
                type="button"
                onClick={() => void grant()}
                disabled={busy !== null}
                className="inline-flex h-8 items-center gap-1.5 rounded-md bg-brand-500 px-3 text-xs font-semibold text-ink-950 transition-colors hover:bg-brand-400 disabled:opacity-50"
              >
                {busy === "grant" ? <LoaderCircle size={13} className="animate-spin" /> : <UserPlus size={13} />} Attribuer
              </button>
              <button type="button" onClick={() => setTarget(null)} className="h-8 rounded-md px-2 text-xs text-ink-400 hover:text-ink-200">
                Annuler
              </button>
            </div>
          )}
        </div>
      )}
      {!manual && <p className="text-xs text-ink-400">Ce badge suit sa règle : les titulaires se mettent à jour seuls.</p>}

      {holders.length === 0 ? (
        <p className="py-4 text-center text-sm text-ink-400">Personne n&apos;a encore ce badge.</p>
      ) : (
        <ul className="divide-y divide-ink-800">
          {holders.map((h) => (
            <li key={h.id} className="flex items-center gap-3 py-2">
              <img src={h.avatar} alt="" className="h-8 w-8 shrink-0 rounded-full object-cover" />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm text-ink-100">
                  {h.name} <span className="text-ink-400">@{h.username}</span>
                </p>
                <p className="truncate font-mono text-[11px] text-ink-500">
                  {h.source ? `${SOURCES[h.source] ?? h.source}` : "condition remplie"}
                  {h.since && ` · depuis le ${fmt.format(new Date(h.since))}`}
                  {h.expiresAt && ` · jusqu'au ${fmt.format(new Date(h.expiresAt))}`}
                  {h.note && ` · ${h.note}`}
                </p>
              </div>
              {h.source && canManage && (
                <button
                  type="button"
                  onClick={() => void revoke(h)}
                  disabled={busy !== null}
                  className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs text-ink-400 transition-colors hover:text-danger disabled:opacity-50"
                  aria-label={`Retirer le badge à ${h.name}`}
                >
                  {busy === h.id ? <LoaderCircle size={13} className="animate-spin" /> : <UserMinus size={13} />} Retirer
                </button>
              )}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
