"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Archive, ArchiveRestore, Check, LoaderCircle, Lock, Save, ShieldCheck, Trash2 } from "lucide-react";
import { BadgeIcon, OfficialBadge, OfficialSeal } from "@/components/badges/OfficialBadge";
import { BADGE_ICONS, RULE_LABELS, type BadgeInput, type BadgeRule, type BadgeRuleType } from "@/lib/badges";
import { confirmDialog } from "@/lib/confirm";
import { can, type StaffRights } from "@/lib/staff";
import { toast } from "@/lib/toast";
import { Toggle } from "@/components/ui/controls";

export type EditableBadge = BadgeInput & {
  id: string | null;
  system: boolean;
  validated: boolean;
  archived: boolean;
  autoGranted: number;
};

const RULE_TYPES: BadgeRuleType[] = ["manual", "early", "seniority", "plan", "verified", "partner"];

function defaultRule(type: BadgeRuleType): BadgeRule {
  switch (type) {
    case "early":
      return { type, limit: 100, requireDiscord: true, requirePage: true };
    case "seniority":
      return { type, days: 365 };
    case "plan":
      return { type, tier: "plus" };
    default:
      return { type } as BadgeRule;
  }
}

const label = "text-[0.8rem] font-medium text-ink-200";

/** Formulaire d'un badge : identité, visibilité, règle d'attribution, sceau officiel, archivage. */
export function BadgeEditor({ initial, rights, premiumName }: { initial: EditableBadge; rights: StaffRights; premiumName: string }) {
  const router = useRouter();
  const [badge, setBadge] = useState(initial);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const set = (patch: Partial<EditableBadge>) => {
    setBadge((b) => ({ ...b, ...patch }));
    setError(null);
  };
  const isNew = badge.id === null;
  const founderRule = badge.rule.type === "founder";
  const lockedType = badge.system || founderRule;
  const canValidate = can(rights, "badges.validate");

  async function send(method: string, url: string, body?: unknown) {
    const res = await fetch(url, { method, headers: body ? { "Content-Type": "application/json" } : undefined, body: body ? JSON.stringify(body) : undefined }).catch(() => null);
    const json = (await res?.json().catch(() => ({}))) as Record<string, unknown> & { error?: string };
    if (!res?.ok) throw new Error(json.error ?? "Action impossible.");
    return json;
  }

  const payload = (): BadgeInput => ({
    key: badge.key,
    name: badge.name,
    description: badge.description,
    icon: badge.icon,
    imageUrl: badge.imageUrl,
    color: badge.color,
    visibility: badge.visibility,
    staffOnly: badge.staffOnly,
    restricted: badge.restricted,
    rule: badge.rule,
    durationDays: badge.durationDays,
    active: badge.active,
    position: badge.position,
  });

  async function save(event: React.FormEvent) {
    event.preventDefault();
    setBusy("save");
    try {
      if (isNew) {
        const json = (await send("POST", "/api/admin/badges", payload())) as { badge: { id: string } };
        toast("Badge créé", { tone: "success" });
        router.push(`/admin/badges/${json.badge.id}`);
      } else {
        const json = (await send("PATCH", `/api/admin/badges/${badge.id}`, { action: "update", badge: payload() })) as { sealRemoved?: boolean };
        if (json.sealRemoved) set({ validated: false });
        toast("Badge enregistré", { tone: "success", description: json.sealRemoved ? "Son apparence a changé : le sceau officiel a été retiré, à reposer par un administrateur habilité." : undefined });
        router.refresh();
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Enregistrement impossible.");
    } finally {
      setBusy(null);
    }
  }

  async function toggleSeal() {
    const next = !badge.validated;
    const ok = await confirmDialog({
      title: next ? "Valider officiellement ce badge ?" : "Retirer le sceau officiel ?",
      message: next
        ? "Le sceau apparaîtra à côté du badge, partout où il est affiché. Il atteste que le badge est officiel, pas que ses titulaires sont vérifiés."
        : "Le badge restera attribué, mais sans le sceau officiel.",
      confirmLabel: next ? "Valider" : "Retirer le sceau",
      tone: next ? undefined : "danger",
    });
    if (!ok) return;
    setBusy("seal");
    try {
      await send("PATCH", `/api/admin/badges/${badge.id}`, { action: "validate", validated: next });
      set({ validated: next });
      toast(next ? "Badge validé officiellement" : "Sceau retiré", { tone: "success" });
      router.refresh();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Action impossible.", { tone: "error" });
    } finally {
      setBusy(null);
    }
  }

  async function archive(restore: boolean) {
    if (!restore) {
      const ok = await confirmDialog({ title: "Archiver ce badge ?", message: "Il disparaît des profils ; ses attributions et son historique sont conservés.", confirmLabel: "Archiver", tone: "danger" });
      if (!ok) return;
    }
    setBusy("archive");
    try {
      await send("PATCH", `/api/admin/badges/${badge.id}`, { action: restore ? "restore" : "archive" });
      set({ archived: !restore, active: restore ? badge.active : false });
      router.refresh();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Action impossible.", { tone: "error" });
    } finally {
      setBusy(null);
    }
  }

  async function remove() {
    const ok = await confirmDialog({
      title: "Supprimer ce badge ?",
      message: "S'il a déjà été attribué, il est archivé à la place (l'historique est conservé). Sinon il est supprimé définitivement.",
      confirmLabel: "Supprimer",
      tone: "danger",
    });
    if (!ok) return;
    setBusy("delete");
    try {
      const json = (await send("DELETE", `/api/admin/badges/${badge.id}`)) as { archived?: boolean };
      toast(json.archived ? "Badge archivé (il avait déjà été attribué)" : "Badge supprimé", { tone: "success" });
      router.push("/admin/badges");
      router.refresh();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Suppression impossible.", { tone: "error" });
    } finally {
      setBusy(null);
    }
  }

  const preview = { key: badge.key || "apercu", name: badge.name || "Nom du badge", description: badge.description, icon: badge.icon, imageUrl: badge.imageUrl, color: badge.color, validated: badge.validated, staff: badge.staffOnly };

  return (
    <form onSubmit={save} className="grid gap-4 lg:grid-cols-[1fr_300px]">
      <div className="space-y-4">
        <section className="hud-panel space-y-4 rounded-[2px] border border-ink-700 bg-ink-900/80 p-4">
          <h2 className="hud-label text-ink-400">Identité</h2>
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="block space-y-1.5">
              <span className={label}>Nom</span>
              <input className="field" value={badge.name} maxLength={32} onChange={(e) => set({ name: e.target.value })} required />
            </label>
            <label className="block space-y-1.5">
              <span className={label}>Identifiant</span>
              <input
                className="field font-mono"
                value={badge.key}
                maxLength={32}
                disabled={badge.system}
                onChange={(e) => set({ key: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "") })}
                required
              />
            </label>
          </div>
          <label className="block space-y-1.5">
            <span className={label}>Description (au survol)</span>
            <input className="field" value={badge.description} maxLength={140} onChange={(e) => set({ description: e.target.value })} />
          </label>
          <div>
            <span className={label}>Logo</span>
            <div className="mt-1.5 flex flex-wrap gap-1.5" role="radiogroup" aria-label="Logo du badge">
              {BADGE_ICONS.map((icon) => (
                <button
                  key={icon}
                  type="button"
                  role="radio"
                  aria-checked={badge.icon === icon}
                  aria-label={icon}
                  onClick={() => set({ icon })}
                  className={`flex h-9 w-9 items-center justify-center rounded-md border transition-colors ${badge.icon === icon ? "border-brand-400 bg-brand-500/10 text-ink-100" : "border-ink-700 text-ink-400 hover:border-ink-500 hover:text-ink-200"}`}
                >
                  <BadgeIcon icon={icon} size={16} />
                </button>
              ))}
            </div>
          </div>
          <div className="grid gap-3 sm:grid-cols-[auto_1fr]">
            <label className="block space-y-1.5">
              <span className={label}>Couleur</span>
              <span className="flex items-center gap-2">
                <input type="color" className="h-9 w-12 cursor-pointer rounded border border-ink-700 bg-transparent" value={badge.color} onChange={(e) => set({ color: e.target.value })} />
                <input className="field !w-28 font-mono" value={badge.color} maxLength={7} onChange={(e) => set({ color: e.target.value })} />
              </span>
            </label>
            <label className="block space-y-1.5">
              <span className={label}>Image (facultatif, remplace le logo)</span>
              <input className="field font-mono text-xs" value={badge.imageUrl} placeholder="/api/uploads/…" onChange={(e) => set({ imageUrl: e.target.value.trim() })} />
            </label>
          </div>
        </section>

        <section className="hud-panel space-y-4 rounded-[2px] border border-ink-700 bg-ink-900/80 p-4">
          <h2 className="hud-label text-ink-400">Attribution</h2>
          <label className="block space-y-1.5">
            <span className={label}>Règle</span>
            {lockedType ? (
              <p className="field flex items-center gap-2 !h-auto py-2 text-sm text-ink-300">
                <Lock size={13} aria-hidden="true" /> {RULE_LABELS[badge.rule.type].label} — {RULE_LABELS[badge.rule.type].description}
              </p>
            ) : (
              <select className="field" value={badge.rule.type} onChange={(e) => set({ rule: defaultRule(e.target.value as BadgeRuleType) })}>
                {RULE_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {RULE_LABELS[t].label} — {RULE_LABELS[t].description}
                  </option>
                ))}
              </select>
            )}
          </label>
          {founderRule && (
            <p className="text-xs text-ink-400">
              Calculé à partir de <code>FOUNDER_UNCLAIM_IDS</code> / <code>FOUNDER_DISCORD_IDS</code> dans l&apos;environnement du serveur : personne ne peut se l&apos;attribuer depuis le site.
            </p>
          )}
          {badge.rule.type === "early" && (
            <div className="grid gap-3 sm:grid-cols-3">
              <label className="block space-y-1.5">
                <span className={label}>Places</span>
                <input
                  type="number"
                  className="field font-mono"
                  min={1}
                  max={100000}
                  value={badge.rule.limit}
                  onChange={(e) => set({ rule: { ...badge.rule, limit: Math.max(1, Math.trunc(Number(e.target.value) || 1)) } as BadgeRule })}
                />
                <span className="block text-xs text-ink-500">{badge.autoGranted} déjà attribuée{badge.autoGranted > 1 ? "s" : ""}</span>
              </label>
              <div className="sm:col-span-2 space-y-2">
                <Toggle
                  label="Compte Discord rattaché"
                  description="Un compte Discord ne compte qu'une fois : empêche d'obtenir plusieurs places avec plusieurs comptes."
                  checked={badge.rule.requireDiscord}
                  onChange={(requireDiscord) => set({ rule: { ...badge.rule, requireDiscord } as BadgeRule })}
                />
                <Toggle
                  label="Une page publiée"
                  description="Seuls les comptes qui ont vraiment créé leur page."
                  checked={badge.rule.requirePage}
                  onChange={(requirePage) => set({ rule: { ...badge.rule, requirePage } as BadgeRule })}
                />
              </div>
            </div>
          )}
          {badge.rule.type === "seniority" && (
            <label className="block max-w-xs space-y-1.5">
              <span className={label}>Ancienneté minimale (jours)</span>
              <input
                type="number"
                className="field font-mono"
                min={1}
                max={36500}
                value={badge.rule.days}
                onChange={(e) => set({ rule: { type: "seniority", days: Math.max(1, Math.trunc(Number(e.target.value) || 1)) } })}
              />
            </label>
          )}
          {badge.rule.type === "plan" && (
            <label className="block max-w-xs space-y-1.5">
              <span className={label}>À partir de la formule</span>
              <select className="field" value={badge.rule.tier} onChange={(e) => set({ rule: { type: "plan", tier: e.target.value as "plus" | "pro" | "team" } })}>
                <option value="plus">{premiumName}</option>
                <option value="pro">{premiumName} Pro</option>
                <option value="team">{premiumName} Équipe</option>
              </select>
            </label>
          )}
          {badge.rule.type === "manual" && (
            <label className="block max-w-xs space-y-1.5">
              <span className={label}>Durée d&apos;une attribution</span>
              <select className="field" value={badge.durationDays ?? 0} onChange={(e) => set({ durationDays: Number(e.target.value) || null })}>
                <option value={0}>Permanente</option>
                <option value={7}>7 jours</option>
                <option value={30}>30 jours</option>
                <option value={90}>90 jours</option>
                <option value={365}>1 an</option>
              </select>
            </label>
          )}
          <div className="space-y-2 border-t border-ink-800 pt-3">
            <Toggle
              label="Badge du staff"
              description="Attribué seulement par les administrateurs qui ont la permission « Badges du staff » ; affiché sur la page Staff."
              checked={badge.staffOnly}
              onChange={(staffOnly) => set({ staffOnly })}
              disabled={!can(rights, "badges.staff")}
            />
            <Toggle
              label="Réservé aux fondateurs"
              description="Seuls les fondateurs peuvent le modifier, l'attribuer ou le retirer."
              checked={badge.restricted}
              onChange={(restricted) => set({ restricted })}
              disabled={rights.level !== "founder" || founderRule}
            />
          </div>
        </section>

        <section className="hud-panel space-y-3 rounded-[2px] border border-ink-700 bg-ink-900/80 p-4">
          <h2 className="hud-label text-ink-400">Affichage</h2>
          <Toggle label="Actif" description="Désactivé, il n'apparaît plus nulle part (les attributions sont gardées)." checked={badge.active} onChange={(active) => set({ active })} disabled={badge.archived} />
          <Toggle
            label="Visible sur les pages publiques"
            description="Masqué : visible seulement dans l'administration (badge interne)."
            checked={badge.visibility === "public"}
            onChange={(on) => set({ visibility: on ? "public" : "hidden" })}
          />
          <label className="block max-w-[10rem] space-y-1.5">
            <span className={label}>Ordre d&apos;affichage</span>
            <input type="number" className="field font-mono" min={0} max={999} value={badge.position} onChange={(e) => set({ position: Math.max(0, Math.trunc(Number(e.target.value) || 0)) })} />
          </label>
        </section>
      </div>

      <aside className="space-y-4 lg:sticky lg:top-20 lg:self-start">
        <section className="hud-panel space-y-3 rounded-[2px] border border-ink-700 bg-ink-900/80 p-4">
          <h2 className="hud-label text-ink-400">Aperçu</h2>
          <div className="flex min-h-16 items-center justify-center rounded-md border border-ink-800 bg-ink-950/60 p-4">
            <OfficialBadge badge={preview} />
          </div>
          <p className="text-xs text-ink-500">Survole le badge : son nom et sa description s&apos;affichent, comme sur les profils.</p>
        </section>

        {!isNew && (
          <section className="hud-panel space-y-3 rounded-[2px] border border-claim/30 bg-ink-900/80 p-4">
            <h2 className="hud-label inline-flex items-center gap-1.5 text-claim">
              <OfficialSeal size={13} /> Validation officielle
            </h2>
            <p className="text-xs text-ink-400">
              {badge.validated ? "Validé : le sceau s'affiche à côté du badge." : "Non validé : le badge s'affiche sans sceau."} La validation concerne le badge, pas l&apos;identité de ses titulaires.
            </p>
            {canValidate ? (
              <button
                type="button"
                onClick={() => void toggleSeal()}
                disabled={busy !== null}
                className={`inline-flex w-full items-center justify-center gap-1.5 rounded-md px-3 py-2 text-sm font-semibold transition-colors disabled:opacity-50 ${
                  badge.validated ? "border border-danger/50 text-danger hover:bg-danger/10" : "bg-claim text-ink-950 hover:brightness-110"
                }`}
              >
                {busy === "seal" ? <LoaderCircle size={15} className="animate-spin" /> : <ShieldCheck size={15} />}
                {badge.validated ? "Retirer le sceau" : "Valider officiellement"}
              </button>
            ) : (
              <p className="inline-flex items-center gap-1.5 text-xs text-ink-500">
                <Lock size={12} aria-hidden="true" /> Permission « Valider les badges » requise.
              </p>
            )}
          </section>
        )}

        <div className="space-y-2">
          {error && (
            <p className="text-sm text-danger" role="alert">
              {error}
            </p>
          )}
          <button
            type="submit"
            disabled={busy !== null}
            className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-brand-500 px-4 py-2.5 text-sm font-semibold text-ink-950 transition-colors hover:bg-brand-400 disabled:opacity-50"
          >
            {busy === "save" ? <LoaderCircle size={16} className="animate-spin" /> : isNew ? <Check size={16} /> : <Save size={16} />} {isNew ? "Créer le badge" : "Enregistrer"}
          </button>
          {!isNew && !badge.system && (
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => void archive(badge.archived)}
                disabled={busy !== null}
                className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-md border border-ink-600 px-3 py-2 text-xs font-medium text-ink-200 transition-colors hover:border-ink-400 disabled:opacity-50"
              >
                {badge.archived ? <ArchiveRestore size={14} /> : <Archive size={14} />} {badge.archived ? "Restaurer" : "Archiver"}
              </button>
              <button
                type="button"
                onClick={() => void remove()}
                disabled={busy !== null}
                className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-md border border-ink-600 px-3 py-2 text-xs font-medium text-ink-300 transition-colors hover:border-danger/60 hover:text-danger disabled:opacity-50"
              >
                <Trash2 size={14} /> Supprimer
              </button>
            </div>
          )}
          {badge.system && <p className="text-xs text-ink-500">Badge intégré : il se désactive mais ne se supprime pas.</p>}
        </div>
      </aside>
    </form>
  );
}
