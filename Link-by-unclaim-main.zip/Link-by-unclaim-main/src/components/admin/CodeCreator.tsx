"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Check, Copy, Download, LoaderCircle, Plus } from "lucide-react";

/** Création d'un lot de codes : ils ne sont affichés qu'une seule fois, à copier ou télécharger. */
export function CodeCreator({ premiumName }: { premiumName: string }) {
  const router = useRouter();
  const [form, setForm] = useState({ count: 1, days: 30, tier: "plus", maxUses: 1, expiresAt: "", note: "" });
  const [state, setState] = useState<{ status: "idle" | "saving" | "error"; message?: string }>({ status: "idle" });
  const [codes, setCodes] = useState<string[]>([]);
  const [copied, setCopied] = useState(false);

  async function create(event: React.FormEvent) {
    event.preventDefault();
    setState({ status: "saving" });
    const res = await fetch("/api/admin/codes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...form, expiresAt: form.expiresAt ? new Date(`${form.expiresAt}T23:59:59`).toISOString() : null }),
    }).catch(() => null);
    const json = (await res?.json().catch(() => ({}))) as { codes?: string[]; error?: string } | undefined;
    if (!res?.ok || !json?.codes) {
      setState({ status: "error", message: json?.error ?? "Création impossible." });
      return;
    }
    setCodes(json.codes);
    setCopied(false);
    setState({ status: "idle" });
    router.refresh();
  }

  function download() {
    const blob = new Blob([`${codes.join("\n")}\n`], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `codes-${premiumName.toLowerCase().replace(/[^a-z0-9]+/g, "")}-${new Date().toISOString().slice(0, 10)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }

  const num = (key: "count" | "days" | "maxUses", value: string) => setForm((f) => ({ ...f, [key]: Math.max(0, Math.trunc(Number(value) || 0)) }));

  return (
    <div className="space-y-4">
      <form onSubmit={create} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
        <label className="space-y-1.5">
          <span className="text-[0.8rem] font-medium text-ink-200">Nombre</span>
          <input type="number" min={1} max={200} className="field font-mono" value={form.count} onChange={(e) => num("count", e.target.value)} />
        </label>
        <label className="space-y-1.5">
          <span className="text-[0.8rem] font-medium text-ink-200">Formule</span>
          <select className="field" value={form.tier} onChange={(e) => setForm((f) => ({ ...f, tier: e.target.value }))}>
            <option value="plus">Link+</option>
            <option value="pro">Pro</option>
            <option value="team">Équipe</option>
          </select>
        </label>
        <label className="space-y-1.5">
          <span className="text-[0.8rem] font-medium text-ink-200">Durée offerte (jours)</span>
          <input type="number" min={0} max={3650} className="field font-mono" value={form.days} onChange={(e) => num("days", e.target.value)} />
          <span className="block text-[11px] text-ink-500">0 = sans limite</span>
        </label>
        <label className="space-y-1.5">
          <span className="text-[0.8rem] font-medium text-ink-200">Utilisations par code</span>
          <input type="number" min={1} max={10000} className="field font-mono" value={form.maxUses} onChange={(e) => num("maxUses", e.target.value)} />
        </label>
        <label className="space-y-1.5">
          <span className="text-[0.8rem] font-medium text-ink-200">À échanger avant le</span>
          <input type="date" className="field" value={form.expiresAt} onChange={(e) => setForm((f) => ({ ...f, expiresAt: e.target.value }))} />
        </label>
        <label className="space-y-1.5">
          <span className="text-[0.8rem] font-medium text-ink-200">Note interne</span>
          <input className="field" maxLength={120} value={form.note} placeholder="Concours Discord…" onChange={(e) => setForm((f) => ({ ...f, note: e.target.value }))} />
        </label>
        <div className="flex items-center gap-3 sm:col-span-2 lg:col-span-5">
          <button
            type="submit"
            disabled={state.status === "saving" || form.count < 1 || form.maxUses < 1}
            className="inline-flex items-center gap-2 rounded-md bg-claim px-4 py-2 text-sm font-semibold text-ink-950 transition hover:brightness-110 disabled:opacity-50"
          >
            {state.status === "saving" ? <LoaderCircle size={16} className="animate-spin" /> : <Plus size={16} />} Créer {form.count > 1 ? `${form.count} codes` : "le code"}
          </button>
          {state.status === "error" && (
            <p className="text-sm text-danger" role="alert">
              {state.message}
            </p>
          )}
        </div>
      </form>

      {codes.length > 0 && (
        <div className="space-y-3 rounded-md border border-claim/40 bg-claim/5 p-4">
          <p className="text-sm text-ink-100">
            <strong className="text-claim">Copie ces codes maintenant :</strong> ils ne seront plus jamais affichés (seule leur empreinte est conservée).
          </p>
          <pre className="scrollbar-thin max-h-60 overflow-auto rounded-md border border-ink-700 bg-ink-950 p-3 font-mono text-sm text-ink-100 select-all">{codes.join("\n")}</pre>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => navigator.clipboard.writeText(codes.join("\n")).then(() => setCopied(true))}
              className="inline-flex items-center gap-1.5 rounded-md border border-ink-600 px-3 py-1.5 text-xs font-medium text-ink-200 hover:border-ink-400"
            >
              {copied ? <Check size={14} /> : <Copy size={14} />} {copied ? "Copiés" : "Copier"}
            </button>
            <button type="button" onClick={download} className="inline-flex items-center gap-1.5 rounded-md border border-ink-600 px-3 py-1.5 text-xs font-medium text-ink-200 hover:border-ink-400">
              <Download size={14} /> Télécharger (.txt)
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
