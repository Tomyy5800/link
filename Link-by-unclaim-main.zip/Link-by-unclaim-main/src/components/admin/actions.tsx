"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { BadgeCheck, Ban, Check, Eraser, Handshake, LoaderCircle, RotateCcw, Shield, Sparkles, Star, Trash, X } from "lucide-react";

// Actions de l'administration : appellent /api/admin/… puis rafraîchissent la page serveur.

function useAdminAction() {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function run(url: string, method: "PATCH" | "DELETE" | "POST" | "PUT", body?: unknown): Promise<unknown> {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(url, {
        method,
        headers: body ? { "Content-Type": "application/json" } : undefined,
        body: body ? JSON.stringify(body) : undefined,
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) {
        setError(json.error ?? "Action impossible.");
        return null;
      }
      startTransition(() => router.refresh());
      return json;
    } catch {
      setError("Connexion perdue.");
      return null;
    } finally {
      setBusy(false);
    }
  }
  return { run, busy: busy || pending, error };
}

const btn =
  "inline-flex h-7 items-center gap-1 rounded-md border border-ink-700 px-2 text-xs font-medium text-ink-200 transition hover:border-ink-500 hover:text-ink-100 disabled:opacity-40";

function ErrorText({ error }: { error: string | null }) {
  return error ? (
    <p className="mt-1 text-xs text-danger" role="alert">
      {error}
    </p>
  ) : null;
}

/** Demande un motif (affiché à l'utilisateur) avant une suspension. */
function ReasonPrompt({ label, onConfirm, onCancel, busy }: { label: string; onConfirm: (reason: string) => void; onCancel: () => void; busy: boolean }) {
  const [reason, setReason] = useState("");
  return (
    <form
      className="mt-2 flex w-full flex-wrap items-center gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        onConfirm(reason.trim());
      }}
    >
      <input autoFocus className="field !h-8 min-w-48 flex-1 text-xs" value={reason} maxLength={280} onChange={(e) => setReason(e.target.value)} placeholder="Motif (montré au propriétaire)" />
      <button type="submit" disabled={busy} className={`${btn} border-danger/50 text-danger hover:border-danger`}>
        {busy ? <LoaderCircle size={13} className="animate-spin" /> : <Ban size={13} />} {label}
      </button>
      <button type="button" onClick={onCancel} className={btn} aria-label="Annuler">
        <X size={13} />
      </button>
    </form>
  );
}

type AdminUser = {
  id: string;
  plan: string;
  premiumActive: boolean;
  partner: boolean;
  verified: boolean;
  role: string;
  suspended: boolean;
  isSelf: boolean;
  /** Le compte connecté est fondateur : lui seul nomme ou retire un administrateur. */
  canPromote: boolean;
};

export function UserActions({ user }: { user: AdminUser }) {
  const { run, busy, error } = useAdminAction();
  const [days, setDays] = useState("30");
  const [tier, setTier] = useState("plus");
  const [mode, setMode] = useState<"idle" | "plan" | "suspend">("idle");
  const url = `/api/admin/users/${user.id}`;

  return (
    <div className="flex flex-wrap items-center gap-1.5">
      {user.premiumActive ? (
        <button type="button" className={btn} disabled={busy} onClick={() => run(url, "PATCH", { plan: { plan: "free" } })} title="Repasser en offre gratuite">
          <Sparkles size={13} className="text-claim" /> Retirer
        </button>
      ) : (
        <button type="button" className={btn} disabled={busy} onClick={() => setMode(mode === "plan" ? "idle" : "plan")}>
          <Sparkles size={13} className="text-claim" /> Offrir
        </button>
      )}
      <button
        type="button"
        className={`${btn} ${user.verified ? "border-brand-500/60 text-brand-300" : ""}`}
        disabled={busy}
        aria-pressed={user.verified}
        onClick={() => run(url, "PATCH", { verified: !user.verified })}
        title={user.verified ? "Retirer le badge vérifié" : "Attribuer le badge vérifié"}
      >
        <BadgeCheck size={13} /> {user.verified ? "Vérifié" : "Vérifier"}
      </button>
      <button
        type="button"
        className={`${btn} ${user.partner ? "border-brand-500/60 text-brand-300" : ""}`}
        disabled={busy}
        aria-pressed={user.partner}
        onClick={() => {
          if (!user.partner || window.confirm("Retirer le statut de partenaire officiel à ce compte ?")) {
            void run(url, "PATCH", { partner: !user.partner });
          }
        }}
        title={user.partner ? "Retirer le statut de partenaire" : "Nommer partenaire officiel"}
      >
        <Handshake size={13} /> {user.partner ? "Partenaire" : "Partenariat"}
      </button>
      {!user.isSelf && user.canPromote && (
        <button
          type="button"
          className={`${btn} ${user.role === "admin" ? "border-claim/60 text-claim" : ""}`}
          disabled={busy}
          onClick={() => {
            if (user.role === "admin" || window.confirm("Donner l'accès complet à l'administration à ce compte ?")) {
              void run(url, "PATCH", { role: user.role === "admin" ? "user" : "admin" });
            }
          }}
        >
          <Shield size={13} /> {user.role === "admin" ? "Admin" : "Promouvoir"}
        </button>
      )}
      {!user.isSelf &&
        (user.suspended ? (
          <button type="button" className={btn} disabled={busy} onClick={() => run(url, "PATCH", { suspend: null })}>
            <RotateCcw size={13} /> Lever la suspension
          </button>
        ) : (
          <button type="button" className={`${btn} hover:border-danger hover:text-danger`} disabled={busy} onClick={() => setMode(mode === "suspend" ? "idle" : "suspend")}>
            <Ban size={13} /> Suspendre
          </button>
        ))}
      {busy && <LoaderCircle size={14} className="animate-spin text-ink-400" />}

      {mode === "plan" && (
        <form
          className="mt-2 flex w-full flex-wrap items-center gap-2"
          onSubmit={async (e) => {
            e.preventDefault();
            if (await run(url, "PATCH", { plan: { plan: tier, days: Number(days) } })) setMode("idle");
          }}
        >
          <select className="field !h-8 !w-auto text-xs" value={tier} onChange={(e) => setTier(e.target.value)} aria-label="Formule">
            <option value="plus">Link+</option>
            <option value="pro">Pro</option>
            <option value="team">Équipe</option>
          </select>
          <select className="field !h-8 !w-auto text-xs" value={days} onChange={(e) => setDays(e.target.value)} aria-label="Durée">
            <option value="7">7 jours</option>
            <option value="30">30 jours</option>
            <option value="90">90 jours</option>
            <option value="365">1 an</option>
            <option value="0">Sans limite</option>
          </select>
          <button type="submit" className={`${btn} border-claim/50 text-claim`} disabled={busy}>
            <Check size={13} /> Activer
          </button>
        </form>
      )}
      {mode === "suspend" && (
        <ReasonPrompt
          label="Suspendre le compte"
          busy={busy}
          onCancel={() => setMode("idle")}
          onConfirm={async (reason) => {
            if (await run(url, "PATCH", { suspend: { reason } })) setMode("idle");
          }}
        />
      )}
      <ErrorText error={error} />
    </div>
  );
}

export function PageActions({ page }: { page: { id: string; slug: string; suspended: boolean; featured: boolean } }) {
  const { run, busy, error } = useAdminAction();
  const [mode, setMode] = useState<"idle" | "suspend">("idle");
  const url = `/api/admin/pages/${page.id}`;
  return (
    <div className="flex flex-wrap items-center gap-1.5">
      <button
        type="button"
        className={`${btn} ${page.featured ? "border-claim/60 text-claim" : ""}`}
        disabled={busy}
        aria-pressed={page.featured}
        onClick={() => run(url, "PATCH", { featured: !page.featured })}
        title="Mise en avant sur la page d'accueil"
      >
        <Star size={13} /> {page.featured ? "En avant" : "Mettre en avant"}
      </button>
      {page.suspended ? (
        <button type="button" className={btn} disabled={busy} onClick={() => run(url, "PATCH", { suspend: null })}>
          <RotateCcw size={13} /> Rétablir
        </button>
      ) : (
        <button type="button" className={`${btn} hover:border-danger hover:text-danger`} disabled={busy} onClick={() => setMode(mode === "suspend" ? "idle" : "suspend")}>
          <Ban size={13} /> Suspendre
        </button>
      )}
      <button
        type="button"
        className={`${btn} hover:border-danger hover:text-danger`}
        disabled={busy}
        onClick={() => {
          const typed = window.prompt(`Suppression définitive de la page, de ses statistiques et de ses fichiers.\nTape « ${page.slug} » pour confirmer.`);
          if (typed === page.slug) void run(url, "DELETE");
        }}
      >
        <Trash size={13} /> Supprimer
      </button>
      {busy && <LoaderCircle size={14} className="animate-spin text-ink-400" />}
      {mode === "suspend" && (
        <ReasonPrompt
          label="Suspendre la page"
          busy={busy}
          onCancel={() => setMode("idle")}
          onConfirm={async (reason) => {
            if (await run(url, "PATCH", { suspend: { reason } })) setMode("idle");
          }}
        />
      )}
      <ErrorText error={error} />
    </div>
  );
}

export function ReportActions({ report }: { report: { id: string; status: string; pageSuspended: boolean } }) {
  const { run, busy, error } = useAdminAction();
  const [mode, setMode] = useState<"idle" | "suspend">("idle");
  const url = `/api/admin/reports/${report.id}`;
  if (report.status !== "open") {
    return (
      <div className="flex items-center gap-1.5">
        <button type="button" className={btn} disabled={busy} onClick={() => run(url, "PATCH", { status: "open" })}>
          <RotateCcw size={13} /> Rouvrir
        </button>
        <ErrorText error={error} />
      </div>
    );
  }
  return (
    <div className="flex flex-wrap items-center gap-1.5">
      {!report.pageSuspended && (
        <button type="button" className={`${btn} border-danger/50 text-danger hover:border-danger`} disabled={busy} onClick={() => setMode(mode === "suspend" ? "idle" : "suspend")}>
          <Ban size={13} /> Suspendre la page
        </button>
      )}
      <button type="button" className={btn} disabled={busy} onClick={() => run(url, "PATCH", { status: "resolved" })}>
        <Check size={13} /> Traité
      </button>
      <button type="button" className={btn} disabled={busy} onClick={() => run(url, "PATCH", { status: "dismissed" })}>
        <X size={13} /> Sans suite
      </button>
      {busy && <LoaderCircle size={14} className="animate-spin text-ink-400" />}
      {mode === "suspend" && (
        <ReasonPrompt
          label="Suspendre"
          busy={busy}
          onCancel={() => setMode("idle")}
          onConfirm={async (reason) => {
            if (await run(url, "PATCH", { status: "resolved", suspendPage: { reason } })) setMode("idle");
          }}
        />
      )}
      <ErrorText error={error} />
    </div>
  );
}

export function CodeToggle({ id, disabled }: { id: string; disabled: boolean }) {
  const { run, busy, error } = useAdminAction();
  return (
    <>
      <button type="button" className={btn} disabled={busy} onClick={() => run(`/api/admin/codes/${id}`, "PATCH", { disabled: !disabled })}>
        {disabled ? <RotateCcw size={13} /> : <Ban size={13} />} {disabled ? "Réactiver" : "Désactiver"}
      </button>
      <ErrorText error={error} />
    </>
  );
}

export function ClearCacheButton({ prefix, label }: { prefix: string; label: string }) {
  const { run, busy, error } = useAdminAction();
  const [done, setDone] = useState<number | null>(null);
  return (
    <div className="flex flex-wrap items-center gap-2">
      <button
        type="button"
        className={btn}
        disabled={busy}
        onClick={async () => {
          const res = (await run(`/api/admin/cache?prefix=${encodeURIComponent(prefix)}`, "DELETE")) as { cleared?: number } | null;
          if (res) setDone(res.cleared ?? 0);
        }}
      >
        {busy ? <LoaderCircle size={13} className="animate-spin" /> : <Eraser size={13} />} {label}
      </button>
      {done !== null && <span className="text-xs text-mint">{done} entrée{done > 1 ? "s" : ""} supprimée{done > 1 ? "s" : ""}</span>}
      <ErrorText error={error} />
    </div>
  );
}

export function OrderActions({ order }: { order: { id: string; status: string; online: boolean } }) {
  const { run, busy, error } = useAdminAction();
  const url = `/api/admin/orders/${order.id}`;
  return (
    <div className="flex flex-wrap items-center justify-end gap-1.5">
      {order.status === "paid" && (
        <button
          type="button"
          className={`${btn} hover:border-danger hover:text-danger`}
          disabled={busy}
          onClick={() => {
            const message = order.online
              ? "Rembourser ce paiement chez Stripe et retirer l'accès acheté ?"
              : "Marquer cette commande remboursée et retirer l'accès acheté ? (Le remboursement d'argent est à faire de ton côté.)";
            if (window.confirm(message)) void run(url, "PATCH", { action: "refund", online: order.online, revoke: true });
          }}
        >
          <RotateCcw size={13} /> Rembourser
        </button>
      )}
      {(order.status === "pending" || order.status === "failed") && (
        <button
          type="button"
          className={btn}
          disabled={busy}
          onClick={() => {
            if (window.confirm("Valider cette commande à la main ? N'utilise ceci que si le paiement a bien été reçu.")) {
              void run(url, "PATCH", { action: "markPaid" });
            }
          }}
        >
          <Check size={13} /> Valider
        </button>
      )}
      {busy && <LoaderCircle size={14} className="animate-spin text-ink-400" />}
      <ErrorText error={error} />
    </div>
  );
}

export function PartnerApplicationActions({ id }: { id: string }) {
  const { run, busy, error } = useAdminAction();
  const [mode, setMode] = useState<"idle" | "refuse">("idle");
  const url = `/api/admin/partners/${id}`;
  return (
    <div className="flex flex-wrap items-center gap-1.5">
      <button type="button" className={`${btn} border-mint/50 text-mint hover:border-mint`} disabled={busy} onClick={() => run(url, "PATCH", { decision: "accept" })}>
        <Check size={13} /> Accepter
      </button>
      <button type="button" className={btn} disabled={busy} onClick={() => setMode(mode === "refuse" ? "idle" : "refuse")}>
        <X size={13} /> Refuser
      </button>
      {busy && <LoaderCircle size={14} className="animate-spin text-ink-400" />}
      {mode === "refuse" && (
        <ReasonPrompt
          label="Refuser"
          busy={busy}
          onCancel={() => setMode("idle")}
          onConfirm={async (note) => {
            if (await run(url, "PATCH", { decision: "refuse", note })) setMode("idle");
          }}
        />
      )}
      <ErrorText error={error} />
    </div>
  );
}
