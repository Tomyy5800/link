"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowDown, ArrowUp, Check, LoaderCircle, Plus, Save, Trash } from "lucide-react";
import { formatPrice, intervalLabel, monthlyCents, type LegalInfo, type Offer, type PlatformSettings } from "@/lib/features";
import { PAID_TIERS, tierName } from "@/lib/plans";

type Pricing = Pick<PlatformSettings, "premiumName" | "premiumUrl" | "offers" | "legal">;

const LEGAL_FIELDS: { key: keyof LegalInfo; label: string; placeholder: string; wide?: boolean }[] = [
  { key: "sellerName", label: "Nom ou raison sociale", placeholder: "Prénom Nom, ou Unclaim SAS" },
  { key: "status", label: "Statut juridique", placeholder: "Entrepreneur individuel (micro-entreprise)" },
  { key: "siret", label: "SIREN / SIRET", placeholder: "123 456 789 00012" },
  { key: "email", label: "E-mail de contact", placeholder: "contact@exemple.fr" },
  { key: "address", label: "Adresse", placeholder: "1 rue Exemple, 75000 Paris", wide: true },
  { key: "vatMention", label: "Mention TVA", placeholder: "TVA non applicable, art. 293 B du CGI", wide: true },
  { key: "publisher", label: "Directeur de la publication", placeholder: "Prénom Nom" },
  { key: "mediator", label: "Médiateur de la consommation", placeholder: "Nom du médiateur, site web" },
  { key: "host", label: "Hébergeur", placeholder: "Nom, adresse et téléphone de l'hébergeur", wide: true },
];

function Section({ title, description, children }: { title: string; description?: React.ReactNode; children: React.ReactNode }) {
  return (
    <section className="hud-panel space-y-4 rounded-[2px] border border-ink-700 bg-ink-900/80 p-4">
      <div>
        <h2 className="hud-label text-ink-400">{title}</h2>
        {description && <p className="mt-1 text-xs text-ink-400">{description}</p>}
      </div>
      {children}
    </section>
  );
}

const input = "field !h-9";

/** Offres en vente, nom de l'offre, achat pour offrir et informations légales du vendeur. */
export function PricingForm({ initial }: { initial: Pricing }) {
  const router = useRouter();
  const [pricing, setPricing] = useState(initial);
  const [state, setState] = useState<{ status: "idle" | "saving" | "saved" | "error"; message?: string }>({ status: "idle" });
  const set = (patch: Partial<Pricing>) => {
    setPricing((p) => ({ ...p, ...patch }));
    setState({ status: "idle" });
  };
  const setOffer = (index: number, patch: Partial<Offer>) => set({ offers: pricing.offers.map((o, i) => (i === index ? { ...o, ...patch } : o)) });
  const move = (index: number, to: number) => {
    const next = [...pricing.offers];
    const [item] = next.splice(index, 1);
    next.splice(to, 0, item);
    set({ offers: next });
  };

  async function save(event: React.FormEvent) {
    event.preventDefault();
    setState({ status: "saving" });
    const res = await fetch("/api/admin/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(pricing),
    }).catch(() => null);
    const json = (await res?.json().catch(() => ({}))) as { error?: string } | undefined;
    if (!res?.ok) {
      setState({ status: "error", message: json?.error ?? "Enregistrement impossible." });
      return;
    }
    setState({ status: "saved" });
    router.refresh();
  }

  return (
    <form onSubmit={save} className="space-y-6">
      <Section title="Offre payante">
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block space-y-1.5">
            <span className="text-[0.8rem] font-medium text-ink-200">Nom de l&apos;offre</span>
            <input className={input} value={pricing.premiumName} maxLength={24} onChange={(e) => set({ premiumName: e.target.value })} />
          </label>
          <label className="block space-y-1.5">
            <span className="text-[0.8rem] font-medium text-ink-200">Boutique externe (https, facultatif)</span>
            <input
              className={input}
              value={pricing.premiumUrl}
              inputMode="url"
              placeholder="Lien vers une boutique qui vend des codes"
              onChange={(e) => set({ premiumUrl: e.target.value.trim() })}
            />
            <span className="block text-xs text-ink-500">Utilisée seulement tant que le paiement en ligne n&apos;est pas ouvert.</span>
          </label>
        </div>
      </Section>

      <Section
        title="Offres en vente"
        description="Abonnements résiliables à tout moment, facturés chaque mois ou chaque année. Prix TTC par période. Chaque offre vend une formule ; jusqu'à 12 offres, affichées dans cet ordre sous leur formule. Un nouveau prix s'applique aux nouvelles souscriptions (les abonnés gardent le leur)."
      >
        <ul className="space-y-3">
          {pricing.offers.map((offer, i) => (
            <li key={i} className={`rounded-md border p-3 ${offer.active ? "border-ink-700" : "border-dashed border-ink-700 opacity-70"}`}>
              <div className="grid gap-3 sm:grid-cols-[130px_1fr_1fr_100px_100px]">
                <label className="space-y-1">
                  <span className="text-xs text-ink-400">Formule</span>
                  <select className={input} value={offer.tier} onChange={(e) => setOffer(i, { tier: e.target.value as Offer["tier"] })}>
                    {PAID_TIERS.map((t) => (
                      <option key={t} value={t}>
                        {tierName(t, pricing.premiumName)}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="space-y-1">
                  <span className="text-xs text-ink-400">Nom</span>
                  <input className={input} value={offer.name} maxLength={32} onChange={(e) => setOffer(i, { name: e.target.value })} />
                </label>
                <label className="space-y-1">
                  <span className="text-xs text-ink-400">Identifiant (adresse)</span>
                  <input
                    className={`${input} font-mono`}
                    value={offer.id}
                    maxLength={24}
                    onChange={(e) => setOffer(i, { id: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "") })}
                  />
                </label>
                <label className="space-y-1">
                  <span className="text-xs text-ink-400">Prix (€)</span>
                  <input
                    className={`${input} font-mono`}
                    type="number"
                    min={0.5}
                    step={0.01}
                    value={(offer.priceCents / 100).toFixed(2)}
                    onChange={(e) => setOffer(i, { priceCents: Math.round(Number(e.target.value) * 100) || 0 })}
                  />
                </label>
                <label className="space-y-1">
                  <span className="text-xs text-ink-400">Facturation</span>
                  <select className={input} value={offer.interval} onChange={(e) => setOffer(i, { interval: e.target.value === "year" ? "year" : "month" })}>
                    <option value="month">Mensuelle</option>
                    <option value="year">Annuelle</option>
                  </select>
                </label>
              </div>
              <label className="mt-3 block space-y-1">
                <span className="text-xs text-ink-400">Description</span>
                <input className={input} value={offer.description} maxLength={80} onChange={(e) => setOffer(i, { description: e.target.value })} />
              </label>
              <div className="mt-3 flex flex-wrap items-center gap-4 text-xs">
                <span className="font-mono text-claim">
                  {tierName(offer.tier, pricing.premiumName)} · {formatPrice(offer.priceCents)} {intervalLabel(offer.interval)}
                  {offer.interval === "year" && <span className="text-ink-400"> · {formatPrice(monthlyCents(offer))} / mois</span>}
                </span>
                <label className="inline-flex items-center gap-1.5 text-ink-300">
                  <input type="checkbox" checked={offer.active} onChange={(e) => setOffer(i, { active: e.target.checked })} /> En vente
                </label>
                <label className="inline-flex items-center gap-1.5 text-ink-300">
                  <input type="checkbox" checked={offer.highlight} onChange={(e) => setOffer(i, { highlight: e.target.checked })} /> Mise en avant
                </label>
                <span className="ml-auto flex gap-1">
                  <button type="button" disabled={i === 0} onClick={() => move(i, i - 1)} className="rounded p-1 text-ink-400 hover:text-ink-100 disabled:opacity-30" aria-label="Monter">
                    <ArrowUp size={14} />
                  </button>
                  <button
                    type="button"
                    disabled={i === pricing.offers.length - 1}
                    onClick={() => move(i, i + 1)}
                    className="rounded p-1 text-ink-400 hover:text-ink-100 disabled:opacity-30"
                    aria-label="Descendre"
                  >
                    <ArrowDown size={14} />
                  </button>
                  <button
                    type="button"
                    onClick={() => set({ offers: pricing.offers.filter((_, j) => j !== i) })}
                    className="rounded p-1 text-ink-400 hover:text-danger"
                    aria-label="Supprimer l'offre"
                  >
                    <Trash size={14} />
                  </button>
                </span>
              </div>
            </li>
          ))}
        </ul>
        {pricing.offers.length < 12 && (
          <button
            type="button"
            onClick={() =>
              set({
                offers: [
                  ...pricing.offers,
                  { id: `offre-${pricing.offers.length + 1}`, tier: "plus", name: "Mensuel", interval: "month", priceCents: 299, description: "", highlight: false, active: false },
                ],
              })
            }
            className="flex w-full items-center justify-center gap-1.5 rounded-md border border-dashed border-ink-600 py-2 text-sm text-ink-300 hover:border-ink-400 hover:text-ink-100"
          >
            <Plus size={15} /> Ajouter une offre
          </button>
        )}
        <p className="text-xs text-ink-400">
          Changer un prix n&apos;affecte pas les abonnements en cours ni les factures passées : chaque abonnement garde le prix de sa souscription jusqu&apos;à un changement de formule.
        </p>
      </Section>

      <Section
        title="Informations légales"
        description={
          <>
            Reprises dans les <a href="/mentions-legales" target="_blank" className="text-brand-300 underline">mentions légales</a>, les{" "}
            <a href="/cgv" target="_blank" className="text-brand-300 underline">CGV</a> et la{" "}
            <a href="/confidentialite" target="_blank" className="text-brand-300 underline">politique de confidentialité</a>. Obligatoires avant d&apos;ouvrir la vente
            à des particuliers.
          </>
        }
      >
        <div className="grid gap-3 sm:grid-cols-2">
          {LEGAL_FIELDS.map((field) => (
            <label key={field.key} className={`block space-y-1 ${field.wide ? "sm:col-span-2" : ""}`}>
              <span className="text-xs text-ink-400">{field.label}</span>
              <input
                className={input}
                value={pricing.legal[field.key]}
                maxLength={300}
                placeholder={field.placeholder}
                onChange={(e) => set({ legal: { ...pricing.legal, [field.key]: e.target.value } })}
              />
            </label>
          ))}
        </div>
      </Section>

      <div className="sticky bottom-4 z-10 flex items-center justify-end gap-3 rounded-md border border-ink-700 bg-ink-900/95 p-3 shadow-2xl shadow-black/50 backdrop-blur">
        {state.status === "error" && (
          <p className="mr-auto text-sm text-danger" role="alert">
            {state.message}
          </p>
        )}
        {state.status === "saved" && (
          <p className="mr-auto inline-flex items-center gap-1.5 text-sm text-mint" role="status">
            <Check size={15} /> Enregistré.
          </p>
        )}
        <button
          type="submit"
          disabled={state.status === "saving"}
          className="inline-flex items-center gap-2 rounded-md bg-brand-500 px-4 py-2 text-sm font-semibold text-ink-950 transition hover:bg-brand-400 disabled:opacity-50"
        >
          {state.status === "saving" ? <LoaderCircle size={16} className="animate-spin" /> : <Save size={16} />} Enregistrer
        </button>
      </div>
    </form>
  );
}
