"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { BadgeCheck, Bot, Euro, Flag, Gauge, Gift, Handshake, History, LayoutTemplate, ShieldCheck, SlidersHorizontal, Store, Tags, Users } from "lucide-react";

const ITEMS = [
  { href: "/admin", label: "Vue d'ensemble", icon: Gauge },
  { href: "/admin/users", label: "Comptes", icon: Users },
  { href: "/admin/pages", label: "Pages", icon: LayoutTemplate },
  { href: "/admin/reports", label: "Signalements", icon: Flag, badge: "reports" as const },
  { href: "/admin/partners", label: "Partenaires", icon: Handshake, badge: "partners" as const },
  { href: "/admin/badges", label: "Badges", icon: BadgeCheck },
  { href: "/admin/staff", label: "Staff et permissions", icon: ShieldCheck },
  { href: "/admin/discord", label: "Rôles Discord", icon: Bot },
  { href: "/admin/sales", label: "Ventes", icon: Euro },
  { href: "/admin/pricing", label: "Tarifs et abonnements", icon: Tags },
  { href: "/admin/boutique", label: "Boutique officielle", icon: Store },
  { href: "/admin/settings", label: "Fonctionnalités", icon: SlidersHorizontal },
  { href: "/admin/codes", label: "Codes", icon: Gift },
  { href: "/admin/audit", label: "Journal", icon: History },
];

export function AdminNav({ openReports, pendingPartners = 0 }: { openReports: number; pendingPartners?: number }) {
  const pathname = usePathname();
  return (
    <nav aria-label="Administration" className="scrollbar-thin flex gap-1 overflow-x-auto lg:flex-col lg:overflow-visible">
      {ITEMS.map(({ href, label, icon: Icon, badge }) => {
        const active = href === "/admin" ? pathname === href : pathname.startsWith(href);
        return (
          <Link
            key={href}
            href={href}
            aria-current={active ? "page" : undefined}
            className={`flex shrink-0 items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium transition-colors duration-150 ${
              active ? "bg-ink-800 text-ink-100" : "text-ink-400 hover:bg-ink-850 hover:text-ink-200"
            }`}
          >
            <Icon size={16} className={active ? "text-brand-400" : ""} />
            {label}
            {badge === "partners" && pendingPartners > 0 && (
              <span className="ml-auto rounded-sm bg-brand-500 px-1.5 font-mono text-[11px] font-semibold text-ink-950">{pendingPartners}</span>
            )}
            {badge === "reports" && openReports > 0 && (
              <span className="ml-auto rounded-sm bg-danger px-1.5 font-mono text-[11px] font-semibold text-ink-950">{openReports}</span>
            )}
          </Link>
        );
      })}
    </nav>
  );
}
