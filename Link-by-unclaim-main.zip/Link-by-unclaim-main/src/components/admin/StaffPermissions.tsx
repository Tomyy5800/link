"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { LoaderCircle } from "lucide-react";
import { STAFF_PERMISSIONS, STAFF_PERMISSION_KEYS, type StaffPermission } from "@/lib/staff";
import { toast } from "@/lib/toast";

/** Cases des permissions sensibles d'un administrateur (modifiables par un fondateur). */
export function StaffPermissions({ userId, initial, editable }: { userId: string; initial: StaffPermission[]; editable: boolean }) {
  const router = useRouter();
  const [perms, setPerms] = useState(new Set(initial));
  const [busy, setBusy] = useState(false);

  async function toggle(key: StaffPermission) {
    const next = new Set(perms);
    if (next.has(key)) next.delete(key);
    else next.add(key);
    setPerms(next);
    setBusy(true);
    const res = await fetch(`/api/admin/users/${userId}/permissions`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ permissions: [...next] }),
    }).catch(() => null);
    const json = (await res?.json().catch(() => ({}))) as { error?: string };
    setBusy(false);
    if (!res?.ok) {
      setPerms(new Set(perms));
      toast(json.error ?? "Modification impossible.", { tone: "error" });
      return;
    }
    toast(`${STAFF_PERMISSIONS[key].label} : ${next.has(key) ? "accordée" : "retirée"}`, { tone: "success" });
    router.refresh();
  }

  return (
    <ul className="flex flex-wrap gap-1.5" aria-label="Permissions sensibles">
      {STAFF_PERMISSION_KEYS.map((key) => {
        const on = perms.has(key);
        return (
          <li key={key}>
            <button
              type="button"
              role="switch"
              aria-checked={on}
              disabled={!editable || busy}
              title={STAFF_PERMISSIONS[key].description}
              onClick={() => void toggle(key)}
              className={`inline-flex items-center gap-1 rounded-md border px-2 py-1 text-xs font-medium transition-colors disabled:cursor-default ${
                on ? "border-mint/50 bg-mint/10 text-mint" : "border-ink-700 text-ink-400"
              } ${editable ? (on ? "hover:bg-mint/15" : "hover:border-ink-500 hover:text-ink-200") : ""}`}
            >
              {busy && <LoaderCircle size={11} className="animate-spin" />}
              {STAFF_PERMISSIONS[key].label}
            </button>
          </li>
        );
      })}
    </ul>
  );
}
