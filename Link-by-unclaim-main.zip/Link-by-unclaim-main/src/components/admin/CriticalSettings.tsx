"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { History, LoaderCircle, Lock, ShieldAlert, Store, TicketPercent } from "lucide-react";
import { confirmDialog } from "@/lib/confirm";
import { toast } from "@/lib/toast";

type Key = "personalShops" | "launchFreeAccess";

export type CriticalEvent = { id: string; key: string; to: boolean; actor: string; at: string; reason: string };

const ITEMS: { key: Key; label: string; icon: typeof Store; on: string; off: string; enable: string; disable: string }[] = [
  {
    key: "personalShops",
    label: "Boutiques personnelles des profils",
    icon: Store,
    on: "Ouvertes : le bloc Boutique est utilisable selon les formules et les réglages ci-dessous, et les commandes sont acceptées.",
    off: "Fermées (valeur initiale) : aucune boutique n'est visible publiquement, aucune commande n'est acceptée et aucune nouvelle boutique ne peut être activée. Les boutiques et commandes existantes sont conservées.",
    enable:
      "Les boutiques personnelles deviendront visibles sur les pages publiques et pourront recevoir des commandes. Link by Unclaim n'encaisse rien : vérifie que les conditions d'utilisation couvrent bien ces ventes entre utilisateurs.",
    disable: "Toutes les boutiques personnelles disparaîtront des pages publiques et les commandes seront refusées. Rien n'est supprimé.",
  },
  {
    key: "launchFreeAccess",
    label: "Accès offert à tous (lancement)",
    icon: TicketPercent,
    on: "Activé : tous les comptes ont les fonctions de toutes les formules, sans abonnement.",
    off: "Désactivé (valeur initiale) : seules les formules actives et vérifiées (abonnement, code, don) donnent accès aux fonctions payantes.",
    enable: "Tous les comptes, y compris gratuits, auront immédiatement accès à toutes les fonctions payantes, sans abonnement.",
    disable: "Les comptes sans formule active perdront l'accès aux fonctions payantes (leurs réglages sont gardés en veille).",
  },
];

const fmt = new Intl.DateTimeFormat("fr-FR", { dateStyle: "short", timeStyle: "short", timeZone: "Europe/Paris" });

/** Réglages sensibles : interrupteurs avec confirmation et historique des changements. */
export function CriticalSettings({ values, allowed, history }: { values: Record<Key, boolean>; allowed: boolean; history: CriticalEvent[] }) {
  const router = useRouter();
  const [busy, setBusy] = useState<Key | null>(null);

  async function toggle(item: (typeof ITEMS)[number]) {
    const next = !values[item.key];
    const ok = await confirmDialog({
      title: `${next ? "Activer" : "Désactiver"} : ${item.label} ?`,
      message: next ? item.enable : item.disable,
      confirmLabel: next ? "Activer" : "Désactiver",
      tone: next ? undefined : "danger",
    });
    if (!ok) return;
    setBusy(item.key);
    const res = await fetch("/api/admin/settings/critical", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ key: item.key, value: next, confirm: true }),
    }).catch(() => null);
    const json = (await res?.json().catch(() => ({}))) as { error?: string } | undefined;
    setBusy(null);
    if (!res?.ok) {
      toast(json?.error ?? "Changement impossible.", { tone: "error" });
      return;
    }
    toast(`${item.label} : ${next ? "activé" : "désactivé"}`, { tone: "success", description: "Appliqué partout sous 30 secondes." });
    router.refresh();
  }

  return (
    <section className="hud-panel space-y-4 rounded-[2px] border border-claim/40 bg-ink-900/80 p-4" aria-labelledby="critical-title">
      <div className="flex items-start gap-2">
        <ShieldAlert size={18} className="mt-0.5 shrink-0 text-claim" aria-hidden="true" />
        <div>
          <h2 id="critical-title" className="hud-label text-claim">
            Fonctionnalités sensibles
          </h2>
          <p className="mt-1 text-xs text-ink-400">Contrôlées par le serveur (pages, API, commandes). Chaque changement demande une confirmation et reste dans l&apos;historique.</p>
        </div>
      </div>
      <ul className="divide-y divide-ink-800">
        {ITEMS.map((item) => {
          const on = values[item.key];
          const Icon = item.icon;
          return (
            <li key={item.key} className="flex flex-col gap-3 py-3 sm:flex-row sm:items-center">
              <Icon size={18} className={`shrink-0 ${on ? "text-mint" : "text-ink-500"}`} aria-hidden="true" />
              <div className="min-w-0 flex-1">
                <p className="flex flex-wrap items-center gap-2 text-sm font-medium text-ink-100">
                  {item.label}
                  <span className={`rounded-sm px-1.5 py-px font-mono text-[10px] font-semibold ${on ? "bg-mint/15 text-mint" : "bg-ink-800 text-ink-300"}`}>
                    {on ? "ACTIVÉ" : "DÉSACTIVÉ"}
                  </span>
                </p>
                <p className="text-xs text-ink-400">{on ? item.on : item.off}</p>
              </div>
              {allowed ? (
                <button
                  type="button"
                  disabled={busy !== null}
                  onClick={() => void toggle(item)}
                  className={`inline-flex shrink-0 items-center justify-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-semibold transition-colors disabled:opacity-50 ${
                    on ? "border border-danger/50 text-danger hover:bg-danger/10" : "bg-brand-500 text-ink-950 hover:bg-brand-400"
                  }`}
                >
                  {busy === item.key && <LoaderCircle size={13} className="animate-spin" />}
                  {on ? "Désactiver" : "Activer"}
                </button>
              ) : (
                <span className="inline-flex shrink-0 items-center gap-1 text-xs text-ink-500" title="Permission « Réglages sensibles » requise">
                  <Lock size={12} aria-hidden="true" /> Permission requise
                </span>
              )}
            </li>
          );
        })}
      </ul>
      <details className="group rounded-md border border-ink-800 bg-ink-950/40 px-3 py-2">
        <summary className="flex cursor-pointer list-none items-center gap-1.5 text-xs font-medium text-ink-300">
          <History size={13} aria-hidden="true" /> Historique ({history.length})
        </summary>
        {history.length === 0 ? (
          <p className="mt-2 text-xs text-ink-500">Aucun changement pour l&apos;instant : les valeurs initiales s&apos;appliquent.</p>
        ) : (
          <ul className="mt-2 space-y-1 text-xs">
            {history.map((h) => (
              <li key={h.id} className="flex flex-wrap gap-x-2 text-ink-300">
                <span className="font-mono text-ink-500">{fmt.format(new Date(h.at))}</span>
                <span>{ITEMS.find((i) => i.key === h.key)?.label ?? h.key}</span>
                <span className={h.to ? "text-mint" : "text-danger"}>{h.to ? "activé" : "désactivé"}</span>
                <span className="text-ink-500">par {h.actor}</span>
              </li>
            ))}
          </ul>
        )}
      </details>
    </section>
  );
}
