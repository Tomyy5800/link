import Link from "next/link";
import { ChevronLeft, ChevronRight, Search } from "lucide-react";
import type { ReactNode } from "react";

// Briques d'affichage de l'administration (composants serveur).

export function PageTitle({ title, description, aside }: { title: string; description?: string; aside?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="font-display text-2xl font-bold tracking-tight">{title}</h1>
        {description && <p className="mt-1 text-sm text-ink-400">{description}</p>}
      </div>
      {aside}
    </div>
  );
}

export function Panel({ title, children, className = "", aside }: { title?: string; children: ReactNode; className?: string; aside?: ReactNode }) {
  return (
    <section className={`hud-panel rounded-[2px] border border-ink-700 bg-ink-900/80 p-4 ${className}`}>
      {(title || aside) && (
        <div className="mb-3 flex items-center justify-between gap-2">
          {title && <h2 className="hud-label text-ink-400">{title}</h2>}
          {aside}
        </div>
      )}
      {children}
    </section>
  );
}

export function Stat({ label, value, hint, tone }: { label: string; value: ReactNode; hint?: ReactNode; tone?: "claim" | "danger" | "mint" }) {
  const color = tone === "claim" ? "text-claim" : tone === "danger" ? "text-danger" : tone === "mint" ? "text-mint" : "text-ink-100";
  return (
    <div className="rounded-[2px] border border-ink-700 bg-ink-900/80 p-4">
      <p className="hud-label text-[10px] text-ink-500">{label}</p>
      <p className={`mt-1 font-display text-2xl font-bold tabular-nums ${color}`}>{value}</p>
      {hint && <p className="mt-0.5 text-xs text-ink-400">{hint}</p>}
    </div>
  );
}

export function Chip({ children, tone = "muted" }: { children: ReactNode; tone?: "muted" | "claim" | "danger" | "mint" | "brand" }) {
  const tones = {
    muted: "border-ink-600 text-ink-300",
    claim: "border-claim/50 bg-claim/10 text-claim",
    danger: "border-danger/50 bg-danger/10 text-danger",
    mint: "border-mint/50 bg-mint/10 text-mint",
    brand: "border-brand-500/50 bg-brand-500/10 text-brand-300",
  };
  return <span className={`inline-flex items-center gap-1 rounded-sm border px-1.5 py-px font-mono text-[11px] font-semibold ${tones[tone]}`}>{children}</span>;
}

/** Recherche par paramètre d'URL (?q=), sans JavaScript. */
export function SearchBox({ placeholder, defaultValue, hidden }: { placeholder: string; defaultValue: string; hidden?: Record<string, string> }) {
  return (
    <form className="relative w-full sm:w-80" role="search">
      {Object.entries(hidden ?? {}).map(([k, v]) => (
        <input key={k} type="hidden" name={k} value={v} />
      ))}
      <Search size={15} className="pointer-events-none absolute top-1/2 left-2.5 -translate-y-1/2 text-ink-500" aria-hidden="true" />
      <input name="q" defaultValue={defaultValue} placeholder={placeholder} className="field !pl-8" aria-label={placeholder} />
    </form>
  );
}

export function Pager({ page, pages, href }: { page: number; pages: number; href: (page: number) => string }) {
  if (pages <= 1) return null;
  const btn = "inline-flex h-8 items-center gap-1 rounded-md border border-ink-700 px-2.5 text-xs text-ink-300 transition hover:border-ink-500 hover:text-ink-100";
  return (
    <div className="mt-4 flex items-center justify-between text-xs text-ink-400">
      {page > 1 ? (
        <Link className={btn} href={href(page - 1)}>
          <ChevronLeft size={14} /> Précédent
        </Link>
      ) : (
        <span />
      )}
      <span className="font-mono">
        {page} / {pages}
      </span>
      {page < pages ? (
        <Link className={btn} href={href(page + 1)}>
          Suivant <ChevronRight size={14} />
        </Link>
      ) : (
        <span />
      )}
    </div>
  );
}

export const nf = new Intl.NumberFormat("fr-FR");

/** Date en heure de Paris : le serveur de production tourne en UTC, son fuseau ne doit pas décaler l'affichage. */
export function formatDate(date: Date | string | null | undefined, withTime = false): string {
  if (!date) return "—";
  return new Date(date).toLocaleString("fr-FR", withTime ? { dateStyle: "short", timeStyle: "short", timeZone: "Europe/Paris" } : { dateStyle: "medium", timeZone: "Europe/Paris" });
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} o`;
  if (bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(1)} Ko`;
  if (bytes < 1024 ** 3) return `${(bytes / 1024 ** 2).toFixed(1)} Mo`;
  return `${(bytes / 1024 ** 3).toFixed(2)} Go`;
}

export function pageNumber(raw: string | string[] | undefined): number {
  const n = Number(Array.isArray(raw) ? raw[0] : raw);
  return Number.isInteger(n) && n > 0 ? n : 1;
}

export function str(raw: string | string[] | undefined): string {
  return (Array.isArray(raw) ? raw[0] : raw)?.trim().slice(0, 80) ?? "";
}
