"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { LoaderCircle, Lock, Pencil, Plus, Save, Trash2, X } from "lucide-react";
import { BadgeIcon } from "@/components/badges/OfficialBadge";
import { BADGE_ICONS, type BadgeIconKey } from "@/lib/badges";
import { formatPrice } from "@/lib/features";
import { AVATAR_FRAMES, FRAME_KEYS, SHOP_CATEGORIES, SHOP_CATEGORY_KEYS, type ShopItemInput } from "@/lib/official-shop";
import { confirmDialog } from "@/lib/confirm";
import { toast } from "@/lib/toast";
import { Toggle } from "@/components/ui/controls";

export type AdminShopItem = ShopItemInput & { id: string; sold: number };
type BadgeChoice = { key: string; name: string };

const EMPTY: ShopItemInput = {
  slug: "",
  category: "profil",
  name: "",
  description: "",
  perks: [],
  priceCents: 299,
  icon: "sparkles",
  imageUrl: "",
  color: "#22c9e8",
  reward: { type: "frame", frame: "aurore" },
  active: false,
  position: 0,
};

/** Articles de la boutique officielle : liste, création, modification, retrait. */
export function ShopItemsEditor({ items, badges, allowed, canSell }: { items: AdminShopItem[]; badges: BadgeChoice[]; allowed: boolean; canSell: boolean }) {
  const router = useRouter();
  const [editing, setEditing] = useState<{ id: string | null; item: ShopItemInput; sold: number } | null>(null);
  const [perks, setPerks] = useState("");
  const [busy, setBusy] = useState<string | null>(null);

  const open = (id: string | null, item: ShopItemInput, sold = 0) => {
    setEditing({ id, item, sold });
    setPerks(item.perks.join("\n"));
  };
  const set = (patch: Partial<ShopItemInput>) => setEditing((e) => (e ? { ...e, item: { ...e.item, ...patch } } : e));

  async function save() {
    if (!editing) return;
    setBusy("save");
    const body = { ...editing.item, perks: perks.split("\n").map((p) => p.trim()).filter(Boolean).slice(0, 6) };
    const res = await fetch(editing.id ? `/api/admin/shop-items/${editing.id}` : "/api/admin/shop-items", {
      method: editing.id ? "PATCH" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }).catch(() => null);
    const json = (await res?.json().catch(() => ({}))) as { error?: string };
    setBusy(null);
    if (!res?.ok) {
      toast(json.error ?? "Enregistrement impossible.", { tone: "error" });
      return;
    }
    toast(editing.id ? "Article enregistré" : "Article créé", { tone: "success" });
    setEditing(null);
    router.refresh();
  }

  async function remove(item: AdminShopItem) {
    const ok = await confirmDialog({
      title: `Supprimer « ${item.name} » ?`,
      message: item.sold ? "Déjà acheté : il sera seulement retiré de la vente (les acheteurs le gardent)." : "Il n'a jamais été acheté : il sera supprimé.",
      confirmLabel: "Supprimer",
      tone: "danger",
    });
    if (!ok) return;
    setBusy(item.id);
    const res = await fetch(`/api/admin/shop-items/${item.id}`, { method: "DELETE" }).catch(() => null);
    setBusy(null);
    if (!res?.ok) {
      toast("Suppression impossible.", { tone: "error" });
      return;
    }
    router.refresh();
  }

  return (
    <div className="space-y-4">
      {!canSell && (
        <p className="rounded-md border border-claim/40 bg-claim/10 px-4 py-3 text-sm text-ink-100">
          Paiement en ligne fermé (pas de clé Stripe) : la boutique s&apos;affiche avec « Bientôt disponible », aucun achat n&apos;est possible.
        </p>
      )}
      <section className="hud-panel rounded-[2px] border border-ink-700 bg-ink-900/80 p-4">
        <div className="mb-3 flex items-center justify-between gap-2">
          <h2 className="hud-label text-ink-400">Articles ({items.length})</h2>
          {allowed ? (
            <button type="button" onClick={() => open(null, { ...EMPTY, position: items.length })} className="inline-flex items-center gap-1.5 rounded-md bg-brand-500 px-3 py-1.5 text-xs font-semibold text-ink-950 transition-colors hover:bg-brand-400">
              <Plus size={14} /> Nouvel article
            </button>
          ) : (
            <span className="inline-flex items-center gap-1 text-xs text-ink-500">
              <Lock size={12} aria-hidden="true" /> Permission « Réglages sensibles » requise
            </span>
          )}
        </div>
        {items.length === 0 ? (
          <p className="py-6 text-center text-sm text-ink-400">Aucun article : la boutique officielle n&apos;affiche que les abonnements.</p>
        ) : (
          <ul className="divide-y divide-ink-800">
            {items.map((item) => (
              <li key={item.id} className={`flex items-center gap-3 py-2.5 ${item.active ? "" : "opacity-60"}`}>
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg" style={{ background: `${item.color}22`, color: item.color }}>
                  <BadgeIcon icon={item.icon} size={17} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-medium text-ink-100">{item.name}</span>
                  <span className="block truncate text-xs text-ink-400">
                    {SHOP_CATEGORIES[item.category].label} · {item.reward.type === "frame" ? `cadre ${AVATAR_FRAMES[item.reward.frame].label}` : `badge ${item.reward.badgeKey}`} · {item.sold} vendu{item.sold > 1 ? "s" : ""}
                    {!item.active && " · hors vente"}
                  </span>
                </span>
                <span className="font-mono text-sm tabular-nums text-ink-200">{formatPrice(item.priceCents)}</span>
                {allowed && (
                  <span className="flex gap-1">
                    <button type="button" onClick={() => open(item.id, item, item.sold)} className="rounded p-1.5 text-ink-400 transition-colors hover:text-ink-100" aria-label={`Modifier ${item.name}`}>
                      <Pencil size={14} />
                    </button>
                    <button type="button" onClick={() => void remove(item)} disabled={busy !== null} className="rounded p-1.5 text-ink-400 transition-colors hover:text-danger" aria-label={`Supprimer ${item.name}`}>
                      {busy === item.id ? <LoaderCircle size={14} className="animate-spin" /> : <Trash2 size={14} />}
                    </button>
                  </span>
                )}
              </li>
            ))}
          </ul>
        )}
      </section>

      {editing && (
        <section className="ui-panel-in hud-panel space-y-4 rounded-[2px] border border-brand-500/40 bg-ink-900/90 p-4" aria-label="Article">
          <div className="flex items-center justify-between">
            <h2 className="hud-label text-ink-300">{editing.id ? "Modifier l'article" : "Nouvel article"}</h2>
            <button type="button" onClick={() => setEditing(null)} className="rounded p-1 text-ink-400 hover:text-ink-100" aria-label="Fermer">
              <X size={16} />
            </button>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="block space-y-1">
              <span className="text-xs text-ink-400">Nom</span>
              <input className="field" value={editing.item.name} maxLength={48} onChange={(e) => set({ name: e.target.value })} />
            </label>
            <label className="block space-y-1">
              <span className="text-xs text-ink-400">Identifiant</span>
              <input className="field font-mono" value={editing.item.slug} maxLength={32} onChange={(e) => set({ slug: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "") })} />
            </label>
            <label className="block space-y-1">
              <span className="text-xs text-ink-400">Catégorie</span>
              <select className="field" value={editing.item.category} onChange={(e) => set({ category: e.target.value as ShopItemInput["category"] })}>
                {SHOP_CATEGORY_KEYS.map((c) => (
                  <option key={c} value={c}>
                    {SHOP_CATEGORIES[c].label}
                  </option>
                ))}
              </select>
            </label>
            <label className="block space-y-1">
              <span className="text-xs text-ink-400">Prix (€, paiement unique)</span>
              <input
                className="field font-mono"
                type="number"
                min={0.5}
                step={0.01}
                value={(editing.item.priceCents / 100).toFixed(2)}
                onChange={(e) => set({ priceCents: Math.round(Number(e.target.value) * 100) || 0 })}
              />
            </label>
          </div>
          <label className="block space-y-1">
            <span className="text-xs text-ink-400">Description</span>
            <textarea className="field" rows={2} maxLength={280} value={editing.item.description} onChange={(e) => set({ description: e.target.value })} />
          </label>
          <label className="block space-y-1">
            <span className="text-xs text-ink-400">Avantages (un par ligne, 6 au plus)</span>
            <textarea className="field text-sm" rows={3} value={perks} onChange={(e) => setPerks(e.target.value)} />
          </label>
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="block space-y-1">
              <span className="text-xs text-ink-400">Récompense</span>
              <select
                className="field"
                value={editing.item.reward.type}
                disabled={editing.sold > 0}
                onChange={(e) => set({ reward: e.target.value === "badge" ? { type: "badge", badgeKey: badges[0]?.key ?? "" } : { type: "frame", frame: "aurore" } })}
              >
                <option value="frame">Cadre d&apos;avatar</option>
                <option value="badge" disabled={!badges.length}>
                  Badge exclusif
                </option>
              </select>
            </label>
            {editing.item.reward.type === "frame" ? (
              <label className="block space-y-1">
                <span className="text-xs text-ink-400">Cadre</span>
                <select className="field" value={editing.item.reward.frame} disabled={editing.sold > 0} onChange={(e) => set({ reward: { type: "frame", frame: e.target.value as (typeof FRAME_KEYS)[number] } })}>
                  {FRAME_KEYS.map((f) => (
                    <option key={f} value={f}>
                      {AVATAR_FRAMES[f].label} — {AVATAR_FRAMES[f].description}
                    </option>
                  ))}
                </select>
              </label>
            ) : (
              <label className="block space-y-1">
                <span className="text-xs text-ink-400">Badge (règle manuelle, hors staff)</span>
                <select className="field" value={editing.item.reward.badgeKey} disabled={editing.sold > 0} onChange={(e) => set({ reward: { type: "badge", badgeKey: e.target.value } })}>
                  {badges.map((b) => (
                    <option key={b.key} value={b.key}>
                      {b.name}
                    </option>
                  ))}
                </select>
              </label>
            )}
          </div>
          {editing.sold > 0 && <p className="text-xs text-ink-500">Déjà vendu : la récompense ne change plus (les acheteurs gardent ce qu&apos;ils ont payé).</p>}
          <div className="grid gap-3 sm:grid-cols-[auto_1fr]">
            <label className="block space-y-1">
              <span className="text-xs text-ink-400">Couleur</span>
              <input type="color" className="h-9 w-14 cursor-pointer rounded border border-ink-700 bg-transparent" value={editing.item.color} onChange={(e) => set({ color: e.target.value })} />
            </label>
            <div>
              <span className="text-xs text-ink-400">Icône</span>
              <div className="mt-1 flex flex-wrap gap-1">
                {BADGE_ICONS.map((icon) => (
                  <button
                    key={icon}
                    type="button"
                    aria-label={icon}
                    aria-pressed={editing.item.icon === icon}
                    onClick={() => set({ icon: icon as BadgeIconKey })}
                    className={`flex h-8 w-8 items-center justify-center rounded-md border transition-colors ${editing.item.icon === icon ? "border-brand-400 bg-brand-500/10 text-ink-100" : "border-ink-700 text-ink-400 hover:text-ink-200"}`}
                  >
                    <BadgeIcon icon={icon} size={14} />
                  </button>
                ))}
              </div>
            </div>
          </div>
          <Toggle label="En vente" description="Visible dans la boutique officielle (achat possible seulement si le paiement en ligne est ouvert)." checked={editing.item.active} onChange={(active) => set({ active })} />
          <div className="flex justify-end">
            <button type="button" onClick={() => void save()} disabled={busy !== null} className="inline-flex items-center gap-1.5 rounded-md bg-brand-500 px-4 py-2 text-sm font-semibold text-ink-950 transition-colors hover:bg-brand-400 disabled:opacity-50">
              {busy === "save" ? <LoaderCircle size={15} className="animate-spin" /> : <Save size={15} />} Enregistrer
            </button>
          </div>
        </section>
      )}
    </div>
  );
}
