"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { CircleAlert, CircleCheck, Link2, LoaderCircle, Plug, RefreshCw, Save, Trash2 } from "lucide-react";
import { OfficialBadge } from "@/components/badges/OfficialBadge";
import type { PublicBadge } from "@/lib/badges";
import { confirmDialog } from "@/lib/confirm";
import { toast } from "@/lib/toast";
import { Toggle } from "@/components/ui/controls";

type Config = { guildId: string; enabled: boolean; intervalMinutes: number };
type Status = { lastRunAt: string | null; ok: boolean; message: string; mode: "list" | "members" | null; checked: number; granted: number; revoked: number; errors: string[] };
type Role = { id: string; name: string; color: number };
export type LinkRow = { id: string; roleId: string; roleName: string; enabled: boolean; removeOnLoss: boolean; badge: PublicBadge & { id: string } };
export type BadgeOption = PublicBadge & { id: string };

const fmt = new Intl.DateTimeFormat("fr-FR", { dateStyle: "short", timeStyle: "short", timeZone: "Europe/Paris" });

async function call<T>(method: string, url: string, body?: unknown): Promise<T> {
  const res = await fetch(url, { method, headers: body ? { "Content-Type": "application/json" } : undefined, body: body ? JSON.stringify(body) : undefined }).catch(() => null);
  const json = (await res?.json().catch(() => ({}))) as T & { error?: string };
  if (!res?.ok) throw new Error(json.error ?? "Action impossible.");
  return json;
}

/** Synchronisation des rôles du serveur Discord officiel avec les badges (configuration, associations, état). */
export function DiscordSync({
  config: initialConfig,
  status,
  botConfigured,
  links,
  badges,
  allowed,
}: {
  config: Config;
  status: Status;
  botConfigured: boolean;
  links: LinkRow[];
  badges: BadgeOption[];
  allowed: boolean;
}) {
  const router = useRouter();
  const [config, setConfig] = useState(initialConfig);
  const [roles, setRoles] = useState<Role[] | null>(null);
  const [guildName, setGuildName] = useState<string | null>(null);
  const [draft, setDraft] = useState({ roleId: "", badgeId: badges[0]?.id ?? "", removeOnLoss: true });
  const [busy, setBusy] = useState<string | null>(null);

  async function run(key: string, task: () => Promise<void>) {
    setBusy(key);
    try {
      await task();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Action impossible.", { tone: "error" });
    } finally {
      setBusy(null);
    }
  }

  const save = () =>
    run("save", async () => {
      await call("PUT", "/api/admin/discord", config);
      toast("Configuration enregistrée", { tone: "success" });
      router.refresh();
    });

  const test = () =>
    run("test", async () => {
      const json = await call<{ guild: { name: string }; roles: Role[] }>("POST", "/api/admin/discord/sync", { action: "test" });
      setGuildName(json.guild.name);
      setRoles(json.roles);
      toast(`Connecté au serveur « ${json.guild.name} »`, { tone: "success", description: `${json.roles.length} rôles lus.` });
    });

  const sync = () =>
    run("sync", async () => {
      const json = await call<{ status: Status }>("POST", "/api/admin/discord/sync", { action: "sync" });
      toast(json.status.ok ? "Synchronisation terminée" : "Synchronisation avec erreurs", { tone: json.status.ok ? "success" : "error", description: json.status.message });
      router.refresh();
    });

  const addLink = () =>
    run("link", async () => {
      const role = roles?.find((r) => r.id === draft.roleId);
      await call("POST", "/api/admin/discord/links", { ...draft, roleName: role?.name ?? "" });
      toast("Association ajoutée", { tone: "success" });
      setDraft((d) => ({ ...d, roleId: "" }));
      router.refresh();
    });

  const patchLink = (link: LinkRow, patch: Partial<Pick<LinkRow, "enabled" | "removeOnLoss">>) =>
    run(link.id, async () => {
      await call("PATCH", `/api/admin/discord/links/${link.id}`, patch);
      router.refresh();
    });

  const removeLink = async (link: LinkRow) => {
    const ok = await confirmDialog({
      title: "Supprimer cette association ?",
      message: "Les badges déjà donnés par la synchronisation restent en place ; retire-les à la main si besoin.",
      confirmLabel: "Supprimer",
      tone: "danger",
    });
    if (!ok) return;
    await run(link.id, async () => {
      await call("DELETE", `/api/admin/discord/links/${link.id}`);
      router.refresh();
    });
  };

  const disabled = !allowed || busy !== null;

  return (
    <div className="space-y-4">
      <section className={`hud-panel space-y-3 rounded-[2px] border p-4 ${botConfigured ? "border-ink-700 bg-ink-900/80" : "border-claim/40 bg-claim/5"}`}>
        <h2 className="hud-label text-ink-400">État</h2>
        {botConfigured ? (
          <p className="flex items-center gap-2 text-sm text-ink-100">
            <CircleCheck size={16} className="text-mint" /> Jeton du bot présent dans l&apos;environnement du serveur.
          </p>
        ) : (
          <div className="space-y-2 text-sm text-ink-300">
            <p className="flex items-center gap-2 text-ink-100">
              <CircleAlert size={16} className="text-claim" /> Bot non configuré : la synchronisation est inactive.
            </p>
            <ol className="list-decimal space-y-1 pl-5 text-xs">
              <li>Sur discord.com/developers, crée une application, puis un bot (onglet Bot) et copie son jeton.</li>
              <li>Active l&apos;intention « Server Members Intent » (lecture de tous les membres).</li>
              <li>Invite le bot sur le serveur officiel (OAuth2 › URL Generator, portée « bot », aucune permission requise).</li>
              <li>
                Ajoute <code>DISCORD_BOT_TOKEN=…</code> dans l&apos;environnement du serveur, redémarre, puis teste la connexion ici.
              </li>
            </ol>
          </div>
        )}
        <div className="rounded-md border border-ink-800 bg-ink-950/40 px-3 py-2 text-xs">
          <p className="text-ink-300">
            Dernière synchronisation : {status.lastRunAt ? fmt.format(new Date(status.lastRunAt)) : "jamais"}
            {status.lastRunAt && (
              <span className={status.ok ? "text-mint" : "text-danger"}> · {status.ok ? "réussie" : "en erreur"}</span>
            )}
          </p>
          <p className="mt-0.5 text-ink-400">{status.message}</p>
          {status.lastRunAt && (
            <p className="mt-0.5 font-mono text-ink-500">
              {status.checked} vérifiés · +{status.granted} badges · −{status.revoked} badges{status.mode === "members" ? " · lecture membre par membre" : ""}
            </p>
          )}
          {status.errors.length > 0 && (
            <ul className="mt-1 list-disc pl-4 text-danger">
              {status.errors.map((e, i) => (
                <li key={i}>{e}</li>
              ))}
            </ul>
          )}
        </div>
      </section>

      <section className="hud-panel space-y-3 rounded-[2px] border border-ink-700 bg-ink-900/80 p-4">
        <h2 className="hud-label text-ink-400">Serveur officiel</h2>
        <div className="grid gap-3 sm:grid-cols-[1fr_180px]">
          <label className="block space-y-1.5">
            <span className="text-[0.8rem] font-medium text-ink-200">Identifiant du serveur Discord</span>
            <input
              className="field font-mono"
              value={config.guildId}
              inputMode="numeric"
              placeholder="123456789012345678"
              disabled={!allowed}
              onChange={(e) => setConfig({ ...config, guildId: e.target.value.replace(/\D/g, "").slice(0, 22) })}
            />
            {guildName && <span className="block text-xs text-mint">Serveur : {guildName}</span>}
          </label>
          <label className="block space-y-1.5">
            <span className="text-[0.8rem] font-medium text-ink-200">Fréquence</span>
            <select className="field" value={config.intervalMinutes} disabled={!allowed} onChange={(e) => setConfig({ ...config, intervalMinutes: Number(e.target.value) })}>
              <option value={15}>Toutes les 15 min</option>
              <option value={60}>Toutes les heures</option>
              <option value={360}>Toutes les 6 h</option>
              <option value={1440}>Une fois par jour</option>
            </select>
          </label>
        </div>
        <Toggle
          label="Synchronisation automatique"
          description="Périodique, et à chaque connexion d'un compte relié à Discord par Unclaim Auth."
          checked={config.enabled}
          disabled={!allowed}
          onChange={(enabled) => setConfig({ ...config, enabled })}
        />
        <div className="flex flex-wrap gap-2">
          <button type="button" onClick={() => void save()} disabled={disabled} className="inline-flex items-center gap-1.5 rounded-md bg-brand-500 px-3 py-2 text-sm font-semibold text-ink-950 transition-colors hover:bg-brand-400 disabled:opacity-50">
            {busy === "save" ? <LoaderCircle size={15} className="animate-spin" /> : <Save size={15} />} Enregistrer
          </button>
          <button type="button" onClick={() => void test()} disabled={disabled || !botConfigured} className="inline-flex items-center gap-1.5 rounded-md border border-ink-600 px-3 py-2 text-sm text-ink-200 transition-colors hover:border-ink-400 disabled:opacity-50">
            {busy === "test" ? <LoaderCircle size={15} className="animate-spin" /> : <Plug size={15} />} Tester et lire les rôles
          </button>
          <button type="button" onClick={() => void sync()} disabled={disabled || !botConfigured} className="inline-flex items-center gap-1.5 rounded-md border border-ink-600 px-3 py-2 text-sm text-ink-200 transition-colors hover:border-ink-400 disabled:opacity-50">
            {busy === "sync" ? <LoaderCircle size={15} className="animate-spin" /> : <RefreshCw size={15} />} Synchroniser maintenant
          </button>
        </div>
      </section>

      <section className="hud-panel space-y-3 rounded-[2px] border border-ink-700 bg-ink-900/80 p-4">
        <h2 className="hud-label text-ink-400">Rôles associés aux badges</h2>
        <p className="text-xs text-ink-400">
          Un compte Link n&apos;est relié qu&apos;au compte Discord prouvé par sa connexion Unclaim Auth. Seuls les badges à règle manuelle peuvent suivre un rôle ; un badge
          donné à la main n&apos;est jamais retiré par la synchronisation.
        </p>
        {links.length > 0 && (
          <ul className="divide-y divide-ink-800">
            {links.map((link) => (
              <li key={link.id} className={`flex flex-col gap-2 py-2.5 sm:flex-row sm:items-center ${link.enabled ? "" : "opacity-60"}`}>
                <span className="inline-flex min-w-0 flex-1 items-center gap-2 text-sm">
                  <span className="truncate font-medium text-ink-100">@{link.roleName || link.roleId}</span>
                  <Link2 size={13} className="shrink-0 text-ink-500" aria-hidden="true" />
                  <OfficialBadge badge={link.badge} />
                </span>
                <label className="inline-flex items-center gap-1.5 text-xs text-ink-300">
                  <input type="checkbox" checked={link.removeOnLoss} disabled={disabled} onChange={(e) => void patchLink(link, { removeOnLoss: e.target.checked })} /> Retirer si le rôle est perdu
                </label>
                <label className="inline-flex items-center gap-1.5 text-xs text-ink-300">
                  <input type="checkbox" checked={link.enabled} disabled={disabled} onChange={(e) => void patchLink(link, { enabled: e.target.checked })} /> Active
                </label>
                <button type="button" onClick={() => void removeLink(link)} disabled={disabled} className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs text-ink-400 transition-colors hover:text-danger disabled:opacity-50" aria-label="Supprimer l'association">
                  {busy === link.id ? <LoaderCircle size={13} className="animate-spin" /> : <Trash2 size={13} />}
                </button>
              </li>
            ))}
          </ul>
        )}
        {allowed && (
          <div className="grid gap-2 rounded-md border border-ink-800 bg-ink-950/40 p-3 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
            <label className="block space-y-1">
              <span className="block text-xs text-ink-400">Rôle Discord</span>
              {roles ? (
                <select className="field" value={draft.roleId} onChange={(e) => setDraft({ ...draft, roleId: e.target.value })}>
                  <option value="">Choisir un rôle…</option>
                  {roles.map((r) => (
                    <option key={r.id} value={r.id}>
                      @{r.name}
                    </option>
                  ))}
                </select>
              ) : (
                <input className="field font-mono" value={draft.roleId} inputMode="numeric" placeholder="ID du rôle (ou « Tester » pour la liste)" onChange={(e) => setDraft({ ...draft, roleId: e.target.value.replace(/\D/g, "") })} />
              )}
            </label>
            <label className="block space-y-1">
              <span className="block text-xs text-ink-400">Badge donné</span>
              <select className="field" value={draft.badgeId} onChange={(e) => setDraft({ ...draft, badgeId: e.target.value })}>
                {badges.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                    {b.staff ? " (staff)" : ""}
                  </option>
                ))}
              </select>
            </label>
            <button type="button" onClick={() => void addLink()} disabled={disabled || !draft.roleId || !draft.badgeId} className="inline-flex h-9 items-center justify-center gap-1.5 rounded-md bg-brand-500 px-3 text-sm font-semibold text-ink-950 transition-colors hover:bg-brand-400 disabled:opacity-50">
              {busy === "link" ? <LoaderCircle size={15} className="animate-spin" /> : <Link2 size={15} />} Associer
            </button>
          </div>
        )}
        {!allowed && <p className="text-xs text-ink-500">Permission « Synchronisation Discord » requise pour modifier.</p>}
      </section>
    </div>
  );
}
