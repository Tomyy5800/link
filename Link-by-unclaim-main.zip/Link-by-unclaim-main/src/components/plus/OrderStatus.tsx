"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Check, CircleAlert, Copy, LoaderCircle } from "lucide-react";

type OrderState = {
  order: { status: string; offerName: string; days: number; gift: boolean; giftCode: string | null };
  plan: { plan: string; planExpiresAt: string | null } | null;
};

/** Suit la confirmation du paiement (envoyée par Stripe au serveur, parfois avec quelques secondes de retard). */
export function OrderStatus({ orderId, premiumName }: { orderId: string | null; premiumName: string }) {
  const [data, setData] = useState<OrderState | null>(null);
  const [failed, setFailed] = useState(false);
  const [copied, setCopied] = useState(false);
  const [tries, setTries] = useState(0);

  useEffect(() => {
    if (!orderId) return;
    let stop = false;
    const load = async () => {
      const res = await fetch(`/api/me/orders/${orderId}`, { cache: "no-store" }).catch(() => null);
      if (stop) return;
      if (!res?.ok) {
        setFailed(true);
        return;
      }
      const json = (await res.json()) as OrderState;
      setData(json);
      if (json.order.status === "pending") setTimeout(() => setTries((t) => t + 1), 2000);
    };
    if (tries < 30) void load();
    return () => {
      stop = true;
    };
  }, [orderId, tries]);

  if (!orderId || failed) {
    return (
      <p className="mt-8 flex items-center gap-2 text-ink-300">
        <CircleAlert size={18} className="text-danger" /> Commande introuvable. Si tu as été débité·e, écris-nous avec la date du paiement.
      </p>
    );
  }
  if (!data || data.order.status === "pending") {
    return (
      <div className="mt-8 space-y-2">
        <p className="inline-flex items-center gap-2 text-lg font-semibold">
          <LoaderCircle size={20} className="animate-spin text-brand-300" /> Confirmation du paiement…
        </p>
        <p className="text-sm text-ink-400">
          {tries >= 30 ? "La confirmation tarde : ton accès sera activé dès réception, tu peux fermer cette page." : "Quelques secondes, on attend la banque."}
        </p>
      </div>
    );
  }
  if (data.order.status !== "paid") {
    return (
      <p className="mt-8 flex items-center gap-2 text-ink-300">
        <CircleAlert size={18} className="text-danger" />
        {data.order.status === "refunded" ? "Cette commande a été remboursée." : "Le paiement n'a pas abouti : rien n'a été débité."}
      </p>
    );
  }

  if (data.order.gift && data.order.giftCode) {
    return (
      <div className="mt-8 w-full space-y-4">
        <h1 className="font-display text-3xl font-bold">Merci pour ce cadeau</h1>
        <p className="text-ink-300">
          Voici le code {premiumName} ({data.order.offerName}) à offrir. La personne l&apos;active dans Réglages › {premiumName} de son éditeur.
        </p>
        <div className="flex items-center gap-2 rounded-md border border-claim/50 bg-ink-900 p-2 pl-4">
          <code className="flex-1 font-mono text-lg tracking-wider text-ink-100 select-all">{data.order.giftCode}</code>
          <button
            type="button"
            onClick={() => navigator.clipboard.writeText(data.order.giftCode ?? "").then(() => setCopied(true))}
            className="inline-flex items-center gap-1.5 rounded-md bg-ink-750 px-3 py-2 text-sm text-ink-100 hover:bg-ink-700"
          >
            {copied ? <Check size={15} /> : <Copy size={15} />} {copied ? "Copié" : "Copier"}
          </button>
        </div>
        <p className="text-xs text-ink-400">Le code reste disponible ici tant que tu gardes ce lien ; garde-le précieusement.</p>
      </div>
    );
  }

  const until = data.plan?.planExpiresAt ? new Date(data.plan.planExpiresAt).toLocaleDateString("fr-FR", { dateStyle: "long", timeZone: "Europe/Paris" }) : null;
  return (
    <div className="mt-8 space-y-4">
      <h1 className="font-display text-3xl font-bold">Bienvenue dans {premiumName}</h1>
      <p className="text-ink-300">{until ? `Ton accès est actif jusqu'au ${until}.` : "Ton accès est actif, sans limite de durée."}</p>
      <Link href="/dashboard" className="inline-flex rounded-md bg-brand-500 px-5 py-2.5 font-semibold text-ink-950 transition hover:bg-brand-400">
        Personnaliser ma page
      </Link>
    </div>
  );
}
