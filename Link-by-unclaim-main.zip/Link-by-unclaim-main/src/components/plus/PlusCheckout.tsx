"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowRight, Check, ExternalLink, LoaderCircle, Lock, RefreshCw, ShieldCheck, Sparkles, X } from "lucide-react";
import { formatPrice, monthlyCents, type BillingInterval, type Offer } from "@/lib/features";
import { TIER_RANK, type Tier } from "@/lib/plans";
import { toast } from "@/lib/toast";

export type TierCard = {
  tier: Tier;
  name: string;
  tagline: string;
  audience: string;
  /** Ce que la formule apporte de plus que la précédente. */
  highlights: string[];
  offers: Offer[];
  /** Formule mise en avant. */
  featured: boolean;
};

type Props = {
  cards: TierCard[];
  loggedIn: boolean;
  /** Paiement en ligne ouvert (clés Stripe présentes). */
  canPay: boolean;
  testMode: boolean;
  /** Boutique externe (codes), si le paiement en ligne n'est pas ouvert. */
  shopUrl: string;
  /** Formule actuelle du compte connecté. */
  current: { tier: Tier; name: string; until: string | null; subscribed: boolean; offerId: string | null } | null;
};

const day = (iso: string) => new Date(iso).toLocaleDateString("fr-FR", { dateStyle: "long", timeZone: "Europe/Paris" });

/** Économie de l'annuel par rapport à douze mois au tarif mensuel. */
function yearlySaving(offers: Offer[]): number | null {
  const month = offers.find((o) => o.interval === "month");
  const year = offers.find((o) => o.interval === "year");
  if (!month || !year) return null;
  const saving = Math.round((1 - year.priceCents / (month.priceCents * 12)) * 100);
  return saving > 0 ? saving : null;
}

/** Cartes des formules, choix mensuel ou annuel, et confirmation (CGV, rétractation, changement de formule). */
export function PlusCheckout({ cards, loggedIn, canPay, testMode, shopUrl, current }: Props) {
  const router = useRouter();
  const intervals = new Set(cards.flatMap((c) => c.offers.map((o) => o.interval)));
  const [interval, setBilling] = useState<BillingInterval>(intervals.has("year") ? "year" : "month");
  const [selected, setSelected] = useState<{ card: TierCard; offer: Offer } | null>(null);
  const [accepted, setAccepted] = useState(false);
  const [state, setState] = useState<{ status: "idle" | "sending" | "error"; message?: string }>({ status: "idle" });
  const saving = yearlySaving(cards.find((c) => c.tier === "plus")?.offers ?? []);
  const changing = Boolean(current?.subscribed && selected);

  async function pay() {
    if (!selected || !accepted) return;
    setState({ status: "sending" });
    const res = await fetch("/api/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ kind: "subscription", offerId: selected.offer.id, acceptTerms: true }),
    }).catch(() => null);
    const json = (await res?.json().catch(() => ({}))) as { url?: string; changed?: boolean; error?: string } | undefined;
    if (res?.ok && json?.url) {
      window.location.href = json.url;
      return;
    }
    if (res?.ok && json?.changed) {
      toast(`Formule changée : ${selected.card.name}`, { tone: "success", description: "La différence a été calculée au prorata de la période en cours." });
      setSelected(null);
      setState({ status: "idle" });
      router.refresh();
      return;
    }
    setState({ status: "error", message: json?.error ?? "Le paiement n'a pas pu démarrer. Réessaie dans un instant." });
  }

  return (
    <div>
      {intervals.size > 1 && (
        <div className="mb-6 flex justify-center">
          <div role="radiogroup" aria-label="Période de facturation" className="relative inline-flex rounded-lg border border-ink-700 bg-ink-900 p-1">
            {(["month", "year"] as const).map((value) => (
              <button
                key={value}
                type="button"
                role="radio"
                aria-checked={interval === value}
                onClick={() => setBilling(value)}
                className={`relative rounded-md px-4 py-1.5 text-sm font-semibold transition-colors duration-200 ${interval === value ? "bg-ink-100 text-ink-950" : "text-ink-300 hover:text-ink-100"}`}
              >
                {value === "month" ? "Mensuel" : "Annuel"}
                {value === "year" && saving && (
                  <span className={`ml-1.5 rounded-sm px-1 py-px font-mono text-[10px] ${interval === value ? "bg-mint text-ink-950" : "bg-mint/15 text-mint"}`}>−{saving} %</span>
                )}
              </button>
            ))}
          </div>
        </div>
      )}

      <ul className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {cards.map((card) => {
          const offer = card.offers.find((o) => o.interval === interval) ?? card.offers[0];
          const isCurrentTier = current?.tier === card.tier;
          const isCurrentOffer = Boolean(current?.subscribed && offer && current.offerId === offer.id);
          return (
            <li
              key={card.tier}
              data-spotlight
              data-tone={card.tier === "free" ? undefined : "claim"}
              className={`ui-spotlight relative flex flex-col rounded-xl border bg-ink-900/90 p-6 transition-[border-color,box-shadow] duration-200 ${
                card.featured ? "ui-glow-border border-transparent" : "border-ink-700 hover:border-ink-500"
              } ${selected?.card.tier === card.tier ? "ring-2 ring-brand-400" : ""}`}
            >
              {card.featured && (
                <span className="absolute -top-3 left-6 inline-flex items-center gap-1 rounded-sm bg-claim px-2 py-0.5 font-mono text-[11px] font-semibold text-ink-950">
                  <Sparkles size={11} aria-hidden="true" /> Le choix des créateurs
                </span>
              )}
              <p className="hud-label text-ink-400">{card.tagline}</p>
              <h3 className="mt-2 font-display text-2xl font-bold">{card.name}</h3>
              <p className="mt-1 text-xs text-ink-400">{card.audience}</p>

              {card.tier === "free" ? (
                <p className="mt-4 font-display text-4xl font-bold">0 €</p>
              ) : offer ? (
                <>
                  <p className="mt-4 flex items-baseline gap-1.5">
                    <span className="font-display text-4xl font-bold tabular-nums">{formatPrice(offer.interval === "year" ? monthlyCents(offer) : offer.priceCents)}</span>
                    <span className="text-sm text-ink-400">/ mois</span>
                  </p>
                  <p className="mt-1 text-sm text-ink-300">
                    {offer.interval === "year" ? `soit ${formatPrice(offer.priceCents)} facturés chaque année` : "facturé chaque mois"}
                  </p>
                  <p className="mt-2 text-xs text-ink-500">Sans engagement · résiliable à tout moment</p>
                </>
              ) : (
                <p className="mt-4 text-sm text-ink-400">Bientôt disponible</p>
              )}

              <ul className="mt-5 space-y-2 text-sm">
                {card.highlights.map((h) => (
                  <li key={h} className="flex gap-2 text-ink-200">
                    <Check size={15} className="mt-0.5 shrink-0 text-mint" aria-hidden="true" />
                    <span>{h}</span>
                  </li>
                ))}
              </ul>

              <div className="mt-auto pt-6">
                {card.tier === "free" ? (
                  <a
                    href={loggedIn ? "/dashboard" : "/login"}
                    className="flex w-full items-center justify-center gap-1.5 rounded-md border border-ink-500 px-4 py-2.5 text-sm font-semibold text-ink-100 transition-colors hover:border-ink-300"
                  >
                    {loggedIn ? "Mon espace" : "Créer ma page"} <ArrowRight size={14} />
                  </a>
                ) : !offer ? null : canPay ? (
                  loggedIn ? (
                    isCurrentOffer ? (
                      <a
                        href="/dashboard/abonnement"
                        className="flex w-full items-center justify-center gap-1.5 rounded-md border border-mint/50 px-4 py-2.5 text-sm font-semibold text-mint transition-colors hover:bg-mint/10"
                      >
                        <Check size={15} /> Ton abonnement
                      </a>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          setSelected({ card, offer });
                          setAccepted(false);
                          setState({ status: "idle" });
                          requestAnimationFrame(() => document.getElementById("confirmation")?.scrollIntoView({ behavior: "smooth", block: "center" }));
                        }}
                        className={`w-full rounded-md px-4 py-2.5 text-sm font-semibold transition-[filter,background-color] duration-150 ${
                          card.featured ? "bg-claim text-ink-950 hover:brightness-110" : "bg-brand-500 text-ink-950 hover:bg-brand-400"
                        }`}
                      >
                        {current?.subscribed ? (TIER_RANK[card.tier] > TIER_RANK[current.tier] ? `Passer à ${card.name}` : isCurrentTier ? "Changer de période" : `Passer à ${card.name}`) : `S'abonner à ${card.name}`}
                      </button>
                    )
                  ) : (
                    <a
                      href={`/login?next=${encodeURIComponent("/plus")}`}
                      className="block w-full rounded-md border border-ink-500 px-4 py-2.5 text-center text-sm font-semibold text-ink-100 transition-colors hover:border-ink-300"
                    >
                      Se connecter pour s&apos;abonner
                    </a>
                  )
                ) : shopUrl ? (
                  <a
                    href={shopUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex w-full items-center justify-center gap-1.5 rounded-md bg-brand-500 px-4 py-2.5 text-sm font-semibold text-ink-950 transition-colors hover:bg-brand-400"
                  >
                    Obtenir un code <ExternalLink size={14} />
                  </a>
                ) : (
                  <span className="block w-full rounded-md border border-dashed border-ink-600 px-4 py-2.5 text-center text-sm text-ink-400">Bientôt disponible</span>
                )}
                {isCurrentTier && !isCurrentOffer && <p className="mt-2 text-center text-xs text-mint">Ta formule actuelle</p>}
              </div>
            </li>
          );
        })}
      </ul>

      {selected && (
        <section id="confirmation" className="ui-panel-in hud-panel mx-auto mt-8 max-w-xl rounded-[2px] border border-ink-600 bg-ink-850 p-6" aria-label="Confirmer l'abonnement">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="hud-label text-ink-400">{changing ? "Changement de formule" : "Récapitulatif"}</p>
              <p className="mt-1 font-display text-xl font-bold">
                {selected.card.name} · {selected.offer.interval === "year" ? "annuel" : "mensuel"} — {formatPrice(selected.offer.priceCents)}
                <span className="text-base font-normal text-ink-400"> {selected.offer.interval === "year" ? "/ an" : "/ mois"}</span>
              </p>
            </div>
            <button type="button" onClick={() => setSelected(null)} className="rounded p-1 text-ink-400 transition-colors hover:text-ink-100" aria-label="Fermer">
              <X size={18} />
            </button>
          </div>

          {testMode && (
            <p className="mt-4 rounded-md border border-claim/40 bg-claim/10 px-3 py-2 text-xs text-ink-100">
              Mode test : aucun vrai paiement. Carte de test Stripe : 4242 4242 4242 4242, date future, CVC au choix.
            </p>
          )}

          <ul className="mt-4 space-y-1.5 text-sm text-ink-300">
            {changing ? (
              <>
                <li className="flex gap-2">
                  <RefreshCw size={15} className="mt-0.5 shrink-0 text-brand-300" aria-hidden="true" /> Le changement est immédiat : la différence pour la période en
                  cours est facturée (ou créditée) au prorata, sur ta carte enregistrée.
                </li>
                {current?.until && <li className="pl-6 text-xs text-ink-400">Ta période actuelle se termine le {day(current.until)}.</li>}
              </>
            ) : (
              <>
                <li className="flex gap-2">
                  <Check size={15} className="mt-0.5 shrink-0 text-mint" aria-hidden="true" /> Renouvelé automatiquement chaque {selected.offer.interval === "year" ? "année" : "mois"}.
                </li>
                <li className="flex gap-2">
                  <Check size={15} className="mt-0.5 shrink-0 text-mint" aria-hidden="true" /> Résiliable à tout moment depuis Mon espace › Offre : tu gardes l&apos;accès
                  jusqu&apos;à la fin de la période payée.
                </li>
              </>
            )}
          </ul>

          <label className="mt-5 flex cursor-pointer items-start gap-3 text-sm text-ink-200">
            <input type="checkbox" checked={accepted} onChange={(e) => setAccepted(e.target.checked)} className="mt-1 h-4 w-4 shrink-0 accent-[#22c9e8]" />
            <span>
              J&apos;accepte les{" "}
              <a href="/cgv" target="_blank" className="text-brand-300 underline">
                conditions générales de vente
              </a>{" "}
              et l&apos;abonnement à renouvellement automatique. Je demande l&apos;accès immédiat à {selected.card.name} et je reconnais perdre mon droit de
              rétractation de 14 jours une fois l&apos;accès ouvert (article L221-28 du Code de la consommation).
            </span>
          </label>
          <p className="mt-2 pl-7 text-xs text-ink-400">Si tu es mineur·e, demande l&apos;accord d&apos;un parent avant de t&apos;abonner.</p>

          {state.status === "error" && (
            <p className="mt-4 text-sm text-danger" role="alert">
              {state.message}
            </p>
          )}

          <button
            type="button"
            onClick={pay}
            disabled={!accepted || state.status === "sending"}
            className="mt-5 flex w-full items-center justify-center gap-2 rounded-md bg-claim px-4 py-3 font-semibold text-ink-950 transition-[filter,opacity] duration-150 hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {state.status === "sending" ? <LoaderCircle size={18} className="animate-spin" /> : <Lock size={16} />}
            {changing ? `Confirmer le passage à ${selected.card.name}` : `S'abonner — ${formatPrice(selected.offer.priceCents)} ${selected.offer.interval === "year" ? "/ an" : "/ mois"}`}
          </button>
          <p className="mt-3 flex items-center justify-center gap-1.5 text-xs text-ink-400">
            <ShieldCheck size={13} className="text-mint" aria-hidden="true" /> Paiement sécurisé par Stripe : tes données de carte ne passent jamais par Link by Unclaim.
          </p>
        </section>
      )}
    </div>
  );
}
