"use client";

import { useEffect, useLayoutEffect, useRef, useState, type CSSProperties, type KeyboardEvent, type ReactNode } from "react";
import { ArrowLeft, ArrowRight, CircleHelp, Coins, Layers, ListChecks } from "lucide-react";
import { smoothScrollTo } from "@/lib/scroll";

const ICONS = { formules: Layers, inclus: ListChecks, prix: Coins, questions: CircleHelp } as const;

/** Une partie : « short » est le nom affiché sur téléphone, où les quatre onglets doivent tenir. */
export type Chapter = { id: keyof typeof ICONS; label: string; short: string; hint: string; content: ReactNode };

/**
 * La page Link+ en parties : une barre d'onglets collée sous l'en-tête, une partie à la fois,
 * qui glisse dans le sens du déplacement. L'adresse garde la partie ouverte (#inclus…), les
 * flèches du clavier passent d'un onglet à l'autre, et chaque partie propose la suivante.
 */
export function PlusChapters({ chapters }: { chapters: Chapter[] }) {
  const [active, setActive] = useState(0);
  const [direction, setDirection] = useState(1);
  const [pill, setPill] = useState({ left: 0, width: 0, ready: false });
  const rootRef = useRef<HTMLElement>(null);
  const tabs = useRef<(HTMLButtonElement | null)[]>([]);

  // Partie demandée dans l'adresse (lien partagé, retour arrière).
  useEffect(() => {
    const fromHash = () => {
      const index = chapters.findIndex((c) => `#${c.id}` === window.location.hash);
      if (index >= 0) setActive(index);
    };
    fromHash();
    window.addEventListener("hashchange", fromHash);
    return () => window.removeEventListener("hashchange", fromHash);
  }, [chapters]);

  useLayoutEffect(() => {
    const measure = () => {
      const tab = tabs.current[active];
      if (tab) setPill({ left: tab.offsetLeft, width: tab.offsetWidth, ready: true });
    };
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, [active]);

  const open = (index: number, focus = false) => {
    if (index === active || index < 0 || index >= chapters.length) return;
    setDirection(index > active ? 1 : -1);
    setActive(index);
    window.history.replaceState(window.history.state, "", `#${chapters[index].id}`);
    if (focus) tabs.current[index]?.focus();
    tabs.current[index]?.scrollIntoView({ block: "nearest", inline: "nearest" });
    // La nouvelle partie commence sous la barre d'onglets, même si on lisait plus bas.
    const root = rootRef.current;
    if (root && root.getBoundingClientRect().top < 0) smoothScrollTo(root.getBoundingClientRect().top + window.scrollY - 72);
  };

  const onKeyDown = (event: KeyboardEvent) => {
    const moves: Record<string, number> = { ArrowRight: active + 1, ArrowLeft: active - 1, Home: 0, End: chapters.length - 1 };
    if (event.key in moves) {
      event.preventDefault();
      open(Math.min(chapters.length - 1, Math.max(0, moves[event.key])), true);
    }
  };

  const next = chapters[active + 1];
  const previous = chapters[active - 1];

  return (
    <section ref={rootRef} id="parties" aria-label="Tout savoir sur les formules" className="mt-12">
      <div className="sticky top-[4.25rem] z-20 -mx-4 px-4 py-2 sm:mx-0 sm:px-0">
        <div
          role="tablist"
          aria-label="Parties"
          onKeyDown={onKeyDown}
          className="scrollbar-none relative mx-auto flex w-full max-w-3xl gap-1 overflow-x-auto rounded-2xl border border-white/10 bg-ink-950/80 p-1.5 shadow-[0_18px_40px_-24px_#000] backdrop-blur-xl"
        >
          <span
            className={`pointer-events-none absolute inset-y-1.5 rounded-xl bg-gradient-to-b from-ink-750 to-ink-800 ring-1 ring-white/10 ${pill.ready ? "transition-[left,width] duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]" : "opacity-0"}`}
            style={{ left: pill.left, width: pill.width }}
            aria-hidden="true"
          />
          {chapters.map((chapter, index) => {
            const Icon = ICONS[chapter.id];
            const selected = index === active;
            return (
              <button
                key={chapter.id}
                ref={(el) => {
                  tabs.current[index] = el;
                }}
                type="button"
                role="tab"
                id={`onglet-${chapter.id}`}
                aria-selected={selected}
                aria-controls={`partie-${chapter.id}`}
                tabIndex={selected ? 0 : -1}
                onClick={() => open(index)}
                className={`ui-press relative z-10 flex min-w-max flex-1 items-center justify-center gap-1 rounded-xl px-2 py-2.5 text-sm font-semibold transition-colors sm:gap-2 sm:px-3 ${
                  selected ? "text-ink-50" : "text-ink-400 hover:text-ink-200"
                }`}
              >
                <Icon size={16} className={selected ? "text-claim" : ""} aria-hidden="true" />
                <span className="sm:hidden">{chapter.short}</span>
                <span className="hidden sm:inline">{chapter.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="relative mt-6" style={{ "--chapter-dir": direction } as CSSProperties}>
        {chapters.map((chapter, index) => (
          <div
            key={chapter.id}
            role="tabpanel"
            id={`partie-${chapter.id}`}
            aria-labelledby={`onglet-${chapter.id}`}
            hidden={index !== active}
            className="ui-chapter"
          >
            <p className="mb-6 text-center text-sm text-ink-400">{chapter.hint}</p>
            {chapter.content}
          </div>
        ))}
      </div>

      {/* Fil des parties : on avance sans remonter chercher les onglets. */}
      <div className="mx-auto mt-12 flex max-w-3xl items-center justify-between gap-3 border-t border-ink-800 pt-6">
        {previous ? (
          <button type="button" onClick={() => open(active - 1)} className="ui-press inline-flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold text-ink-300 transition hover:bg-ink-850 hover:text-ink-100">
            <ArrowLeft size={16} aria-hidden="true" /> {previous.label}
          </button>
        ) : (
          <span />
        )}
        <span className="flex gap-1.5" aria-hidden="true">
          {chapters.map((chapter, index) => (
            <span key={chapter.id} className={`h-1.5 rounded-full transition-all duration-500 ${index === active ? "w-6 bg-claim" : "w-1.5 bg-ink-600"}`} />
          ))}
        </span>
        {next ? (
          <button
            type="button"
            onClick={() => open(active + 1)}
            className="ui-press inline-flex items-center gap-2 rounded-xl border border-claim/40 bg-claim/10 px-4 py-2 text-sm font-semibold text-claim transition hover:bg-claim/15"
          >
            {next.label} <ArrowRight size={16} aria-hidden="true" />
          </button>
        ) : (
          <span />
        )}
      </div>
    </section>
  );
}
