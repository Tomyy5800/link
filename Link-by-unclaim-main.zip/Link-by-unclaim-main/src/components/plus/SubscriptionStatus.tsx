"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { CircleAlert, LoaderCircle } from "lucide-react";
import { celebrate } from "@/lib/confetti";

type State = { state: "pending" | "active" | "failed"; tier: string | null; until: string | null };

/**
 * Suit l'activation d'un abonnement après le paiement : le serveur relit la session chez Stripe
 * (elle doit appartenir au compte connecté). Rien n'est affiché comme réussi avant cette vérification.
 */
export function SubscriptionStatus({ sessionId, premiumName }: { sessionId: string; premiumName: string }) {
  const [data, setData] = useState<State | null>(null);
  const [tries, setTries] = useState(0);

  useEffect(() => {
    let stop = false;
    const load = async () => {
      const res = await fetch(`/api/me/checkout-session?session=${encodeURIComponent(sessionId)}`, { cache: "no-store" }).catch(() => null);
      if (stop) return;
      const json = res?.ok ? ((await res.json()) as State) : { state: "failed" as const, tier: null, until: null };
      setData(json);
      if (json.state === "pending") setTimeout(() => setTries((t) => t + 1), 2000);
      if (json.state === "active") celebrate();
    };
    if (tries < 30) void load();
    return () => {
      stop = true;
    };
  }, [sessionId, tries]);

  if (!data || data.state === "pending") {
    return (
      <div className="mt-8 space-y-2" role="status">
        <p className="inline-flex items-center gap-2 text-lg font-semibold">
          <LoaderCircle size={20} className="animate-spin text-brand-300" /> Confirmation de l&apos;abonnement…
        </p>
        <p className="text-sm text-ink-400">
          {tries >= 30 ? "La confirmation tarde : ton accès sera activé dès que Stripe nous l'aura confirmé, tu peux fermer cette page." : "Quelques secondes, on attend la confirmation de Stripe."}
        </p>
      </div>
    );
  }
  if (data.state === "failed") {
    return (
      <p className="mt-8 flex items-center gap-2 text-ink-300">
        <CircleAlert size={18} className="text-danger" /> Abonnement introuvable ou non abouti : rien n&apos;a été activé. Si tu as été débité·e, écris-nous.
      </p>
    );
  }
  const until = data.until ? new Date(data.until).toLocaleDateString("fr-FR", { dateStyle: "long", timeZone: "Europe/Paris" }) : null;
  return (
    <div className="mt-8 space-y-4">
      <h1 className="font-display text-3xl font-bold">Bienvenue dans {premiumName}</h1>
      <p className="text-ink-300">
        Ton abonnement est actif{until ? ` ; prochaine échéance autour du ${until}` : ""}. Tu peux le gérer ou le résilier à tout moment dans Mon espace › Offre.
      </p>
      <div className="flex flex-wrap justify-center gap-2">
        <Link href="/dashboard" className="inline-flex rounded-md bg-brand-500 px-5 py-2.5 font-semibold text-ink-950 transition-colors hover:bg-brand-400">
          Personnaliser ma page
        </Link>
        <Link href="/dashboard/abonnement" className="inline-flex rounded-md border border-ink-500 px-5 py-2.5 font-semibold text-ink-100 transition-colors hover:border-ink-300">
          Mon abonnement
        </Link>
      </div>
    </div>
  );
}
