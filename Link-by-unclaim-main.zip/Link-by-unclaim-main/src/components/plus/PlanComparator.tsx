"use client";

import { useRef, useState, type ReactNode } from "react";
import { Check, ChevronDown, Lock, Sparkles } from "lucide-react";

export type ComparatorTier = { name: string; tagline: string };
/** Fonction et rang de la première formule qui la contient (0 : ouverte à tous). */
export type ComparatorFeature = { key: string; label: string; description: string; rank: number };
/** Limite chiffrée, une valeur par formule (même ordre que les formules). */
export type ComparatorLimit = { label: string; values: number[]; display: string[] };

/**
 * « Ce qui est inclus », en un coup d'œil : on choisit une formule, les fonctions qu'elle
 * contient s'allument (celles qui viennent de se débloquer brillent un instant) et les jauges
 * des limites se remplissent. Le tableau complet reste à un clic pour les comparaisons fines.
 */
export function PlanComparator({
  tiers,
  features,
  limits,
  initial,
  table,
}: {
  tiers: ComparatorTier[];
  features: ComparatorFeature[];
  limits: ComparatorLimit[];
  initial: number;
  table: ReactNode;
}) {
  const [rank, setRank] = useState(initial);
  const [previousRank, setPreviousRank] = useState(initial);
  const [full, setFull] = useState(false);
  const switches = useRef(0);

  const choose = (next: number) => {
    if (next === rank) return;
    switches.current += 1;
    setPreviousRank(rank);
    setRank(next);
  };

  const included = features.filter((f) => f.rank <= rank).length;

  return (
    <div className="mx-auto max-w-5xl">
      <div className="flex flex-col items-center gap-4">
        <div role="radiogroup" aria-label="Formule à comparer" className="flex flex-wrap justify-center gap-2">
          {tiers.map((tier, index) => (
            <button
              key={tier.name}
              type="button"
              role="radio"
              aria-checked={index === rank}
              onClick={() => choose(index)}
              className={`ui-press rounded-full border px-4 py-2 text-sm font-semibold transition ${
                index === rank
                  ? index === 0
                    ? "border-ink-200 bg-ink-100 text-ink-950"
                    : "border-claim bg-claim text-ink-950 shadow-[0_0_24px_-4px_rgba(255,194,71,0.6)]"
                  : "border-ink-700 bg-ink-900/70 text-ink-300 hover:border-ink-500 hover:text-ink-100"
              }`}
            >
              {tier.name}
            </button>
          ))}
        </div>
        <p className="text-center text-sm text-ink-300" aria-live="polite">
          <span key={included} className="inline-block animate-pop font-display text-2xl font-bold text-ink-50 tabular-nums">
            {included}
          </span>{" "}
          fonction{included > 1 ? "s" : ""} sur {features.length} avec <span className="font-semibold text-ink-100">{tiers[rank]?.name}</span>
          <span className="block text-xs text-ink-500">{tiers[rank]?.tagline}</span>
        </p>
      </div>

      <ul className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {features.map((feature) => {
          const on = feature.rank <= rank;
          // Débloquée par ce dernier choix : un éclat, rejoué à chaque nouveau choix.
          const fresh = on && feature.rank > previousRank;
          return (
            <li
              key={fresh ? `${feature.key}-${switches.current}` : feature.key}
              data-spotlight={on ? "" : undefined}
              data-tone={on && feature.rank > 0 ? "claim" : undefined}
              className={`relative flex gap-3 rounded-xl border p-4 transition-[border-color,background-color,opacity] duration-500 ${on ? "ui-spotlight" : ""} ${
                on ? (feature.rank > 0 ? "border-claim/30 bg-claim/[0.06]" : "border-ink-700 bg-ink-900/90") : "border-ink-800 bg-ink-950/40 opacity-55"
              } ${fresh ? "ui-unlock" : ""}`}
            >
              <span
                className={`mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg transition-colors duration-500 ${
                  on ? (feature.rank > 0 ? "bg-claim text-ink-950" : "bg-mint/15 text-mint") : "bg-ink-850 text-ink-500"
                }`}
                aria-hidden="true"
              >
                {on ? fresh ? <Sparkles size={15} /> : <Check size={15} /> : <Lock size={13} />}
              </span>
              <span className="min-w-0">
                <span className={`block text-sm font-semibold ${on ? "text-ink-50" : "text-ink-300"}`}>{feature.label}</span>
                <span className="mt-0.5 block text-xs leading-relaxed text-ink-400">{feature.description}</span>
                {!on && <span className="mt-1.5 inline-block rounded-md bg-ink-850 px-1.5 py-0.5 text-[11px] font-semibold text-ink-300">Dès {tiers[feature.rank]?.name}</span>}
              </span>
              <span className="sr-only">{on ? "Inclus" : "Non inclus"}</span>
            </li>
          );
        })}
      </ul>

      <div className="mt-10 rounded-2xl border border-ink-700 bg-ink-900/80 p-5 sm:p-6">
        <p className="hud-label text-ink-400">Les limites de {tiers[rank]?.name}</p>
        <ul className="mt-4 grid gap-x-8 gap-y-4 sm:grid-cols-2">
          {limits.map((limit) => {
            const max = Math.max(...limit.values, 1);
            const value = limit.values[rank] ?? 0;
            return (
              <li key={limit.label}>
                <div className="flex items-baseline justify-between gap-3 text-sm">
                  <span className="text-ink-300">{limit.label}</span>
                  <span className="font-mono font-semibold text-ink-50 tabular-nums">{limit.display[rank]}</span>
                </div>
                <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-ink-800">
                  <div
                    className={`h-full rounded-full transition-[width] duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] ${rank === 0 ? "bg-ink-300" : "bg-gradient-to-r from-brand-400 to-claim"}`}
                    style={{ width: `${Math.max(value > 0 ? 4 : 0, (value / max) * 100)}%` }}
                  />
                </div>
              </li>
            );
          })}
        </ul>
      </div>

      <div className="mt-6 text-center">
        <button
          type="button"
          onClick={() => setFull((v) => !v)}
          aria-expanded={full}
          className="ui-press inline-flex items-center gap-2 rounded-xl border border-ink-600 px-4 py-2 text-sm font-semibold text-ink-200 transition hover:border-ink-400 hover:text-ink-50"
        >
          {full ? "Masquer le tableau complet" : "Voir le tableau complet"}
          <ChevronDown size={16} className={`transition-transform duration-300 ${full ? "rotate-180" : ""}`} aria-hidden="true" />
        </button>
      </div>
      {full && <div className="animate-rise mt-6">{table}</div>}
    </div>
  );
}
