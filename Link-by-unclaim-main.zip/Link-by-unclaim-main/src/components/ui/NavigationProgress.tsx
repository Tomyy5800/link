"use client";

import { useEffect, useRef, useState } from "react";
import { usePathname, useSearchParams } from "next/navigation";

/**
 * Fine barre en haut de l'écran pendant un changement de page : elle part au clic sur un lien
 * interne, avance doucement, et se remplit quand la nouvelle adresse est affichée.
 * Invisible pour les navigations instantanées (moins de 120 ms).
 */
export function NavigationProgress() {
  const pathname = usePathname();
  const search = useSearchParams();
  const [progress, setProgress] = useState<number | null>(null);
  const timers = useRef<{ show?: number; trickle?: number; hide?: number }>({});
  /** La barre est affichée (la navigation dure plus de 120 ms). */
  const shownRef = useRef(false);

  useEffect(() => {
    const clear = () => {
      window.clearTimeout(timers.current.show);
      window.clearInterval(timers.current.trickle);
      window.clearTimeout(timers.current.hide);
    };
    const start = () => {
      clear();
      timers.current.show = window.setTimeout(() => {
        shownRef.current = true;
        setProgress(0.12);
        timers.current.trickle = window.setInterval(() => setProgress((p) => (p === null ? p : p + (0.92 - p) * 0.08)), 180);
        // Filet de sécurité : une navigation qui n'aboutit jamais (téléchargement…) ne laisse pas la barre affichée.
        timers.current.hide = window.setTimeout(() => {
          window.clearInterval(timers.current.trickle);
          shownRef.current = false;
          setProgress(null);
        }, 12_000);
      }, 120);
    };
    const onClick = (event: MouseEvent) => {
      if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      const link = (event.target as Element | null)?.closest?.("a[href]") as HTMLAnchorElement | null;
      if (!link || link.target === "_blank" || link.hasAttribute("download")) return;
      const url = new URL(link.href, window.location.href);
      if (url.origin !== window.location.origin || url.pathname.startsWith("/api/")) return;
      if (url.pathname === window.location.pathname && url.search === window.location.search) return;
      start();
    };
    document.addEventListener("click", onClick, true);
    return () => {
      document.removeEventListener("click", onClick, true);
      clear();
    };
  }, []);

  // Nouvelle adresse affichée : la barre se remplit puis disparaît.
  useEffect(() => {
    window.clearTimeout(timers.current.show);
    window.clearInterval(timers.current.trickle);
    window.clearTimeout(timers.current.hide);
    if (!shownRef.current) return;
    shownRef.current = false;
    setProgress(1);
    timers.current.hide = window.setTimeout(() => setProgress(null), 380);
  }, [pathname, search]);

  return (
    <div
      className="ui-progress"
      style={{ transform: `scaleX(${progress ?? 0})`, opacity: progress === null || progress >= 1 ? 0 : 1 }}
      aria-hidden="true"
    />
  );
}
