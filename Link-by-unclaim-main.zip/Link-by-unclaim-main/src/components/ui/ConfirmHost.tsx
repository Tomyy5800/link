"use client";

import { useEffect, useRef, useState } from "react";
import { CircleHelp, TriangleAlert } from "lucide-react";
import { CONFIRM_EVENT, type ConfirmRequest } from "@/lib/confirm";

/** Affiche les demandes de confirmDialog() : fenêtre modale, Entrée pour confirmer, Échap pour annuler. */
export function ConfirmHost() {
  const [request, setRequest] = useState<ConfirmRequest | null>(null);
  const dialogRef = useRef<HTMLDialogElement>(null);
  const answered = useRef(false);

  useEffect(() => {
    const onRequest = (event: Event) => {
      event.preventDefault();
      answered.current = false;
      setRequest((event as CustomEvent<ConfirmRequest>).detail);
    };
    window.addEventListener(CONFIRM_EVENT, onRequest);
    return () => window.removeEventListener(CONFIRM_EVENT, onRequest);
  }, []);

  useEffect(() => {
    const dialog = dialogRef.current;
    if (request && dialog && !dialog.open) dialog.showModal();
  }, [request]);

  const answer = (ok: boolean) => {
    if (!request || answered.current) return;
    answered.current = true;
    request.resolve(ok);
    const dialog = dialogRef.current;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    // Fermeture en fondu (140 ms), puis la fenêtre est retirée.
    if (dialog?.open && !reduced) {
      dialog.setAttribute("data-closing", "");
      setTimeout(() => {
        dialog.removeAttribute("data-closing");
        dialog.close();
        setRequest(null);
      }, 140);
      return;
    }
    dialog?.close();
    setRequest(null);
  };

  const danger = request?.tone === "danger";
  const Icon = danger ? TriangleAlert : CircleHelp;

  return (
    <dialog
      ref={dialogRef}
      aria-label={request?.title}
      onClose={() => answer(false)}
      onClick={(event) => event.target === dialogRef.current && answer(false)}
      className="ui-dialog-host m-auto w-[min(92vw,420px)] rounded-2xl border border-ink-600 bg-ink-900 p-0 text-ink-100 shadow-2xl shadow-black/70 backdrop:bg-ink-950/70 backdrop:backdrop-blur-sm"
    >
      {request && (
        <div className="p-6">
          <div className="flex items-start gap-3">
            <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${danger ? "bg-danger/15 text-danger" : "bg-brand-500/15 text-brand-300"}`}>
              <Icon size={20} />
            </span>
            <div className="min-w-0">
              <p className="font-display text-lg font-bold">{request.title}</p>
              {request.message && <p className="mt-1 text-sm leading-relaxed text-ink-300">{request.message}</p>}
            </div>
          </div>
          <div className="mt-6 flex justify-end gap-2">
            <button
              type="button"
              autoFocus={danger}
              onClick={() => answer(false)}
              className="ui-press rounded-md border border-ink-600 px-4 py-2 text-sm font-semibold text-ink-200 transition hover:border-ink-400 hover:text-white"
            >
              {request.cancelLabel ?? "Annuler"}
            </button>
            <button
              type="button"
              autoFocus={!danger}
              onClick={() => answer(true)}
              className={`ui-press rounded-md px-4 py-2 text-sm font-semibold transition ${
                danger ? "bg-danger text-white hover:brightness-110" : "bg-brand-500 text-ink-950 hover:bg-brand-400"
              }`}
            >
              {request.confirmLabel ?? "Confirmer"}
            </button>
          </div>
        </div>
      )}
    </dialog>
  );
}
