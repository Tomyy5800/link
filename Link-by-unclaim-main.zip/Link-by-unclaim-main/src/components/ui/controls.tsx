"use client";

import { createContext, useContext, useId, useRef, useState, type ReactNode } from "react";
import { FileAudio, FileVideo, ImagePlus, LoaderCircle, X } from "lucide-react";
import { normalizeImageUrl } from "@/lib/urls";

// Contrôles de formulaire de l'éditeur.

/** Tailles maximales d'import, fournies par l'éditeur selon l'offre du compte. */
export const UploadLimits = createContext<{ imageMb: number; mediaMb: number }>({ imageMb: 2, mediaMb: 0 });

/** Envoie un fichier à /api/uploads et renvoie son adresse. */
async function uploadFile(file: File): Promise<string> {
  const form = new FormData();
  form.append("file", file);
  const res = await fetch("/api/uploads", { method: "POST", body: form });
  const json = (await res.json().catch(() => ({}))) as { url?: string; error?: string };
  if (!res.ok || !json.url) throw new Error(json.error ?? "Import impossible.");
  return json.url;
}

export function Field({
  label,
  hint,
  error,
  children,
  htmlFor,
  aside,
}: {
  label: string;
  hint?: ReactNode;
  error?: string | null;
  children: ReactNode;
  htmlFor?: string;
  aside?: ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-baseline justify-between gap-2">
        <label htmlFor={htmlFor} className="text-[0.8rem] font-medium text-ink-200">
          {label}
        </label>
        {aside}
      </div>
      {children}
      {error ? (
        <p className="text-xs text-danger" role="alert">
          {error}
        </p>
      ) : hint ? (
        <p className="text-xs leading-relaxed text-ink-400">{hint}</p>
      ) : null}
    </div>
  );
}

export function TextField({
  label,
  value,
  onChange,
  placeholder,
  hint,
  error,
  maxLength,
  type = "text",
  onBlur,
  inputMode,
  prefix,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  hint?: ReactNode;
  error?: string | null;
  maxLength?: number;
  type?: string;
  onBlur?: () => void;
  inputMode?: "text" | "url" | "email" | "numeric";
  prefix?: string;
}) {
  const id = useId();
  return (
    <Field
      label={label}
      hint={hint}
      error={error}
      htmlFor={id}
      aside={maxLength && value.length > maxLength * 0.8 ? <span className="text-[0.7rem] text-ink-400">{value.length}/{maxLength}</span> : null}
    >
      <div className="flex">
        {prefix && (
          <span className="flex items-center rounded-l-[10px] border border-r-0 border-ink-700 bg-ink-800 px-2.5 text-sm text-ink-400">
            {prefix}
          </span>
        )}
        <input
          id={id}
          type={type}
          inputMode={inputMode}
          className={`field ${prefix ? "rounded-l-none" : ""}`}
          value={value}
          placeholder={placeholder}
          maxLength={maxLength}
          aria-invalid={error ? true : undefined}
          onChange={(e) => onChange(e.target.value)}
          onBlur={onBlur}
          spellCheck={type === "text"}
        />
      </div>
    </Field>
  );
}

export function TextArea({
  label,
  value,
  onChange,
  placeholder,
  hint,
  maxLength,
  rows = 4,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  hint?: ReactNode;
  maxLength?: number;
  rows?: number;
}) {
  const id = useId();
  return (
    <Field
      label={label}
      hint={hint}
      htmlFor={id}
      aside={maxLength ? <span className="text-[0.7rem] text-ink-400">{value.length}/{maxLength}</span> : null}
    >
      <textarea
        id={id}
        className="field"
        rows={rows}
        value={value}
        placeholder={placeholder}
        maxLength={maxLength}
        onChange={(e) => onChange(e.target.value)}
      />
    </Field>
  );
}

export function Toggle({
  label,
  description,
  checked,
  onChange,
  disabled = false,
}: {
  label: string;
  description?: string;
  checked: boolean;
  onChange: (value: boolean) => void;
  /** Interrupteur visible mais non modifiable (droit manquant, valeur imposée). */
  disabled?: boolean;
}) {
  const id = useId();
  return (
    <div className={`flex items-center justify-between gap-4 ${disabled ? "opacity-60" : ""}`}>
      <label htmlFor={id} className={`min-w-0 ${disabled ? "cursor-not-allowed" : "cursor-pointer"}`}>
        <span className="block text-sm text-ink-100">{label}</span>
        {description && <span className="block text-xs text-ink-400">{description}</span>}
      </label>
      <button
        id={id}
        type="button"
        role="switch"
        aria-checked={checked}
        disabled={disabled}
        onClick={() => onChange(!checked)}
        className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors disabled:cursor-not-allowed ${
          checked ? "bg-brand-500" : "bg-ink-700 ring-1 ring-inset ring-ink-500"
        }`}
      >
        <span
          className={`inline-block h-5 w-5 rounded-full shadow transition-transform ${checked ? "translate-x-[22px] bg-ink-950" : "translate-x-0.5 bg-ink-300"}`}
        />
      </button>
    </div>
  );
}

export function Segmented<T extends string>({
  label,
  value,
  options,
  onChange,
}: {
  label?: string;
  value: T;
  options: { value: T; label: ReactNode; title?: string }[];
  onChange: (value: T) => void;
}) {
  const content = (
    <div role="radiogroup" aria-label={label} className="flex rounded-md border border-ink-700 bg-ink-900 p-0.5">
      {options.map((option) => (
        <button
          key={option.value}
          type="button"
          role="radio"
          aria-checked={value === option.value}
          title={option.title}
          onClick={() => onChange(option.value)}
          className={`flex min-h-8 flex-1 items-center justify-center gap-1.5 rounded-[4px] px-2 text-xs font-medium transition ${
            value === option.value ? "bg-ink-700 text-ink-100 shadow-sm" : "text-ink-400 hover:text-ink-200"
          }`}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
  if (!label) return content;
  return (
    <div className="space-y-1.5">
      <p className="text-[0.8rem] font-medium text-ink-200">{label}</p>
      {content}
    </div>
  );
}

export function Select<T extends string>({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: T;
  options: { value: T; label: string }[];
  onChange: (value: T) => void;
}) {
  const id = useId();
  return (
    <Field label={label} htmlFor={id}>
      <select id={id} className="field" value={value} onChange={(e) => onChange(e.target.value as T)}>
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </Field>
  );
}

export function ColorField({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  const id = useId();
  const [text, setText] = useState(value);
  const [prev, setPrev] = useState(value);
  if (prev !== value) {
    setPrev(value);
    setText(value);
  }
  return (
    <Field label={label} htmlFor={id}>
      <div className="flex items-center gap-2">
        <label className="relative h-9 w-9 shrink-0 cursor-pointer overflow-hidden rounded-md border border-ink-600" style={{ background: value }}>
          <input
            type="color"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
            aria-label={`${label} (sélecteur)`}
          />
        </label>
        <input
          id={id}
          className="field font-mono uppercase"
          value={text}
          maxLength={7}
          onChange={(e) => {
            const next = e.target.value.startsWith("#") ? e.target.value : `#${e.target.value}`;
            setText(next);
            if (/^#[0-9a-fA-F]{6}$/.test(next)) onChange(next.toLowerCase());
          }}
          onBlur={() => setText(value)}
        />
      </div>
    </Field>
  );
}

export function RangeField({
  label,
  value,
  min,
  max,
  step = 1,
  unit = "",
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  unit?: string;
  onChange: (value: number) => void;
}) {
  const id = useId();
  return (
    <Field label={label} htmlFor={id} aside={<span className="font-mono text-xs text-ink-400">{value}{unit}</span>}>
      <input id={id} type="range" className="w-full" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} />
    </Field>
  );
}

/** URL d'image + import de fichier (stocké par /api/uploads). */
export function ImageField({
  label,
  value,
  onChange,
  hint,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  hint?: ReactNode;
}) {
  const id = useId();
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { imageMb } = useContext(UploadLimits);
  const invalid = value !== "" && normalizeImageUrl(value) === null;

  async function upload(file: File) {
    setError(null);
    if (file.size > imageMb * 1024 * 1024) {
      setError(`Image trop lourde (${imageMb} Mo maximum).`);
      return;
    }
    setUploading(true);
    try {
      onChange(await uploadFile(file));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Import impossible.");
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  return (
    <Field label={label} htmlFor={id} hint={hint} error={error ?? (invalid ? "URL d'image invalide." : null)}>
      <div className="flex gap-2">
        {value && !invalid && (
          <img src={value} alt="" className="h-9 w-9 shrink-0 rounded-md border border-ink-700 object-cover" />
        )}
        <input
          id={id}
          className="field min-w-0"
          value={value}
          placeholder="https://… ou importe un fichier"
          inputMode="url"
          aria-invalid={invalid || undefined}
          onChange={(e) => onChange(e.target.value)}
        />
        {value ? (
          <button
            type="button"
            onClick={() => onChange("")}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md border border-ink-700 text-ink-300 transition hover:border-ink-500 hover:text-ink-100"
            aria-label="Retirer l'image"
          >
            <X size={16} />
          </button>
        ) : null}
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          disabled={uploading}
          className="flex h-9 shrink-0 items-center gap-1.5 rounded-md border border-ink-700 bg-ink-800 px-2.5 text-xs font-medium text-ink-200 transition hover:border-ink-500 disabled:opacity-60"
        >
          {uploading ? <LoaderCircle size={15} className="animate-spin" /> : <ImagePlus size={15} />}
          Importer
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="image/png,image/jpeg,image/gif,image/webp"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) void upload(file);
          }}
        />
      </div>
    </Field>
  );
}

/** Fichier audio ou vidéo importé sur la plateforme (aucun lien externe). */
export function MediaField({
  label,
  kind,
  value,
  onChange,
  hint,
}: {
  label: string;
  kind: "audio" | "video";
  value: string;
  onChange: (value: string) => void;
  hint?: ReactNode;
}) {
  const id = useId();
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { mediaMb } = useContext(UploadLimits);
  const Icon = kind === "audio" ? FileAudio : FileVideo;

  async function upload(file: File) {
    setError(null);
    if (file.size > mediaMb * 1024 * 1024) {
      setError(`Fichier trop lourd (${mediaMb} Mo maximum).`);
      return;
    }
    setUploading(true);
    try {
      onChange(await uploadFile(file));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Import impossible.");
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  return (
    <Field label={label} htmlFor={id} hint={hint ?? `${kind === "audio" ? "MP3, OGG, WAV ou M4A" : "MP4 ou WebM"}, ${mediaMb} Mo maximum.`} error={error}>
      <div className="flex items-center gap-2">
        <span className="flex h-9 min-w-0 flex-1 items-center gap-2 rounded-md border border-ink-700 bg-ink-900 px-2.5 text-sm text-ink-300">
          <Icon size={15} className="shrink-0" aria-hidden="true" />
          <span className="truncate">{value ? `Fichier importé (${value.split("/").pop()?.slice(-6)})` : "Aucun fichier"}</span>
        </span>
        {value && (
          <button
            type="button"
            onClick={() => onChange("")}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md border border-ink-700 text-ink-300 transition hover:border-ink-500 hover:text-ink-100"
            aria-label="Retirer le fichier"
          >
            <X size={16} />
          </button>
        )}
        <button
          id={id}
          type="button"
          onClick={() => fileRef.current?.click()}
          disabled={uploading || mediaMb <= 0}
          className="flex h-9 shrink-0 items-center gap-1.5 rounded-md border border-ink-700 bg-ink-800 px-2.5 text-xs font-medium text-ink-200 transition hover:border-ink-500 disabled:opacity-60"
        >
          {uploading ? <LoaderCircle size={15} className="animate-spin" /> : <Icon size={15} />}
          Importer
        </button>
        <input
          ref={fileRef}
          type="file"
          accept={kind === "audio" ? "audio/mpeg,audio/ogg,audio/wav,audio/mp4,.mp3,.ogg,.wav,.m4a" : "video/mp4,video/webm"}
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) void upload(file);
          }}
        />
      </div>
    </Field>
  );
}
