"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { CircleAlert, CircleCheck, Info, PartyPopper, X } from "lucide-react";
import { TOAST_EVENT, type ToastItem, type ToastTone } from "@/lib/toast";

const ICONS: Record<ToastTone, { icon: typeof Info; color: string; bar: string }> = {
  info: { icon: Info, color: "text-brand-300", bar: "bg-brand-500" },
  success: { icon: CircleCheck, color: "text-mint", bar: "bg-mint" },
  error: { icon: CircleAlert, color: "text-danger", bar: "bg-danger" },
  celebrate: { icon: PartyPopper, color: "text-claim", bar: "bg-claim" },
};

const MAX_VISIBLE = 4;

type Entry = ToastItem & { leaving?: boolean };

/** Pile de notifications (toast()) en bas de l'écran. */
export function Toaster() {
  const [items, setItems] = useState<Entry[]>([]);
  const timers = useRef(new Map<number, number>());

  const dismiss = useCallback((id: number) => {
    window.clearTimeout(timers.current.get(id));
    timers.current.delete(id);
    setItems((list) => list.map((t) => (t.id === id ? { ...t, leaving: true } : t)));
    window.setTimeout(() => setItems((list) => list.filter((t) => t.id !== id)), 240);
  }, []);

  const schedule = useCallback(
    (item: ToastItem) => {
      const duration = item.duration ?? (item.tone === "error" ? 5000 : 3200);
      timers.current.set(item.id, window.setTimeout(() => dismiss(item.id), duration));
    },
    [dismiss],
  );

  useEffect(() => {
    const onToast = (event: Event) => {
      const item = (event as CustomEvent<ToastItem>).detail;
      setItems((list) => {
        // Le même message deux fois de suite : on remplace plutôt que d'empiler.
        const rest = list.filter((t) => t.message !== item.message);
        return [...rest, item].slice(-MAX_VISIBLE);
      });
      schedule(item);
    };
    const map = timers.current;
    window.addEventListener(TOAST_EVENT, onToast);
    return () => {
      window.removeEventListener(TOAST_EVENT, onToast);
      map.forEach((timer) => window.clearTimeout(timer));
    };
  }, [schedule]);

  return (
    <div
      role="region"
      aria-label="Notifications"
      className="pointer-events-none fixed inset-x-0 bottom-20 z-[150] flex flex-col items-center gap-2 px-4 lg:bottom-6"
    >
      {items.map((item) => {
        const tone = ICONS[item.tone ?? "info"];
        const Icon = tone.icon;
        const duration = item.duration ?? (item.tone === "error" ? 5000 : 3200);
        return (
          <div
            key={item.id}
            role={item.tone === "error" ? "alert" : "status"}
            data-leaving={item.leaving ? "" : undefined}
            className="ui-toast pointer-events-auto relative flex w-full max-w-sm items-start gap-3 overflow-hidden rounded-xl border border-ink-600 bg-ink-850/95 py-3 pr-2 pl-3.5 text-sm text-ink-100 shadow-2xl shadow-black/60 backdrop-blur"
            onMouseEnter={() => window.clearTimeout(timers.current.get(item.id))}
            onMouseLeave={() => schedule({ ...item, duration: 1500 })}
          >
            <Icon size={18} className={`mt-px shrink-0 ${tone.color}`} aria-hidden="true" />
            <div className="min-w-0 flex-1">
              <p className="font-medium">{item.message}</p>
              {item.description && <p className="mt-0.5 text-xs text-ink-400">{item.description}</p>}
            </div>
            {item.action && (
              <button
                type="button"
                onClick={() => {
                  item.action?.onClick();
                  dismiss(item.id);
                }}
                className="ui-press shrink-0 rounded-md border border-ink-600 px-2 py-1 text-xs font-semibold text-ink-100 hover:border-ink-400"
              >
                {item.action.label}
              </button>
            )}
            <button
              type="button"
              onClick={() => dismiss(item.id)}
              className="shrink-0 rounded p-1 text-ink-500 transition hover:text-ink-100"
              aria-label="Fermer la notification"
            >
              <X size={14} />
            </button>
            <span
              className={`ui-toast-timer absolute bottom-0 left-0 h-0.5 w-full opacity-60 ${tone.bar}`}
              style={{ animationDuration: `${duration}ms` }}
              aria-hidden="true"
            />
          </div>
        );
      })}
    </div>
  );
}
