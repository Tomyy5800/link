"use client";

import { useState } from "react";
import { Check, Link2 } from "lucide-react";
import { toast } from "@/lib/toast";

/** Copie un texte (souvent l'adresse d'une page) : l'icône se change en coche, une notification confirme. */
export function CopyButton({
  value,
  label = "Copier le lien",
  done = "Lien copié",
  className = "",
  children,
}: {
  value: string;
  label?: string;
  done?: string;
  className?: string;
  children?: React.ReactNode;
}) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(value);
          setCopied(true);
          toast(done, { tone: "success", description: value });
          window.setTimeout(() => setCopied(false), 1800);
        } catch {
          toast("Copie impossible : sélectionne l'adresse à la main.", { tone: "error" });
        }
      }}
      className={`ui-press ${className}`}
      title={label}
      aria-label={label}
    >
      {copied ? <Check size={15} className="animate-pop text-mint" /> : <Link2 size={15} />}
      {children}
    </button>
  );
}
