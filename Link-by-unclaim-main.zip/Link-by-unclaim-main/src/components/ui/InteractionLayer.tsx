"use client";

import { useEffect } from "react";

/**
 * Une seule écoute du pointeur pour toute l'interface :
 * - [data-spotlight] reçoit --mx / --my (position du pointeur dans l'élément) pour son halo ;
 * - [data-tilt] reçoit --rx / --ry (inclinaison 3D, valeur maximale en degrés, 7 par défaut) ;
 * - .lbu-btn et [data-ripple] font une onde à l'appui.
 * Les boutons ne bougent jamais (pas d'effet aimanté) : seuls leurs couleurs et leurs halos changent.
 * Halo et inclinaison ignorent le tactile ; rien ne bouge si le visiteur a demandé moins d'animations.
 */
export function InteractionLayer() {
  useEffect(() => {
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)");
    let frame = 0;
    let pending: PointerEvent | null = null;
    let tilted: HTMLElement | null = null;

    const release = () => {
      if (!tilted) return;
      tilted.style.setProperty("--rx", "0deg");
      tilted.style.setProperty("--ry", "0deg");
      tilted.removeAttribute("data-tilting");
      tilted = null;
    };

    const apply = () => {
      frame = 0;
      const event = pending;
      pending = null;
      if (!event || !(event.target instanceof Element)) return;

      const spot = event.target.closest<HTMLElement>("[data-spotlight]");
      if (spot) {
        const rect = spot.getBoundingClientRect();
        spot.style.setProperty("--mx", `${event.clientX - rect.left}px`);
        spot.style.setProperty("--my", `${event.clientY - rect.top}px`);
      }

      const tilt = reduced.matches ? null : event.target.closest<HTMLElement>("[data-tilt]");
      if (tilt !== tilted) release();
      if (tilt) {
        const rect = tilt.getBoundingClientRect();
        const max = Number(tilt.dataset.tilt) || 7;
        const x = (event.clientX - rect.left) / rect.width - 0.5;
        const y = (event.clientY - rect.top) / rect.height - 0.5;
        tilt.style.setProperty("--rx", `${(-y * max).toFixed(2)}deg`);
        tilt.style.setProperty("--ry", `${(x * max).toFixed(2)}deg`);
        tilt.setAttribute("data-tilting", "");
        tilted = tilt;
      }
    };

    const onMove = (event: PointerEvent) => {
      if (event.pointerType === "touch") return;
      pending = event;
      if (!frame) frame = requestAnimationFrame(apply);
    };
    const onLeave = () => release();

    // Onde au toucher sur les boutons des pages publiques (et tout élément [data-ripple]).
    const onDown = (event: PointerEvent) => {
      if (reduced.matches || event.button !== 0 || !(event.target instanceof Element)) return;
      const host = event.target.closest<HTMLElement>(".lbu-btn, [data-ripple]");
      if (!host) return;
      const rect = host.getBoundingClientRect();
      const size = Math.max(rect.width, rect.height) * 2.2;
      const dot = document.createElement("span");
      dot.className = "ui-ripple";
      dot.setAttribute("aria-hidden", "true");
      Object.assign(dot.style, {
        width: `${size}px`,
        height: `${size}px`,
        left: `${event.clientX - rect.left - size / 2}px`,
        top: `${event.clientY - rect.top - size / 2}px`,
      });
      host.appendChild(dot);
      dot.addEventListener("animationend", () => dot.remove(), { once: true });
    };

    document.addEventListener("pointermove", onMove, { passive: true });
    document.addEventListener("pointerdown", onDown, { passive: true });
    document.documentElement.addEventListener("pointerleave", onLeave);
    return () => {
      document.removeEventListener("pointermove", onMove);
      document.removeEventListener("pointerdown", onDown);
      document.documentElement.removeEventListener("pointerleave", onLeave);
      if (frame) cancelAnimationFrame(frame);
    };
  }, []);
  return null;
}
