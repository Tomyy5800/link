"use client";

import { useEffect, useId, useMemo, useRef, useState, type ComponentType } from "react";
import { CornerDownLeft, Search } from "lucide-react";

export type Command = {
  id: string;
  label: string;
  group: string;
  /** Texte d'aide à droite (raccourci, adresse…). */
  hint?: string;
  icon?: ComponentType<{ size?: number; className?: string }>;
  /** Mots supplémentaires pour la recherche. */
  keywords?: string;
  run: () => void;
};

const OPEN_EVENT = "lbu:palette";

/** Ouvre la palette depuis n'importe quel bouton. */
export function openCommandPalette() {
  window.dispatchEvent(new Event(OPEN_EVENT));
}

const fold = (s: string) => s.normalize("NFD").replace(/\p{M}/gu, "").toLowerCase();

/** Palette de commandes (Ctrl+K ou ⌘K) : aller n'importe où, tout faire au clavier. */
export function CommandPalette({ commands, placeholder = "Que veux-tu faire ?" }: { commands: Command[]; placeholder?: string }) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [active, setActive] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLUListElement>(null);
  const restoreRef = useRef<HTMLElement | null>(null);
  const listId = useId();

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setOpen((o) => !o);
      }
    };
    const onOpen = () => setOpen(true);
    window.addEventListener("keydown", onKey);
    window.addEventListener(OPEN_EVENT, onOpen);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener(OPEN_EVENT, onOpen);
    };
  }, []);

  useEffect(() => {
    if (open) {
      restoreRef.current = document.activeElement as HTMLElement | null;
      setQuery("");
      setActive(0);
      requestAnimationFrame(() => inputRef.current?.focus());
    } else {
      restoreRef.current?.focus?.();
    }
  }, [open]);

  const results = useMemo(() => {
    const words = fold(query).split(/\s+/).filter(Boolean);
    if (!words.length) return commands;
    return commands.filter((c) => {
      const hay = fold(`${c.label} ${c.group} ${c.keywords ?? ""}`);
      return words.every((w) => hay.includes(w));
    });
  }, [commands, query]);

  useEffect(() => {
    listRef.current?.querySelector(`[data-index="${active}"]`)?.scrollIntoView({ block: "nearest" });
  }, [active]);

  if (!open) return null;

  function run(command: Command | undefined) {
    if (!command) return;
    setOpen(false);
    // Laisse la palette se fermer avant d'agir (navigation, focus d'un champ…).
    requestAnimationFrame(() => command.run());
  }

  let lastGroup = "";
  return (
    <div className="fixed inset-0 z-[100] flex items-start justify-center bg-ink-950/70 px-4 pt-[12vh] backdrop-blur-sm" onMouseDown={() => setOpen(false)}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Palette de commandes"
        className="w-full max-w-lg overflow-hidden rounded-xl border border-ink-600 bg-ink-900 shadow-2xl shadow-black/60 animate-rise"
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2 border-b border-ink-700 px-4">
          <Search size={16} className="shrink-0 text-ink-400" aria-hidden="true" />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setActive(0);
            }}
            onKeyDown={(e) => {
              if (e.key === "ArrowDown") {
                e.preventDefault();
                setActive((a) => Math.min(results.length - 1, a + 1));
              } else if (e.key === "ArrowUp") {
                e.preventDefault();
                setActive((a) => Math.max(0, a - 1));
              } else if (e.key === "Enter") {
                e.preventDefault();
                run(results[active]);
              } else if (e.key === "Escape") {
                e.preventDefault();
                setOpen(false);
              }
            }}
            placeholder={placeholder}
            className="h-12 min-w-0 flex-1 bg-transparent text-sm text-ink-100 outline-none placeholder:text-ink-500"
            role="combobox"
            aria-expanded="true"
            aria-controls={listId}
            aria-activedescendant={results[active] ? `${listId}-${results[active].id}` : undefined}
            autoComplete="off"
            spellCheck={false}
          />
          <kbd className="rounded border border-ink-600 px-1.5 font-mono text-[10px] text-ink-400">Échap</kbd>
        </div>
        <ul ref={listRef} id={listId} role="listbox" className="scrollbar-thin max-h-[50vh] overflow-y-auto py-1">
          {results.length === 0 && <li className="px-4 py-6 text-center text-sm text-ink-400">Aucune action ne correspond.</li>}
          {results.map((c, i) => {
            const header = c.group !== lastGroup ? c.group : null;
            lastGroup = c.group;
            const Icon = c.icon;
            return (
              <li key={c.id} role="presentation">
                {header && <p className="px-4 pt-2 pb-1 text-[10px] font-semibold tracking-[0.14em] text-ink-500 uppercase">{header}</p>}
                <button
                  type="button"
                  id={`${listId}-${c.id}`}
                  role="option"
                  aria-selected={i === active}
                  data-index={i}
                  onMouseMove={() => setActive(i)}
                  onClick={() => run(c)}
                  className={`flex w-full items-center gap-3 px-4 py-2 text-left text-sm transition ${i === active ? "bg-brand-500/15 text-white" : "text-ink-200"}`}
                >
                  {Icon && <Icon size={16} className={i === active ? "text-brand-300" : "text-ink-400"} />}
                  <span className="min-w-0 flex-1 truncate">{c.label}</span>
                  {c.hint && <span className="shrink-0 font-mono text-[11px] text-ink-500">{c.hint}</span>}
                  {i === active && <CornerDownLeft size={13} className="shrink-0 text-ink-400" aria-hidden="true" />}
                </button>
              </li>
            );
          })}
        </ul>
        <p className="border-t border-ink-800 px-4 py-2 text-[11px] text-ink-500">↑ ↓ pour choisir · Entrée pour valider · Ctrl+K pour ouvrir ou fermer</p>
      </div>
    </div>
  );
}

/** Bouton « Rechercher… ⌘K » pour les barres supérieures. */
export function PaletteButton({ className = "", compact = false }: { className?: string; compact?: boolean }) {
  return (
    <button
      type="button"
      onClick={openCommandPalette}
      className={`inline-flex h-8 items-center gap-2 rounded-lg border border-ink-700 px-2.5 text-xs text-ink-400 transition hover:border-ink-500 hover:text-ink-100 ${className}`}
      title="Palette de commandes (Ctrl+K)"
    >
      <Search size={14} aria-hidden="true" /> <span className={compact ? "hidden 2xl:inline" : "hidden md:inline"}>Rechercher…</span>
      <kbd className={`hidden rounded border border-ink-600 px-1 font-mono text-[10px] ${compact ? "xl:inline" : "md:inline"}`}>Ctrl K</kbd>
      <span className="sr-only">Palette de commandes</span>
    </button>
  );
}
