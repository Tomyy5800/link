import Link from "next/link";
import { useId } from "react";

/**
 * Symbole Link by Unclaim : deux chunks entrelacés — l'ambre « claim » pour Link,
 * le cyan « signal » pour Unclaim. Les masques créent le croisement dessus-dessous.
 * Source : charte/logos/link-mark.svg.
 */
export function LogoMark({ size = 28, tile = true }: { size?: number; tile?: boolean }) {
  const id = useId().replace(/:/g, "");
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden="true">
      <defs>
        <mask id={`${id}a`} maskUnits="userSpaceOnUse" x="0" y="0" width="64" height="64">
          <rect width="64" height="64" fill="#fff" />
          <rect x="21.5" y="31" width="9" height="14" fill="#000" />
        </mask>
        <mask id={`${id}b`} maskUnits="userSpaceOnUse" x="0" y="0" width="64" height="64">
          <rect width="64" height="64" fill="#fff" />
          <rect x="33.5" y="19" width="9" height="14" fill="#000" />
        </mask>
      </defs>
      {tile && (
        <>
          <rect width="64" height="64" rx="14" fill="#0f172b" />
          <rect x="0.75" y="0.75" width="62.5" height="62.5" rx="13.25" fill="none" stroke="#ffffff" strokeOpacity="0.12" strokeWidth="1.5" />
        </>
      )}
      <rect x="26" y="26" width="24" height="24" rx="3" fill="none" stroke="#22c9e8" strokeWidth="5" mask={`url(#${id}b)`} />
      <rect x="14" y="14" width="24" height="24" rx="3" fill="none" stroke="#ffc247" strokeWidth="5" mask={`url(#${id}a)`} />
    </svg>
  );
}

/** Logotype : « Link » en Chakra Petch 700, « by Unclaim » en JetBrains Mono. */
export function Logo({ href = "/", size = 30 }: { href?: string; size?: number }) {
  return (
    <Link href={href} className="group inline-flex items-center gap-2.5" aria-label="Link by Unclaim — accueil">
      <LogoMark size={size} />
      <span className="inline-flex items-baseline gap-2">
        <span className="font-display text-[1.2rem] leading-none font-bold tracking-tight text-ink-100">Link</span>
        <span className="font-mono text-[0.78rem] leading-none text-ink-400">by Unclaim</span>
      </span>
    </Link>
  );
}

/** Les cinq chunks du « + » de Link+ (coordonnées du symbole 64 × 64). */
const PLUS_CHUNKS = [
  [48.5, 4.5],
  [42.5, 10.5],
  [48.5, 10.5],
  [54.5, 10.5],
  [48.5, 16.5],
] as const;

/**
 * Symbole Link+ : le symbole Link et un « + » fait de cinq chunks revendiqués (ambre).
 * Source : charte/logos/link-plus-mark.svg.
 */
export function PlusMark({ size = 28, tile = true }: { size?: number; tile?: boolean }) {
  const id = useId().replace(/:/g, "");
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden="true">
      <defs>
        <mask id={`${id}a`} maskUnits="userSpaceOnUse" x="0" y="0" width="64" height="64">
          <rect width="64" height="64" fill="#fff" />
          <rect x="21.5" y="31" width="9" height="14" fill="#000" />
        </mask>
        <mask id={`${id}b`} maskUnits="userSpaceOnUse" x="0" y="0" width="64" height="64">
          <rect width="64" height="64" fill="#fff" />
          <rect x="33.5" y="19" width="9" height="14" fill="#000" />
        </mask>
      </defs>
      {tile && (
        <>
          <rect width="64" height="64" rx="14" fill="#0f172b" />
          <rect x="0.75" y="0.75" width="62.5" height="62.5" rx="13.25" fill="none" stroke="#ffc247" strokeOpacity="0.45" strokeWidth="1.5" />
        </>
      )}
      <rect x="26" y="26" width="24" height="24" rx="3" fill="none" stroke="#22c9e8" strokeWidth="5" mask={`url(#${id}b)`} />
      <rect x="14" y="14" width="24" height="24" rx="3" fill="none" stroke="#ffc247" strokeWidth="5" mask={`url(#${id}a)`} />
      <g fill="#ffc247">
        {PLUS_CHUNKS.map(([x, y]) => (
          <rect key={`${x}-${y}`} x={x} y={y} width="5" height="5" rx="1" />
        ))}
      </g>
    </svg>
  );
}

/** Logotype de l'offre payante : symbole Link+ et nom de l'offre (« Link+ » par défaut). */
export function PlusLogo({ size = 30, name = "Link+" }: { size?: number; name?: string }) {
  const plus = name.endsWith("+");
  return (
    <span className="inline-flex items-center gap-2.5" aria-label={name}>
      <PlusMark size={size} />
      <span className="font-display leading-none font-bold tracking-tight text-ink-100" style={{ fontSize: size * 0.68 }}>
        {plus ? name.slice(0, -1) : name}
        {plus && <span className="text-claim">+</span>}
      </span>
    </span>
  );
}
