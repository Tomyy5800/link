import type { ReactNode } from "react";
import { SiteFooter, SiteHeader } from "./SiteChrome";

/** Valeur saisie dans l'administration, ou repère bien visible tant qu'elle manque. */
export function Fill({ value, label }: { value: string; label: string }) {
  if (value.trim()) return <>{value}</>;
  return <mark className="rounded-sm bg-claim/20 px-1 text-claim">[{label} — à compléter dans l&apos;administration]</mark>;
}

export function LegalSection({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="mt-8">
      <h2 className="font-display text-xl font-bold text-ink-100">{title}</h2>
      <div className="mt-2 space-y-3 text-[0.95rem] leading-relaxed text-ink-300">{children}</div>
    </section>
  );
}

export function LegalPage({ title, updated, loggedIn, premiumName, children }: { title: string; updated: string; loggedIn: boolean; premiumName: string; children: ReactNode }) {
  return (
    <div className="bg-hud min-h-screen">
      <SiteHeader loggedIn={loggedIn} premiumName={premiumName} />
      <main className="mx-auto max-w-3xl px-4 pt-12 pb-20 sm:px-6">
        <p className="hud-label text-brand-300">Informations légales</p>
        <h1 className="mt-2 font-display text-4xl font-bold tracking-tight">{title}</h1>
        <p className="mt-2 text-sm text-ink-400">Dernière mise à jour : {updated}</p>
        {children}
      </main>
      <SiteFooter premiumName={premiumName} />
    </div>
  );
}
