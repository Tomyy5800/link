"use client";

import { useEffect, useLayoutEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { ArrowRight, Menu, X } from "lucide-react";
import { Logo } from "@/components/brand/Logo";

/** Sections de la page d'accueil, dans l'ordre de la page. */
const SECTIONS = [
  { id: "comment", label: "Comment ça marche", show: "lg:block" },
  { id: "fonctionnalites", label: "Fonctionnalités", show: "lg:block" },
  { id: "integrations", label: "Intégrations", show: "xl:block" },
  { id: "modeles", label: "Modèles", show: "lg:block" },
  { id: "questions", label: "Questions", show: "lg:block" },
] as const;

/** Section de l'accueil qui passe sous la ligne de lecture (40 % de la hauteur de l'écran). */
function sectionInView(): string | null {
  const line = window.innerHeight * 0.4;
  for (const { id } of SECTIONS) {
    const rect = document.getElementById(id)?.getBoundingClientRect();
    if (rect && rect.top <= line && rect.bottom > line) return id;
  }
  return null;
}

type Pill = { left: number; width: number; visible: boolean; snap: boolean };

/**
 * En-tête des pages vitrine (accueil, Link+, partenaires, pages légales). Il flotte au-dessus de
 * la page (sur l'accueil, le territoire 3D passe dessous) et sa hauteur ne change jamais (sinon la
 * page sauterait au défilement) : un îlot de verre discret, plus dense en descendant, avec la
 * progression de lecture. Une pastille glisse sous la rubrique survolée ou en
 * cours ; sur mobile, un menu plein écran.
 */
export function MarketingHeader({ premiumName, loggedIn }: { premiumName: string; loggedIn: boolean }) {
  const pathname = usePathname();
  const home = pathname === "/";
  const [scrolled, setScrolled] = useState(false);
  const [section, setSection] = useState<string | null>(null);
  const [hovered, setHovered] = useState<string | null>(null);
  const [menu, setMenu] = useState(false);
  const [pill, setPill] = useState<Pill>({ left: 0, width: 0, visible: false, snap: true });
  const links = useRef(new Map<string, HTMLElement>());

  const current = home ? section : pathname.startsWith("/plus") ? "plus" : pathname.startsWith("/partenaires") ? "partenaires" : null;
  const target = hovered ?? current;

  useEffect(() => {
    const onScroll = () => {
      const y = window.scrollY;
      // Deux seuils : pas de va-et-vient quand on s'arrête pile à la limite.
      setScrolled((was) => (was ? y > 4 : y > 24));
      if (home) setSection(sectionInView());
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, [home]);

  // Pastille : se pose sous la rubrique visée ; apparaît sur place, puis glisse d'une rubrique à l'autre.
  useLayoutEffect(() => {
    const measure = () => {
      const el = target ? links.current.get(target) : undefined;
      setPill((prev) => {
        if (!el || el.offsetWidth === 0) return { ...prev, visible: false };
        return { left: el.offsetLeft, width: el.offsetWidth, visible: true, snap: !prev.visible };
      });
    };
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, [target]);

  useEffect(() => {
    if (!menu) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => event.key === "Escape" && setMenu(false);
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener("keydown", onKey);
    };
  }, [menu]);

  const register = (key: string) => (el: HTMLElement | null) => {
    if (el) links.current.set(key, el);
    else links.current.delete(key);
  };
  const hover = (key: string) => ({ onPointerEnter: () => setHovered(key), onFocus: () => setHovered(key), onBlur: () => setHovered(null) });
  const linkClass = (key: string, show: string) =>
    `relative z-10 hidden rounded-lg px-3 py-1.5 transition-colors ${show} ${current === key ? "text-ink-50" : "text-ink-300 hover:text-ink-100"}`;
  const cta = loggedIn ? { href: "/dashboard", label: "Mon espace" } : { href: "/login", label: "Se connecter" };

  return (
    <>
      <header className="fixed inset-x-0 top-0 z-40 h-16 px-2 pt-2 sm:px-4">
        <div
          className={`relative mx-auto flex h-12 max-w-6xl items-center justify-between gap-3 rounded-2xl border pr-1.5 pl-3 transition-[background-color,border-color,box-shadow] duration-500 sm:pl-4 ${
            scrolled
              ? "border-white/10 bg-ink-950/80 shadow-[0_18px_40px_-22px_#000,inset_0_1px_0_rgba(255,255,255,0.05)] backdrop-blur-xl"
              : "border-white/[0.06] bg-ink-950/40 backdrop-blur-md"
          }`}
        >
          <Logo />
          <nav className="relative flex items-center gap-0.5 text-sm" aria-label="Navigation principale" onPointerLeave={() => setHovered(null)}>
            <span
              className={`pointer-events-none absolute inset-y-0 rounded-lg bg-white/[0.07] ring-1 ring-white/10 ${
                pill.snap ? "transition-opacity" : "transition-[left,width,opacity]"
              } duration-300 ease-[cubic-bezier(0.16,1,0.3,1)]`}
              style={{ left: pill.left, width: pill.width, opacity: pill.visible ? 1 : 0 }}
              aria-hidden="true"
            />
            {SECTIONS.map(({ id, label, show }) =>
              home ? (
                <a key={id} ref={register(id)} href={`#${id}`} aria-current={current === id ? "true" : undefined} className={linkClass(id, show)} {...hover(id)}>
                  {label}
                </a>
              ) : (
                <Link key={id} ref={register(id)} href={`/#${id}`} className={linkClass(id, show)} {...hover(id)}>
                  {label}
                </Link>
              ),
            )}
            <Link
              ref={register("partenaires")}
              href="/partenaires"
              aria-current={current === "partenaires" ? "page" : undefined}
              className={linkClass("partenaires", "lg:block")}
              {...hover("partenaires")}
            >
              Partenaires
            </Link>
            <Link
              ref={register("plus")}
              href="/plus"
              aria-current={current === "plus" ? "page" : undefined}
              className="relative z-10 hidden rounded-lg px-3 py-1.5 font-semibold text-claim transition hover:brightness-110 sm:block"
              {...hover("plus")}
            >
              {premiumName}
            </Link>
            <Link
              href={cta.href}
              className={`ui-press relative z-10 ml-1.5 hidden items-center rounded-xl border px-3.5 py-1.5 font-semibold transition-colors duration-300 sm:inline-flex ${
                scrolled ? "border-brand-400 bg-brand-500 text-ink-950 hover:bg-brand-400" : "border-ink-500 text-ink-100 hover:border-ink-300 hover:bg-ink-800"
              }`}
            >
              {cta.label}
            </Link>
            <button
              type="button"
              onClick={() => setMenu(true)}
              className="ui-press relative z-10 ml-1 flex h-9 w-9 items-center justify-center rounded-xl border border-ink-600 text-ink-100 lg:hidden"
              aria-label="Ouvrir le menu"
              aria-expanded={menu}
            >
              <Menu size={18} />
            </button>
          </nav>
          <span
            className={`ui-scroll-progress pointer-events-none absolute inset-x-5 -bottom-px h-px transition-opacity duration-500 ${scrolled ? "opacity-100" : "opacity-0"}`}
            aria-hidden="true"
          />
        </div>
      </header>
      {/* Hors accueil, la page commence sous l'en-tête ; l'accueil réserve lui-même cette place dans son héros. */}
      {!home && <div className="h-16" aria-hidden="true" />}
      {/* Hors de l'en-tête : son flou d'arrière-plan piégerait un élément « fixed ». */}
      {menu && (
        <div
          className="animate-fade fixed inset-0 z-50 flex flex-col bg-ink-950/97 px-6 pt-5 pb-8 backdrop-blur-xl lg:hidden"
          role="dialog"
          aria-modal="true"
          aria-label="Menu"
          onClick={(event) => (event.target as Element).closest("a") && setMenu(false)}
        >
          <div className="flex items-center justify-between">
            <Logo />
            <button type="button" onClick={() => setMenu(false)} className="ui-press flex h-10 w-10 items-center justify-center rounded-xl border border-ink-600" aria-label="Fermer le menu">
              <X size={18} />
            </button>
          </div>
          <nav className="ui-stagger mt-8 flex flex-col" aria-label="Menu mobile">
            {SECTIONS.map(({ id, label }) =>
              home ? (
                <a key={id} href={`#${id}`} className="border-b border-ink-800 py-3.5 font-display text-2xl font-semibold text-ink-100">
                  {label}
                </a>
              ) : (
                <Link key={id} href={`/#${id}`} className="border-b border-ink-800 py-3.5 font-display text-2xl font-semibold text-ink-100">
                  {label}
                </Link>
              ),
            )}
            <Link href="/partenaires" className="border-b border-ink-800 py-3.5 font-display text-2xl font-semibold text-ink-100">
              Partenaires
            </Link>
            <Link href="/plus" className="border-b border-ink-800 py-3.5 font-display text-2xl font-semibold text-claim">
              {premiumName}
            </Link>
          </nav>
          <Link
            href={cta.href}
            className="ui-press mt-auto inline-flex items-center justify-center gap-2 rounded-xl bg-brand-500 px-5 py-3.5 font-semibold text-ink-950"
          >
            {loggedIn ? "Ouvrir mon espace" : "Créer ma page gratuitement"} <ArrowRight size={18} />
          </Link>
        </div>
      )}
    </>
  );
}
