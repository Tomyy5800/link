"use client";

import { useEffect, useRef, useState } from "react";
import { confetti } from "@/lib/confetti";
import { validateSlug } from "@/lib/slug";
import { ClaimBox } from "@/components/landing/ClaimBox";

/**
 * Page introuvable sur une adresse de page (« /kaelis ») : l'adresse est peut-être libre, on
 * propose de la revendiquer tout de suite, déjà saisie. L'hôte est lu dans le navigateur : la
 * page 404 est figée au build, avant que l'adresse publique du site soit connue.
 */
export function NotFoundClaim() {
  const [slug, setSlug] = useState<string | null>(null);
  const [host, setHost] = useState("");
  useEffect(() => {
    setHost(window.location.host);
    // /mon-pseudo ou /profil/mon-pseudo : même adresse à revendiquer.
    const segment = decodeURIComponent(window.location.pathname.slice(1)).replace(/^profil\//, "");
    setSlug(!segment.includes("/") && validateSlug(segment, { allowShort: true }).ok ? segment.toLowerCase() : "");
  }, []);
  if (slug === null) return <div className="h-[104px]" aria-hidden="true" />;
  return (
    <div className="flex w-full justify-center">
      <ClaimBox host={host} loggedIn={false} size="md" initialValue={slug} />
    </div>
  );
}

const COLS = 9;
const ROWS = 4;
const STEPS = [5, 12, 20, COLS * ROWS];

/** Petit jeu d'attente : revendiquer des chunks d'un clic, avec une fête à chaque palier. */
export function ChunkGame() {
  const [claimed, setClaimed] = useState<Set<number>>(() => new Set([13, 14, 22]));
  // Copie toujours à jour : deux clics rapides ne se marchent pas dessus.
  const latest = useRef(claimed);
  const count = claimed.size;
  const next = STEPS.find((s) => s > count) ?? COLS * ROWS;

  return (
    <div className="w-full max-w-sm">
      <p className="hud-label text-ink-500">En attendant, agrandis ton territoire</p>
      <div className="mt-3 grid gap-1.5" style={{ gridTemplateColumns: `repeat(${COLS}, minmax(0, 1fr))` }}>
        {Array.from({ length: COLS * ROWS }, (_, i) => {
          const owned = claimed.has(i);
          return (
            <button
              key={i}
              type="button"
              aria-pressed={owned}
              aria-label={`Chunk ${i + 1}${owned ? ", revendiqué" : ""}`}
              onClick={(event) => {
                const nextSet = new Set(latest.current);
                const adding = !nextSet.has(i);
                if (adding) nextSet.add(i);
                else nextSet.delete(i);
                latest.current = nextSet;
                setClaimed(nextSet);
                if (adding && STEPS.includes(nextSet.size)) {
                  confetti({ origin: event.currentTarget, count: nextSet.size === COLS * ROWS ? 140 : 50, spread: 120, power: 0.9 });
                }
              }}
              className={`aspect-square rounded-[3px] transition duration-300 ${
                owned
                  ? "animate-pop bg-claim shadow-[0_0_14px_-2px_rgb(255_194_71/0.7)]"
                  : "border border-ink-600 hover:border-brand-400 hover:bg-brand-500/20"
              }`}
            />
          );
        })}
      </div>
      <p className="mt-3 text-xs text-ink-400" aria-live="polite">
        {count >= COLS * ROWS ? (
          <span className="font-semibold text-claim">Toute la carte est à toi. Impressionnant !</span>
        ) : (
          <>
            <span className="font-semibold text-claim tabular-nums">{count}</span> chunk{count > 1 ? "s" : ""} revendiqué{count > 1 ? "s" : ""} · prochain palier :{" "}
            {next}
          </>
        )}
      </p>
    </div>
  );
}
