"use client";

import { useEffect } from "react";
import Lenis from "lenis";
import "lenis/dist/lenis.css";
import { registerScroller } from "@/lib/scroll";

/**
 * Défilement amorti des pages vitrine (Lenis) : la molette glisse au lieu de sauter, les ancres
 * (« Voir un exemple », menu) arrivent en douceur sous l'en-tête. Les zones qui défilent toutes
 * seules (téléphone de démonstration, fenêtres) gardent leur défilement natif. Désactivé si le
 * visiteur a demandé moins d'animations ; le tactile reste natif.
 */
export function SmoothScroll() {
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const lenis = new Lenis({
      autoRaf: true,
      lerp: 0.11,
      smoothWheel: true,
      allowNestedScroll: true,
      // Le décalage sous l'en-tête vient du « scroll-margin-top » des sections (globals.css).
      anchors: true,
    });
    registerScroller(lenis);
    // Fenêtres modales ouvertes (galerie de modèles, menu) : on laisse la page tranquille.
    const observer = new MutationObserver(() => {
      if (document.querySelector("dialog[open]")) lenis.stop();
      else lenis.start();
    });
    observer.observe(document.body, { subtree: true, attributes: true, attributeFilter: ["open"] });
    return () => {
      observer.disconnect();
      registerScroller(null);
      lenis.destroy();
    };
  }, []);
  return null;
}
