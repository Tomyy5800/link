import { ViewTransition, type ReactNode } from "react";

/**
 * Fondu entre les pages vitrine (accueil, Link+, partenaires, connexion) : l'ancienne page
 * s'efface vers le haut, la nouvelle monte en douceur (classes « ui-page » de globals.css).
 * Seulement à l'entrée et à la sortie d'une page, jamais pendant qu'on l'utilise.
 */
export function PageTransition({ children }: { children: ReactNode }) {
  return (
    <ViewTransition enter="ui-page" exit="ui-page" default="none">
      {children}
    </ViewTransition>
  );
}
