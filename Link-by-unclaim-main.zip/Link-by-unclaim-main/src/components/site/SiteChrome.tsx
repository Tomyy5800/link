import Link from "next/link";
import { Logo } from "@/components/brand/Logo";
import { MarketingHeader } from "./MarketingHeader";

/** En-tête des pages vitrine (tarifs, partenaires, pages légales) : le même menu que l'accueil. */
export function SiteHeader({ loggedIn, premiumName = "Link+" }: { loggedIn: boolean; premiumName?: string }) {
  return <MarketingHeader loggedIn={loggedIn} premiumName={premiumName} />;
}

/** Pied de page commun : liens légaux obligatoires pour vendre en ligne. */
export function SiteFooter({ premiumName = "Link+" }: { premiumName?: string }) {
  return (
    <footer className="border-t border-white/10 bg-ink-950">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-4 py-8 text-sm text-ink-400 sm:flex-row sm:px-6">
        <Logo size={26} />
        <nav aria-label="Informations" className="flex flex-wrap justify-center gap-x-5 gap-y-2">
          <Link href="/plus" className="hover:text-ink-100">
            {premiumName}
          </Link>
          <Link href="/boutique" className="hover:text-ink-100">
            Boutique
          </Link>
          <Link href="/partenaires" className="hover:text-ink-100">
            Partenaires
          </Link>
          <Link href="/staff" className="hover:text-ink-100">
            Équipe
          </Link>
          <Link href="/cgu" className="hover:text-ink-100">
            CGU
          </Link>
          <Link href="/cgv" className="hover:text-ink-100">
            CGV
          </Link>
          <Link href="/mentions-legales" className="hover:text-ink-100">
            Mentions légales
          </Link>
          <Link href="/confidentialite" className="hover:text-ink-100">
            Confidentialité
          </Link>
        </nav>
        <p className="text-center sm:text-right">Projet indépendant, non affilié à Discord, NationsGlory, Google ni Microsoft.</p>
      </div>
    </footer>
  );
}
