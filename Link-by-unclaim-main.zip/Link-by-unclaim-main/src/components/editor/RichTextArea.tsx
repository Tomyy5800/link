"use client";

import { useEffect, useId, useMemo, useRef, useState, type ReactNode } from "react";
import { CalendarClock, Search, Smile, X } from "lucide-react";
import { TIMESTAMP_STYLES, TIMESTAMP_STYLE_LABELS, discordTimestampTag, formatDiscordTimestamp, type TimestampStyle } from "@/lib/discord-markup";
import { EMOJI_CATEGORIES } from "@/lib/emoji";
import { Field } from "@/components/ui/controls";

const toolBtn =
  "inline-flex h-7 items-center gap-1.5 rounded-md border border-ink-700 px-2 text-xs font-medium text-ink-300 transition hover:border-ink-500 hover:text-ink-100";

/** Valeur d'un champ datetime-local pour « maintenant + 1 h » (heure locale). */
function defaultLocal(): string {
  const d = new Date(Date.now() + 60 * 60 * 1000);
  d.setMinutes(0, 0, 0);
  return new Date(d.getTime() - d.getTimezoneOffset() * 60_000).toISOString().slice(0, 16);
}

/** Sélecteur d'émojis (codes Discord les plus courants) avec recherche. */
export function EmojiPicker({ onPick, onClose }: { onPick: (emoji: string) => void; onClose: () => void }) {
  const [category, setCategory] = useState(EMOJI_CATEGORIES[0].id);
  const [query, setQuery] = useState("");
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose();
    };
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  const list = useMemo(() => {
    const q = query.trim().toLowerCase().replace(/:/g, "");
    if (q) {
      const seen = new Set<string>();
      return EMOJI_CATEGORIES.flatMap((c) => c.emojis).filter(([name, e]) => name.includes(q) && !seen.has(e) && seen.add(e));
    }
    return EMOJI_CATEGORIES.find((c) => c.id === category)?.emojis ?? [];
  }, [category, query]);

  return (
    <div ref={ref} className="absolute left-0 z-40 mt-1 w-[min(320px,85vw)] rounded-md border border-ink-600 bg-ink-850 p-2 shadow-2xl shadow-black/50" role="dialog" aria-label="Émojis">
      <div className="relative">
        <Search size={13} className="pointer-events-none absolute top-1/2 left-2 -translate-y-1/2 text-ink-500" aria-hidden="true" />
        <input autoFocus className="field !h-8 !pl-7 text-xs" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Chercher (fire, heart, crown…)" />
      </div>
      {!query && (
        <div className="mt-2 flex gap-1 overflow-x-auto">
          {EMOJI_CATEGORIES.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => setCategory(c.id)}
              className={`shrink-0 rounded px-2 py-1 text-[11px] ${category === c.id ? "bg-ink-700 text-ink-100" : "text-ink-400 hover:text-ink-200"}`}
            >
              {c.label}
            </button>
          ))}
        </div>
      )}
      <div className="scrollbar-thin mt-2 grid max-h-48 grid-cols-8 gap-0.5 overflow-y-auto">
        {list.map(([name, emoji]) => (
          <button
            key={`${name}-${emoji}`}
            type="button"
            title={`:${name}:`}
            onClick={() => onPick(emoji)}
            className="flex h-8 items-center justify-center rounded text-lg hover:bg-ink-700"
          >
            {emoji}
          </button>
        ))}
        {list.length === 0 && <p className="col-span-8 py-3 text-center text-xs text-ink-400">Aucun émoji trouvé.</p>}
      </div>
      <p className="mt-2 border-t border-ink-700 pt-2 text-[11px] leading-relaxed text-ink-400">
        Émoji d&apos;un serveur Discord : dans Discord, tape <code className="text-ink-200">{"\\:nom:"}</code> puis colle ici le code obtenu (
        <code className="text-ink-200">&lt;:nom:123…&gt;</code>).
      </p>
    </div>
  );
}

/** Choix d'une date, insérée comme une date Discord affichée à l'heure de chaque visiteur. */
function DateInserter({ onInsert, onClose }: { onInsert: (tag: string) => void; onClose: () => void }) {
  const [value, setValue] = useState(defaultLocal);
  const [style, setStyle] = useState<TimestampStyle>("R");
  const date = new Date(value);
  const valid = !Number.isNaN(date.getTime());
  return (
    <div className="absolute left-0 z-40 mt-1 w-[min(320px,85vw)] space-y-2 rounded-md border border-ink-600 bg-ink-850 p-3 shadow-2xl shadow-black/50" role="dialog" aria-label="Date Discord">
      <div className="flex items-center justify-between">
        <p className="text-xs font-semibold text-ink-100">Date Discord</p>
        <button type="button" onClick={onClose} className="text-ink-400 hover:text-ink-100" aria-label="Fermer">
          <X size={14} />
        </button>
      </div>
      <input type="datetime-local" className="field !h-8 text-xs" value={value} onChange={(e) => setValue(e.target.value)} />
      <select className="field !h-8 text-xs" value={style} onChange={(e) => setStyle(e.target.value as TimestampStyle)}>
        {TIMESTAMP_STYLES.map((s) => (
          <option key={s} value={s}>
            {TIMESTAMP_STYLE_LABELS[s]}
          </option>
        ))}
      </select>
      {valid && (
        <p className="text-xs text-ink-300">
          Aperçu : <span className="rounded bg-ink-700 px-1 text-ink-100">{formatDiscordTimestamp(Math.floor(date.getTime() / 1000), style)}</span>
        </p>
      )}
      <button
        type="button"
        disabled={!valid}
        onClick={() => onInsert(discordTimestampTag(date, style))}
        className="w-full rounded-md bg-brand-500 px-3 py-1.5 text-xs font-semibold text-ink-950 transition hover:bg-brand-400 disabled:opacity-40"
      >
        Insérer
      </button>
      <p className="text-[11px] leading-relaxed text-ink-400">Chaque visiteur voit la date à son heure locale, comme sur Discord.</p>
    </div>
  );
}

/** Zone de texte avec mise en forme Discord : émojis et dates insérés là où se trouve le curseur. */
export function RichTextArea({
  label,
  value,
  onChange,
  placeholder,
  hint,
  maxLength,
  rows = 4,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  hint?: ReactNode;
  maxLength?: number;
  rows?: number;
}) {
  const id = useId();
  const ref = useRef<HTMLTextAreaElement>(null);
  const [open, setOpen] = useState<"emoji" | "date" | null>(null);

  function insert(text: string) {
    const el = ref.current;
    const start = el?.selectionStart ?? value.length;
    const end = el?.selectionEnd ?? value.length;
    const next = `${value.slice(0, start)}${text}${value.slice(end)}`;
    if (maxLength && next.length > maxLength) return;
    onChange(next);
    requestAnimationFrame(() => {
      el?.focus();
      el?.setSelectionRange(start + text.length, start + text.length);
    });
  }

  return (
    <Field
      label={label}
      hint={hint}
      htmlFor={id}
      aside={maxLength ? <span className="text-[0.7rem] text-ink-400">{value.length}/{maxLength}</span> : null}
    >
      <textarea id={id} ref={ref} className="field" rows={rows} value={value} placeholder={placeholder} maxLength={maxLength} onChange={(e) => onChange(e.target.value)} />
      <div className="relative flex gap-1.5">
        <button type="button" className={toolBtn} onClick={() => setOpen(open === "emoji" ? null : "emoji")} aria-expanded={open === "emoji"}>
          <Smile size={13} /> Émoji
        </button>
        <button type="button" className={toolBtn} onClick={() => setOpen(open === "date" ? null : "date")} aria-expanded={open === "date"}>
          <CalendarClock size={13} /> Date Discord
        </button>
        {open === "emoji" && (
          <EmojiPicker
            onPick={(emoji) => {
              insert(emoji);
            }}
            onClose={() => setOpen(null)}
          />
        )}
        {open === "date" && (
          <DateInserter
            onInsert={(tag) => {
              insert(tag);
              setOpen(null);
            }}
            onClose={() => setOpen(null)}
          />
        )}
      </div>
    </Field>
  );
}
