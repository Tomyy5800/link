"use client";

import { useState } from "react";
import { LoaderCircle, Palette } from "lucide-react";
import { confirmDialog } from "@/lib/confirm";
import { FeatureSection, useFeature } from "./EditorContext";

/** Kit de marque : le thème de cette page appliqué à toutes les autres pages du compte. */
export function BrandKitCard({ pageId, otherPages, saved }: { pageId: string; otherPages: number; saved: boolean }) {
  const feature = useFeature("brandKit");
  const [includeCss, setIncludeCss] = useState(false);
  const [status, setStatus] = useState<{ kind: "idle" | "busy" | "ok" | "error"; text?: string }>({ kind: "idle" });
  if (feature === "off" || otherPages === 0) return null;

  async function apply() {
    const ok = await confirmDialog({
      title: `Appliquer ce thème à ${otherPages} autre${otherPages > 1 ? "s" : ""} page${otherPages > 1 ? "s" : ""} ?`,
      message: "Leurs couleurs, polices et mise en page actuelles seront remplacées.",
      confirmLabel: "Appliquer",
    });
    if (!ok) return;
    setStatus({ kind: "busy" });
    const res = await fetch(`/api/me/pages/${pageId}/brand-kit`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ includeCss }),
    }).catch(() => null);
    const json = (await res?.json().catch(() => ({}))) as { count?: number; error?: string };
    setStatus(res?.ok ? { kind: "ok", text: `Thème appliqué à ${json.count ?? otherPages} page${(json.count ?? otherPages) > 1 ? "s" : ""}.` } : { kind: "error", text: json.error ?? "Échec, réessaie." });
  }

  return (
    <section className="mt-4 space-y-3 rounded-lg border border-ink-700 bg-ink-850/60 p-4" aria-label="Kit de marque">
      <h3 className="hud-label inline-flex items-center gap-1.5 text-ink-400">
        <Palette size={13} className="text-claim" aria-hidden="true" /> Kit de marque
      </h3>
      <FeatureSection feature="brandKit" title="Kit de marque">
        <div className="space-y-3">
          <p className="text-xs leading-relaxed text-ink-400">
            Toutes tes pages aux mêmes couleurs : le thème de celle-ci (couleurs, fond, cartes, polices, mise en page) est copié sur les autres. Leur contenu ne
            change pas.
          </p>
          <label className="flex items-center gap-2 text-sm text-ink-200">
            <input type="checkbox" checked={includeCss} onChange={(e) => setIncludeCss(e.target.checked)} className="h-4 w-4 accent-[#22c9e8]" /> Copier aussi le
            CSS personnalisé
          </label>
          <button
            type="button"
            onClick={apply}
            disabled={!saved || status.kind === "busy"}
            className="inline-flex items-center gap-2 rounded-md bg-claim px-3 py-2 text-sm font-semibold text-ink-950 transition hover:brightness-110 disabled:opacity-40"
            title={saved ? undefined : "Attends la fin de l'enregistrement"}
          >
            {status.kind === "busy" && <LoaderCircle size={14} className="animate-spin" />} Appliquer à mes {otherPages} autre{otherPages > 1 ? "s" : ""} page
            {otherPages > 1 ? "s" : ""}
          </button>
          {status.text && <p className={`text-xs ${status.kind === "error" ? "text-danger" : "text-mint"}`}>{status.text}</p>}
        </div>
      </FeatureSection>
    </section>
  );
}
