"use client";

import { createContext, useContext, type ReactNode } from "react";
import { Lock, Sparkles } from "lucide-react";
import { modeTier, type Entitlements, type FeatureKey } from "@/lib/features";
import { tierName } from "@/lib/plans";

/** Ce que l'éditeur sait du compte et de la plateforme (droits, état de l'API NationsGlory). */
export type EditorEnv = {
  /** Page en cours d'édition (routes /api/me/pages/:id). */
  pageId: string;
  entitlements: Entitlements;
  /** mock : données de démonstration · live : API réelle · off : clé absente. */
  ngMode: "mock" | "live" | "off";
  /** Pseudo et serveur NationsGlory du profil, valeurs par défaut des blocs. */
  ngUsername: string;
  ngServer: string;
  /** Ouvre l'onglet Réglages sur la carte Link+. */
  openPlus: () => void;
  /** Cadres d'avatar débloqués par le propriétaire (boutique officielle). */
  frames?: string[];
};

const Ctx = createContext<EditorEnv | null>(null);

export function EditorEnvProvider({ value, children }: { value: EditorEnv; children: ReactNode }) {
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useEditorEnv(): EditorEnv {
  const env = useContext(Ctx);
  if (!env) throw new Error("useEditorEnv hors de l'éditeur");
  return env;
}

/** on : utilisable · locked : réservé à l'offre payante · off : désactivé par l'administration. */
export type FeatureState = "on" | "locked" | "off";

export function useFeature(key: FeatureKey): FeatureState {
  const { entitlements } = useEditorEnv();
  if (entitlements.features[key]) return "on";
  return entitlements.modes[key] === "off" ? "off" : "locked";
}

/** Formule qui débloque une fonctionnalité (« Link+ », « Link+ Pro »…). */
export function useRequiredTierName(feature?: FeatureKey): string {
  const { entitlements } = useEditorEnv();
  const needed = feature ? modeTier(entitlements.modes[feature]) : null;
  return tierName(needed ?? "plus", entitlements.premiumName);
}

/** Petite étiquette « Link+ » (ou « Link+ Pro »…) posée à côté d'un réglage réservé. */
export function PlusBadge({ className = "", feature }: { className?: string; feature?: FeatureKey }) {
  const name = useRequiredTierName(feature);
  return (
    <span className={`inline-flex items-center gap-1 rounded-sm border border-claim/40 bg-claim/10 px-1.5 py-px font-mono text-[10px] font-semibold tracking-wide text-claim ${className}`}>
      <Sparkles size={10} aria-hidden="true" /> {name}
    </span>
  );
}

/**
 * Enveloppe une section soumise à une fonctionnalité :
 * disponible → contenu normal ; réservée → contenu grisé et appel à Link+ ; désactivée → rien.
 */
export function FeatureSection({ feature, title, children }: { feature: FeatureKey; title?: string; children: ReactNode }) {
  const state = useFeature(feature);
  const { openPlus } = useEditorEnv();
  const needed = useRequiredTierName(feature);
  if (state === "off") return null;
  if (state === "on") return <>{children}</>;
  return (
    <div className="relative">
      <div className="pointer-events-none select-none opacity-40" aria-hidden="true" inert>
        {children}
      </div>
      <div className="absolute inset-0 flex items-center justify-center p-3">
        <button
          type="button"
          onClick={openPlus}
          className="flex max-w-xs flex-col items-center gap-1.5 rounded-md border border-claim/40 bg-ink-950/90 px-4 py-3 text-center shadow-xl shadow-black/40 backdrop-blur transition hover:border-claim"
        >
          <span className="inline-flex items-center gap-1.5 text-sm font-semibold text-ink-100">
            <Lock size={14} className="text-claim" aria-hidden="true" /> {title ?? "Fonction réservée"}
          </span>
          <span className="text-xs text-ink-300">Disponible avec {needed}. Voir les formules →</span>
        </button>
      </div>
    </div>
  );
}
