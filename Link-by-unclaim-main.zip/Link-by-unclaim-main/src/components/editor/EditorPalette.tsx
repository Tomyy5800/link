"use client";

import { useMemo } from "react";
import { useRouter } from "next/navigation";
import { Copy, ExternalLink, LayoutDashboard, LayoutGrid, Monitor, Palette, Pencil, Plus, Redo2, Settings, Smartphone, Undo2, UserRound, Zap } from "lucide-react";
import { BLOCK_META, BLOCK_TYPES, type BlockType } from "@/lib/blocks";
import { CommandPalette, type Command } from "@/components/ui/CommandPalette";
import { BLOCK_ICONS } from "./BlocksPanel";

type Tab = "blocs" | "profil" | "apparence" | "reglages";

type Props = {
  slug: string;
  appUrl: string;
  pageId: string;
  pages: { id: string; name: string; slug: string; role: string }[];
  /** Types de blocs proposés (ceux que l'administration n'a pas coupés). */
  blockTypes: BlockType[];
  onTab: (tab: Tab) => void;
  onAddBlock: (type: BlockType) => void;
  onUndo: () => void;
  onRedo: () => void;
  onDevice: (device: "mobile" | "desktop") => void;
  onCopyLink: () => void;
  onAutomations: () => void;
};

/** Palette de commandes de l'éditeur (Ctrl+K) : tout l'éditeur au clavier. */
export function EditorPalette(props: Props) {
  const router = useRouter();
  const { slug, pageId, pages, blockTypes } = props;
  const commands = useMemo<Command[]>(
    () => [
      ...blockTypes.map((type) => ({
        id: `add-${type}`,
        group: "Ajouter un bloc",
        label: BLOCK_META[type].label,
        hint: BLOCK_META[type].category,
        icon: BLOCK_ICONS[type],
        keywords: `ajouter nouveau ${BLOCK_META[type].description}`,
        run: () => props.onAddBlock(type),
      })),
      { id: "tab-blocs", group: "Onglets", label: "Blocs", icon: LayoutGrid, run: () => props.onTab("blocs") },
      { id: "tab-profil", group: "Onglets", label: "Profil", icon: UserRound, keywords: "nom bio avatar", run: () => props.onTab("profil") },
      { id: "tab-apparence", group: "Onglets", label: "Apparence", icon: Palette, keywords: "theme couleurs police fond", run: () => props.onTab("apparence") },
      { id: "tab-reglages", group: "Onglets", label: "Réglages", icon: Settings, keywords: "adresse visibilite seo qr", run: () => props.onTab("reglages") },
      { id: "automations", group: "Onglets", label: "Automatisations", icon: Zap, keywords: "regles live anniversaire bandeau", run: props.onAutomations },
      { id: "undo", group: "Actions", label: "Annuler", icon: Undo2, hint: "Ctrl+Z", run: props.onUndo },
      { id: "redo", group: "Actions", label: "Rétablir", icon: Redo2, hint: "Ctrl+Maj+Z", run: props.onRedo },
      { id: "copy", group: "Actions", label: "Copier le lien de la page", icon: Copy, keywords: "partager", run: props.onCopyLink },
      { id: "view", group: "Actions", label: "Voir ma page publique", icon: ExternalLink, hint: `/${slug}`, run: () => window.open(`/${slug}`, "_blank") },
      { id: "mobile", group: "Aperçu", label: "Aperçu mobile", icon: Smartphone, run: () => props.onDevice("mobile") },
      { id: "desktop", group: "Aperçu", label: "Aperçu ordinateur", icon: Monitor, run: () => props.onDevice("desktop") },
      ...pages
        .filter((p) => p.id !== pageId && p.role !== "viewer")
        .map((p) => ({ id: `page-${p.id}`, group: "Mes pages", label: `Modifier ${p.name}`, hint: `/${p.slug}`, icon: Pencil, run: () => router.push(`/dashboard/pages/${p.id}`) })),
      { id: "new", group: "Mes pages", label: "Nouvelle page", icon: Plus, run: () => router.push("/dashboard/nouvelle") },
      { id: "space", group: "Mes pages", label: "Mon espace", icon: LayoutDashboard, run: () => router.push("/dashboard") },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [slug, pageId, pages, blockTypes, router],
  );
  return <CommandPalette commands={commands} placeholder="Ajouter un bloc, changer d'onglet, aller à…" />;
}

export function availableBlockTypes(presenceOff: boolean): BlockType[] {
  return BLOCK_TYPES.filter((t) => !(t === "discordPresence" && presenceOff));
}
