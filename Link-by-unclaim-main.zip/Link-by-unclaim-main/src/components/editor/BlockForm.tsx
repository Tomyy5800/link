"use client";

import { AlignCenter, AlignLeft, AlignRight, Plus, Trash } from "lucide-react";
import type { Block, BlockData } from "@/lib/blocks";
import {
  PLATFORMS,
  PLATFORM_KEYS,
  detectPlatform,
  isValidMcUsername,
  normalizeUrl,
  parseDiscordInvite,
  type Platform,
} from "@/lib/urls";
import { SocialIcon } from "@/components/icons/SocialIcon";
import { ImageField, RangeField, Segmented, Select, TextArea, TextField, Toggle } from "@/components/ui/controls";
import { useEditorEnv } from "./EditorContext";
import { EmbedForm } from "./EmbedForm";
import { ContactForm, GameForm } from "./GameContactForms";
import { CollectionForm, CountdownForm, EmojiField, EventsForm, MusicForm, RadioForm } from "./MoreForms";
import { BadgesForm, CopyForm, FaqForm, GalleryForm, PresenceForm } from "./NewBlockForms";
import { RichTextArea } from "./RichTextArea";
import { ShopForm } from "./ShopForm";

/** Boutiques personnelles fermées par l'administration : la boutique est gardée mais invisible. */
function ShopPausedNotice() {
  const { entitlements } = useEditorEnv();
  if (entitlements.personalShops) return null;
  return (
    <p className="mb-3 rounded-md border border-claim/40 bg-claim/10 px-3 py-2 text-xs leading-relaxed text-ink-100">
      Les boutiques personnelles sont fermées pour l&apos;instant par l&apos;équipe Unclaim : ta boutique est conservée, mais elle n&apos;est pas visible sur ta page
      et aucune commande n&apos;est acceptée. Elle réapparaîtra telle quelle à leur ouverture.
    </p>
  );
}
import { NationsGloryForm, NgCountryForm } from "./NgForms";

type Setter<T> = (patch: Partial<T>) => void;

const ALIGN_OPTIONS = [
  { value: "left" as const, label: <AlignLeft size={15} />, title: "Aligner à gauche" },
  { value: "center" as const, label: <AlignCenter size={15} />, title: "Centrer" },
  { value: "right" as const, label: <AlignRight size={15} />, title: "Aligner à droite" },
];

function urlError(value: string): string | null {
  return value && normalizeUrl(value) === null ? "Adresse invalide (http, https ou mailto)." : null;
}

/** Après saisie, complète « exemple.fr » en « https://exemple.fr ». */
function completeUrl(value: string, set: (v: string) => void) {
  const normalized = normalizeUrl(value);
  if (normalized && normalized !== value) set(normalized);
}

export const FORMAT_HINT = (
  <>
    Mise en forme Discord : <code className="text-ink-200">**gras**</code> <code className="text-ink-200">*italique*</code>{" "}
    <code className="text-ink-200">__souligné__</code> <code className="text-ink-200">||spoiler||</code>{" "}
    <code className="text-ink-200">[lien](url)</code> <code className="text-ink-200"># titre</code>{" "}
    <code className="text-ink-200">-# petit texte</code> <code className="text-ink-200">&gt; citation</code>{" "}
    <code className="text-ink-200">:fire:</code> <code className="text-ink-200">&lt;t:…:R&gt;</code>
  </>
);

export function BlockForm({ block, onChange }: { block: Block; onChange: (block: Block) => void }) {
  const set = (patch: object) => onChange({ ...block, data: { ...block.data, ...patch } } as Block);

  switch (block.type) {
    case "heading":
      return <HeadingForm data={block.data} set={set} />;
    case "text":
      return <TextForm data={block.data} set={set} />;
    case "link":
      return <LinkForm data={block.data} set={set} />;
    case "socials":
      return <SocialsForm data={block.data} set={set} />;
    case "image":
      return <ImageForm data={block.data} set={set} />;
    case "discord":
      return <DiscordForm data={block.data} set={set} />;
    case "discordServer":
      return <DiscordServerForm data={block.data} set={set} />;
    case "nationsglory":
      return <NationsGloryForm data={block.data} set={set} />;
    case "skin":
      return <SkinForm data={block.data} set={set} />;
    case "embed":
      return <EmbedForm data={block.data} set={set} />;
    case "countdown":
      return <CountdownForm data={block.data} set={set} />;
    case "gallery":
      return <GalleryForm data={block.data} set={set} />;
    case "faq":
      return <FaqForm data={block.data} set={set} />;
    case "badges":
      return <BadgesForm data={block.data} set={set} />;
    case "copy":
      return <CopyForm data={block.data} set={set} />;
    case "ngCountry":
      return <NgCountryForm data={block.data} set={set} />;
    case "discordPresence":
      return <PresenceForm data={block.data} set={set} />;
    case "radio":
      return <RadioForm data={block.data} set={set} />;
    case "music":
      return <MusicForm data={block.data} set={set} />;
    case "events":
      return <EventsForm data={block.data} set={set} />;
    case "collection":
      return <CollectionForm data={block.data} set={set} />;
    case "game":
      return <GameForm data={block.data} set={set} />;
    case "contact":
      return <ContactForm data={block.data} set={set} />;
    case "shop":
      return (
        <>
          <ShopPausedNotice />
          <ShopForm data={block.data} set={set} />
        </>
      );
    case "divider":
      return (
        <Segmented
          label="Style"
          value={block.data.style}
          onChange={(style) => set({ style })}
          options={[
            { value: "line", label: "Ligne" },
            { value: "dots", label: "Points" },
            { value: "space", label: "Espace" },
          ]}
        />
      );
  }
}

function HeadingForm({ data, set }: { data: BlockData<"heading">; set: Setter<BlockData<"heading">> }) {
  return (
    <div className="space-y-4">
      <TextField label="Titre" value={data.text} maxLength={120} onChange={(text) => set({ text })} placeholder="Mes projets" />
      <div className="grid grid-cols-2 gap-3">
        <Segmented
          label="Taille"
          value={data.size}
          onChange={(size) => set({ size })}
          options={[
            { value: "sm", label: "S" },
            { value: "md", label: "M" },
            { value: "lg", label: "L" },
          ]}
        />
        <Segmented label="Alignement" value={data.align} onChange={(align) => set({ align })} options={ALIGN_OPTIONS} />
      </div>
    </div>
  );
}

function TextForm({ data, set }: { data: BlockData<"text">; set: Setter<BlockData<"text">> }) {
  return (
    <div className="space-y-4">
      <RichTextArea label="Texte" value={data.text} maxLength={2000} rows={6} onChange={(text) => set({ text })} hint={FORMAT_HINT} />
      <Segmented label="Alignement" value={data.align} onChange={(align) => set({ align })} options={ALIGN_OPTIONS} />
    </div>
  );
}

function LinkForm({ data, set }: { data: BlockData<"link">; set: Setter<BlockData<"link">> }) {
  const detected = detectPlatform(data.url);
  return (
    <div className="space-y-4">
      <TextField label="Texte du bouton" value={data.label} maxLength={80} onChange={(label) => set({ label })} placeholder="Ma chaîne YouTube" />
      <TextField
        label="Adresse"
        value={data.url}
        inputMode="url"
        onChange={(url) => set({ url })}
        onBlur={() => completeUrl(data.url, (url) => set({ url }))}
        placeholder="https://…"
        error={urlError(data.url)}
      />
      <TextField label="Sous-titre (optionnel)" value={data.description} maxLength={140} onChange={(description) => set({ description })} />
      <Select
        label="Icône"
        value={data.icon}
        onChange={(icon) => set({ icon })}
        options={[
          { value: "auto", label: `Automatique (${PLATFORMS[detected].label})` },
          { value: "none", label: "Aucune" },
          ...PLATFORM_KEYS.map((key) => ({ value: key, label: PLATFORMS[key].label })),
        ]}
      />
      <div className="grid grid-cols-[auto_1fr] items-end gap-3">
        <EmojiField value={data.emoji} onChange={(emoji) => set({ emoji })} />
        <p className="pb-2 text-xs text-ink-400">Remplace l&apos;icône devant le texte.</p>
      </div>
      <ImageField label="Vignette (facultative)" value={data.thumbnail} onChange={(thumbnail) => set({ thumbnail })} />
      {data.thumbnail && (
        <Segmented
          label="Disposition"
          value={data.layout}
          onChange={(layout) => set({ layout })}
          options={[
            { value: "classic", label: "Vignette à gauche" },
            { value: "featured", label: "Grande image" },
          ]}
        />
      )}
      <Select
        label="Animation"
        value={data.animation}
        onChange={(animation) => set({ animation })}
        options={[
          { value: "none", label: "Aucune" },
          { value: "pulse", label: "Pulsation" },
          { value: "buzz", label: "Vibration" },
          { value: "wobble", label: "Balancement" },
          { value: "shine", label: "Reflet" },
        ]}
      />
      <Toggle label="Mettre en avant" description="Un halo animé attire l'œil sur ce lien." checked={data.highlight} onChange={(highlight) => set({ highlight })} />
      <Toggle
        label="Contenu sensible"
        description="Le visiteur confirme avant d'ouvrir le lien (contenu réservé à un public averti)."
        checked={data.sensitive}
        onChange={(sensitive) => set({ sensitive })}
      />
    </div>
  );
}

function SocialsForm({ data, set }: { data: BlockData<"socials">; set: Setter<BlockData<"socials">> }) {
  const items = data.items;
  const update = (index: number, patch: Partial<{ platform: Platform; url: string }>) =>
    set({ items: items.map((item, i) => (i === index ? { ...item, ...patch } : item)) });

  return (
    <div className="space-y-4">
      <ul className="space-y-2">
        {items.map((item, index) => (
          <li key={index} className="flex items-start gap-2">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md border border-ink-700 bg-ink-800 text-ink-200">
              <SocialIcon platform={item.platform} size={16} />
            </div>
            <select
              className="field !w-[8.5rem] shrink-0"
              value={item.platform}
              aria-label="Plateforme"
              onChange={(e) => update(index, { platform: e.target.value as Platform })}
            >
              {PLATFORM_KEYS.map((key) => (
                <option key={key} value={key}>
                  {PLATFORMS[key].label}
                </option>
              ))}
            </select>
            <div className="min-w-0 flex-1">
              <input
                className="field"
                value={item.url}
                inputMode="url"
                placeholder="https://…"
                aria-label={`Adresse ${PLATFORMS[item.platform].label}`}
                aria-invalid={urlError(item.url) ? true : undefined}
                onChange={(e) => {
                  const url = e.target.value;
                  const guess = detectPlatform(url);
                  update(index, guess !== "website" ? { url, platform: guess } : { url });
                }}
                onBlur={() => completeUrl(item.url, (url) => update(index, { url }))}
              />
            </div>
            <button
              type="button"
              onClick={() => set({ items: items.filter((_, i) => i !== index) })}
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md text-ink-400 transition hover:bg-ink-800 hover:text-danger"
              aria-label="Retirer ce réseau"
            >
              <Trash size={15} />
            </button>
          </li>
        ))}
      </ul>
      {items.length < 16 && (
        <button
          type="button"
          onClick={() => set({ items: [...items, { platform: "website", url: "" }] })}
          className="flex w-full items-center justify-center gap-1.5 rounded-md border border-dashed border-ink-600 py-2 text-sm text-ink-300 transition hover:border-ink-400 hover:text-ink-100"
        >
          <Plus size={15} /> Ajouter un réseau
        </button>
      )}
      <Segmented
        label="Affichage"
        value={data.style}
        onChange={(style) => set({ style })}
        options={[
          { value: "icons", label: "Icônes" },
          { value: "pills", label: "Étiquettes" },
        ]}
      />
    </div>
  );
}

function ImageForm({ data, set }: { data: BlockData<"image">; set: Setter<BlockData<"image">> }) {
  return (
    <div className="space-y-4">
      <ImageField label="Image" value={data.url} onChange={(url) => set({ url })} hint="PNG, JPEG, GIF ou WebP, 2 Mo maximum." />
      <TextField label="Description (accessibilité)" value={data.alt} maxLength={140} onChange={(alt) => set({ alt })} placeholder="Ma base sur Blue au coucher du soleil" />
      <TextField label="Légende (optionnelle)" value={data.caption} maxLength={140} onChange={(caption) => set({ caption })} />
      <TextField
        label="Lien au clic (optionnel)"
        value={data.href}
        inputMode="url"
        onChange={(href) => set({ href })}
        onBlur={() => completeUrl(data.href, (href) => set({ href }))}
        error={urlError(data.href)}
      />
      <Segmented
        label="Format"
        value={data.aspect}
        onChange={(aspect) => set({ aspect })}
        options={[
          { value: "auto", label: "Original" },
          { value: "square", label: "1:1" },
          { value: "video", label: "16:9" },
          { value: "portrait", label: "4:5" },
        ]}
      />
    </div>
  );
}

function DiscordForm({ data, set }: { data: BlockData<"discord">; set: Setter<BlockData<"discord">> }) {
  return (
    <div className="space-y-4">
      <p className="text-xs leading-relaxed text-ink-400">Avatar, bannière et pseudo viennent de ton compte Discord relié par Unclaim Auth.</p>
      <TextField label="Note (optionnelle)" value={data.note} maxLength={190} onChange={(note) => set({ note })} placeholder="Écris-moi pour une alliance !" />
      <Toggle label="Afficher la bannière" checked={data.showBanner} onChange={(showBanner) => set({ showBanner })} />
      <Toggle label="Bouton « Voir le profil Discord »" checked={data.showFriendButton} onChange={(showFriendButton) => set({ showFriendButton })} />
    </div>
  );
}

function DiscordServerForm({ data, set }: { data: BlockData<"discordServer">; set: Setter<BlockData<"discordServer">> }) {
  const invalid = data.invite.trim() !== "" && !parseDiscordInvite(data.invite);
  return (
    <div className="space-y-4">
      <TextField
        label="Lien d'invitation"
        value={data.invite}
        onChange={(invite) => set({ invite })}
        placeholder="discord.gg/monserveur"
        error={invalid ? "Format attendu : discord.gg/code ou discord.com/invite/code." : null}
        hint="Utilise une invitation permanente pour qu'elle n'expire pas."
      />
      <TextField label="Message (optionnel)" value={data.note} maxLength={140} onChange={(note) => set({ note })} />
    </div>
  );
}

function usernameError(value: string) {
  return value && !isValidMcUsername(value) ? "2 à 16 caractères : lettres, chiffres et _." : null;
}

function SkinForm({ data, set }: { data: BlockData<"skin">; set: Setter<BlockData<"skin">> }) {
  const { ngUsername: ngDefault } = useEditorEnv();
  return (
    <div className="space-y-4">
      <TextField
        label="Pseudo du skin"
        value={data.username}
        maxLength={16}
        onChange={(username) => set({ username: username.trim() })}
        placeholder={ngDefault ? `Pseudo de la page : ${ngDefault}` : "Ton pseudo en jeu"}
        error={usernameError(data.username)}
        hint="Le skin est récupéré sur le serveur de skins NationsGlory."
      />
      <Select
        label="Animation"
        value={data.animation}
        onChange={(animation) => set({ animation })}
        options={[
          { value: "idle", label: "Repos" },
          { value: "walk", label: "Marche" },
          { value: "run", label: "Course" },
          { value: "fly", label: "Vol" },
          { value: "wave", label: "Salut de la main" },
          { value: "crouch", label: "Accroupi" },
          { value: "none", label: "Aucune" },
        ]}
      />
      <TextField label="Légende" value={data.label} maxLength={60} onChange={(label) => set({ label })} placeholder={data.username || ngDefault || "Mon skin"} />
      <RangeField label="Hauteur" value={data.height} min={220} max={520} step={10} unit=" px" onChange={(height) => set({ height })} />
      <Toggle label="Rotation automatique" checked={data.autoRotate} onChange={(autoRotate) => set({ autoRotate })} />
      <Toggle label="Afficher le pseudo au-dessus" checked={data.showName} onChange={(showName) => set({ showName })} />
    </div>
  );
}
