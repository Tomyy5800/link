"use client";

import { useCallback, useRef, useState, type ComponentType } from "react";
import {
  DndContext,
  KeyboardSensor,
  PointerSensor,
  closestCenter,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext,
  arrayMove,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import {
  Activity,
  BadgeCheck,
  CalendarDays,
  FolderOpen,
  Music2,
  CalendarClock,
  Castle,
  ChevronDown,
  ClipboardCopy,
  Flag,
  GalleryHorizontalEnd,
  MessageCircleQuestionMark,
  Radio,
  Timer,
  Clapperboard,
  Columns2,
  Copy,
  Eye,
  EyeOff,
  GripVertical,
  Heading,
  LayoutPanelLeft,
  Lock,
  Image as ImageIcon,
  Link2,
  Minus,
  Plus,
  RectangleHorizontal,
  Rotate3d,
  Server,
  Share2,
  Trash,
  Type,
  Gamepad2,
  Mail,
  ShoppingBag,
} from "lucide-react";
import {
  BLOCK_META,
  BLOCK_TYPES,
  blockSummary,
  createBlock,
  type Block,
  type BlockType,
} from "@/lib/blocks";
import { toast } from "@/lib/toast";
import type { Theme } from "@/lib/theme";
import { DiscordLogo } from "@/components/icons/SocialIcon";
import { BlockForm } from "./BlockForm";
import { BlockPicker, CATEGORY_COLOR } from "./BlockPicker";
import { flashBlock } from "./flash";
import { BlockLayoutFields } from "./BlockLayoutFields";
import { PlusBadge, useEditorEnv, useFeature } from "./EditorContext";
import { ScheduleFields } from "./NewBlockForms";

export const BLOCK_ICONS: Record<BlockType, ComponentType<{ size?: number; className?: string }>> = {
  heading: Heading,
  text: Type,
  link: Link2,
  socials: Share2,
  image: ImageIcon,
  discord: DiscordLogo,
  discordServer: Server,
  nationsglory: Castle,
  skin: Rotate3d,
  embed: Clapperboard,
  divider: Minus,
  countdown: Timer,
  gallery: GalleryHorizontalEnd,
  faq: MessageCircleQuestionMark,
  badges: BadgeCheck,
  copy: ClipboardCopy,
  ngCountry: Flag,
  discordPresence: Activity,
  radio: Radio,
  music: Music2,
  events: CalendarDays,
  collection: FolderOpen,
  game: Gamepad2,
  contact: Mail,
  shop: ShoppingBag,
};

type Props = {
  blocks: Block[];
  onChange: (blocks: Block[]) => void;
  theme: Theme;
  /** Bloc déplié (piloté par l'éditeur : un clic dans l'aperçu l'ouvre ici). */
  openId: string | null;
  onOpenChange: (id: string | null) => void;
};

/** Types de blocs dont la fonctionnalité est désactivée par l'administration. */
const GATED_TYPES: Partial<Record<BlockType, "presence" | "shop">> = { discordPresence: "presence", shop: "shop" };

export function BlocksPanel({ blocks, onChange, theme, openId, onOpenChange: setOpenId }: Props) {
  const { entitlements } = useEditorEnv();
  const maxBlocks = entitlements.limits.blocks;
  const [adding, setAdding] = useState(false);
  const closePicker = useCallback(() => setAdding(false), []);
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  const replace = (next: Block) => onChange(blocks.map((b) => (b.id === next.id ? next : b)));

  function onDragEnd(event: DragEndEvent) {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const from = blocks.findIndex((b) => b.id === active.id);
    const to = blocks.findIndex((b) => b.id === over.id);
    if (from >= 0 && to >= 0) onChange(arrayMove(blocks, from, to));
  }

  function add(type: BlockType) {
    const block = createBlock(type);
    onChange([...blocks, block]);
    setOpenId(block.id);
    setAdding(false);
    toast(`${BLOCK_META[type].label} ajouté`, { tone: "success", description: "Remplis-le ici : l'aperçu suit en direct." });
    requestAnimationFrame(() => document.getElementById(`block-${block.id}`)?.scrollIntoView({ behavior: "smooth", block: "center" }));
    flashBlock(block.id);
  }

  function duplicate(block: Block) {
    const copy = { ...structuredClone(block), id: createBlock(block.type).id } as Block;
    const index = blocks.findIndex((b) => b.id === block.id);
    onChange([...blocks.slice(0, index + 1), copy, ...blocks.slice(index + 1)]);
    setOpenId(copy.id);
    flashBlock(copy.id);
  }

  // Suppression immédiate, rattrapable depuis la notification (le bloc revient à sa place).
  const latest = useRef(blocks);
  latest.current = blocks;
  function remove(block: Block) {
    const index = blocks.findIndex((b) => b.id === block.id);
    onChange(blocks.filter((b) => b.id !== block.id));
    if (openId === block.id) setOpenId(null);
    toast(`${BLOCK_META[block.type].label} supprimé`, {
      tone: "info",
      duration: 6000,
      action: {
        label: "Annuler",
        onClick: () => {
          const current = latest.current;
          if (current.some((b) => b.id === block.id)) return;
          const at = Math.min(index, current.length);
          onChange([...current.slice(0, at), block, ...current.slice(at)]);
          flashBlock(block.id);
        },
      },
    });
  }

  const full = blocks.length >= maxBlocks;
  const available = BLOCK_TYPES.filter((t) => {
    const gate = GATED_TYPES[t];
    // Boutiques personnelles fermées par l'administration : aucune nouvelle boutique.
    return !gate || (entitlements.modes[gate] !== "off" && (gate !== "shop" || entitlements.personalShops));
  });

  return (
    <div className="space-y-3">
      {blocks.length === 0 && (
        <p className="rounded-md border border-dashed border-ink-700 p-6 text-center text-sm text-ink-400">
          Ta page n&apos;a encore aucun bloc. Ajoute un lien, tes réseaux ou ton skin pour commencer.
        </p>
      )}

      {/* id stable : évite un écart d'hydratation sur les attributs aria générés par dnd-kit */}
      <DndContext id="lbu-blocks" sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}>
        <SortableContext items={blocks.map((b) => b.id)} strategy={verticalListSortingStrategy}>
          <ul className="space-y-2">
            {blocks.map((block) => (
              <SortableBlock
                key={block.id}
                block={block}
                open={openId === block.id}
                onToggleOpen={() => setOpenId(openId === block.id ? null : block.id)}
                onChange={replace}
                onDuplicate={() => duplicate(block)}
                onDelete={() => remove(block)}
                canDuplicate={!full}
                theme={theme}
              />
            ))}
          </ul>
        </SortableContext>
      </DndContext>

      <button
        type="button"
        disabled={full}
        onClick={() => setAdding(true)}
        className="ui-press group flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-ink-600 py-3.5 text-sm font-medium text-ink-200 transition hover:border-brand-400 hover:bg-brand-500/5 hover:text-white disabled:cursor-not-allowed disabled:opacity-50"
      >
        <span className="flex h-6 w-6 items-center justify-center rounded-md bg-brand-500/15 text-brand-300 transition-transform duration-300 group-hover:rotate-90">
          <Plus size={15} />
        </span>
        {full ? `Limite de ${maxBlocks} blocs atteinte` : "Ajouter un bloc"}
      </button>
      {adding && <BlockPicker types={available} onPick={add} onClose={closePicker} />}
      {full && !entitlements.premium && (
        <p className="text-center text-xs text-ink-400">
          Plus de blocs avec <PlusBadge className="align-middle" />
        </p>
      )}
    </div>
  );
}

function IconButton({
  label,
  onClick,
  children,
  danger,
  pressed,
}: {
  label: string;
  onClick: () => void;
  children: React.ReactNode;
  danger?: boolean;
  pressed?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      aria-pressed={pressed}
      title={label}
      className={`flex h-8 w-8 items-center justify-center rounded-lg text-ink-400 transition hover:bg-ink-700 ${
        danger ? "hover:text-danger" : "hover:text-ink-100"
      }`}
    >
      {children}
    </button>
  );
}

function SortableBlock({
  block,
  open,
  onToggleOpen,
  onChange,
  onDuplicate,
  onDelete,
  canDuplicate,
  theme,
}: {
  block: Block;
  open: boolean;
  onToggleOpen: () => void;
  onChange: (block: Block) => void;
  onDuplicate: () => void;
  onDelete: () => void;
  canDuplicate: boolean;
  theme: Theme;
}) {
  const { attributes, listeners, setNodeRef, setActivatorNodeRef, transform, transition, isDragging } = useSortable({ id: block.id });
  const Icon = BLOCK_ICONS[block.type];
  const meta = BLOCK_META[block.type];
  const scheduled = Boolean(block.startsAt || block.endsAt);
  const [showSchedule, setShowSchedule] = useState(scheduled);
  const [pane, setPane] = useState<"content" | "layout">("content");
  const scheduling = useFeature("scheduling");
  const { openPlus } = useEditorEnv();

  return (
    <li
      ref={setNodeRef}
      id={`block-${block.id}`}
      style={{ transform: CSS.Transform.toString(transform), transition }}
      className={`rounded-xl border bg-ink-850 transition-[box-shadow,border-color,scale,rotate] duration-200 ${
        isDragging
          ? "relative z-10 scale-[1.03] rotate-[0.8deg] border-brand-500/70 shadow-[0_24px_48px_-12px_rgba(0,0,0,0.8),0_0_0_1px_rgba(34,201,232,0.35)]"
          : open
            ? "border-ink-600"
            : "border-ink-750 hover:border-ink-600"
      } ${block.visible ? "" : "opacity-60"}`}
    >
      <div className="flex items-center gap-1 p-1.5">
        <button
          ref={setActivatorNodeRef}
          type="button"
          {...attributes}
          {...listeners}
          className="flex h-8 w-6 shrink-0 cursor-grab touch-none items-center justify-center rounded-md text-ink-500 hover:text-ink-200 active:cursor-grabbing"
          aria-label={`Déplacer le bloc ${meta.label}`}
        >
          <GripVertical size={16} />
        </button>
        <button type="button" onClick={onToggleOpen} className="group flex min-w-0 flex-1 items-center gap-2.5 rounded-lg px-1 py-1 text-left" aria-expanded={open}>
          <span
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg"
            style={{ background: `${CATEGORY_COLOR[meta.category]}1f`, color: CATEGORY_COLOR[meta.category] }}
          >
            <Icon size={15} />
          </span>
          <span className="min-w-0 flex-1">
            <span className="flex items-center gap-1.5 text-sm font-medium text-ink-100">
              {meta.label}
              {scheduled && <CalendarClock size={13} className="text-brand-400" aria-label="Programmé" />}
            </span>
            <span className="block truncate text-xs text-ink-400">{blockSummary(block)}</span>
          </span>
          <ChevronDown size={16} className={`shrink-0 text-ink-500 transition-transform ${open ? "rotate-180" : ""}`} />
        </button>
        <IconButton
          label={block.width === "half" ? "Pleine largeur" : "Demi-largeur"}
          pressed={block.width === "half"}
          onClick={() => onChange({ ...block, width: block.width === "half" ? "full" : "half" })}
        >
          {block.width === "half" ? <Columns2 size={15} /> : <RectangleHorizontal size={15} />}
        </IconButton>
        <IconButton label={block.visible ? "Masquer" : "Afficher"} onClick={() => onChange({ ...block, visible: !block.visible })}>
          {block.visible ? <Eye size={15} /> : <EyeOff size={15} />}
        </IconButton>
      </div>

      {open && (
        <div className="border-t border-ink-750 px-3.5 pt-4 pb-3.5">
          <div className="mb-4 flex gap-1 rounded-md border border-ink-750 bg-ink-900 p-0.5" role="tablist" aria-label="Réglages du bloc">
            {(
              [
                ["content", "Contenu", Type],
                ["layout", "Disposition et style", LayoutPanelLeft],
              ] as const
            ).map(([key, label, PaneIcon]) => (
              <button
                key={key}
                type="button"
                role="tab"
                aria-selected={pane === key}
                onClick={() => setPane(key)}
                className={`flex flex-1 items-center justify-center gap-1.5 rounded-[4px] py-1.5 text-xs font-medium transition ${
                  pane === key ? "bg-ink-700 text-ink-100" : "text-ink-400 hover:text-ink-200"
                }`}
              >
                <PaneIcon size={13} /> {label}
              </button>
            ))}
          </div>
          {pane === "content" ? <BlockForm block={block} onChange={onChange} /> : <BlockLayoutFields block={block} theme={theme} onChange={onChange} />}
          {showSchedule && scheduling === "on" && (
            <div className="mt-5 border-t border-ink-750 pt-4">
              <p className="hud-label mb-3 text-ink-400">Programmation</p>
              <ScheduleFields
                startsAt={block.startsAt}
                endsAt={block.endsAt}
                onChange={(patch) => onChange({ ...block, ...patch } as Block)}
              />
            </div>
          )}
          <div className="mt-5 flex items-center justify-end gap-1 border-t border-ink-750 pt-3">
            {!(showSchedule && scheduling === "on") && scheduling !== "off" && (
              <button
                type="button"
                onClick={() => (scheduling === "on" ? setShowSchedule(true) : openPlus())}
                className="mr-auto inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs text-ink-300 transition hover:bg-ink-750 hover:text-ink-100"
              >
                <CalendarClock size={14} /> Programmer {scheduling === "locked" && <Lock size={11} className="text-claim" />}
              </button>
            )}
            {canDuplicate && (
              <button
                type="button"
                onClick={onDuplicate}
                className="inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs text-ink-300 transition hover:bg-ink-750 hover:text-ink-100"
              >
                <Copy size={14} /> Dupliquer
              </button>
            )}
            <button
              type="button"
              onClick={onDelete}
              className="inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs text-ink-300 transition hover:bg-danger/10 hover:text-danger"
            >
              <Trash size={14} /> Supprimer
            </button>
          </div>
        </div>
      )}
    </li>
  );
}
