"use client";

import { useEffect, useState } from "react";
import { ChevronDown, Copy, ExternalLink, Plus, ShoppingBag } from "lucide-react";
import type { BlockData } from "@/lib/blocks";
import { MAX_PRODUCTS, SHOP_CURRENCIES, formatMoney, makeProduct, newProductId, parsePrice, priceInput, type ShopProduct } from "@/lib/shop";
import { normalizeUrl, toSafeImageSrc } from "@/lib/urls";
import { ImageField, Segmented, Select, TextArea, TextField, Toggle } from "@/components/ui/controls";
import { EmojiField } from "./MoreForms";
import { ItemTools, addButton, moveItem } from "./NewBlockForms";

type Setter<T> = (patch: Partial<T>) => void;

const CURRENCY_LABEL: Record<(typeof SHOP_CURRENCIES)[number], string> = {
  EUR: "Euro (€)",
  USD: "Dollar américain ($)",
  GBP: "Livre sterling (£)",
  CHF: "Franc suisse (CHF)",
  CAD: "Dollar canadien ($ CA)",
};

/** Champ de prix : on tape librement (« 12,5 »), le bloc garde des centimes. */
function PriceField({ label, value, onChange, hint }: { label: string; value: number | null; onChange: (cents: number | null) => void; hint?: string }) {
  const [text, setText] = useState(priceInput(value));
  // Valeur changée ailleurs (annuler, dupliquer) : le champ suit.
  useEffect(() => {
    if (parsePrice(text) !== value) setText(priceInput(value));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);
  const invalid = text.trim() !== "" && parsePrice(text) === null;
  return (
    <TextField
      label={label}
      value={text}
      inputMode="numeric"
      onChange={(next) => {
        setText(next);
        const cents = parsePrice(next);
        if (next.trim() === "" || cents !== null) onChange(next.trim() === "" ? null : cents);
      }}
      placeholder="0,00"
      hint={hint}
      error={invalid ? "Montant invalide." : null}
    />
  );
}

/** Variantes tapées à la suite, séparées par des virgules. */
function OptionsField({ value, onChange }: { value: string[]; onChange: (options: string[]) => void }) {
  const [text, setText] = useState(value.join(", "));
  useEffect(() => {
    const parsed = text.split(",").map((s) => s.trim()).filter(Boolean);
    if (parsed.join("\u0000") !== value.join("\u0000")) setText(value.join(", "));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);
  return (
    <TextField
      label="Choix proposés (facultatif)"
      value={text}
      onChange={(next) => {
        setText(next);
        onChange(
          next
            .split(",")
            .map((s) => s.trim().slice(0, 32))
            .filter(Boolean)
            .slice(0, 12),
        );
      }}
      placeholder="S, M, L, XL"
      hint="Séparés par des virgules : l'acheteur en choisit un."
    />
  );
}

function blankProduct(): ShopProduct {
  return makeProduct({ id: newProductId() });
}

/**
 * Bloc « Boutique » : réglages de la vitrine et fiches produits (photos, prix, promo, variantes,
 * stock, achat par lien ou commande via le panier).
 */
export function ShopForm({ data, set }: { data: BlockData<"shop">; set: Setter<BlockData<"shop">> }) {
  const products = data.products;
  const [open, setOpen] = useState<string | null>(products.length === 1 ? products[0].id : null);

  // Produits venus d'un modèle ou de l'assistant sans identifiant : on leur en donne un.
  useEffect(() => {
    if (products.some((p) => !p.id)) set({ products: products.map((p) => (p.id ? p : { ...p, id: newProductId() })) });
  }, [products, set]);

  const update = (index: number, patch: Partial<ShopProduct>) => set({ products: products.map((p, i) => (i === index ? { ...p, ...patch } : p)) });
  const addProduct = () => {
    const product = blankProduct();
    set({ products: [...products, product] });
    setOpen(product.id);
  };

  return (
    <div className="space-y-4">
      <TextField label="Titre" value={data.title} maxLength={60} onChange={(title) => set({ title })} placeholder="Ma boutique" />
      <TextArea label="Présentation (facultative)" value={data.intro} maxLength={240} rows={2} onChange={(intro) => set({ intro })} placeholder="Merch officiel, impressions, commissions…" />
      <div className="grid grid-cols-2 gap-3">
        <Select label="Devise" value={data.currency} onChange={(currency) => set({ currency })} options={SHOP_CURRENCIES.map((c) => ({ value: c, label: CURRENCY_LABEL[c] }))} />
        <Segmented
          label="Vitrine"
          value={data.layout}
          onChange={(layout) => set({ layout })}
          options={[
            { value: "grid", label: "Grille" },
            { value: "carousel", label: "Défilé" },
            { value: "list", label: "Liste" },
          ]}
        />
      </div>

      <div>
        <p className="hud-label mb-2 flex items-center gap-1.5 text-ink-400">
          <ShoppingBag size={12} aria-hidden="true" /> Produits · {products.length}/{MAX_PRODUCTS}
        </p>
        <ul className="space-y-2">
          {products.map((product, index) => {
            const expanded = open === product.id;
            const thumb = toSafeImageSrc(product.images[0] ?? "");
            return (
              <li key={product.id || index} className={`overflow-hidden rounded-lg border transition ${expanded ? "border-ink-500 bg-ink-850/60" : "border-ink-700"}`}>
                <div className="flex items-center gap-2 p-2">
                  <button type="button" onClick={() => setOpen(expanded ? null : product.id)} className="flex min-w-0 flex-1 items-center gap-2.5 text-left" aria-expanded={expanded}>
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-md bg-ink-800 text-ink-400">
                      {thumb ? <img src={thumb} alt="" className="h-full w-full object-cover" /> : product.emoji ? <span className="text-xl">{product.emoji}</span> : <ShoppingBag size={16} />}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-semibold text-ink-100">{product.name || "Produit sans nom"}</span>
                      <span className="block truncate text-xs text-ink-400">
                        {product.price === null ? "Prix libre" : formatMoney(product.price, data.currency)} · {product.mode === "order" ? "Commande via le panier" : "Lien d'achat"}
                        {product.soldOut ? " · épuisé" : ""}
                      </span>
                    </span>
                    <ChevronDown size={16} className={`shrink-0 text-ink-400 transition-transform ${expanded ? "rotate-180" : ""}`} aria-hidden="true" />
                  </button>
                  <ItemTools
                    index={index}
                    count={products.length}
                    label={product.name || `le produit ${index + 1}`}
                    onMove={(to) => set({ products: moveItem(products, index, to) })}
                    onRemove={() => set({ products: products.filter((_, i) => i !== index) })}
                  />
                </div>
                {expanded && (
                  <div className="animate-rise space-y-4 border-t border-ink-700 p-3">
                    <TextField label="Nom" value={product.name} maxLength={80} onChange={(name) => update(index, { name })} placeholder="Sweat « Saison 3 »" />
                    <div className="grid grid-cols-2 gap-3">
                      <PriceField label="Prix" value={product.price} onChange={(price) => update(index, { price })} hint="Vide : prix libre." />
                      <PriceField label="Ancien prix (promo)" value={product.compareAt} onChange={(compareAt) => update(index, { compareAt })} hint="Affiché barré." />
                    </div>
                    <div className="space-y-2">
                      {product.images.map((src, i) => (
                        <div key={i} className="flex items-end gap-2">
                          <div className="min-w-0 flex-1">
                            <ImageField label={i === 0 ? "Photo principale" : `Photo ${i + 1}`} value={src} onChange={(url) => update(index, { images: product.images.map((s, j) => (j === i ? url : s)) })} />
                          </div>
                          <ItemTools
                            index={i}
                            count={product.images.length}
                            label={`la photo ${i + 1}`}
                            onMove={(to) => update(index, { images: moveItem(product.images, i, to) })}
                            onRemove={() => update(index, { images: product.images.filter((_, j) => j !== i) })}
                          />
                        </div>
                      ))}
                      {product.images.length < 4 && (
                        <button type="button" onClick={() => update(index, { images: [...product.images, ""] })} className={addButton}>
                          <Plus size={15} /> Ajouter une photo ({product.images.length}/4)
                        </button>
                      )}
                    </div>
                    {product.images.length === 0 && (
                      <div className="grid grid-cols-[auto_1fr] items-end gap-3">
                        <EmojiField value={product.emoji} onChange={(emoji) => update(index, { emoji })} />
                        <p className="pb-2 text-xs text-ink-400">Sans photo, cet émoji illustre le produit en grand.</p>
                      </div>
                    )}
                    <TextArea label="Description" value={product.description} maxLength={600} rows={3} onChange={(description) => update(index, { description })} placeholder="Matière, dimensions, délai…" />
                    <div className="grid grid-cols-[1fr_2fr] gap-3">
                      <TextField label="Intitulé du choix" value={product.optionLabel} maxLength={24} onChange={(optionLabel) => update(index, { optionLabel })} placeholder="Taille" />
                      <OptionsField value={product.options} onChange={(options) => update(index, { options })} />
                    </div>
                    <TextField label="Étiquette (facultative)" value={product.badge} maxLength={24} onChange={(badge) => update(index, { badge })} placeholder="Nouveau, Édition limitée…" />

                    <Segmented
                      label="Achat"
                      value={product.mode}
                      onChange={(mode) => update(index, { mode })}
                      options={[
                        { value: "link", label: "Lien vers ma boutique" },
                        { value: "order", label: "Commande via le panier" },
                      ]}
                    />
                    {product.mode === "link" ? (
                      <TextField
                        label="Adresse d'achat"
                        value={product.url}
                        inputMode="url"
                        onChange={(url) => update(index, { url })}
                        onBlur={() => {
                          const normalized = normalizeUrl(product.url);
                          if (normalized && normalized !== product.url) update(index, { url: normalized });
                        }}
                        placeholder="https://ko-fi.com/…, Shopify, Etsy, Tipeee…"
                        error={product.url && normalizeUrl(product.url) === null ? "Adresse invalide (http ou https)." : null}
                      />
                    ) : (
                      <p className="rounded-md border border-ink-700 bg-ink-900/60 p-2.5 text-xs leading-relaxed text-ink-300">
                        Le visiteur ajoute le produit à son panier et t&apos;envoie une demande de commande avec son contact. Tu la retrouves dans « Mon espace ›
                        Commandes » et tu règles le paiement avec lui.
                      </p>
                    )}
                    <TextField
                      label="Texte du bouton (facultatif)"
                      value={product.buttonLabel}
                      maxLength={30}
                      onChange={(buttonLabel) => update(index, { buttonLabel })}
                      placeholder={product.mode === "link" ? "Acheter" : "Ajouter au panier"}
                    />
                    <div className="grid grid-cols-2 items-end gap-3">
                      <TextField
                        label="Stock (facultatif)"
                        value={product.stock === null ? "" : String(product.stock)}
                        inputMode="numeric"
                        onChange={(value) => {
                          const digits = value.replace(/\D/g, "").slice(0, 5);
                          update(index, { stock: digits === "" ? null : Number(digits) });
                        }}
                        placeholder="Non suivi"
                      />
                      <Toggle label="Épuisé" checked={product.soldOut} onChange={(soldOut) => update(index, { soldOut })} />
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {products.length < MAX_PRODUCTS && (
                        <button
                          type="button"
                          onClick={() => {
                            const copy = { ...product, id: newProductId(), name: product.name ? `${product.name} (copie)`.slice(0, 80) : "" };
                            set({ products: [...products.slice(0, index + 1), copy, ...products.slice(index + 1)] });
                            setOpen(copy.id);
                          }}
                          className="inline-flex items-center gap-1.5 rounded-md border border-ink-600 px-2.5 py-1.5 text-xs text-ink-200 transition hover:border-ink-400"
                        >
                          <Copy size={13} /> Dupliquer
                        </button>
                      )}
                      {product.mode === "link" && normalizeUrl(product.url) && (
                        <a
                          href={normalizeUrl(product.url) ?? undefined}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 rounded-md border border-ink-600 px-2.5 py-1.5 text-xs text-ink-200 transition hover:border-ink-400"
                        >
                          <ExternalLink size={13} /> Tester le lien
                        </a>
                      )}
                    </div>
                  </div>
                )}
              </li>
            );
          })}
        </ul>
        {products.length < MAX_PRODUCTS && (
          <button type="button" onClick={addProduct} className={`${addButton} mt-2`}>
            <Plus size={15} /> Ajouter un produit
          </button>
        )}
      </div>

      <TextArea
        label="Paiement et livraison (facultatif)"
        value={data.terms}
        maxLength={300}
        rows={2}
        onChange={(terms) => set({ terms })}
        placeholder="Paiement PayPal après confirmation, envoi sous 3 jours ouvrés."
        hint="Rappelé dans le panier, au moment de commander."
      />
      <p className="text-xs leading-relaxed text-ink-400">
        Link by Unclaim n&apos;encaisse rien : les produits « lien » mènent à ta boutique, les commandes via le panier arrivent dans « Mon espace ›
        Commandes ». Anti-spam inclus : 5 commandes par visiteur et par jour.
      </p>
    </div>
  );
}
