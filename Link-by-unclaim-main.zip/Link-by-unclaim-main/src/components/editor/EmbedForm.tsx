"use client";

import { Code, Globe, Lock, PlayCircle } from "lucide-react";
import type { BlockData } from "@/lib/blocks";
import { describeEmbed } from "@/lib/embeds";
import { normalizeUrl } from "@/lib/urls";
import { RangeField, Segmented, TextArea, TextField, Toggle } from "@/components/ui/controls";
import { PlusBadge, useEditorEnv, useFeature } from "./EditorContext";

type Setter<T> = (patch: Partial<T>) => void;

const PROVIDERS = "YouTube, Twitch (live, VOD, clip, chat), Kick, Spotify, Deezer, Apple Music, SoundCloud, Vimeo, Dailymotion, Streamable, TikTok, X, Instagram, widget Discord, Google Maps";

export function EmbedForm({ data, set }: { data: BlockData<"embed">; set: Setter<BlockData<"embed">> }) {
  const { entitlements } = useEditorEnv();
  const iframe = useFeature("customEmbeds");
  const html = useFeature("htmlWidgets");
  const info = describeEmbed(data, { iframe: iframe === "on", html: html === "on" }, []);

  const modes = [
    { value: "auto" as const, label: <><PlayCircle size={14} /> Service</>, title: "Lecteur d'un service reconnu" },
    ...(iframe !== "off"
      ? [{ value: "iframe" as const, label: <><Globe size={14} /> Site web {iframe === "locked" && <Lock size={11} />}</>, title: "N'importe quel site en iframe" }]
      : []),
    ...(html !== "off"
      ? [{ value: "html" as const, label: <><Code size={14} /> HTML {html === "locked" && <Lock size={11} />}</>, title: "Widget HTML/JS isolé" }]
      : []),
  ];
  const locked = info.kind === "locked";

  return (
    <div className="space-y-4">
      {modes.length > 1 && <Segmented label="Type d'intégration" value={data.mode} onChange={(mode) => set({ mode })} options={modes} />}

      {locked && (
        <p className="flex flex-wrap items-center gap-2 rounded-md border border-claim/30 bg-claim/5 px-3 py-2 text-xs text-ink-300">
          <PlusBadge feature={data.mode === "html" ? "htmlWidgets" : "customEmbeds"} /> {info.reason} font partie d&apos;une formule supérieure : le bloc
          reste masqué sur ta page publique.
        </p>
      )}

      {data.mode === "html" ? (
        <TextArea
          label="Code du widget"
          value={data.html}
          maxLength={20_000}
          rows={8}
          onChange={(value) => set({ html: value })}
          placeholder={'<div id="widget"></div>\n<script src="https://…"></script>'}
          hint="Le code s'exécute dans un cadre isolé de ta page : il ne peut ni lire tes données, ni modifier le reste de la page."
        />
      ) : (
        <TextField
          label={data.mode === "iframe" ? "Adresse du site" : "Lien à intégrer"}
          value={data.url}
          inputMode="url"
          onChange={(url) => set({ url })}
          onBlur={() => {
            const normalized = normalizeUrl(data.url);
            if (normalized && normalized !== data.url) set({ url: normalized });
          }}
          placeholder={data.mode === "iframe" ? "https://mon-site.fr/widget" : "https://youtube.com/watch?v=…"}
          error={info.kind === "empty" && data.url ? info.reason : info.kind === "blocked" ? info.reason : null}
          hint={
            info.kind === "frame"
              ? `${info.label} détecté.`
              : data.mode === "iframe"
                ? "Certains sites refusent d'être intégrés : ils s'afficheront vides."
                : `Pris en charge : ${PROVIDERS}.`
          }
        />
      )}

      <TextField label="Titre (accessibilité)" value={data.title} maxLength={80} onChange={(title) => set({ title })} placeholder="Ma dernière vidéo" />

      <Segmented
        label="Format"
        value={data.aspect}
        onChange={(aspect) => set({ aspect, ...(aspect !== "auto" ? { height: null } : {}) })}
        options={[
          { value: "auto", label: "Auto" },
          { value: "16:9", label: "16:9" },
          { value: "4:3", label: "4:3" },
          { value: "1:1", label: "1:1" },
          { value: "9:16", label: "9:16" },
        ]}
      />
      {data.aspect === "auto" && (
        <>
          <Toggle
            label="Hauteur fixe"
            description="Sinon, la hauteur dépend du service intégré."
            checked={data.height !== null}
            onChange={(on) => set({ height: on ? 360 : null })}
          />
          {data.height !== null && (
            <RangeField label="Hauteur" value={data.height} min={80} max={1200} step={10} unit=" px" onChange={(height) => set({ height })} />
          )}
        </>
      )}
    </div>
  );
}
