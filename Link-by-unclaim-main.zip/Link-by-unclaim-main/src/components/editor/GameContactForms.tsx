"use client";

import { Plus } from "lucide-react";
import type { BlockData } from "@/lib/blocks";
import { GAME_IDS, cleanGameId, gameInfo } from "@/lib/games";
import { normalizeUrl } from "@/lib/urls";
import { Segmented, Select, TextArea, TextField, Toggle } from "@/components/ui/controls";
import { ItemTools, addButton, moveItem } from "./NewBlockForms";

type Setter<T> = (patch: Partial<T>) => void;

// ─── Profil de jeu ─────────────────────────────────────────────────────────

export function GameForm({ data, set }: { data: BlockData<"game">; set: Setter<BlockData<"game">> }) {
  const info = gameInfo(data.game);
  const stats = data.stats;
  const invalidLive = info.live && data.username.trim() !== "" && cleanGameId(data.game, data.username) === null;
  const update = (i: number, patch: Partial<(typeof stats)[number]>) => set({ stats: stats.map((s, j) => (j === i ? { ...s, ...patch } : s)) });

  return (
    <div className="space-y-4">
      <Select
        label="Jeu"
        value={data.game}
        onChange={(game) => set({ game: game as BlockData<"game">["game"] })}
        options={GAME_IDS.map((id) => ({ value: id, label: `${gameInfo(id).name}${gameInfo(id).live ? " · en direct" : ""}` }))}
      />
      {data.game === "other" && <TextField label="Nom du jeu" value={data.customName} maxLength={40} onChange={(customName) => set({ customName })} placeholder="Geometry Dash" />}
      <TextField
        label={info.idLabel}
        value={data.username}
        maxLength={120}
        onChange={(username) => set({ username })}
        placeholder={info.idPlaceholder}
        error={invalidLive ? "Format non reconnu pour ce jeu." : null}
      />
      {info.live ? (
        <Toggle
          label="Données publiques en direct"
          description="Avatar, classements et statistiques publiques, mis à jour automatiquement."
          checked={data.showLive}
          onChange={(showLive) => set({ showLive })}
        />
      ) : (
        <p className="rounded-md border border-ink-700 bg-ink-850 p-2.5 text-xs leading-relaxed text-ink-400">
          {info.name} ne propose pas d&apos;API publique : renseigne ton rang et tes statistiques à la main, ils s&apos;affichent tels quels.
        </p>
      )}
      <TextField label="Rang, niveau ou titre (facultatif)" value={data.rank} maxLength={40} onChange={(rank) => set({ rank })} placeholder="Diamant II, Faction Alpha, niveau 87…" />

      <div className="space-y-2">
        <p className="text-[0.8rem] font-medium text-ink-200">Statistiques {info.live ? "(en plus des données en direct)" : ""}</p>
        <ul className="space-y-2">
          {stats.map((s, i) => (
            <li key={i} className="flex items-center gap-2">
              <input className="field" value={s.label} maxLength={24} onChange={(e) => update(i, { label: e.target.value })} placeholder="Victoires" aria-label={`Nom de la statistique ${i + 1}`} />
              <input className="field" value={s.value} maxLength={24} onChange={(e) => update(i, { value: e.target.value })} placeholder="1 204" aria-label={`Valeur de la statistique ${i + 1}`} />
              <ItemTools index={i} count={stats.length} label={`la statistique ${i + 1}`} onMove={(to) => set({ stats: moveItem(stats, i, to) })} onRemove={() => set({ stats: stats.filter((_, j) => j !== i) })} />
            </li>
          ))}
        </ul>
        {stats.length < 6 && (
          <button type="button" className={addButton} onClick={() => set({ stats: [...stats, { label: "", value: "" }] })}>
            <Plus size={15} /> Ajouter une statistique
          </button>
        )}
      </div>

      <TextField
        label="Lien du profil (facultatif)"
        value={data.url}
        inputMode="url"
        onChange={(url) => set({ url })}
        placeholder={info.profileUrl ? "Laisse vide pour le profil officiel" : "https://…"}
        error={data.url && normalizeUrl(data.url) === null ? "Adresse invalide." : null}
      />
    </div>
  );
}

// ─── Formulaire de contact ─────────────────────────────────────────────────

export function ContactForm({ data, set }: { data: BlockData<"contact">; set: Setter<BlockData<"contact">> }) {
  return (
    <div className="space-y-4">
      <TextField label="Titre" value={data.title} maxLength={80} onChange={(title) => set({ title })} placeholder="Me contacter" />
      <TextArea label="Introduction (facultative)" value={data.intro} maxLength={240} rows={2} onChange={(intro) => set({ intro })} placeholder="Pour un partenariat, une question, un recrutement…" />
      <Segmented
        label="Comment te répondre"
        value={data.contactField}
        onChange={(contactField) => set({ contactField })}
        options={[
          { value: "optional", label: "Facultatif" },
          { value: "required", label: "Obligatoire" },
          { value: "hidden", label: "Masqué" },
        ]}
      />
      <TextField label="Texte du bouton" value={data.buttonLabel} maxLength={40} onChange={(buttonLabel) => set({ buttonLabel })} />
      <TextField label="Message après l'envoi" value={data.successText} maxLength={160} onChange={(successText) => set({ successText })} />
      <p className="text-xs leading-relaxed text-ink-400">
        Les messages arrivent dans « Mon espace › Messages », pour toi et ton équipe. Ton e-mail n&apos;est jamais affiché. Anti-spam inclus : 5 messages
        par visiteur et par jour.
      </p>
    </div>
  );
}
