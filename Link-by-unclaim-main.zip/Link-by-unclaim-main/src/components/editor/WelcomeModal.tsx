"use client";

import { useEffect, useRef, useState } from "react";
import { Check, Copy, LayoutGrid, Palette, Share2, X, Zap } from "lucide-react";
import { celebrate } from "@/lib/confetti";
import { ShareQr } from "./ShareQr";

type Tab = "blocs" | "profil" | "apparence" | "reglages";

/** Fête la création d'une page : lien à partager, QR code et prochaines étapes. */
export function WelcomeModal({ url, slug, onClose, onGo }: { url: string; slug: string; onClose: () => void; onGo: (tab: Tab | "automations") => void }) {
  const [copied, setCopied] = useState(false);
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    closeRef.current?.focus();
    const timer = window.setTimeout(celebrate, 250);
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  const share = async () => {
    if (navigator.share) {
      await navigator.share({ title: "Ma page Link by Unclaim", url }).catch(() => undefined);
    } else {
      await navigator.clipboard.writeText(url);
      setCopied(true);
    }
  };

  const steps: { icon: typeof Palette; title: string; text: string; go: Tab | "automations" }[] = [
    { icon: Palette, title: "Donne-lui ton style", text: "Thèmes, couleurs, polices, effets.", go: "apparence" },
    { icon: LayoutGrid, title: "Ajoute des blocs", text: "Ctrl+K puis le nom d'un bloc, c'est tout.", go: "blocs" },
    { icon: Zap, title: "Automatise-la", text: "Bandeau pendant tes lives, thème d'anniversaire…", go: "automations" },
  ];

  return (
    <div className="fixed inset-0 z-[95] flex items-center justify-center bg-ink-950/75 p-4 backdrop-blur-sm" onMouseDown={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="welcome-title"
        className="ui-glow-border relative w-full max-w-lg overflow-hidden rounded-2xl bg-ink-900 p-6 shadow-2xl shadow-black/60 animate-pop"
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="pointer-events-none absolute -top-24 -right-24 h-56 w-56 rounded-full bg-claim/20 blur-3xl" aria-hidden="true" />
        <button ref={closeRef} type="button" onClick={onClose} className="ui-press absolute top-3 right-3 rounded p-1.5 text-ink-400 hover:text-ink-100" aria-label="Fermer">
          <X size={18} />
        </button>
        <p className="ui-wave text-4xl" aria-hidden="true">
          🎉
        </p>
        <h2 id="welcome-title" className="mt-2 font-display text-2xl font-bold">
          Ta page est en ligne !
        </h2>
        <p className="mt-1 text-sm text-ink-300">Partage ton lien partout : bio Discord, Twitch, TikTok, Instagram…</p>

        <div className="mt-4 flex items-center gap-2 rounded-md border border-ink-700 bg-ink-950 p-1.5 pl-3">
          <span className="min-w-0 flex-1 truncate font-mono text-sm text-brand-300">{url.replace(/^https?:\/\//, "")}</span>
          <button
            type="button"
            onClick={() =>
              void navigator.clipboard.writeText(url).then(() => {
                setCopied(true);
                window.setTimeout(() => setCopied(false), 1800);
              })
            }
            className="inline-flex items-center gap-1.5 rounded-md bg-brand-500 px-3 py-1.5 text-sm font-semibold text-ink-950 hover:bg-brand-400"
          >
            {copied ? <Check size={14} /> : <Copy size={14} />} {copied ? "Copié" : "Copier"}
          </button>
          <button type="button" onClick={share} className="rounded-md border border-ink-600 p-2 text-ink-200 hover:border-ink-400" aria-label="Partager">
            <Share2 size={15} />
          </button>
        </div>

        <details className="mt-3 text-sm">
          <summary className="cursor-pointer text-ink-300 hover:text-ink-100">Afficher le QR code</summary>
          <div className="mt-3">
            <ShareQr url={url} slug={slug} />
          </div>
        </details>

        <p className="hud-label mt-5 text-ink-400">Et maintenant</p>
        <ul className="mt-2 grid gap-2 sm:grid-cols-3">
          {steps.map(({ icon: Icon, title, text, go }) => (
            <li key={title}>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onGo(go);
                }}
                data-spotlight
                className="ui-spotlight ui-press group h-full w-full rounded-lg border border-ink-700 p-3 text-left transition hover:border-brand-400"
              >
                <Icon size={16} className="text-brand-300" />
                <span className="mt-1.5 block text-sm font-semibold text-ink-100">{title}</span>
                <span className="mt-0.5 block text-xs text-ink-400">{text}</span>
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
