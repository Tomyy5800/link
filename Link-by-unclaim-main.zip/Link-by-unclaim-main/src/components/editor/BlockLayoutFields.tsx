"use client";

import { AlignCenter, AlignLeft, AlignRight, Monitor, Smartphone } from "lucide-react";
import type { Block, BlockStyle } from "@/lib/blocks";
import type { Theme } from "@/lib/theme";
import { ColorField, Segmented, Toggle } from "@/components/ui/controls";
import { FeatureSection, useFeature } from "./EditorContext";

/** Disposition (mobile et ordinateur) et style propre d'un bloc. */
export function BlockLayoutFields({ block, theme, onChange }: { block: Block; theme: Theme; onChange: (block: Block) => void }) {
  const layout = useFeature("advancedLayout");
  const grid = layout === "on" && theme.layout !== "stack";
  const columns = theme.columns;
  const style = block.style;
  const setStyle = (patch: Partial<BlockStyle>) => onChange({ ...block, style: { ...style, ...patch } });

  return (
    <div className="space-y-5">
      <div className="space-y-3">
        <p className="hud-label text-ink-400">Disposition</p>
        <Segmented
          label="Sur mobile"
          value={block.width}
          onChange={(width) => onChange({ ...block, width })}
          options={[
            { value: "full", label: <><Smartphone size={13} /> Pleine largeur</> },
            { value: "half", label: "Demi-largeur" },
          ]}
        />
        {grid ? (
          <div className="grid grid-cols-2 gap-3">
            <Segmented
              label="Largeur sur ordinateur"
              value={block.colSpan === null ? "auto" : String(Math.min(block.colSpan, columns))}
              onChange={(v) => onChange({ ...block, colSpan: v === "auto" ? null : Number(v) })}
              options={[
                { value: "auto", label: "Auto", title: "Selon la largeur mobile" },
                ...Array.from({ length: columns }, (_, i) => ({ value: String(i + 1), label: String(i + 1), title: `${i + 1} colonne${i ? "s" : ""}` })),
              ]}
            />
            <Segmented
              label="Hauteur (rangées)"
              value={String(block.rowSpan)}
              onChange={(v) => onChange({ ...block, rowSpan: Number(v) })}
              options={[1, 2, 3, 4].map((n) => ({ value: String(n), label: String(n) }))}
            />
          </div>
        ) : (
          layout !== "off" && (
            <p className="flex items-start gap-2 text-xs leading-relaxed text-ink-400">
              <Monitor size={14} className="mt-px shrink-0" aria-hidden="true" />
              Choisis la grille ou le profil latéral dans Apparence › Mise en page pour régler la largeur et la hauteur sur ordinateur.
            </p>
          )
        )}
      </div>

      <FeatureSection feature="blockStyles" title="Style par bloc">
        <div className="space-y-3">
          <p className="hud-label text-ink-400">Style du bloc</p>
          <Segmented
            label="Fond"
            value={style.surface}
            onChange={(surface) => setStyle({ surface })}
            options={[
              { value: "auto", label: "Thème" },
              { value: "none", label: "Aucun" },
              { value: "accent", label: "Accent" },
              { value: "custom", label: "Couleur" },
            ]}
          />
          {style.surface === "custom" && <ColorField label="Couleur du fond" value={style.color} onChange={(color) => setStyle({ color })} />}
          <Toggle label="Couleur de texte propre" checked={style.text !== null} onChange={(on) => setStyle({ text: on ? "#ffffff" : null })} />
          {style.text !== null && <ColorField label="Couleur du texte" value={style.text} onChange={(text) => setStyle({ text })} />}
          <Segmented
            label="Alignement du contenu"
            value={style.align}
            onChange={(align) => setStyle({ align })}
            options={[
              { value: "auto", label: "Auto" },
              { value: "left", label: <AlignLeft size={15} />, title: "À gauche" },
              { value: "center", label: <AlignCenter size={15} />, title: "Centré" },
              { value: "right", label: <AlignRight size={15} />, title: "À droite" },
            ]}
          />
          {grid && (
            <Segmented
              label="Position verticale dans la case"
              value={style.valign}
              onChange={(valign) => setStyle({ valign })}
              options={[
                { value: "stretch", label: "Remplir" },
                { value: "start", label: "Haut" },
                { value: "center", label: "Milieu" },
                { value: "end", label: "Bas" },
              ]}
            />
          )}
          <Segmented
            label="Masquer sur"
            value={style.hideOn}
            onChange={(hideOn) => setStyle({ hideOn })}
            options={[
              { value: "none", label: "Jamais" },
              { value: "mobile", label: "Mobile" },
              { value: "desktop", label: "Ordinateur" },
            ]}
          />
        </div>
      </FeatureSection>
    </div>
  );
}
