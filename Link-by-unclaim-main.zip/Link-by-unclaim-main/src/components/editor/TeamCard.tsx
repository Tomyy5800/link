"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Check, Copy, LoaderCircle, LogOut, UserPlus, X } from "lucide-react";
import { confirmDialog } from "@/lib/confirm";
import type { MemberRoleView } from "@/lib/member-roles";
import { FeatureSection, useFeature } from "./EditorContext";
import { RoleChip, RolesManager } from "./RolesManager";

type Member = { id: string; role: "editor" | "viewer"; customRoleId: string | null; name: string; avatar: string; self: boolean };
type Roles = { roles: MemberRoleView[]; enabled: boolean; limit: number };
type Invite = { id: string; role: "editor" | "viewer"; expiresAt: string };
type Team = {
  role: "owner" | "editor" | "viewer";
  limit: number;
  owner: { name: string; avatar: string; self: boolean };
  members: Member[];
  invites: Invite[];
};

const ROLE_TEXT = { editor: "Éditeur", viewer: "Lecteur" } as const;
const ROLE_HINT = {
  editor: "modifie les blocs, le profil et l'apparence",
  viewer: "consulte les statistiques et les messages",
} as const;

/** Équipe d'une page : collaborateurs, invitations par lien, rôles. */
export function TeamCard({ pageId, isOwner }: { pageId: string; isOwner: boolean }) {
  const router = useRouter();
  const [team, setTeam] = useState<Team | null>(null);
  const [roles, setRoles] = useState<Roles | null>(null);
  const rolesFeature = useFeature("customRoles");
  const [role, setRole] = useState<"editor" | "viewer">("editor");
  const [link, setLink] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    const [res, rolesRes] = await Promise.all([
      fetch(`/api/me/pages/${pageId}/members`, { cache: "no-store" }).catch(() => null),
      fetch(`/api/me/pages/${pageId}/roles`, { cache: "no-store" }).catch(() => null),
    ]);
    if (res?.ok) setTeam((await res.json()) as Team);
    if (rolesRes?.ok) setRoles((await rolesRes.json()) as Roles);
  }, [pageId]);

  useEffect(() => {
    void load();
  }, [load]);

  async function call(method: string, query = "", body?: unknown) {
    setBusy(true);
    setError(null);
    const res = await fetch(`/api/me/pages/${pageId}/members${query}`, {
      method,
      headers: body ? { "Content-Type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    }).catch(() => null);
    const json = (await res?.json().catch(() => ({}))) as { error?: string; url?: string };
    setBusy(false);
    if (!res?.ok) {
      setError(json.error ?? "Action impossible, réessaie.");
      return null;
    }
    await load();
    return json;
  }

  async function invite() {
    const json = await call("POST", "", { role });
    if (json?.url) {
      setLink(json.url);
      setCopied(false);
    }
  }

  async function leave(memberId: string) {
    const ok = await confirmDialog({ title: "Quitter cette page ?", message: "Tu n'y auras plus accès.", confirmLabel: "Quitter", tone: "danger" });
    if (!ok) return;
    if (await call("DELETE", `?memberId=${memberId}`)) router.push("/dashboard");
  }

  const used = team ? team.members.length + team.invites.length : 0;

  return (
    <section className="space-y-3 rounded-lg border border-ink-700 bg-ink-850/60 p-4" aria-label="Équipe">
      <div className="flex items-center justify-between">
        <h3 className="hud-label text-ink-400">Équipe</h3>
        {team && isOwner && (
          <span className="font-mono text-[11px] text-ink-400">
            {used}/{team.limit}
          </span>
        )}
      </div>
      <p className="text-xs leading-relaxed text-ink-400">
        Gère cette page à plusieurs : manager, équipe, partenaire. Chacun se connecte avec son propre compte Unclaim.
      </p>

      {!team ? (
        <div className="h-10 animate-pulse rounded-md bg-ink-800" />
      ) : (
        <ul className="space-y-2">
          <li className="flex items-center gap-2.5 text-sm">
            <img src={team.owner.avatar} alt="" className="h-7 w-7 rounded-full object-cover" />
            <span className="min-w-0 flex-1 truncate text-ink-100">
              {team.owner.name} {team.owner.self && <span className="text-ink-400">(toi)</span>}
            </span>
            <span className="text-xs text-claim">Propriétaire</span>
          </li>
          {team.members.map((m) => (
            <li key={m.id} className="flex items-center gap-2.5 text-sm">
              <img src={m.avatar} alt="" className="h-7 w-7 rounded-full object-cover" />
              <span className="min-w-0 flex-1 truncate text-ink-100">
                {m.name} {m.self && <span className="text-ink-400">(toi)</span>}
              </span>
              {isOwner ? (
                <>
                  {roles?.enabled && roles.roles.length > 0 ? (
                    <select
                      className="field !h-7 !w-auto max-w-36 !py-0 text-xs"
                      value={m.customRoleId ? `custom:${m.customRoleId}` : m.role}
                      disabled={busy}
                      onChange={(e) => {
                        const v = e.target.value;
                        void call("PATCH", "", v.startsWith("custom:") ? { memberId: m.id, customRoleId: v.slice(7) } : { memberId: m.id, role: v, customRoleId: null });
                      }}
                      aria-label={`Rôle de ${m.name}`}
                    >
                      <option value="editor">Éditeur</option>
                      <option value="viewer">Lecteur</option>
                      <optgroup label="Rôles personnalisés">
                        {roles.roles.map((r) => (
                          <option key={r.id} value={`custom:${r.id}`}>
                            {r.name}
                          </option>
                        ))}
                      </optgroup>
                    </select>
                  ) : (
                    <select
                      className="field !h-7 !w-auto !py-0 text-xs"
                      value={m.role}
                      disabled={busy}
                      onChange={(e) => void call("PATCH", "", { memberId: m.id, role: e.target.value })}
                      aria-label={`Rôle de ${m.name}`}
                    >
                      <option value="editor">Éditeur</option>
                      <option value="viewer">Lecteur</option>
                    </select>
                  )}
                  <button
                    type="button"
                    disabled={busy}
                    onClick={async () => {
                      const ok = await confirmDialog({ title: `Retirer ${m.name} de l'équipe ?`, confirmLabel: "Retirer", tone: "danger" });
                      if (ok) void call("DELETE", `?memberId=${m.id}`);
                    }}
                    className="rounded p-1 text-ink-400 hover:text-danger"
                    aria-label={`Retirer ${m.name}`}
                  >
                    <X size={14} />
                  </button>
                </>
              ) : m.self ? (
                <button type="button" onClick={() => void leave(m.id)} className="inline-flex items-center gap-1 text-xs text-ink-400 hover:text-danger">
                  <LogOut size={13} /> Quitter
                </button>
              ) : m.customRoleId && roles?.enabled && roles.roles.find((r) => r.id === m.customRoleId) ? (
                <RoleChip role={roles.roles.find((r) => r.id === m.customRoleId)!} />
              ) : (
                <span className="text-xs text-ink-400">{ROLE_TEXT[m.role]}</span>
              )}
            </li>
          ))}
          {isOwner &&
            team.invites.map((inv) => (
              <li key={inv.id} className="flex items-center gap-2.5 text-xs text-ink-400">
                <span className="flex h-7 w-7 items-center justify-center rounded-full border border-dashed border-ink-600">
                  <UserPlus size={13} />
                </span>
                <span className="min-w-0 flex-1 truncate">
                  Invitation {ROLE_TEXT[inv.role].toLowerCase()} · expire le {new Date(inv.expiresAt).toLocaleDateString("fr-FR", { day: "numeric", month: "short", timeZone: "Europe/Paris" })}
                </span>
                <button type="button" disabled={busy} onClick={() => void call("DELETE", `?inviteId=${inv.id}`)} className="hover:text-danger">
                  Annuler
                </button>
              </li>
            ))}
        </ul>
      )}

      {isOwner && team && (
        <div className="space-y-2 border-t border-ink-800 pt-3">
          {team.limit === 0 ? (
            <p className="text-xs text-ink-400">Ton offre ne permet pas d&apos;inviter des collaborateurs.</p>
          ) : (
            <>
              <div className="flex flex-wrap items-center gap-2">
                <select className="field !h-8 !w-auto text-sm" value={role} onChange={(e) => setRole(e.target.value as "editor" | "viewer")} aria-label="Rôle de l'invité">
                  <option value="editor">Éditeur</option>
                  <option value="viewer">Lecteur</option>
                </select>
                <button
                  type="button"
                  disabled={busy || used >= team.limit}
                  onClick={invite}
                  className="inline-flex h-8 items-center gap-1.5 rounded-md bg-brand-500 px-3 text-sm font-semibold text-ink-950 transition hover:bg-brand-400 disabled:opacity-40"
                >
                  {busy ? <LoaderCircle size={14} className="animate-spin" /> : <UserPlus size={14} />} Créer un lien d&apos;invitation
                </button>
              </div>
              <p className="text-[11px] text-ink-400">
                {ROLE_TEXT[role]} : {ROLE_HINT[role]}. Le lien sert une seule fois et expire au bout de 7 jours.
              </p>
            </>
          )}
          {link && (
            <div className="flex items-center gap-2 rounded-md border border-brand-500/40 bg-brand-500/5 p-1.5 pl-2.5">
              <span className="min-w-0 flex-1 truncate font-mono text-xs text-ink-200">{link}</span>
              <button
                type="button"
                onClick={() =>
                  void navigator.clipboard.writeText(link).then(() => {
                    setCopied(true);
                    setTimeout(() => setCopied(false), 1600);
                  })
                }
                className="inline-flex items-center gap-1 rounded bg-ink-750 px-2 py-1 text-xs text-ink-100 hover:bg-ink-700"
              >
                {copied ? <Check size={13} /> : <Copy size={13} />} {copied ? "Copié" : "Copier"}
              </button>
            </div>
          )}
          {link && <p className="text-[11px] text-ink-400">Envoie ce lien à la personne : il ne sera plus affiché ensuite.</p>}
        </div>
      )}
      {isOwner && roles && rolesFeature !== "off" && (
        <FeatureSection feature="customRoles" title="Rôles personnalisés">
          <RolesManager pageId={pageId} roles={roles.roles} limit={roles.limit} onChange={load} />
        </FeatureSection>
      )}
      {error && <p className="text-xs text-danger">{error}</p>}
    </section>
  );
}
