"use client";

import { useState } from "react";
import { Camera, Crown, Gamepad2, Headphones, LoaderCircle, Megaphone, Music, Palette, PenLine, Pencil, Plus, Shield, Star, Store, Trash2, UserRound, X, type LucideIcon } from "lucide-react";
import { PAGE_PERMISSIONS, PAGE_PERMISSION_KEYS, ROLE_ICONS, type MemberRoleView, type PagePermission, type RoleIcon } from "@/lib/member-roles";
import { isOfficialName, OFFICIAL_NAME_ERROR } from "@/lib/reserved-names";
import { confirmDialog } from "@/lib/confirm";
import { toast } from "@/lib/toast";

export const ROLE_ICON_COMPONENTS: Record<RoleIcon, LucideIcon> = {
  user: UserRound,
  star: Star,
  shield: Shield,
  pen: PenLine,
  megaphone: Megaphone,
  camera: Camera,
  music: Music,
  gamepad: Gamepad2,
  palette: Palette,
  headphones: Headphones,
  store: Store,
  crown: Crown,
};

/** Pastille d'un rôle personnalisé (nom, couleur, icône). */
export function RoleChip({ role }: { role: Pick<MemberRoleView, "name" | "color" | "icon" | "description"> }) {
  const Icon = ROLE_ICON_COMPONENTS[role.icon] ?? UserRound;
  return (
    <span className="inline-flex max-w-full items-center gap-1 rounded-sm border px-1.5 py-px text-[11px] font-medium" style={{ borderColor: `${role.color}66`, color: role.color, background: `${role.color}14` }} title={role.description || role.name}>
      <Icon size={11} aria-hidden="true" />
      <span className="truncate">{role.name}</span>
    </span>
  );
}

type Draft = { id: string | null; name: string; color: string; icon: RoleIcon; description: string; permissions: PagePermission[] };
const EMPTY: Draft = { id: null, name: "", color: "#a78bfa", icon: "star", description: "", permissions: ["content"] };

/** Rôles personnalisés de la page (Link+ et plus) : permissions limitées à cette page. */
export function RolesManager({ pageId, roles, limit, onChange }: { pageId: string; roles: MemberRoleView[]; limit: number; onChange: () => Promise<void> }) {
  const [draft, setDraft] = useState<Draft | null>(null);
  const [busy, setBusy] = useState(false);
  const nameError = draft && draft.name.trim().length >= 2 && isOfficialName(draft.name) ? OFFICIAL_NAME_ERROR : null;

  async function save() {
    if (!draft) return;
    setBusy(true);
    const { id, ...body } = draft;
    const res = await fetch(id ? `/api/me/pages/${pageId}/roles/${id}` : `/api/me/pages/${pageId}/roles`, {
      method: id ? "PATCH" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }).catch(() => null);
    const json = (await res?.json().catch(() => ({}))) as { error?: string };
    setBusy(false);
    if (!res?.ok) {
      toast(json.error ?? "Enregistrement impossible.", { tone: "error" });
      return;
    }
    toast(id ? "Rôle modifié" : "Rôle créé", { tone: "success" });
    setDraft(null);
    await onChange();
  }

  async function remove(role: MemberRoleView) {
    const ok = await confirmDialog({
      title: `Supprimer le rôle « ${role.name} » ?`,
      message: role.members ? `${role.members} membre${role.members > 1 ? "s" : ""} retrouve${role.members > 1 ? "nt" : ""} son rôle de base (Éditeur ou Lecteur).` : "Aucun membre ne l'a.",
      confirmLabel: "Supprimer",
      tone: "danger",
    });
    if (!ok) return;
    const res = await fetch(`/api/me/pages/${pageId}/roles/${role.id}`, { method: "DELETE" }).catch(() => null);
    if (!res?.ok) toast("Suppression impossible.", { tone: "error" });
    await onChange();
  }

  const togglePerm = (p: PagePermission) =>
    setDraft((d) => (d ? { ...d, permissions: d.permissions.includes(p) ? d.permissions.filter((x) => x !== p) : [...d.permissions, p] } : d));

  return (
    <div className="space-y-2 border-t border-ink-800 pt-3">
      <div className="flex items-center justify-between">
        <p className="text-xs font-semibold text-ink-200">Rôles personnalisés</p>
        <span className="font-mono text-[11px] text-ink-500">
          {roles.length}/{limit}
        </span>
      </div>
      {roles.length > 0 && (
        <ul className="space-y-1.5">
          {roles.map((r) => (
            <li key={r.id} className="flex items-center gap-2 text-xs">
              <RoleChip role={r} />
              <span className="min-w-0 flex-1 truncate text-ink-500">
                {r.permissions.length ? r.permissions.map((p) => PAGE_PERMISSIONS[p].label.toLowerCase()).join(", ") : "aucune permission"} · {r.members} membre{r.members > 1 ? "s" : ""}
              </span>
              <button type="button" onClick={() => setDraft({ id: r.id, name: r.name, color: r.color, icon: r.icon, description: r.description, permissions: r.permissions })} className="rounded p-1 text-ink-400 hover:text-ink-100" aria-label={`Modifier ${r.name}`}>
                <Pencil size={12} />
              </button>
              <button type="button" onClick={() => void remove(r)} className="rounded p-1 text-ink-400 hover:text-danger" aria-label={`Supprimer ${r.name}`}>
                <Trash2 size={12} />
              </button>
            </li>
          ))}
        </ul>
      )}
      {!draft && roles.length < limit && (
        <button type="button" onClick={() => setDraft(EMPTY)} className="inline-flex items-center gap-1.5 rounded-md border border-dashed border-ink-600 px-2.5 py-1.5 text-xs text-ink-300 transition-colors hover:border-ink-400 hover:text-ink-100">
          <Plus size={13} /> Nouveau rôle
        </button>
      )}
      {draft && (
        <div className="ui-panel-in space-y-3 rounded-md border border-ink-700 bg-ink-900 p-3">
          <div className="flex items-center justify-between">
            <p className="text-xs font-semibold text-ink-200">{draft.id ? "Modifier le rôle" : "Nouveau rôle"}</p>
            <button type="button" onClick={() => setDraft(null)} className="rounded p-0.5 text-ink-400 hover:text-ink-100" aria-label="Fermer">
              <X size={13} />
            </button>
          </div>
          <div className="flex gap-2">
            <input type="color" value={draft.color} onChange={(e) => setDraft({ ...draft, color: e.target.value })} className="h-8 w-10 shrink-0 cursor-pointer rounded border border-ink-700 bg-transparent" aria-label="Couleur du rôle" />
            <input className="field !h-8 text-sm" value={draft.name} maxLength={24} placeholder="Rédacteur, Gérant, Community manager…" onChange={(e) => setDraft({ ...draft, name: e.target.value })} aria-label="Nom du rôle" />
          </div>
          {nameError && <p className="text-[11px] text-danger">{nameError}</p>}
          <input className="field !h-8 text-xs" value={draft.description} maxLength={120} placeholder="Description (facultatif)" onChange={(e) => setDraft({ ...draft, description: e.target.value })} aria-label="Description du rôle" />
          <div className="flex flex-wrap gap-1" role="radiogroup" aria-label="Icône du rôle">
            {ROLE_ICONS.map((icon) => {
              const Icon = ROLE_ICON_COMPONENTS[icon];
              return (
                <button
                  key={icon}
                  type="button"
                  role="radio"
                  aria-checked={draft.icon === icon}
                  aria-label={icon}
                  onClick={() => setDraft({ ...draft, icon })}
                  className={`flex h-7 w-7 items-center justify-center rounded-md border transition-colors ${draft.icon === icon ? "border-brand-400 bg-brand-500/10 text-ink-100" : "border-ink-700 text-ink-400 hover:text-ink-200"}`}
                >
                  <Icon size={13} />
                </button>
              );
            })}
          </div>
          <fieldset className="space-y-1">
            <legend className="text-[11px] font-medium text-ink-300">Permissions sur cette page</legend>
            {PAGE_PERMISSION_KEYS.map((p) => (
              <label key={p} className="flex cursor-pointer items-start gap-2 text-xs text-ink-300">
                <input type="checkbox" checked={draft.permissions.includes(p)} onChange={() => togglePerm(p)} className="mt-0.5" />
                <span>
                  <span className="text-ink-100">{PAGE_PERMISSIONS[p].label}</span> — {PAGE_PERMISSIONS[p].description}
                </span>
              </label>
            ))}
            <p className="pt-1 text-[11px] text-ink-500">Adresse, équipe, domaines et suppression restent réservés au propriétaire.</p>
          </fieldset>
          <div className="flex items-center justify-between">
            <RoleChip role={{ ...draft, name: draft.name || "Aperçu" }} />
            <button type="button" onClick={() => void save()} disabled={busy || draft.name.trim().length < 2 || Boolean(nameError)} className="inline-flex h-8 items-center gap-1.5 rounded-md bg-brand-500 px-3 text-xs font-semibold text-ink-950 transition-colors hover:bg-brand-400 disabled:opacity-40">
              {busy && <LoaderCircle size={13} className="animate-spin" />} Enregistrer
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
