"use client";

import { useState } from "react";
import { ArrowDown, ArrowUp, Plus, Trash, X } from "lucide-react";
import type { BlockData } from "@/lib/blocks";
import { ImageField, Segmented, Select, TextArea, TextField, Toggle } from "@/components/ui/controls";

type Setter<T> = (patch: Partial<T>) => void;

/** ISO (UTC) → valeur d'un champ datetime-local (heure locale). */
export function toLocalInput(iso: string | null | undefined): string {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return new Date(d.getTime() - d.getTimezoneOffset() * 60_000).toISOString().slice(0, 16);
}

/** Valeur d'un champ datetime-local → ISO (UTC), ou null si vide. */
export function fromLocalInput(value: string): string | null {
  if (!value) return null;
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}

export function DateTimeField({ label, value, onChange, hint }: { label: string; value: string | null; onChange: (iso: string | null) => void; hint?: string }) {
  const id = `dt-${label.replace(/\W+/g, "-")}`;
  return (
    <div className="space-y-1.5">
      <label htmlFor={id} className="text-[0.8rem] font-medium text-ink-200">
        {label}
      </label>
      <div className="flex gap-2">
        <input id={id} type="datetime-local" className="field" value={toLocalInput(value)} onChange={(e) => onChange(fromLocalInput(e.target.value))} />
        {value && (
          <button
            type="button"
            onClick={() => onChange(null)}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md border border-ink-500 text-ink-300 transition hover:text-ink-100"
            aria-label={`Effacer : ${label}`}
          >
            <X size={15} />
          </button>
        )}
      </div>
      {hint && <p className="text-xs text-ink-400">{hint}</p>}
    </div>
  );
}

export function ScheduleFields({
  startsAt,
  endsAt,
  onChange,
}: {
  startsAt: string | null;
  endsAt: string | null;
  onChange: (patch: { startsAt?: string | null; endsAt?: string | null }) => void;
}) {
  const invalid = startsAt && endsAt && Date.parse(endsAt) <= Date.parse(startsAt);
  return (
    <div className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <DateTimeField label="Afficher à partir du" value={startsAt} onChange={(v) => onChange({ startsAt: v })} />
        <DateTimeField label="Masquer après le" value={endsAt} onChange={(v) => onChange({ endsAt: v })} />
      </div>
      {invalid ? (
        <p className="text-xs text-danger" role="alert">La fin doit être après le début.</p>
      ) : (
        <p className="text-xs text-ink-400">Hors de cette période, le bloc reste dans l&apos;éditeur mais disparaît de ta page publique.</p>
      )}
    </div>
  );
}


export function moveItem<T>(list: T[], from: number, to: number): T[] {
  if (to < 0 || to >= list.length) return list;
  const next = [...list];
  const [item] = next.splice(from, 1);
  next.splice(to, 0, item);
  return next;
}

export function ItemTools({ index, count, onMove, onRemove, label }: { index: number; count: number; onMove: (to: number) => void; onRemove: () => void; label: string }) {
  const btn = "flex h-8 w-8 items-center justify-center rounded-md text-ink-400 transition hover:bg-ink-700 hover:text-ink-100 disabled:opacity-30";
  return (
    <div className="flex shrink-0 items-center">
      <button type="button" className={btn} disabled={index === 0} onClick={() => onMove(index - 1)} aria-label={`Monter ${label}`}>
        <ArrowUp size={14} />
      </button>
      <button type="button" className={btn} disabled={index === count - 1} onClick={() => onMove(index + 1)} aria-label={`Descendre ${label}`}>
        <ArrowDown size={14} />
      </button>
      <button type="button" className={`${btn} hover:!text-danger`} onClick={onRemove} aria-label={`Retirer ${label}`}>
        <Trash size={14} />
      </button>
    </div>
  );
}

export const addButton =
  "flex w-full items-center justify-center gap-1.5 rounded-md border border-dashed border-ink-500 py-2 text-sm text-ink-300 transition hover:border-ink-300 hover:text-ink-100";

export function GalleryForm({ data, set }: { data: BlockData<"gallery">; set: Setter<BlockData<"gallery">> }) {
  const images = data.images;
  const update = (i: number, patch: Partial<{ url: string; alt: string }>) =>
    set({ images: images.map((img, j) => (j === i ? { ...img, ...patch } : img)) });
  return (
    <div className="space-y-4">
      <ul className="space-y-3">
        {images.map((img, i) => (
          <li key={i} className="space-y-2 rounded-md border border-ink-700 p-3">
            <div className="flex items-center justify-between">
              <p className="hud-label text-ink-400">Image {i + 1}</p>
              <ItemTools index={i} count={images.length} label={`l'image ${i + 1}`} onMove={(to) => set({ images: moveItem(images, i, to) })} onRemove={() => set({ images: images.filter((_, j) => j !== i) })} />
            </div>
            <ImageField label="Fichier ou adresse" value={img.url} onChange={(url) => update(i, { url })} />
            <TextField label="Description" value={img.alt} maxLength={140} onChange={(alt) => update(i, { alt })} />
          </li>
        ))}
      </ul>
      {images.length < 12 && (
        <button type="button" className={addButton} onClick={() => set({ images: [...images, { url: "", alt: "" }] })}>
          <Plus size={15} /> Ajouter une image
        </button>
      )}
      <Segmented
        label="Disposition"
        value={data.layout}
        onChange={(layout) => set({ layout })}
        options={[
          { value: "grid", label: "Grille" },
          { value: "carousel", label: "Carrousel" },
        ]}
      />
      {data.layout === "grid" && (
        <Segmented
          label="Colonnes"
          value={String(data.columns) as "2" | "3"}
          onChange={(v) => set({ columns: v === "3" ? 3 : 2 })}
          options={[
            { value: "2", label: "2" },
            { value: "3", label: "3" },
          ]}
        />
      )}
    </div>
  );
}

export function FaqForm({ data, set }: { data: BlockData<"faq">; set: Setter<BlockData<"faq">> }) {
  const items = data.items;
  const update = (i: number, patch: Partial<{ question: string; answer: string }>) =>
    set({ items: items.map((item, j) => (j === i ? { ...item, ...patch } : item)) });
  return (
    <div className="space-y-4">
      <ul className="space-y-3">
        {items.map((item, i) => (
          <li key={i} className="space-y-2 rounded-md border border-ink-700 p-3">
            <div className="flex items-center justify-between">
              <p className="hud-label text-ink-400">Question {i + 1}</p>
              <ItemTools index={i} count={items.length} label={`la question ${i + 1}`} onMove={(to) => set({ items: moveItem(items, i, to) })} onRemove={() => set({ items: items.filter((_, j) => j !== i) })} />
            </div>
            <TextField label="Question" value={item.question} maxLength={140} onChange={(question) => update(i, { question })} placeholder="Comment rejoindre ma nation ?" />
            <TextArea label="Réponse" value={item.answer} maxLength={800} rows={3} onChange={(answer) => update(i, { answer })} />
          </li>
        ))}
      </ul>
      {items.length < 12 && (
        <button type="button" className={addButton} onClick={() => set({ items: [...items, { question: "", answer: "" }] })}>
          <Plus size={15} /> Ajouter une question
        </button>
      )}
    </div>
  );
}

export function BadgesForm({ data, set }: { data: BlockData<"badges">; set: Setter<BlockData<"badges">> }) {
  const [draft, setDraft] = useState("");
  const add = () => {
    const values = draft.split(",").map((v) => v.trim().slice(0, 32)).filter(Boolean);
    if (!values.length) return;
    set({ items: [...data.items, ...values].slice(0, 24) });
    setDraft("");
  };
  return (
    <div className="space-y-4">
      <TextField label="Titre (optionnel)" value={data.title} maxLength={60} onChange={(title) => set({ title })} placeholder="Mes rôles" />
      <div className="space-y-1.5">
        <label htmlFor="badge-input" className="text-[0.8rem] font-medium text-ink-200">
          Badges
        </label>
        <div className="flex gap-2">
          <input
            id="badge-input"
            className="field"
            value={draft}
            maxLength={120}
            placeholder="Diplomatie, Construction, Stream…"
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                add();
              }
            }}
          />
          <button type="button" onClick={add} className="h-9 shrink-0 rounded-md border border-ink-500 px-3 text-sm text-ink-200 transition hover:border-ink-300">
            Ajouter
          </button>
        </div>
        <p className="text-xs text-ink-400">Entrée ou virgule pour en ajouter plusieurs. 24 maximum.</p>
      </div>
      {data.items.length > 0 && (
        <ul className="flex flex-wrap gap-1.5">
          {data.items.map((item, i) => (
            <li key={`${item}-${i}`} className="inline-flex items-center gap-1 rounded-full border border-ink-600 bg-ink-750 py-0.5 pr-1 pl-3 text-xs text-ink-100">
              {item}
              <button
                type="button"
                onClick={() => set({ items: data.items.filter((_, j) => j !== i) })}
                className="flex h-5 w-5 items-center justify-center rounded-full text-ink-400 hover:bg-ink-600 hover:text-ink-100"
                aria-label={`Retirer le badge ${item}`}
              >
                <X size={12} />
              </button>
            </li>
          ))}
        </ul>
      )}
      <Segmented
        label="Style"
        value={data.style}
        onChange={(style) => set({ style })}
        options={[
          { value: "soft", label: "Doux" },
          { value: "outline", label: "Contour" },
          { value: "solid", label: "Plein" },
        ]}
      />
    </div>
  );
}

export function CopyForm({ data, set }: { data: BlockData<"copy">; set: Setter<BlockData<"copy">> }) {
  return (
    <div className="space-y-4">
      <TextField label="Intitulé" value={data.label} maxLength={60} onChange={(label) => set({ label })} />
      <TextField label="Valeur copiée" value={data.value} maxLength={200} onChange={(value) => set({ value })} placeholder="play.nationsglory.fr" />
      <TextField label="Précision (optionnelle)" value={data.hint} maxLength={120} onChange={(hint) => set({ hint })} placeholder="Version 1.7.10, serveur Blue" />
    </div>
  );
}


export function PresenceForm({ data, set }: { data: BlockData<"discordPresence">; set: Setter<BlockData<"discordPresence">> }) {
  return (
    <div className="space-y-4">
      <p className="text-xs leading-relaxed text-ink-400">
        Ton statut (en ligne, absent, ne pas déranger), ton statut personnalisé, ton jeu et ta musique Spotify, mis à jour toutes les 30 secondes.
        Il passe par Lanyard : rejoins une fois son serveur Discord (discord.gg/lanyard) avec ton compte pour l&apos;activer.
      </p>
      <Toggle label="Activité en cours" description="Le jeu ou l'application que tu utilises." checked={data.showActivity} onChange={(showActivity) => set({ showActivity })} />
      <Toggle label="Musique Spotify" checked={data.showSpotify} onChange={(showSpotify) => set({ showSpotify })} />
    </div>
  );
}
