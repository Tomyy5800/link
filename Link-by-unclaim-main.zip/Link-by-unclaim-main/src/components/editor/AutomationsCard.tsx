"use client";

import { useMemo, useState } from "react";
import { Eye, EyeOff, Pencil, Plus, Trash2, Wand2, X, Zap } from "lucide-react";
import {
  AUTOMATION_PRESETS,
  BANNER_STYLES,
  MAX_AUTOMATIONS,
  automationSchema,
  describeTrigger,
  pageBirthday,
  triggerActive,
  type Automation,
  type AutomationAction,
  type AutomationTrigger,
} from "@/lib/automations";
import { blockSummary, BLOCK_META, type Block } from "@/lib/blocks";
import type { PageOptions } from "@/lib/page-schema";
import { THEME_PRESETS } from "@/lib/theme";
import { Segmented, Select, TextField } from "@/components/ui/controls";
import { FeatureSection, useFeature } from "./EditorContext";
import { DateTimeField } from "./NewBlockForms";

const DAYS = [
  [1, "L"],
  [2, "M"],
  [3, "M"],
  [4, "J"],
  [5, "V"],
  [6, "S"],
  [0, "D"],
] as const;
const DAY_NAMES = ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"];

const TIMEZONES = [
  ["Europe/Paris", "France, Belgique, Suisse (Paris)"],
  ["Europe/London", "Royaume-Uni (Londres)"],
  ["America/Montreal", "Québec (Montréal)"],
  ["America/Guadeloupe", "Antilles (Guadeloupe, Martinique)"],
  ["America/Cayenne", "Guyane"],
  ["Indian/Reunion", "La Réunion"],
  ["Indian/Mayotte", "Mayotte"],
  ["Pacific/Noumea", "Nouvelle-Calédonie"],
  ["Pacific/Tahiti", "Polynésie (Tahiti)"],
  ["Africa/Casablanca", "Maroc"],
  ["Africa/Algiers", "Algérie, Tunisie"],
  ["Africa/Dakar", "Sénégal, Côte d'Ivoire"],
] as const;

const BANNER_LABELS: Record<(typeof BANNER_STYLES)[number], string> = { accent: "Accent", live: "Live", celebration: "Fête", info: "Info" };
const ACTION_LABELS: Record<AutomationAction["type"], string> = {
  banner: "Afficher un bandeau",
  highlight: "Mettre un bloc en avant",
  hide: "Masquer un bloc",
  theme: "Changer de thème",
};

function newId(): string {
  return typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID().slice(0, 12) : Math.random().toString(36).slice(2, 14);
}

function defaultTrigger(type: AutomationTrigger["type"]): AutomationTrigger {
  switch (type) {
    case "weekly":
      return { type, days: [3], from: "20:00", to: "23:00" };
    case "dates":
      return { type, start: new Date().toISOString(), end: new Date(Date.now() + 7 * 86_400_000).toISOString() };
    default:
      return { type };
  }
}

function defaultAction(type: AutomationAction["type"], blocks: Block[]): AutomationAction {
  switch (type) {
    case "banner":
      return { type, text: "Nouveau bandeau", url: "", style: "accent" };
    case "highlight":
    case "hide":
      return { type, blockId: blocks[0]?.id ?? "" };
    case "theme":
      return { type, preset: "midnight" };
  }
}

function actionSummary(action: AutomationAction, blocks: Block[]): string {
  const block = (id: string) => {
    const b = blocks.find((x) => x.id === id);
    return b ? `« ${blockSummary(b)} »` : "un bloc supprimé";
  };
  switch (action.type) {
    case "banner":
      return `bandeau « ${action.text} »`;
    case "highlight":
      return `met en avant ${block(action.blockId)}`;
    case "hide":
      return `masque ${block(action.blockId)}`;
    case "theme":
      return `thème ${THEME_PRESETS.find((p) => p.key === action.preset)?.label ?? action.preset}`;
  }
}

/** Éditeur d'une règle : déclencheur (« quand ») et jusqu'à trois actions (« alors »). */
function RuleEditor({ rule, blocks, hasBirthday, onChange, onClose }: { rule: Automation; blocks: Block[]; hasBirthday: boolean; onChange: (r: Automation) => void; onClose: () => void }) {
  const t = rule.trigger;
  const setAction = (i: number, action: AutomationAction) => onChange({ ...rule, actions: rule.actions.map((a, j) => (j === i ? action : a)) });
  const blockOptions = blocks.map((b) => ({ value: b.id, label: `${BLOCK_META[b.type].label} · ${blockSummary(b)}`.slice(0, 70) }));
  const check = automationSchema.safeParse(rule);

  return (
    <div className="space-y-4 rounded-md border border-brand-500/30 bg-ink-900 p-3">
      <div className="flex items-center justify-between gap-2">
        <TextField label="Nom" value={rule.name} maxLength={60} onChange={(name) => onChange({ ...rule, name })} placeholder="Stream du mercredi" />
        <button type="button" onClick={onClose} className="mt-5 rounded p-1 text-ink-400 hover:text-ink-100" aria-label="Fermer l'éditeur de la règle">
          <X size={16} />
        </button>
      </div>

      <fieldset className="space-y-2">
        <legend className="hud-label text-[10px] text-brand-300">Quand</legend>
        <Select
          label="Déclencheur"
          value={t.type}
          onChange={(type) => onChange({ ...rule, trigger: defaultTrigger(type as AutomationTrigger["type"]) })}
          options={[
            { value: "weekly", label: "Chaque semaine, à un créneau" },
            { value: "dates", label: "Entre deux dates" },
            { value: "live", label: "Pendant mes lives (Discord)" },
            { value: "birthday", label: "Le jour de mon anniversaire" },
          ]}
        />
        {t.type === "weekly" && (
          <>
            <div className="flex gap-1" role="group" aria-label="Jours">
              {DAYS.map(([day, letter]) => {
                const on = t.days.includes(day);
                return (
                  <button
                    key={day}
                    type="button"
                    aria-pressed={on}
                    title={DAY_NAMES[day]}
                    onClick={() => {
                      const days = on ? t.days.filter((d) => d !== day) : [...t.days, day];
                      if (days.length) onChange({ ...rule, trigger: { ...t, days } });
                    }}
                    className={`h-8 w-8 rounded-md text-xs font-semibold transition ${on ? "bg-brand-500 text-ink-950" : "border border-ink-700 text-ink-400 hover:text-ink-100"}`}
                  >
                    {letter}
                  </button>
                );
              })}
            </div>
            <div className="grid grid-cols-2 gap-2">
              <label className="space-y-1 text-[0.8rem] font-medium text-ink-200">
                De
                <input type="time" className="field" value={t.from} onChange={(e) => e.target.value && onChange({ ...rule, trigger: { ...t, from: e.target.value } })} />
              </label>
              <label className="space-y-1 text-[0.8rem] font-medium text-ink-200">
                À
                <input type="time" className="field" value={t.to} onChange={(e) => e.target.value && onChange({ ...rule, trigger: { ...t, to: e.target.value } })} />
              </label>
            </div>
            {t.to <= t.from && t.to !== t.from && <p className="text-xs text-ink-400">Le créneau passe minuit : il se termine le lendemain à {t.to}.</p>}
          </>
        )}
        {t.type === "dates" && (
          <div className="grid gap-2 sm:grid-cols-2">
            <DateTimeField label="Début" value={t.start} onChange={(v) => v && onChange({ ...rule, trigger: { ...t, start: v } })} />
            <DateTimeField label="Fin" value={t.end} onChange={(v) => v && onChange({ ...rule, trigger: { ...t, end: v } })} />
          </div>
        )}
        {t.type === "live" && (
          <p className="text-xs leading-relaxed text-ink-400">
            Se déclenche quand ton statut Discord passe « en stream » (Twitch ou YouTube relié à Discord). Il faut un compte Discord relié à ton
            compte Unclaim et avoir rejoint le serveur de Lanyard, comme pour le bloc « Statut Discord ».
          </p>
        )}
        {t.type === "birthday" && (
          <p className={`text-xs ${hasBirthday ? "text-ink-400" : "text-claim"}`}>
            {hasBirthday
              ? "Utilise la date de ton bloc compte à rebours en mode anniversaire."
              : "Ajoute d'abord un bloc « Compte à rebours » en mode anniversaire : c'est sa date qui est utilisée."}
          </p>
        )}
      </fieldset>

      <fieldset className="space-y-3">
        <legend className="hud-label text-[10px] text-brand-300">Alors</legend>
        {rule.actions.map((action, i) => (
          <div key={i} className="space-y-2 rounded-md border border-ink-700 p-2.5">
            <div className="flex items-end gap-2">
              <div className="min-w-0 flex-1">
                <Select
                  label={`Action ${i + 1}`}
                  value={action.type}
                  onChange={(type) => setAction(i, defaultAction(type as AutomationAction["type"], blocks))}
                  options={(Object.keys(ACTION_LABELS) as AutomationAction["type"][]).map((value) => ({ value, label: ACTION_LABELS[value] }))}
                />
              </div>
              {rule.actions.length > 1 && (
                <button
                  type="button"
                  onClick={() => onChange({ ...rule, actions: rule.actions.filter((_, j) => j !== i) })}
                  className="mb-1 rounded p-1.5 text-ink-400 hover:text-danger"
                  aria-label={`Retirer l'action ${i + 1}`}
                >
                  <Trash2 size={14} />
                </button>
              )}
            </div>
            {action.type === "banner" && (
              <>
                <TextField label="Texte" value={action.text} maxLength={120} onChange={(text) => setAction(i, { ...action, text })} />
                <TextField
                  label="Lien (facultatif)"
                  value={action.url}
                  inputMode="url"
                  onChange={(url) => setAction(i, { ...action, url: url.trim() })}
                  placeholder={t.type === "live" ? "Vide : le lien de ton live" : "https://…"}
                />
                <Segmented
                  label="Style"
                  value={action.style}
                  onChange={(style) => setAction(i, { ...action, style })}
                  options={BANNER_STYLES.map((value) => ({ value, label: BANNER_LABELS[value] }))}
                />
              </>
            )}
            {(action.type === "highlight" || action.type === "hide") &&
              (blockOptions.length ? (
                <Select label="Bloc" value={action.blockId} onChange={(blockId) => setAction(i, { ...action, blockId })} options={blockOptions} />
              ) : (
                <p className="text-xs text-ink-400">Ajoute d&apos;abord des blocs à ta page.</p>
              ))}
            {action.type === "theme" && (
              <Select
                label="Thème"
                value={action.preset}
                onChange={(preset) => setAction(i, { ...action, preset })}
                options={THEME_PRESETS.map((p) => ({ value: p.key, label: p.label }))}
              />
            )}
          </div>
        ))}
        {rule.actions.length < 3 && (
          <button
            type="button"
            onClick={() => onChange({ ...rule, actions: [...rule.actions, defaultAction("banner", blocks)] })}
            className="inline-flex items-center gap-1.5 text-xs text-brand-300 hover:underline"
          >
            <Plus size={13} /> Ajouter une action
          </button>
        )}
      </fieldset>
      {!check.success && <p className="text-xs text-danger">{check.error.issues[0]?.message}</p>}
    </div>
  );
}

/** Automatisations de la page : la page change toute seule selon l'heure, les lives ou l'anniversaire. */
export function AutomationsCard({
  options,
  onOptionsChange,
  blocks,
  previewRules,
  onPreviewRules,
}: {
  options: PageOptions;
  onOptionsChange: (options: PageOptions) => void;
  blocks: Block[];
  previewRules: string[];
  onPreviewRules: (ids: string[]) => void;
}) {
  const state = useFeature("automations");
  const [editing, setEditing] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);
  const rules = options.automations;
  const set = (automations: Automation[]) => onOptionsChange({ ...options, automations });
  const hasBirthday = pageBirthday({ blocks }) !== null;
  const now = useMemo(() => new Date(), [rules]);

  if (state === "off") return null;

  function add(rule: Omit<Automation, "id">) {
    const id = newId();
    set([...rules, { ...rule, id }]);
    setAdding(false);
    setEditing(id);
  }

  return (
    <section className="hud-panel space-y-3 rounded-[2px] border border-ink-700 bg-ink-850/60 p-4" aria-label="Automatisations">
      <div className="flex items-center justify-between gap-2">
        <h3 className="hud-label inline-flex items-center gap-1.5 text-ink-400">
          <Zap size={13} className="text-claim" aria-hidden="true" /> Automatisations
        </h3>
        <span className="font-mono text-[11px] text-ink-500">
          {rules.length}/{MAX_AUTOMATIONS}
        </span>
      </div>
      <FeatureSection feature="automations" title="Automatisations">
        <div className="space-y-3">
          <p className="text-xs leading-relaxed text-ink-400">
            Ta page change toute seule : un bandeau pendant tes lives, un thème festif le jour de ton anniversaire, un rendez-vous chaque semaine…
          </p>

          {rules.length > 0 && (
            <ul className="space-y-2">
              {rules.map((rule) => {
                const activeNow = rule.enabled && rule.trigger.type !== "live" && triggerActive(rule.trigger, { now, timeZone: options.timezone, live: { on: false, url: null } }, pageBirthday({ blocks }));
                const previewing = previewRules.includes(rule.id);
                return (
                  <li key={rule.id} className="space-y-2">
                    <div className={`flex items-start gap-2 rounded-md border p-2.5 ${rule.enabled ? "border-ink-700" : "border-dashed border-ink-700 opacity-60"}`}>
                      <input
                        type="checkbox"
                        checked={rule.enabled}
                        onChange={(e) => set(rules.map((r) => (r.id === rule.id ? { ...r, enabled: e.target.checked } : r)))}
                        className="mt-1 h-4 w-4 shrink-0 accent-[#22c9e8]"
                        aria-label={`Activer « ${rule.name || "règle"} »`}
                      />
                      <div className="min-w-0 flex-1">
                        <p className="flex flex-wrap items-center gap-1.5 text-sm font-semibold text-ink-100">
                          {rule.name || "Automatisation"}
                          {activeNow && <span className="rounded-sm bg-mint/15 px-1.5 font-mono text-[10px] text-mint">active</span>}
                        </p>
                        <p className="text-xs text-ink-400">
                          {describeTrigger(rule.trigger, options.timezone)} →{rule.actions.map((a) => actionSummary(a, blocks)).join(", ")}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => onPreviewRules(previewing ? previewRules.filter((id) => id !== rule.id) : [...previewRules, rule.id])}
                        aria-pressed={previewing}
                        className={`rounded p-1.5 transition ${previewing ? "bg-brand-500/15 text-brand-300" : "text-ink-400 hover:text-ink-100"}`}
                        title={previewing ? "Ne plus simuler dans l'aperçu" : "Voir dans l'aperçu comme si elle était active"}
                      >
                        {previewing ? <EyeOff size={14} /> : <Eye size={14} />}
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditing(editing === rule.id ? null : rule.id)}
                        className="rounded p-1.5 text-ink-400 hover:text-ink-100"
                        aria-label={`Modifier « ${rule.name || "règle"} »`}
                      >
                        <Pencil size={14} />
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          set(rules.filter((r) => r.id !== rule.id));
                          onPreviewRules(previewRules.filter((id) => id !== rule.id));
                        }}
                        className="rounded p-1.5 text-ink-400 hover:text-danger"
                        aria-label={`Supprimer « ${rule.name || "règle"} »`}
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                    {editing === rule.id && (
                      <RuleEditor
                        rule={rule}
                        blocks={blocks}
                        hasBirthday={hasBirthday}
                        onChange={(next) => set(rules.map((r) => (r.id === rule.id ? next : r)))}
                        onClose={() => setEditing(null)}
                      />
                    )}
                  </li>
                );
              })}
            </ul>
          )}

          {adding ? (
            <div className="space-y-2">
              <p className="text-xs font-medium text-ink-200">Partir d&apos;un modèle :</p>
              <ul className="grid gap-2">
                {AUTOMATION_PRESETS.map((preset) => (
                  <li key={preset.key}>
                    <button
                      type="button"
                      onClick={() => add(preset.build())}
                      className="w-full rounded-md border border-ink-700 p-2.5 text-left transition hover:border-brand-400"
                    >
                      <span className="flex items-center gap-1.5 text-sm font-semibold text-ink-100">
                        <Wand2 size={13} className="text-brand-300" /> {preset.title}
                      </span>
                      <span className="mt-0.5 block text-xs text-ink-400">{preset.text}</span>
                    </button>
                  </li>
                ))}
              </ul>
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => add({ name: "", enabled: true, trigger: defaultTrigger("weekly"), actions: [defaultAction("banner", blocks)] })}
                  className="text-xs text-brand-300 hover:underline"
                >
                  Règle vierge
                </button>
                <button type="button" onClick={() => setAdding(false)} className="text-xs text-ink-400 hover:text-ink-100">
                  Annuler
                </button>
              </div>
            </div>
          ) : (
            rules.length < MAX_AUTOMATIONS && (
              <button
                type="button"
                onClick={() => setAdding(true)}
                className="flex w-full items-center justify-center gap-1.5 rounded-md border border-dashed border-ink-600 py-2 text-sm text-ink-300 transition hover:border-brand-400 hover:text-ink-100"
              >
                <Plus size={15} /> Ajouter une automatisation
              </button>
            )
          )}

          <Select
            label="Fuseau horaire des créneaux"
            value={options.timezone}
            onChange={(timezone) => onOptionsChange({ ...options, timezone })}
            options={[
              ...TIMEZONES.map(([value, label]) => ({ value, label })),
              ...(TIMEZONES.some(([tz]) => tz === options.timezone) ? [] : [{ value: options.timezone, label: options.timezone }]),
            ]}
          />
        </div>
      </FeatureSection>
    </section>
  );
}
