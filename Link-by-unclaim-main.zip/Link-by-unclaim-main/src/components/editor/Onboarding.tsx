"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, ArrowRight, Check, LoaderCircle, LogOut, Lock, Sparkles, X } from "lucide-react";
import { NG_SERVERS, NG_SERVER_KEYS } from "@/lib/nationsglory-shared";
import type { OwnerProfile } from "@/lib/page-schema";
import { providerMeta } from "@/lib/identity";
import { validateSlug } from "@/lib/slug";
import { PAGE_TEMPLATES, getTemplate } from "@/lib/templates";
import { THEME_PRESETS, backgroundStyle, getPreset } from "@/lib/theme";
import { isValidMcUsername } from "@/lib/urls";
import { Logo } from "@/components/brand/Logo";
import { Select, TextField } from "@/components/ui/controls";

type Props = {
  owner: OwnerProfile;
  suggestedSlug: string;
  host: string;
  /** Adresses de 3 ou 4 caractères autorisées pour ce compte. */
  allowShortSlug: boolean;
  premiumName: string;
  /** Création de pages fermée par l'administration. */
  closed: boolean;
  /** Pages dont le compte est déjà propriétaire. */
  existingPages: number;
  pageLimit: number;
  /** Link+ permettrait d'en créer davantage. */
  canUpgrade: boolean;
  /** L'adresse vient de la landing (« Revendique ton adresse »). */
  claimed?: boolean;
  /** Modèle choisi dans la galerie de la landing. */
  initialTemplate?: string;
};
type Availability = { state: "idle" | "checking" | "free" | "taken"; message?: string };

/** Création de la page : adresse, nom affiché, pseudo NationsGlory et thème de départ. */
export function Onboarding({
  owner,
  suggestedSlug,
  host,
  allowShortSlug,
  premiumName,
  closed,
  existingPages,
  pageLimit,
  canUpgrade,
  claimed = false,
  initialTemplate,
}: Props) {
  const router = useRouter();
  const limitReached = existingPages >= pageLimit;
  const [label, setLabel] = useState("");
  const [slug, setSlug] = useState(suggestedSlug);
  const [displayName, setDisplayName] = useState(owner.globalName ?? owner.username);
  // Connexion NationsGlory : le pseudo est déjà prouvé, on le reprend.
  const [ngUsername, setNgUsername] = useState(owner.ngAccount ?? "");
  const [ngServer, setNgServer] = useState("blue");
  const startTemplate = initialTemplate ?? (owner.ngAccount ? "joueur" : "minimal");
  const [template, setTemplate] = useState(startTemplate);
  const [preset, setPreset] = useState(getTemplate(startTemplate)?.preset ?? "unclaim");
  const [fromLanding, setFromLanding] = useState(claimed);

  // Adresse revendiquée sur la landing avant la connexion (l'URL de retour a pu la perdre).
  useEffect(() => {
    try {
      const stored = localStorage.getItem("lbu:claim");
      localStorage.removeItem("lbu:claim");
      if (!claimed && stored && validateSlug(stored, { allowShort: allowShortSlug }).ok) {
        setSlug(stored);
        setFromLanding(true);
      }
    } catch {
      // stockage indisponible : l'adresse suggérée reste
    }
  }, [claimed, allowShortSlug]);
  const [availability, setAvailability] = useState<Availability>({ state: "idle" });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const local = validateSlug(slug, { allowShort: allowShortSlug, premiumName });
  const ngInvalid = ngUsername !== "" && !isValidMcUsername(ngUsername);

  useEffect(() => {
    if (!local.ok) return;
    const controller = new AbortController();
    setAvailability({ state: "checking" });
    const timer = setTimeout(() => {
      fetch(`/api/slugs/check?slug=${encodeURIComponent(local.slug)}`, { signal: controller.signal })
        .then((r) => r.json() as Promise<{ available: boolean; error?: string }>)
        .then((json) => setAvailability(json.available ? { state: "free" } : { state: "taken", message: json.error }))
        .catch(() => undefined);
    }, 350);
    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [local.ok, local.ok ? local.slug : null]);

  const canSubmit = !closed && !limitReached && local.ok && availability.state === "free" && displayName.trim() && !ngInvalid && !submitting;

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (!canSubmit || !local.ok) return;
    setSubmitting(true);
    setError(null);
    const res = await fetch("/api/me/pages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ slug: local.slug, displayName: displayName.trim(), label: label.trim(), ngUsername, ngServer, preset, template }),
    });
    const json = (await res.json().catch(() => ({}))) as { error?: string; id?: string };
    if (res.ok && json.id) {
      router.push(`/dashboard/pages/${json.id}?bienvenue=1`);
      return;
    }
    setError(json.error ?? "La création a échoué.");
    setSubmitting(false);
  }

  const slugStatus = !slug
    ? null
    : !local.ok
      ? { ok: false, text: local.error }
      : availability.state === "checking"
        ? { ok: null, text: "Vérification…" }
        : availability.state === "taken"
          ? { ok: false, text: availability.message ?? "Adresse déjà prise." }
          : availability.state === "free"
            ? { ok: true, text: "Adresse disponible !" }
            : null;

  return (
    <div className="bg-hud min-h-screen">
      <header className="mx-auto flex max-w-5xl items-center justify-between px-4 py-5">
        <Logo />
        {existingPages > 0 ? (
          <a href="/dashboard" className="inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm text-ink-300 transition hover:text-ink-100">
            <ArrowLeft size={15} /> Mon espace
          </a>
        ) : (
        <form action="/api/auth/logout" method="post">
          <button type="submit" className="inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm text-ink-400 transition hover:text-ink-100">
            <LogOut size={15} /> Déconnexion
          </button>
        </form>
        )}
      </header>

      <main className="mx-auto max-w-xl px-4 pt-6 pb-20 animate-rise">
        <div className="flex items-center gap-3">
          <img src={owner.avatarUrl} alt="" className="h-12 w-12 rounded-full ring-2 ring-ink-700" />
          <div>
            <p className="text-sm text-ink-400">Connecté·e via Unclaim Auth · {providerMeta(owner.provider).name}</p>
            <p className="font-semibold">{owner.globalName ?? owner.discordUsername ?? "Nouveau membre"}</p>
          </div>
        </div>
        <h1 className="mt-6 font-display text-3xl font-bold tracking-tight">{existingPages ? "Nouvelle page" : "Crée ta page"}</h1>
        <p className="mt-2 text-ink-300">
          {existingPages
            ? "Une page par projet, équipe, serveur ou partenariat : chacune a son adresse, son style et ses statistiques."
            : "Tu pourras tout modifier ensuite dans l'éditeur."}
        </p>
        {!limitReached && !closed && (
          <a
            href="/dashboard/assistant"
            className="group mt-6 flex items-center gap-4 rounded-md border border-brand-500/40 bg-brand-500/10 p-4 transition hover:border-brand-400"
          >
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-brand-500 text-ink-950">
              <Sparkles size={20} aria-hidden="true" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block font-semibold text-ink-100">Créer avec l&apos;assistant</span>
              <span className="block text-sm text-ink-300">Réponds à quelques questions, ta page se construit sous tes yeux. Moins de cinq minutes.</span>
            </span>
            <ArrowRight size={18} className="shrink-0 text-brand-300" aria-hidden="true" />
          </a>
        )}
        {limitReached && !closed && (
          <div role="status" className="mt-6 space-y-2 rounded-md border border-claim/40 bg-claim/10 p-4 text-sm text-ink-100">
            <p className="flex gap-2">
              <Lock size={16} className="mt-0.5 shrink-0 text-claim" aria-hidden="true" />
              {pageLimit === 1 ? "Ton offre comprend une page." : `Tu as atteint la limite de ${pageLimit} pages de ton offre.`}
            </p>
            {canUpgrade && (
              <a href="/plus" className="inline-flex items-center gap-1.5 font-semibold text-claim hover:underline">
                {premiumName} permet d&apos;en créer davantage <ArrowRight size={14} />
              </a>
            )}
          </div>
        )}
        {closed && (
          <p role="status" className="mt-6 flex gap-2 rounded-md border border-claim/40 bg-claim/10 p-3 text-sm text-ink-100">
            <Lock size={16} className="mt-0.5 shrink-0 text-claim" aria-hidden="true" />
            La création de nouvelles pages est momentanément fermée. Reviens un peu plus tard !
          </p>
        )}

        <form onSubmit={submit} className="mt-8 space-y-6">
          <div className="space-y-1.5">
            <TextField label="Ton adresse" value={slug} prefix={`${host}/`} maxLength={30} onChange={(v) => setSlug(v.toLowerCase().replace(/\s+/g, "-"))} />
            {slugStatus && (
              <p
                className={`flex items-center gap-1.5 text-xs ${
                  slugStatus.ok === true ? "text-mint" : slugStatus.ok === false ? "text-danger" : "text-ink-400"
                }`}
                aria-live="polite"
              >
                {slugStatus.ok === true ? <Check size={13} /> : slugStatus.ok === false ? <X size={13} /> : <LoaderCircle size={13} className="animate-spin" />}
                {slugStatus.text}
              </p>
            )}
            {fromLanding && (
              <p className="animate-rise flex items-center gap-1.5 text-xs text-claim">
                <Sparkles size={13} /> L&apos;adresse que tu as revendiquée sur l&apos;accueil : il ne reste qu&apos;à valider.
              </p>
            )}
          </div>

          <TextField label="Nom affiché" value={displayName} maxLength={48} onChange={setDisplayName} />

          {existingPages > 0 && (
            <TextField
              label="Nom dans « Mon espace » (facultatif)"
              value={label}
              maxLength={40}
              onChange={setLabel}
              placeholder="Ma team, Partenariat X…"
              hint="Pour t'y retrouver entre tes pages ; il n'apparaît pas sur la page publique."
            />
          )}

          <TextField
            label="Pseudo NationsGlory (optionnel)"
            value={ngUsername}
            maxLength={16}
            onChange={(v) => setNgUsername(v.trim())}
            placeholder="Ton pseudo en jeu"
            error={ngInvalid ? "2 à 16 caractères : lettres, chiffres et _." : null}
            hint="Ajoute automatiquement ton profil de jeu et ton skin 3D à la page."
          />
          {ngUsername && !ngInvalid && (
            <Select
              label="Serveur principal"
              value={ngServer}
              onChange={setNgServer}
              options={NG_SERVER_KEYS.map((value) => ({ value, label: NG_SERVERS[value].label }))}
            />
          )}

          <fieldset>
            <legend className="mb-2 text-[0.8rem] font-medium text-ink-200">Modèle</legend>
            <div className="grid gap-2 sm:grid-cols-2">
              {PAGE_TEMPLATES.map((t) => {
                const theme = getPreset(t.preset)?.theme;
                const active = template === t.id;
                return (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => {
                      setTemplate(t.id);
                      setPreset(t.preset);
                    }}
                    aria-pressed={active}
                    className={`flex items-stretch gap-3 rounded-md border p-2 text-left transition ${active ? "border-brand-400 ring-2 ring-brand-500/30" : "border-ink-700 hover:border-ink-500"}`}
                  >
                    <span className="w-12 shrink-0 rounded" style={theme ? backgroundStyle(theme) : undefined} aria-hidden="true">
                      <span className="mx-1.5 mt-2 block h-1.5 rounded-full" style={{ background: theme?.accent }} />
                      <span className="mx-1.5 mt-1 block h-1.5 rounded-full opacity-60" style={{ background: theme?.text }} />
                    </span>
                    <span className="min-w-0 py-0.5">
                      <span className="block text-sm font-semibold text-ink-100">{t.name}</span>
                      <span className="block text-xs leading-snug text-ink-400">{t.description}</span>
                    </span>
                  </button>
                );
              })}
            </div>
          </fieldset>

          <fieldset>
            <legend className="mb-2 text-[0.8rem] font-medium text-ink-200">Thème de départ</legend>
            <div className="grid grid-cols-4 gap-2 sm:grid-cols-7">
              {THEME_PRESETS.map((p) => (
                <button
                  key={p.key}
                  type="button"
                  onClick={() => setPreset(p.key)}
                  aria-pressed={preset === p.key}
                  title={p.label}
                  className={`overflow-hidden rounded-md border p-1 transition ${preset === p.key ? "border-brand-400 ring-2 ring-brand-500/30" : "border-ink-700 hover:border-ink-500"}`}
                >
                  <div className="flex h-12 items-end rounded-lg p-1.5" style={backgroundStyle(p.theme)}>
                    <span className="h-1.5 w-full rounded-full" style={{ background: p.theme.accent }} />
                  </div>
                  <span className="mt-1 block truncate text-[0.68rem] text-ink-300">{p.label}</span>
                </button>
              ))}
            </div>
          </fieldset>

          {error && (
            <p role="alert" className="rounded-md border border-danger/30 bg-danger/10 p-3 text-sm text-red-200">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={!canSubmit}
            className="group flex w-full items-center justify-center gap-2 rounded-md bg-brand-500 px-5 py-3 font-semibold text-ink-950 transition hover:bg-brand-400 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {submitting ? <LoaderCircle size={18} className="animate-spin" /> : null}
            {existingPages ? "Créer cette page" : "Créer ma page"}
            {!submitting && <ArrowRight size={18} />}
          </button>
        </form>
      </main>
    </div>
  );
}
