"use client";

import { Castle, ImageIcon } from "lucide-react";
import type { OwnerProfile, Profile } from "@/lib/page-schema";
import { NG_SERVERS, NG_SERVER_KEYS } from "@/lib/nationsglory-shared";
import { isValidMcUsername } from "@/lib/urls";
import { ProviderIcon } from "@/components/auth/ProviderButton";
import { providerMeta } from "@/lib/identity";
import { ImageField, Select, TextField } from "@/components/ui/controls";
import { FORMAT_HINT } from "./BlockForm";
import { RichTextArea } from "./RichTextArea";

type Props = { profile: Profile; owner: OwnerProfile; onChange: (profile: Profile) => void };

export function ProfilePanel({ profile, owner, onChange }: Props) {
  const set = (patch: Partial<Profile>) => onChange({ ...profile, ...patch });
  const ngInvalid = profile.ngUsername !== "" && !isValidMcUsername(profile.ngUsername);

  const sources = [
    // « discord » = avatar du compte de connexion (Discord, ou Google, Microsoft, Twitch…).
    {
      value: "discord" as const,
      label: owner.discordId ? "Discord" : providerMeta(owner.provider).name,
      icon: <ProviderIcon provider={owner.discordId ? "discord" : owner.provider} size={16} />,
      preview: owner.avatarUrl,
      pixelated: false,
    },
    {
      value: "nationsglory" as const,
      label: "Skin NG",
      icon: <Castle size={16} />,
      preview: profile.ngUsername && !ngInvalid ? `/api/skin/${encodeURIComponent(profile.ngUsername)}?type=face&size=64` : null,
      pixelated: true,
    },
    { value: "custom" as const, label: "Image", icon: <ImageIcon size={16} />, preview: profile.avatarUrl || null, pixelated: false },
  ];

  return (
    <div className="space-y-5">
      <TextField
        label="Nom affiché"
        value={profile.displayName}
        maxLength={48}
        onChange={(displayName) => set({ displayName })}
        error={profile.displayName.trim() ? null : "Le nom affiché est obligatoire."}
      />
      <TextField label="Pronoms (optionnel)" value={profile.pronouns} maxLength={40} onChange={(pronouns) => set({ pronouns })} placeholder="il/lui, elle/iel…" />
      <RichTextArea
        label="Présentation"
        value={profile.bio}
        maxLength={600}
        rows={5}
        onChange={(bio) => set({ bio })}
        placeholder="Qui es-tu, sur quel serveur joues-tu, qu'est-ce que tu crées ?"
        hint={FORMAT_HINT}
      />

      <TextField
        label="Pseudo NationsGlory"
        value={profile.ngUsername}
        maxLength={16}
        onChange={(ngUsername) => set({ ngUsername: ngUsername.trim() })}
        placeholder="Ton pseudo en jeu"
        error={ngInvalid ? "2 à 16 caractères : lettres, chiffres et _." : null}
        hint="Utilisé par défaut par les blocs NationsGlory et Skin 3D, et affiché en badge."
      />
      <Select
        label="Serveur NationsGlory principal"
        value={profile.ngServer}
        onChange={(ngServer) => set({ ngServer })}
        options={NG_SERVER_KEYS.map((value) => ({ value, label: NG_SERVERS[value].label }))}
      />

      <div className="space-y-2">
        <p className="text-[0.8rem] font-medium text-ink-200">Avatar</p>
        <div className="grid grid-cols-3 gap-2" role="radiogroup" aria-label="Source de l'avatar">
          {sources.map((source) => {
            const active = profile.avatarSource === source.value;
            const disabled = source.value === "nationsglory" && !source.preview;
            return (
              <button
                key={source.value}
                type="button"
                role="radio"
                aria-checked={active}
                disabled={disabled}
                title={disabled ? "Renseigne d'abord ton pseudo NationsGlory" : undefined}
                onClick={() => set({ avatarSource: source.value })}
                className={`flex flex-col items-center gap-2 rounded-md border p-3 text-xs font-medium transition disabled:cursor-not-allowed disabled:opacity-40 ${
                  active ? "border-brand-400 bg-brand-500/10 text-ink-100" : "border-ink-700 text-ink-300 hover:border-ink-500"
                }`}
              >
                {source.preview ? (
                  <img src={source.preview} alt="" className={`h-11 w-11 rounded-full object-cover ${source.pixelated ? "pixelated" : ""}`} />
                ) : (
                  <span className="flex h-11 w-11 items-center justify-center rounded-full bg-ink-750 text-ink-400">{source.icon}</span>
                )}
                <span className="inline-flex items-center gap-1">{source.label}</span>
              </button>
            );
          })}
        </div>
        {profile.avatarSource === "custom" && (
          <ImageField label="Image d'avatar" value={profile.avatarUrl} onChange={(avatarUrl) => set({ avatarUrl })} hint="Carrée de préférence." />
        )}
      </div>

      <ImageField
        label="Bannière (optionnelle)"
        value={profile.bannerUrl}
        onChange={(bannerUrl) => set({ bannerUrl })}
        hint={owner.bannerUrl ? "Sinon, ta bannière Discord est utilisée." : "Sinon, un dégradé de ta couleur d'accent est utilisé."}
      />
    </div>
  );
}
