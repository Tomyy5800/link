"use client";

import { useEffect, useRef, useState } from "react";
import { Check, X } from "lucide-react";
import { celebrate } from "@/lib/confetti";
import type { Block } from "@/lib/blocks";
import type { Profile } from "@/lib/page-schema";
import { toSafeHref } from "@/lib/urls";

type Tab = "blocs" | "profil" | "apparence" | "reglages";

/** Étapes faites en dehors du brouillon (ouvrir sa page, copier son lien), mémorisées dans le navigateur. */
export function markStep(slug: string, step: "visited" | "shared") {
  try {
    localStorage.setItem(`lbu:step:${slug}:${step}`, "1");
    window.dispatchEvent(new Event("lbu:steps"));
  } catch {
    // stockage indisponible : l'étape sera simplement proposée à nouveau
  }
}

function readStep(slug: string, step: string): boolean {
  try {
    return localStorage.getItem(`lbu:step:${slug}:${step}`) === "1";
  } catch {
    return false;
  }
}

/** Nombre de liens utilisables sur la page (boutons, réseaux, dossiers). */
function countLinks(blocks: Block[]): number {
  let n = 0;
  for (const b of blocks) {
    if (b.type === "link" && toSafeHref(b.data.url)) n++;
    if (b.type === "socials") n += b.data.items.filter((i) => toSafeHref(i.url)).length;
    if (b.type === "collection") n += b.data.links.filter((l) => toSafeHref(l.url)).length;
  }
  return n;
}

/** Liste « Premiers pas » : guide les nouveaux comptes, disparaît une fois tout fait ou masquée. */
export function GettingStarted({ slug, profile, blocks, onGo }: { slug: string; profile: Profile; blocks: Block[]; onGo: (tab: Tab) => void }) {
  const [, setTick] = useState(0);
  const [hidden, setHidden] = useState(true);

  useEffect(() => {
    const refresh = () => setTick((t) => t + 1);
    setHidden(readStep(slug, "dismissed"));
    window.addEventListener("lbu:steps", refresh);
    return () => window.removeEventListener("lbu:steps", refresh);
  }, [slug]);

  const steps: { label: string; done: boolean; action?: () => void; actionLabel?: string }[] = [
    { label: "Écris ta présentation", done: profile.bio.trim().length > 0, action: () => onGo("profil"), actionLabel: "Profil" },
    { label: "Ajoute au moins 3 liens ou réseaux", done: countLinks(blocks) >= 3 },
    { label: "Ouvre ta page publique", done: readStep(slug, "visited"), action: () => window.open(`/${slug}`, "_blank"), actionLabel: "Voir" },
    { label: "Copie ton lien pour le partager", done: readStep(slug, "shared"), action: () => onGo("reglages"), actionLabel: "Réglages" },
  ];
  const done = steps.filter((s) => s.done).length;
  const complete = done === steps.length;

  // Dernière étape franchie pendant la session : on fête ça, puis la liste s'efface.
  const previous = useRef<number | null>(null);
  const [celebrating, setCelebrating] = useState(false);
  useEffect(() => {
    const before = previous.current;
    previous.current = done;
    if (hidden || before === null || before >= steps.length || !complete) return;
    setCelebrating(true);
    celebrate();
    const timer = window.setTimeout(() => setCelebrating(false), 6000);
    return () => window.clearTimeout(timer);
  }, [done, complete, hidden, steps.length]);

  if (celebrating) {
    return (
      <section className="animate-pop mb-4 flex items-center gap-3 rounded-xl border border-mint/40 bg-[linear-gradient(120deg,rgba(0,188,125,0.15),rgba(34,201,232,0.1))] p-4" role="status">
        <span className="ui-wave text-2xl" aria-hidden="true">
          🏆
        </span>
        <span>
          <span className="block text-sm font-semibold text-ink-100">Premiers pas terminés !</span>
          <span className="block text-xs text-ink-300">Ta page est prête : colle ton lien dans ta bio et regarde les visites arriver.</span>
        </span>
      </section>
    );
  }
  if (hidden || complete) return null;

  return (
    <section className="mb-4 rounded-xl border border-brand-500/30 bg-brand-500/5 p-3" aria-label="Premiers pas">
      <div className="flex items-center justify-between">
        <p className="text-sm font-semibold text-ink-100">
          Premiers pas <span className="font-mono text-xs font-normal text-ink-400">{done}/{steps.length}</span>
        </p>
        <button
          type="button"
          onClick={() => {
            try {
              localStorage.setItem(`lbu:step:${slug}:dismissed`, "1");
            } catch {
              // ignoré
            }
            setHidden(true);
          }}
          className="rounded p-1 text-ink-400 hover:text-ink-100"
          aria-label="Masquer les premiers pas"
        >
          <X size={14} />
        </button>
      </div>
      <div className="mt-2 h-1 overflow-hidden rounded-full bg-ink-700" aria-hidden="true">
        <div
          className="h-full rounded-full bg-gradient-to-r from-brand-500 to-mint shadow-[0_0_10px_rgba(34,201,232,0.7)] transition-[width] duration-700 ease-[cubic-bezier(0.16,1,0.3,1)]"
          style={{ width: `${(done / steps.length) * 100}%` }}
        />
      </div>
      <ul className="mt-3 space-y-1.5">
        {steps.map((step) => (
          <li key={step.label} className="flex items-center gap-2 text-xs">
            <span
              className={`flex h-4 w-4 shrink-0 items-center justify-center rounded-full transition-colors ${step.done ? "animate-pop bg-mint text-ink-950" : "border border-ink-500"}`}
              aria-hidden="true"
            >
              {step.done && <Check size={11} strokeWidth={3} />}
            </span>
            <span className={step.done ? "text-ink-400 line-through" : "text-ink-200"}>{step.label}</span>
            {!step.done && step.action && (
              <button type="button" onClick={step.action} className="ml-auto text-brand-300 hover:underline">
                {step.actionLabel}
              </button>
            )}
          </li>
        ))}
      </ul>
    </section>
  );
}
