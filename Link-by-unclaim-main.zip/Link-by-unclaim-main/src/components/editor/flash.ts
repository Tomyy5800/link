// Fait briller un bloc dans la liste de l'éditeur et dans l'aperçu (ajout, duplication,
// restauration), puis amène l'aperçu jusqu'à lui.

export function flashBlock(id: string): void {
  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  // Deux images : le bloc vient d'être ajouté à l'état, le DOM n'est pas encore à jour.
  requestAnimationFrame(() =>
    requestAnimationFrame(() => {
      const cell = document.querySelector<HTMLElement>(`[data-block="${CSS.escape(id)}"]`);
      cell?.scrollIntoView({ behavior: reduced ? "auto" : "smooth", block: "nearest" });
      if (reduced) return;
      for (const el of [document.getElementById(`block-${id}`), cell]) {
        el?.animate(
          [
            { boxShadow: "0 0 0 2px rgb(34 201 232 / 0.95), 0 0 28px rgb(34 201 232 / 0.55)" },
            { boxShadow: "0 0 0 2px rgb(34 201 232 / 0), 0 0 28px rgb(34 201 232 / 0)" },
          ],
          { duration: 1500, easing: "cubic-bezier(0.16, 1, 0.3, 1)" },
        );
      }
    }),
  );
}
