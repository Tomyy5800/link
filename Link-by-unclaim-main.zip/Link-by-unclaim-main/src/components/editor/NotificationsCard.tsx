"use client";

import { useEffect, useState } from "react";
import { Bell, Check, LoaderCircle, Send, Trash2 } from "lucide-react";
import { DISCORD_WEBHOOK } from "@/lib/notifications";
import { Toggle } from "@/components/ui/controls";
import { FeatureSection, useFeature } from "./EditorContext";

type State = { allowed: boolean; configured: boolean; masked: string; onMessage: boolean; onOrder: boolean; weekly: boolean };

/** Notifications Discord : nouveaux messages de contact et bilan de la semaine dans un salon. */
export function NotificationsCard({ pageId }: { pageId: string }) {
  const feature = useFeature("webhooks");
  const [state, setState] = useState<State | null>(null);
  const [webhook, setWebhook] = useState("");
  const [status, setStatus] = useState<{ kind: "idle" | "busy" | "ok" | "error"; text?: string }>({ kind: "idle" });

  useEffect(() => {
    if (feature === "off") return;
    fetch(`/api/me/pages/${pageId}/notifications`, { cache: "no-store" })
      .then((r) => (r.ok ? (r.json() as Promise<State>) : null))
      .then((s) => s && setState(s))
      .catch(() => undefined);
  }, [pageId, feature]);

  if (feature === "off") return null;

  async function save(patch: Partial<{ discordWebhook: string | null; onMessage: boolean; onOrder: boolean; weekly: boolean }>, done?: string) {
    if (!state) return;
    setStatus({ kind: "busy" });
    const res = await fetch(`/api/me/pages/${pageId}/notifications`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ onMessage: state.onMessage, onOrder: state.onOrder, weekly: state.weekly, ...patch }),
    }).catch(() => null);
    const json = (await res?.json().catch(() => null)) as (State & { error?: string }) | null;
    if (!res?.ok || !json || json.error) {
      setStatus({ kind: "error", text: json?.error ?? "Enregistrement impossible." });
      return;
    }
    setState(json);
    setWebhook("");
    setStatus({ kind: "ok", text: done ?? "Enregistré." });
  }

  async function test() {
    setStatus({ kind: "busy" });
    const res = await fetch(`/api/me/pages/${pageId}/notifications`, { method: "POST" }).catch(() => null);
    const json = (await res?.json().catch(() => ({}))) as { error?: string };
    setStatus(res?.ok ? { kind: "ok", text: "Message de test envoyé : regarde ton salon Discord." } : { kind: "error", text: json.error ?? "Envoi impossible." });
  }

  const invalid = webhook !== "" && !DISCORD_WEBHOOK.test(webhook.trim());

  return (
    <section className="space-y-3 rounded-lg border border-ink-700 bg-ink-850/60 p-4" aria-label="Notifications Discord">
      <h3 className="hud-label inline-flex items-center gap-1.5 text-ink-400">
        <Bell size={13} className="text-brand-300" aria-hidden="true" /> Notifications Discord
      </h3>
      <FeatureSection feature="webhooks" title="Notifications Discord">
        <div className="space-y-3">
          <p className="text-xs leading-relaxed text-ink-400">
            Reçois dans un salon de ton serveur les nouveaux messages de contact et le bilan de la semaine. Dans Discord : Paramètres du salon › Intégrations ›
            Webhooks › Nouveau webhook › Copier l&apos;URL.
          </p>
          {state?.configured && (
            <div className="flex items-center gap-2 rounded-md border border-mint/30 bg-mint/5 px-2.5 py-1.5">
              <Check size={14} className="shrink-0 text-mint" />
              <span className="min-w-0 flex-1 truncate font-mono text-[11px] text-ink-200">{state.masked}</span>
              <button type="button" onClick={test} disabled={status.kind === "busy"} className="inline-flex items-center gap-1 text-xs text-brand-300 hover:underline">
                <Send size={12} /> Tester
              </button>
              <button
                type="button"
                onClick={() => save({ discordWebhook: null }, "Webhook retiré.")}
                disabled={status.kind === "busy"}
                className="rounded p-1 text-ink-400 hover:text-danger"
                aria-label="Retirer le webhook"
              >
                <Trash2 size={13} />
              </button>
            </div>
          )}
          <div className="flex gap-2">
            <input
              className="field min-w-0 flex-1 font-mono text-xs"
              value={webhook}
              onChange={(e) => setWebhook(e.target.value)}
              placeholder={state?.configured ? "Remplacer par une autre adresse…" : "https://discord.com/api/webhooks/…"}
              aria-label="Adresse du webhook Discord"
              aria-invalid={invalid || undefined}
              autoComplete="off"
              spellCheck={false}
            />
            <button
              type="button"
              disabled={!webhook.trim() || invalid || status.kind === "busy" || !state}
              onClick={() => save({ discordWebhook: webhook.trim() }, "Webhook enregistré. Envoie un test pour vérifier.")}
              className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-md bg-brand-500 px-3 text-sm font-semibold text-ink-950 transition hover:bg-brand-400 disabled:opacity-40"
            >
              {status.kind === "busy" ? <LoaderCircle size={14} className="animate-spin" /> : "Enregistrer"}
            </button>
          </div>
          {invalid && <p className="text-xs text-danger">Ce n&apos;est pas une adresse de webhook Discord.</p>}
          {state && (
            <>
              <Toggle
                label="Nouveaux messages de contact"
                checked={state.onMessage}
                onChange={(onMessage) => {
                  setState({ ...state, onMessage });
                  void save({ onMessage });
                }}
              />
              <Toggle
                label="Nouvelles commandes de la boutique"
                checked={state.onOrder}
                onChange={(onOrder) => {
                  setState({ ...state, onOrder });
                  void save({ onOrder });
                }}
              />
              <Toggle
                label="Bilan de la semaine"
                description="Vues, clics, messages et lien le plus cliqué, une fois par semaine."
                checked={state.weekly}
                onChange={(weekly) => {
                  setState({ ...state, weekly });
                  void save({ weekly });
                }}
              />
            </>
          )}
          {status.text && <p className={`text-xs ${status.kind === "error" ? "text-danger" : "text-mint"}`}>{status.text}</p>}
        </div>
      </FeatureSection>
    </section>
  );
}
