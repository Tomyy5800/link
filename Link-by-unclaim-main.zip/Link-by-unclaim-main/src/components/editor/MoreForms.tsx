"use client";

import { useState } from "react";
import { Check, Plus, Radio, Smile } from "lucide-react";
import { MUSIC_PLATFORMS, type BlockData, type MusicPlatform } from "@/lib/blocks";
import { daysInMonth } from "@/lib/birthday";
import { RADIO_PRESETS, RADIO_PRESET_IDS, resolveRadio } from "@/lib/radio";
import { normalizeUrl } from "@/lib/urls";
import { ImageField, Segmented, Select, TextField, Toggle } from "@/components/ui/controls";
import { MUSIC_LABELS } from "@/components/page/blocks/MoreBlocks";
import { useNowPlaying } from "@/components/page/blocks/RadioBlock";
import { DateTimeField, ItemTools, addButton, moveItem } from "./NewBlockForms";
import { EmojiPicker } from "./RichTextArea";

type Setter<T> = (patch: Partial<T>) => void;

const MONTHS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];

function urlError(value: string): string | null {
  return value && normalizeUrl(value) === null ? "Adresse invalide (http, https ou mailto)." : null;
}

/** Champ d'émoji court avec sélecteur. */
export function EmojiField({ value, onChange, label = "Émoji" }: { value: string; onChange: (v: string) => void; label?: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <span className="mb-1.5 block text-[0.8rem] font-medium text-ink-200">{label}</span>
      <div className="flex gap-1.5">
        <input className="field !w-16 text-center text-lg" value={value} maxLength={16} onChange={(e) => onChange(e.target.value.trim())} placeholder="—" aria-label={label} />
        <button
          type="button"
          onClick={() => setOpen(!open)}
          className="flex h-9 w-9 items-center justify-center rounded-md border border-ink-700 text-ink-300 hover:border-ink-500 hover:text-ink-100"
          aria-label="Choisir un émoji"
        >
          <Smile size={16} />
        </button>
      </div>
      {open && (
        <EmojiPicker
          onPick={(emoji) => {
            onChange(emoji);
            setOpen(false);
          }}
          onClose={() => setOpen(false)}
        />
      )}
    </div>
  );
}

// ─── Radio ──────────────────────────────────────────────────────────────────

function PresetCard({ id, active, onChoose }: { id: string; active: boolean; onChoose: () => void }) {
  const station = RADIO_PRESETS[id];
  const now = useNowPlaying(station.nowPlaying, true);
  return (
    <button
      type="button"
      onClick={onChoose}
      aria-pressed={active}
      className={`flex w-full items-center gap-3 rounded-md border p-3 text-left transition ${active ? "border-brand-400 bg-brand-500/10" : "border-ink-700 hover:border-ink-500"}`}
    >
      {now?.art ? (
        <img src={now.art} alt="" className="h-11 w-11 shrink-0 rounded-md object-cover" />
      ) : (
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-md bg-ink-750 text-brand-300">
          <Radio size={20} />
        </span>
      )}
      <span className="min-w-0 flex-1">
        <span className="flex items-center gap-1.5 text-sm font-semibold text-ink-100">
          {station.name}
          {now?.online !== false && <span className="h-1.5 w-1.5 rounded-full bg-red-500" aria-label="En direct" />}
        </span>
        <span className="block truncate text-xs text-ink-400">{now?.title ? `${now.title} · ${now.artist ?? ""}` : station.tagline}</span>
      </span>
      {active && <Check size={16} className="shrink-0 text-brand-300" />}
    </button>
  );
}

export function RadioForm({ data, set }: { data: BlockData<"radio">; set: Setter<BlockData<"radio">> }) {
  const custom = !RADIO_PRESET_IDS.includes(data.station);
  const resolved = custom && data.station ? resolveRadio(data.station) : null;
  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <p className="text-[0.8rem] font-medium text-ink-200">Radio</p>
        {RADIO_PRESET_IDS.map((id) => (
          <PresetCard key={id} id={id} active={data.station === id} onChoose={() => set({ station: id })} />
        ))}
        <button
          type="button"
          onClick={() => set({ station: custom ? data.station : "" })}
          aria-pressed={custom}
          className={`w-full rounded-md border p-3 text-left text-sm transition ${custom ? "border-brand-400 bg-brand-500/10 text-ink-100" : "border-ink-700 text-ink-300 hover:border-ink-500"}`}
        >
          Une autre radio (AzuraCast ou flux https)
        </button>
      </div>
      {custom && (
        <>
          <TextField
            label="Adresse de la radio"
            value={data.station}
            inputMode="url"
            maxLength={500}
            onChange={(station) => set({ station: station.trim() })}
            placeholder="https://radio.exemple.fr/public/ma-radio"
            error={data.station && !resolved ? "Adresse https attendue." : null}
            hint={
              resolved?.nowPlaying
                ? "Radio AzuraCast reconnue : titre en cours, pochette et auditeurs affichés."
                : "Page publique AzuraCast (titre en cours affiché) ou adresse directe d'un flux https (.mp3, Icecast…)."
            }
          />
          <TextField label="Nom affiché" value={data.name} maxLength={60} onChange={(name) => set({ name })} placeholder="Ma radio" />
        </>
      )}
      <Toggle label="Titre en cours et pochette" checked={data.showNowPlaying} onChange={(showNowPlaying) => set({ showNowPlaying })} />
      <Toggle label="Nombre d'auditeurs" checked={data.showListeners} onChange={(showListeners) => set({ showListeners })} />
      <Toggle label="Derniers titres diffusés" checked={data.showHistory} onChange={(showHistory) => set({ showHistory })} />
      <p className="text-xs text-ink-400">La radio ne démarre jamais toute seule : le visiteur appuie sur lecture. La musique de fond se met en pause pendant l&apos;écoute.</p>
    </div>
  );
}

// ─── Écouter partout ────────────────────────────────────────────────────────

/** Devine la plateforme d'après l'adresse collée. */
function detectMusicPlatform(url: string): MusicPlatform | null {
  const host = (() => {
    try {
      return new URL(normalizeUrl(url) ?? "").hostname.replace(/^www\./, "");
    } catch {
      return "";
    }
  })();
  if (host.endsWith("spotify.com")) return "spotify";
  if (host === "music.apple.com") return "applemusic";
  if (host.endsWith("deezer.com") || host === "deezer.page.link") return "deezer";
  if (host === "music.youtube.com") return "youtubemusic";
  if (host.endsWith("youtube.com") || host === "youtu.be") return "youtube";
  if (host.endsWith("soundcloud.com")) return "soundcloud";
  if (host.endsWith("tidal.com")) return "tidal";
  if (host.endsWith("bandcamp.com")) return "bandcamp";
  return null;
}

export function MusicForm({ data, set }: { data: BlockData<"music">; set: Setter<BlockData<"music">> }) {
  const links = data.links;
  const update = (i: number, patch: Partial<{ platform: MusicPlatform; url: string }>) => set({ links: links.map((l, j) => (j === i ? { ...l, ...patch } : l)) });
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <TextField label="Titre" value={data.title} maxLength={80} onChange={(title) => set({ title })} placeholder="Nom du morceau" />
        <TextField label="Artiste" value={data.artist} maxLength={80} onChange={(artist) => set({ artist })} />
      </div>
      <ImageField label="Pochette" value={data.cover} onChange={(cover) => set({ cover })} />
      <ul className="space-y-2">
        {links.map((link, i) => (
          <li key={i} className="flex items-start gap-2">
            <select
              className="field !w-[9.5rem] shrink-0"
              value={link.platform}
              aria-label="Plateforme"
              onChange={(e) => update(i, { platform: e.target.value as MusicPlatform })}
            >
              {MUSIC_PLATFORMS.map((p) => (
                <option key={p} value={p}>
                  {p === "other" ? "Autre" : MUSIC_LABELS[p]}
                </option>
              ))}
            </select>
            <input
              className="field min-w-0 flex-1"
              value={link.url}
              inputMode="url"
              placeholder="https://…"
              aria-label={`Lien ${MUSIC_LABELS[link.platform]}`}
              aria-invalid={urlError(link.url) ? true : undefined}
              onChange={(e) => {
                const url = e.target.value;
                const guess = detectMusicPlatform(url);
                update(i, guess ? { url, platform: guess } : { url });
              }}
            />
            <ItemTools index={i} count={links.length} label={`le lien ${i + 1}`} onMove={(to) => set({ links: moveItem(links, i, to) })} onRemove={() => set({ links: links.filter((_, j) => j !== i) })} />
          </li>
        ))}
      </ul>
      {links.length < 10 && (
        <button type="button" className={addButton} onClick={() => set({ links: [...links, { platform: "spotify", url: "" }] })}>
          <Plus size={15} /> Ajouter une plateforme
        </button>
      )}
      <p className="text-xs text-ink-400">Colle un lien : la plateforme est reconnue toute seule.</p>
    </div>
  );
}

// ─── Agenda ─────────────────────────────────────────────────────────────────

export function EventsForm({ data, set }: { data: BlockData<"events">; set: Setter<BlockData<"events">> }) {
  const items = data.items;
  type Item = (typeof items)[number];
  const update = (i: number, patch: Partial<Item>) => set({ items: items.map((it, j) => (j === i ? { ...it, ...patch } : it)) });
  return (
    <div className="space-y-4">
      <TextField label="Titre" value={data.title} maxLength={60} onChange={(title) => set({ title })} placeholder="Agenda" />
      <ul className="space-y-3">
        {items.map((item, i) => (
          <li key={i} className="space-y-2 rounded-md border border-ink-700 p-3">
            <div className="flex items-start gap-2">
              <div className="min-w-0 flex-1">
                <TextField label={`Événement ${i + 1}`} value={item.title} maxLength={80} onChange={(title) => update(i, { title })} placeholder="Stream du mercredi" />
              </div>
              <div className="pt-6">
                <ItemTools index={i} count={items.length} label={`l'événement ${i + 1}`} onMove={(to) => set({ items: moveItem(items, i, to) })} onRemove={() => set({ items: items.filter((_, j) => j !== i) })} />
              </div>
            </div>
            <div className="grid gap-2 sm:grid-cols-2">
              <DateTimeField label="Début" value={item.start || null} onChange={(v) => update(i, { start: v ?? "" })} />
              <DateTimeField label="Fin (facultatif)" value={item.end || null} onChange={(v) => update(i, { end: v ?? "" })} />
            </div>
            <div className="grid gap-2 sm:grid-cols-2">
              <TextField label="Lieu (facultatif)" value={item.location} maxLength={80} onChange={(location) => update(i, { location })} placeholder="Twitch, serveur Blue…" />
              <TextField label="Lien (facultatif)" value={item.url} inputMode="url" onChange={(url) => update(i, { url })} error={urlError(item.url)} />
            </div>
          </li>
        ))}
      </ul>
      {items.length < 20 && (
        <button type="button" className={addButton} onClick={() => set({ items: [...items, { title: "", start: "", end: "", location: "", url: "" }] })}>
          <Plus size={15} /> Ajouter un événement
        </button>
      )}
      <Toggle label="Masquer les événements passés" checked={data.hidePast} onChange={(hidePast) => set({ hidePast })} />
      <Toggle label="Bouton « Ajouter à mon agenda »" checked={data.showAddToCalendar} onChange={(showAddToCalendar) => set({ showAddToCalendar })} />
      <p className="text-xs text-ink-400">Les horaires s&apos;affichent à l&apos;heure de chaque visiteur, comme les dates Discord.</p>
    </div>
  );
}

// ─── Dossier de liens ───────────────────────────────────────────────────────

export function CollectionForm({ data, set }: { data: BlockData<"collection">; set: Setter<BlockData<"collection">> }) {
  const links = data.links;
  type Link = (typeof links)[number];
  const update = (i: number, patch: Partial<Link>) => set({ links: links.map((l, j) => (j === i ? { ...l, ...patch } : l)) });
  return (
    <div className="space-y-4">
      <TextField label="Titre du dossier" value={data.title} maxLength={60} onChange={(title) => set({ title })} placeholder="Mes créations" />
      <TextField label="Description (facultative)" value={data.description} maxLength={140} onChange={(description) => set({ description })} />
      <ul className="space-y-3">
        {links.map((link, i) => (
          <li key={i} className="flex items-end gap-2">
            <EmojiField value={link.emoji} onChange={(emoji) => update(i, { emoji })} label="" />
            <div className="min-w-0 flex-1 space-y-2">
              <input className="field" value={link.label} maxLength={80} onChange={(e) => update(i, { label: e.target.value })} placeholder="Texte du lien" aria-label={`Texte du lien ${i + 1}`} />
              <input
                className="field"
                value={link.url}
                inputMode="url"
                onChange={(e) => update(i, { url: e.target.value })}
                placeholder="https://…"
                aria-label={`Adresse du lien ${i + 1}`}
                aria-invalid={urlError(link.url) ? true : undefined}
              />
            </div>
            <ItemTools index={i} count={links.length} label={`le lien ${i + 1}`} onMove={(to) => set({ links: moveItem(links, i, to) })} onRemove={() => set({ links: links.filter((_, j) => j !== i) })} />
          </li>
        ))}
      </ul>
      {links.length < 12 && (
        <button type="button" className={addButton} onClick={() => set({ links: [...links, { label: "", url: "", emoji: "" }] })}>
          <Plus size={15} /> Ajouter un lien
        </button>
      )}
      <Toggle label="Ouvert par défaut" checked={data.open} onChange={(open) => set({ open })} />
    </div>
  );
}

// ─── Compte à rebours et anniversaire ──────────────────────────────────────

/** Année de naissance : saisie libre, enregistrée seulement une fois complète et plausible. */
function BirthYearField({ value, onChange }: { value: number | null; onChange: (year: number | null) => void }) {
  const [text, setText] = useState(value ? String(value) : "");
  const thisYear = new Date().getFullYear();
  const year = Number(text);
  const invalid = text.length === 4 && (year < 1900 || year > thisYear);
  return (
    <TextField
      label="Année (facultatif)"
      value={text}
      maxLength={4}
      inputMode="numeric"
      placeholder="2008"
      error={invalid ? `Entre 1900 et ${thisYear}` : undefined}
      onChange={(v) => {
        const digits = v.replace(/\D/g, "").slice(0, 4);
        setText(digits);
        const y = Number(digits);
        if (digits === "") onChange(null);
        else if (digits.length === 4 && y >= 1900 && y <= thisYear) onChange(y);
      }}
    />
  );
}

export function CountdownForm({ data, set }: { data: BlockData<"countdown">; set: Setter<BlockData<"countdown">> }) {
  const [month, day] = data.birthday ? data.birthday.split("-") : ["", ""];
  // Un jour qui n'existe pas dans le mois choisi (31 avril…) est ramené au dernier jour du mois.
  const setBirthday = (m: string, d: string) => {
    if (!m || !d) return set({ birthday: "" });
    const max = daysInMonth(Number(m));
    set({ birthday: `${m}-${String(Math.min(Number(d), max)).padStart(2, "0")}` });
  };
  const dayCount = month ? daysInMonth(Number(month)) : 31;
  return (
    <div className="space-y-4">
      <Segmented
        label="Type"
        value={data.mode}
        onChange={(mode) => set({ mode })}
        options={[
          { value: "date", label: "Une date" },
          { value: "birthday", label: "Mon anniversaire" },
        ]}
      />
      {data.mode === "birthday" ? (
        <>
          <div className="grid grid-cols-[1fr_1.4fr_1fr] gap-2">
            <Select
              label="Jour"
              value={day}
              onChange={(d) => setBirthday(month || "01", d)}
              options={[{ value: "", label: "—" }, ...Array.from({ length: dayCount }, (_, i) => ({ value: String(i + 1).padStart(2, "0"), label: String(i + 1) }))]}
            />
            <Select
              label="Mois"
              value={month}
              onChange={(m) => setBirthday(m, day || "01")}
              options={[{ value: "", label: "—" }, ...MONTHS.map((name, i) => ({ value: String(i + 1).padStart(2, "0"), label: name }))]}
            />
            <BirthYearField value={data.birthYear} onChange={(birthYear) => set({ birthYear })} />
          </div>
          {data.birthYear !== null && <Toggle label="Afficher mon âge" checked={data.showAge} onChange={(showAge) => set({ showAge })} />}
          <TextField label="Titre" value={data.title} maxLength={80} onChange={(title) => set({ title })} placeholder="Mon anniversaire" />
          <TextField label="Message le jour J" value={data.birthdayText} maxLength={80} onChange={(birthdayText) => set({ birthdayText })} />
          <p className="text-xs text-ink-400">Le compte à rebours repart tout seul chaque année. Le jour J, des confettis s&apos;affichent toute la journée.</p>
        </>
      ) : (
        <>
          <TextField label="Titre" value={data.title} maxLength={80} onChange={(title) => set({ title })} placeholder="Guerre contre l'Empire" />
          <DateTimeField label="Date et heure" value={data.target || null} onChange={(v) => set({ target: v ?? "" })} hint="À ton heure locale." />
          <TextField label="Message une fois la date passée" value={data.endedText} maxLength={80} onChange={(endedText) => set({ endedText })} />
        </>
      )}
      <Segmented
        label="Affichage"
        value={data.style}
        onChange={(style) => set({ style })}
        options={[
          { value: "boxes", label: "Cases" },
          { value: "inline", label: "Une ligne" },
        ]}
      />
    </div>
  );
}
