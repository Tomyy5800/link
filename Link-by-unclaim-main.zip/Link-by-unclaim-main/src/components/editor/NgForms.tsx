"use client";

import { useEffect, useId, useState } from "react";
import { Check, LoaderCircle, Search, X } from "lucide-react";
import type { BlockData } from "@/lib/blocks";
import { NG_SERVERS, NG_SERVER_KEYS, ngServerMeta, type NgCountrySummary } from "@/lib/nationsglory-shared";
import { isValidMcUsername } from "@/lib/urls";
import { Field, Select, TextField, Toggle } from "@/components/ui/controls";
import { useEditorEnv } from "./EditorContext";

type Setter<T> = (patch: Partial<T>) => void;

function usernameError(value: string) {
  return value && !isValidMcUsername(value) ? "2 à 16 caractères : lettres, chiffres et _." : null;
}

/** Avertit quand les données NationsGlory ne sont pas réelles (démo) ou pas disponibles (clé absente). */
export function NgModeNotice() {
  const { ngMode } = useEditorEnv();
  if (ngMode === "live") return null;
  return (
    <p className="rounded-md border border-claim/30 bg-claim/5 px-3 py-2 text-xs leading-relaxed text-ink-300">
      {ngMode === "mock"
        ? "Mode démonstration : les données NationsGlory affichées sont fictives tant que la clé d'API n'est pas branchée."
        : "La connexion à l'API NationsGlory n'est pas encore active : le bloc s'affichera dès qu'elle le sera."}
    </p>
  );
}

/** Choix de 1 à 3 serveurs, sous forme de pastilles. */
function ServerChips({ value, onChange, fallback }: { value: string[]; onChange: (servers: string[]) => void; fallback: string }) {
  const toggle = (server: string) => {
    if (value.includes(server)) onChange(value.filter((s) => s !== server));
    else if (value.length < 3) onChange([...value, server]);
  };
  return (
    <Field
      label="Serveurs affichés"
      hint={
        value.length
          ? `${value.length}/3 serveurs. L'ordre de sélection est l'ordre d'affichage.`
          : `Aucun choisi : le serveur principal du profil (${ngServerMeta(fallback).label}) est utilisé.`
      }
    >
      <div className="flex flex-wrap gap-1.5" role="group" aria-label="Serveurs NationsGlory">
        {NG_SERVER_KEYS.map((server) => {
          const meta = NG_SERVERS[server];
          const on = value.includes(server);
          const disabled = !on && value.length >= 3;
          return (
            <button
              key={server}
              type="button"
              aria-pressed={on}
              disabled={disabled}
              onClick={() => toggle(server)}
              className={`inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-xs font-medium transition disabled:opacity-35 ${
                on ? "border-brand-400/70 bg-brand-500/10 text-ink-100" : "border-ink-700 text-ink-300 hover:border-ink-500 hover:text-ink-100"
              }`}
            >
              <span className="h-2 w-2 rounded-full" style={{ background: meta.color }} aria-hidden="true" />
              {meta.label}
              {on && <Check size={12} aria-hidden="true" />}
            </button>
          );
        })}
      </div>
    </Field>
  );
}

export function NationsGloryForm({ data, set }: { data: BlockData<"nationsglory">; set: Setter<BlockData<"nationsglory">> }) {
  const { ngUsername, ngServer } = useEditorEnv();
  return (
    <div className="space-y-4">
      <NgModeNotice />
      <TextField
        label="Pseudo NationsGlory"
        value={data.username}
        maxLength={16}
        onChange={(username) => set({ username: username.trim() })}
        placeholder={ngUsername ? `Pseudo du profil : ${ngUsername}` : "Ton pseudo en jeu"}
        error={usernameError(data.username)}
        hint="Laisse vide pour utiliser le pseudo défini dans ton profil."
      />
      <ServerChips value={data.servers} onChange={(servers) => set({ servers })} fallback={ngServer} />
      <Toggle label="Rang dans le pays" checked={data.showRole} onChange={(showRole) => set({ showRole })} />
      <Toggle label="Dernière connexion" checked={data.showLastLogin} onChange={(showLastLogin) => set({ showLastLogin })} />
    </div>
  );
}

/** Recherche d'un pays dans la liste du serveur ; saisie libre du nom si la liste est indisponible. */
function CountryPicker({ server, data, set }: { server: string; data: BlockData<"ngCountry">; set: Setter<BlockData<"ngCountry">> }) {
  const id = useId();
  const [query, setQuery] = useState(data.country);
  const [open, setOpen] = useState(false);
  const [state, setState] = useState<{ loading: boolean; results: NgCountrySummary[]; available: boolean }>({
    loading: false,
    results: [],
    available: true,
  });

  useEffect(() => {
    if (!open) return;
    const controller = new AbortController();
    const timer = window.setTimeout(() => {
      setState((s) => ({ ...s, loading: true }));
      fetch(`/api/nationsglory/countries/${server}?q=${encodeURIComponent(query.trim())}`, { signal: controller.signal })
        .then((r) => (r.ok ? r.json() : Promise.reject(new Error(String(r.status)))))
        .then((json: { results: NgCountrySummary[]; total: number }) =>
          setState({ loading: false, results: json.results, available: json.total > 0 }),
        )
        .catch((error: unknown) => {
          if ((error as Error).name !== "AbortError") setState({ loading: false, results: [], available: false });
        });
    }, 250);
    return () => {
      controller.abort();
      window.clearTimeout(timer);
    };
  }, [open, query, server]);

  const choose = (country: NgCountrySummary) => {
    set({ countryId: country.countryId, country: country.name });
    setQuery(country.name);
    setOpen(false);
  };

  return (
    <Field
      label="Pays"
      htmlFor={id}
      hint={
        data.countryId
          ? "Pays relié : la carte suit ses changements de nom."
          : state.available
            ? "Cherche ton pays dans la liste du serveur."
            : "Liste des pays indisponible pour le moment : saisis le nom exact du pays."
      }
    >
      <div className="relative">
        <Search size={15} className="pointer-events-none absolute top-1/2 left-2.5 -translate-y-1/2 text-ink-500" aria-hidden="true" />
        <input
          id={id}
          className="field !pl-8"
          value={query}
          maxLength={64}
          placeholder="Nom du pays"
          role="combobox"
          aria-expanded={open}
          aria-controls={`${id}-list`}
          aria-autocomplete="list"
          onFocus={() => setOpen(true)}
          onBlur={() => window.setTimeout(() => setOpen(false), 150)}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
            // Saisie libre : le pays sera résolu par son nom côté serveur.
            set({ country: e.target.value, countryId: "" });
          }}
        />
        {state.loading && <LoaderCircle size={15} className="absolute top-1/2 right-2.5 -translate-y-1/2 animate-spin text-ink-400" />}
        {open && state.results.length > 0 && (
          <ul
            id={`${id}-list`}
            role="listbox"
            className="scrollbar-thin absolute inset-x-0 top-full z-30 mt-1 max-h-64 overflow-y-auto rounded-md border border-ink-700 bg-ink-850 p-1 shadow-2xl shadow-black/50"
          >
            {state.results.map((country) => (
              <li key={country.countryId} role="option" aria-selected={country.countryId === data.countryId}>
                <button
                  type="button"
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={() => choose(country)}
                  className="flex w-full items-center gap-2.5 rounded-[4px] px-2 py-1.5 text-left text-sm text-ink-100 hover:bg-ink-750"
                >
                  {country.flagUrl ? (
                    <img src={country.flagUrl} alt="" className="pixelated h-4 w-6 shrink-0 rounded-[2px] object-cover" />
                  ) : (
                    <span className="h-4 w-6 shrink-0 rounded-[2px] bg-ink-700" aria-hidden="true" />
                  )}
                  <span className="min-w-0 flex-1 truncate">{country.name}</span>
                  <span className="shrink-0 font-mono text-[11px] text-ink-400">{country.membersCount} membres</span>
                </button>
              </li>
            ))}
          </ul>
        )}
        {data.countryId && (
          <button
            type="button"
            onClick={() => {
              set({ countryId: "", country: "" });
              setQuery("");
            }}
            className="absolute top-1/2 right-1.5 flex h-6 w-6 -translate-y-1/2 items-center justify-center rounded text-ink-400 hover:text-ink-100"
            aria-label="Effacer le pays"
          >
            <X size={14} />
          </button>
        )}
      </div>
    </Field>
  );
}

export function NgCountryForm({ data, set }: { data: BlockData<"ngCountry">; set: Setter<BlockData<"ngCountry">> }) {
  return (
    <div className="space-y-4">
      <NgModeNotice />
      <Select
        label="Serveur"
        value={data.server}
        onChange={(server) => set({ server, countryId: "" })}
        options={NG_SERVER_KEYS.map((value) => ({ value, label: NG_SERVERS[value].label }))}
      />
      {/* La clé remet le champ à zéro quand on change de serveur. */}
      <CountryPicker key={data.server} server={data.server} data={data} set={set} />
      <Toggle label="Description du pays" checked={data.showDescription} onChange={(showDescription) => set({ showDescription })} />
      <Toggle label="Membres" checked={data.showMembers} onChange={(showMembers) => set({ showMembers })} />
    </div>
  );
}
