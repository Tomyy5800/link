"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowRight, Check, Copy, Inbox, LoaderCircle, Share2, TriangleAlert, UserRound } from "lucide-react";
import { type Block } from "@/lib/blocks";
import type { PageOptions } from "@/lib/page-schema";
import { validateSlug } from "@/lib/slug";
import { TextArea, TextField, Toggle } from "@/components/ui/controls";
import { FeatureSection, useFeature } from "./EditorContext";
import { DateTimeField } from "./NewBlockForms";
import { useEditorEnv } from "./EditorContext";
import { markStep } from "./GettingStarted";
import { PlusCard } from "./PlusCard";
import { ShareQr } from "./ShareQr";
import { StatsCard } from "./StatsCard";
import { AutomationsCard } from "./AutomationsCard";
import { DomainsCard } from "./DomainsCard";
import { NotificationsCard } from "./NotificationsCard";
import { TeamCard } from "./TeamCard";

type Props = {
  pageId: string;
  /** Rôle du compte connecté sur la page (le propriétaire seul change l'adresse ou supprime). */
  role: "owner" | "editor";
  label: string;
  slug: string;
  host: string;
  appUrl: string;
  published: boolean;
  options: PageOptions;
  onOptionsChange: (options: PageOptions) => void;
  onPublishedChange: (published: boolean) => void;
  onSlugChange: (slug: string) => void;
  blocks: Block[];
  previewRules: string[];
  onPreviewRules: (ids: string[]) => void;
};

function Card({ title, children, hud }: { title: string; children: React.ReactNode; hud?: boolean }) {
  return (
    <section className={`space-y-4 border border-ink-700 bg-ink-850/60 p-4 ${hud ? "hud-panel rounded-[2px]" : "rounded-lg"}`}>
      <h3 className="hud-label text-ink-400">{title}</h3>
      {children}
    </section>
  );
}

export function SettingsPanel(props: Props) {
  const { pageId, role, slug, host, appUrl, published, options } = props;
  const isOwner = role === "owner";
  const setOption = (patch: Partial<PageOptions>) => props.onOptionsChange({ ...options, ...patch });
  const redirectState = useFeature("redirect");
  const { entitlements } = useEditorEnv();
  const router = useRouter();
  const [slugDraft, setSlugDraft] = useState(slug);
  const [slugState, setSlugState] = useState<{ status: "idle" | "saving" | "error" | "saved"; message?: string }>({ status: "idle" });
  const [copied, setCopied] = useState(false);
  const [label, setLabel] = useState(props.label);
  const [labelState, setLabelState] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const [confirmDelete, setConfirmDelete] = useState("");
  const [deleting, setDeleting] = useState(false);

  const url = `${appUrl}/${slug}`;
  const local = validateSlug(slugDraft, { allowShort: entitlements.features.shortSlug, premiumName: entitlements.premiumName, allowOfficial: entitlements.admin });
  const [remote, setRemote] = useState<{ slug: string; available: boolean; error?: string } | null>(null);

  // Disponibilité vérifiée en direct par le serveur (pages existantes, anciennes adresses réservées).
  const candidate = local.ok && local.slug !== slug ? local.slug : null;
  useEffect(() => {
    if (!candidate) return;
    const timer = setTimeout(async () => {
      const res = await fetch(`/api/slugs/check?slug=${encodeURIComponent(candidate)}`).catch(() => null);
      const json = (await res?.json().catch(() => null)) as { available?: boolean; error?: string } | null;
      if (json) setRemote({ slug: candidate, available: Boolean(json.available), error: json.error });
    }, 350);
    return () => clearTimeout(timer);
  }, [candidate]);
  const remoteError = remote && local.ok && remote.slug === local.slug && !remote.available ? (remote.error ?? "Cette adresse est déjà prise.") : null;
  const remoteOk = remote && local.ok && remote.slug === local.slug && remote.available;

  async function saveSlug() {
    if (!local.ok || local.slug === slug) return;
    setSlugState({ status: "saving" });
    const res = await fetch(`/api/me/pages/${pageId}/slug`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ slug: local.slug }),
    });
    const json = (await res.json().catch(() => ({}))) as { slug?: string; error?: string };
    if (!res.ok || !json.slug) {
      setSlugState({ status: "error", message: json.error ?? "Changement impossible." });
      return;
    }
    props.onSlugChange(json.slug);
    setSlugDraft(json.slug);
    setSlugState({
      status: "saved",
      message: options.redirectOldSlugs
        ? "Adresse mise à jour. L'ancienne redirige vers la nouvelle et reste réservée 30 jours."
        : "Adresse mise à jour. L'ancienne reste réservée 30 jours mais ne redirige pas.",
    });
  }

  async function share() {
    if (navigator.share) {
      await navigator.share({ url, title: label || slug }).catch(() => undefined);
      return;
    }
    await navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  }

  async function saveLabel() {
    if (label.trim() === props.label) return;
    setLabelState("saving");
    const res = await fetch(`/api/me/pages/${pageId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ label: label.trim() }),
    }).catch(() => null);
    setLabelState(res?.ok ? "saved" : "error");
  }

  async function deletePage() {
    setDeleting(true);
    const res = await fetch(`/api/me/pages/${pageId}`, { method: "DELETE" });
    if (res.ok) router.push("/dashboard");
    else setDeleting(false);
  }

  return (
    <div className="space-y-4">
      {isOwner && <PlusCard entitlements={entitlements} />}

      <Card title="Adresse de ta page" hud>
        <div className="flex items-center gap-2 rounded-md border border-ink-700 bg-ink-900 p-1.5 pl-3">
          <span className="min-w-0 flex-1 truncate font-mono text-sm text-ink-200">
            {host}/<span className="text-brand-300">{slug}</span>
          </span>
          <button
            type="button"
            onClick={() => {
              void navigator.clipboard.writeText(url).then(() => {
                markStep(slug, "shared");
                setCopied(true);
                setTimeout(() => setCopied(false), 1600);
              });
            }}
            className="inline-flex items-center gap-1.5 rounded-lg bg-ink-750 px-2.5 py-1.5 text-xs font-medium text-ink-100 transition hover:bg-ink-700"
          >
            {copied ? <Check size={14} /> : <Copy size={14} />} {copied ? "Copié" : "Copier"}
          </button>
          <button
            type="button"
            onClick={() => void share()}
            className="inline-flex items-center gap-1.5 rounded-lg bg-ink-750 px-2.5 py-1.5 text-xs font-medium text-ink-100 transition-colors hover:bg-ink-700"
            aria-label="Partager le lien"
          >
            <Share2 size={14} /> Partager
          </button>
        </div>
        <p className="font-mono text-[11px] text-ink-500">
          Aussi joignable en {host}/profil/{slug}
        </p>
        <p className="text-xs leading-relaxed text-ink-400">
          Colle ce lien partout où tu as une bio : Discord (Paramètres → Profils → À propos de moi), Twitch, TikTok, Instagram, YouTube… Il
          s&apos;affiche avec un aperçu aux couleurs de ta page.
        </p>
        {isOwner && <div className="flex items-start gap-2">
          <div className="min-w-0 flex-1">
            <TextField
              label="Changer d'adresse"
              value={slugDraft}
              prefix={`${host}/`}
              maxLength={30}
              onChange={(v) => {
                setSlugDraft(v.toLowerCase());
                setSlugState({ status: "idle" });
              }}
              error={slugState.status === "error" ? slugState.message : slugDraft && !local.ok ? local.error : remoteError}
              hint={slugState.status === "saved" ? slugState.message : remoteOk ? "Adresse disponible." : undefined}
            />
          </div>
          <button
            type="button"
            onClick={saveSlug}
            disabled={!local.ok || local.slug === slug || slugState.status === "saving" || Boolean(remoteError)}
            className="mt-[26px] h-9 shrink-0 rounded-md bg-brand-500 px-3 text-sm font-semibold text-ink-950 transition hover:bg-brand-400 disabled:opacity-40"
          >
            {slugState.status === "saving" ? <LoaderCircle size={15} className="animate-spin" /> : "Valider"}
          </button>
        </div>}
        {isOwner && (
          <Toggle
            label="Rediriger les anciennes adresses"
            description="Après un changement, les liens déjà partagés mènent à la nouvelle adresse (personne d'autre ne peut reprendre l'ancienne pendant 30 jours)."
            checked={options.redirectOldSlugs}
            onChange={(redirectOldSlugs) => setOption({ redirectOldSlugs })}
          />
        )}
        <TextField
          label="Nom dans « Mon espace » (facultatif)"
          value={label}
          maxLength={40}
          onChange={(v) => {
            setLabel(v);
            setLabelState("idle");
          }}
          onBlur={saveLabel}
          placeholder="Ma team, Partenariat X…"
          hint={labelState === "saved" ? "Nom enregistré." : labelState === "error" ? "Enregistrement impossible." : "Visible seulement par toi et ton équipe."}
        />
      </Card>

      <AutomationsCard
        options={options}
        onOptionsChange={props.onOptionsChange}
        blocks={props.blocks}
        previewRules={props.previewRules}
        onPreviewRules={props.onPreviewRules}
      />

      <NotificationsCard pageId={pageId} />

      {isOwner && <DomainsCard pageId={pageId} />}

      <Card title="QR code">
        <ShareQr url={url} slug={slug} />
      </Card>

      <Card title="Visibilité">
        <Toggle
          label="Page publique"
          description={published ? "Tout le monde peut voir ta page." : "Ta page est privée : seul ton compte peut l'ouvrir."}
          checked={published}
          onChange={props.onPublishedChange}
        />
        <Toggle
          label="Contenu réservé aux 18 ans et plus"
          description="Les visiteurs confirment leur âge avant de voir la page."
          checked={options.ageGate}
          onChange={(ageGate) => setOption({ ageGate })}
        />
      </Card>

      <Card title="Partage et référencement">
        <Toggle label="Bouton « Partager »" description="En haut de ta page : lien à copier, QR code, partage du téléphone." checked={options.shareButton} onChange={(shareButton) => setOption({ shareButton })} />
        <TextField
          label="Titre pour Google et les aperçus"
          value={options.seoTitle}
          maxLength={70}
          onChange={(seoTitle) => setOption({ seoTitle })}
          placeholder="Ton nom affiché par défaut"
        />
        <TextArea
          label="Description"
          value={options.seoDescription}
          maxLength={160}
          rows={2}
          onChange={(seoDescription) => setOption({ seoDescription })}
          placeholder="Ta présentation par défaut"
        />
        <Toggle
          label="Masquer des moteurs de recherche"
          description="Ta page reste accessible par son lien, mais Google ne la référence pas."
          checked={options.noindex}
          onChange={(noindex) => setOption({ noindex })}
        />
      </Card>

      {redirectState !== "off" && (
        <Card title="Redirection temporaire">
          <FeatureSection feature="redirect" title="Redirection temporaire">
            <div className="space-y-3">
              <p className="text-xs leading-relaxed text-ink-400">
                Pendant un live ou une sortie, ton lien envoie directement les visiteurs vers une autre adresse. Toi, tu vois toujours ta page.
              </p>
              <TextField
                label="Rediriger vers"
                value={options.redirectUrl}
                inputMode="url"
                onChange={(redirectUrl) => setOption({ redirectUrl: redirectUrl.trim() })}
                placeholder="https://twitch.tv/ton-pseudo"
                error={options.redirectUrl && !/^https:\/\/\S+$/.test(options.redirectUrl) ? "Adresse https attendue." : null}
              />
              <DateTimeField
                label="Jusqu'au (facultatif)"
                value={options.redirectUntil || null}
                onChange={(v) => setOption({ redirectUntil: v ?? "" })}
                hint="Sans date, la redirection reste active jusqu'à ce que tu vides l'adresse."
              />
            </div>
          </FeatureSection>
        </Card>
      )}

      <StatsCard blocks={props.blocks} />

      <TeamCard pageId={pageId} isOwner={isOwner} />

      <Card title="Messages et compte">
        <a href={`/dashboard/messages?page=${pageId}`} className="flex items-center gap-2 text-sm text-ink-200 hover:text-white">
          <Inbox size={15} className="text-brand-300" /> Messages reçus par le formulaire de contact <ArrowRight size={14} className="ml-auto" />
        </a>
        <a href="/dashboard/compte" className="flex items-center gap-2 text-sm text-ink-200 hover:text-white">
          <UserRound size={15} className="text-brand-300" /> Mon compte, mes données et la confidentialité <ArrowRight size={14} className="ml-auto" />
        </a>
      </Card>

      {isOwner && <Card title="Zone sensible">
        <p className="flex gap-2 text-xs leading-relaxed text-ink-300">
          <TriangleAlert size={15} className="mt-px shrink-0 text-danger" />
          Supprimer cette page efface définitivement ses blocs, ses images, ses messages et ses statistiques. Son adresse redevient disponible.
        </p>
        <TextField label={`Tape « ${slug} » pour confirmer`} value={confirmDelete} onChange={setConfirmDelete} />
        <button
          type="button"
          disabled={confirmDelete !== slug || deleting}
          onClick={deletePage}
          className="rounded-lg bg-danger/90 px-3 py-2 text-sm font-semibold text-white transition hover:bg-danger disabled:opacity-30"
        >
          {deleting ? "Suppression…" : "Supprimer cette page"}
        </button>
      </Card>}
    </div>
  );
}
