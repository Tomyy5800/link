"use client";

import type { PublicBadge } from "@/lib/badges";
import { useCallback, useEffect, useMemo, useRef, useState, ViewTransition } from "react";
import {
  ChevronDown,
  CircleAlert,
  LayoutDashboard,
  Megaphone,
  Shield,
  ShieldAlert,
  X,
  CircleCheck,
  ExternalLink,
  LayoutGrid,
  LoaderCircle,
  LogOut,
  Monitor,
  Palette,
  PenLine,
  Settings,
  Smartphone,
  UserRound,
  Eye,
  Keyboard,
  Undo2,
  Redo2,
} from "lucide-react";
import { celebrate } from "@/lib/confetti";
import type { ZodError } from "zod";
import { applyAutomations } from "@/lib/automations";
import { BLOCK_META, createBlock, type Block, type BlockType } from "@/lib/blocks";
import type { Entitlements } from "@/lib/features";
import { pageSaveSchema, type OwnerProfile, type PageOptions, type PageView, type Profile } from "@/lib/page-schema";
import type { Theme } from "@/lib/theme";
import { toast, type ToastTone } from "@/lib/toast";
import { Logo } from "@/components/brand/Logo";
import type { EditingHooks } from "@/components/page/CellControls";
import { PageRenderer } from "@/components/page/PageRenderer";
import { UploadLimits } from "@/components/ui/controls";
import { BlocksPanel } from "./BlocksPanel";
import { PaletteButton } from "@/components/ui/CommandPalette";
import { BrandKitCard } from "./BrandKitCard";
import { EditorPalette, availableBlockTypes } from "./EditorPalette";
import { WelcomeModal } from "./WelcomeModal";
import { EditorEnvProvider, type EditorEnv } from "./EditorContext";
import { flashBlock } from "./flash";
import { GettingStarted, markStep } from "./GettingStarted";
import { ProfilePanel } from "./ProfilePanel";
import { SettingsPanel } from "./SettingsPanel";
import { ThemePanel } from "./ThemePanel";

type Draft = { profile: Profile; theme: Theme; blocks: Block[]; published: boolean; customCss: string; options: PageOptions };
type SaveState =
  | { status: "saved"; at?: Date }
  | { status: "pending" | "saving" }
  | { status: "error" | "invalid"; message: string };

type Tab = "blocs" | "profil" | "apparence" | "reglages";

const TABS: { key: Tab; label: string; icon: typeof LayoutGrid }[] = [
  { key: "blocs", label: "Blocs", icon: LayoutGrid },
  { key: "profil", label: "Profil", icon: UserRound },
  { key: "apparence", label: "Apparence", icon: Palette },
  { key: "reglages", label: "Réglages", icon: Settings },
];

const SAVE_DELAY_MS = 800;

/** Traduit la première erreur de validation en message compréhensible. */
function describeIssue(error: ZodError, draft: Draft): string {
  const issue = error.issues[0];
  if (!issue) return "Certaines informations sont invalides.";
  const [root, index] = issue.path;
  if (root === "blocks" && typeof index === "number") {
    const block = draft.blocks[index];
    const label = block ? BLOCK_META[block.type].label : "Bloc";
    return `Bloc n°${index + 1} (${label}) : ${issue.message}`;
  }
  if (root === "profile") return `Profil : ${issue.message}`;
  if (root === "theme") return `Apparence : ${issue.message}`;
  if (root === "customCss") return `CSS personnalisé : ${issue.message}`;
  if (root === "options") return `Réglages : ${issue.message}`;
  return issue.message;
}

/** Pages accessibles depuis le sélecteur de la barre supérieure. */
export type PageSwitchItem = { id: string; name: string; slug: string; avatar: string; role: "owner" | "editor" | "viewer" };

type Props = {
  pageId: string;
  /** Rôle du compte connecté : le propriétaire seul change l'adresse, gère l'équipe ou supprime la page. */
  role: "owner" | "editor";
  label: string;
  pages: PageSwitchItem[];
  initialPage: PageView;
  owner: OwnerProfile;
  host: string;
  appUrl: string;
  entitlements: Entitlements;
  verified: boolean;
  partner: boolean;
  blockedDomains: string[];
  ngMode: EditorEnv["ngMode"];
  /** Message de l'administration affiché en haut de l'éditeur. */
  announcement: string;
  /** Suspension décidée par la modération (la page publique est masquée). */
  suspended: { reason: string } | null;
  /** Page qui vient d'être créée : écran de bienvenue. */
  welcome?: boolean;
  /** Badges officiels du propriétaire (calculés par le serveur), pour l'aperçu. */
  badges?: PublicBadge[];
  /** Cadres d'avatar débloqués par le propriétaire. */
  frames?: string[];
};

export function Editor({
  pageId,
  role,
  label,
  pages,
  initialPage,
  owner,
  host,
  appUrl,
  entitlements,
  verified,
  partner,
  blockedDomains,
  ngMode,
  announcement,
  suspended,
  welcome = false,
  badges = [],
  frames = [],
}: Props) {
  const [draft, setDraft] = useState<Draft>({
    profile: initialPage.profile,
    theme: initialPage.theme,
    blocks: initialPage.blocks,
    published: initialPage.published,
    customCss: initialPage.customCss,
    options: initialPage.options,
  });
  const [slug, setSlug] = useState(initialPage.slug);
  const [tab, setTab] = useState<Tab>("blocs");
  const [device, setDevice] = useState<"mobile" | "desktop">("mobile");
  const [mobilePreview, setMobilePreview] = useState(false);
  const [save, setSave] = useState<SaveState>({ status: "saved" });
  const [openId, setOpenId] = useState<string | null>(null);
  /** Automatisations simulées dans l'aperçu (en plus de celles actives en ce moment). */
  const [previewRules, setPreviewRules] = useState<string[]>([]);
  const [showWelcome, setShowWelcome] = useState(welcome);
  /** Petit message de confirmation en bas de l'écran. */
  const notify = useCallback((text: string, tone: ToastTone = "success") => toast(text, { tone }), []);
  const [showAnnouncement, setShowAnnouncement] = useState(Boolean(announcement));

  // ─── Historique (annuler / rétablir) ─────────────────────────────────────
  // Les retouches rapprochées d'un même réglage (frappe au clavier, curseur) forment une seule étape.
  const draftRef = useRef(draft);
  draftRef.current = draft;
  const historyRef = useRef<{ past: Draft[]; future: Draft[]; lastKey: string; lastAt: number }>({
    past: [],
    future: [],
    lastKey: "",
    lastAt: 0,
  });
  const [, setHistoryTick] = useState(0);

  const update = useCallback(<K extends keyof Draft>(key: K, value: Draft[K]) => {
    const h = historyRef.current;
    const now = Date.now();
    if (h.lastKey !== key || now - h.lastAt > 700) {
      h.past.push(draftRef.current);
      if (h.past.length > 100) h.past.shift();
    }
    h.future = [];
    h.lastKey = key;
    h.lastAt = now;
    setHistoryTick((t) => t + 1);
    setDraft((d) => ({ ...d, [key]: value }));
  }, []);

  const redo = useCallback(() => {
    const h = historyRef.current;
    const next = h.future.pop();
    if (!next) return;
    h.past.push(draftRef.current);
    h.lastKey = "";
    setHistoryTick((t) => t + 1);
    setDraft(next);
    toast("Modification rétablie", { tone: "info", duration: 1800 });
  }, []);

  const undo = useCallback(() => {
    const h = historyRef.current;
    const previous = h.past.pop();
    if (!previous) return;
    h.future.push(draftRef.current);
    h.lastKey = "";
    setHistoryTick((t) => t + 1);
    setDraft(previous);
    toast("Modification annulée", { tone: "info", duration: 2600, action: { label: "Rétablir", onClick: redo } });
  }, [redo]);

  // Ctrl/Cmd+Z et Ctrl/Cmd+Maj+Z (ou Ctrl+Y), hors des champs de texte qui ont leur propre annulation.
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (!(event.ctrlKey || event.metaKey)) return;
      const key = event.key.toLowerCase();
      // Ctrl+S : tout est déjà enregistré automatiquement, on le confirme au lieu d'ouvrir « Enregistrer sous ».
      if (key === "s") {
        event.preventDefault();
        notify(
          saveStatusRef.current === "saved" ? "Tout est enregistré automatiquement" : "Enregistrement en cours…",
          saveStatusRef.current === "saved" ? "success" : "info",
        );
        return;
      }
      const target = event.target as HTMLElement | null;
      if (target && (target.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName))) return;
      if (key === "z" && !event.shiftKey) {
        event.preventDefault();
        undo();
      } else if ((key === "z" && event.shiftKey) || key === "y") {
        event.preventDefault();
        redo();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [undo, redo, notify]);

  // « ? » (hors des champs) : aide des raccourcis clavier.
  const [showShortcuts, setShowShortcuts] = useState(false);
  const closeShortcuts = useCallback(() => setShowShortcuts(false), []);
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key !== "?" || event.ctrlKey || event.metaKey || event.altKey) return;
      const target = event.target as HTMLElement | null;
      if (target && (target.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName))) return;
      event.preventDefault();
      setShowShortcuts((open) => !open);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const canUndo = historyRef.current.past.length > 0;
  const canRedo = historyRef.current.future.length > 0;

  // ─── Sauvegarde automatique ───────────────────────────────────────────────
  // Les requêtes partent l'une après l'autre (jamais en parallèle), la dernière version gagne.
  const savedRef = useRef<string | null>(null);
  const versionRef = useRef(0);
  const queueRef = useRef<Promise<unknown>>(Promise.resolve());

  useEffect(() => {
    const body = JSON.stringify(draft);
    savedRef.current ??= body; // premier rendu : l'état initial est déjà en base
    if (body === savedRef.current) {
      versionRef.current++; // annule une sauvegarde en attente devenue inutile
      setSave((s) => (s.status === "saved" ? s : { status: "saved" }));
      return;
    }
    const parsed = pageSaveSchema.safeParse(draft);
    if (!parsed.success) {
      versionRef.current++;
      setSave({ status: "invalid", message: describeIssue(parsed.error, draft) });
      return;
    }
    setSave({ status: "pending" });
    const version = ++versionRef.current;
    const timer = window.setTimeout(() => {
      queueRef.current = queueRef.current
        .catch(() => undefined)
        .then(async () => {
          if (version !== versionRef.current) return; // une version plus récente est déjà prévue
          setSave({ status: "saving" });
          try {
            const res = await fetch(`/api/me/pages/${pageId}`, {
              method: "PUT",
              headers: { "Content-Type": "application/json" },
              body,
            });
            const json = (await res.json().catch(() => ({}))) as { error?: string };
            if (res.ok) savedRef.current = body;
            if (version !== versionRef.current) return;
            if (res.status === 401) setSave({ status: "error", message: "Session expirée : reconnecte-toi pour enregistrer." });
            else if (!res.ok) setSave({ status: "error", message: json.error ?? "La sauvegarde a échoué." });
            else setSave({ status: "saved", at: new Date() });
          } catch {
            if (version === versionRef.current) setSave({ status: "error", message: "Connexion perdue : tes modifications seront renvoyées à la prochaine retouche." });
          }
        });
    }, SAVE_DELAY_MS);
    return () => window.clearTimeout(timer);
  }, [draft, pageId]);

  const saveStatusRef = useRef(save.status);
  saveStatusRef.current = save.status;

  // Avertit avant de quitter avec des modifications non enregistrées.
  const unsaved = save.status !== "saved";
  useEffect(() => {
    if (!unsaved) return;
    const handler = (event: BeforeUnloadEvent) => event.preventDefault();
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [unsaved]);

  const basePreview: PageView = { ...draft, slug, views: initialPage.views };
  // Aperçu des automatisations : celles actives maintenant, plus celles qu'on simule.
  const automated = entitlements.features.automations
    ? applyAutomations(basePreview, draft.options.automations, {
        now: new Date(),
        timeZone: draft.options.timezone,
        live: { on: false, url: null },
        force: previewRules,
      })
    : { page: basePreview, banners: [] };
  const previewPage = automated.page;

  // Ouvre l'onglet Réglages sur la carte de l'offre payante.
  const openPlus = useCallback(() => {
    setTab("reglages");
    setMobilePreview(false);
    requestAnimationFrame(() => document.getElementById("plus")?.scrollIntoView({ behavior: "smooth", block: "start" }));
  }, []);

  const blockTypes = useMemo(() => availableBlockTypes(entitlements.modes.presence === "off"), [entitlements.modes.presence]);
  const addBlock = useCallback(
    (type: BlockType) => {
      if (draftRef.current.blocks.length >= entitlements.limits.blocks) {
        notify(`Ta formule permet ${entitlements.limits.blocks} blocs au maximum.`, "error");
        return;
      }
      const block = createBlock(type);
      update("blocks", [...draftRef.current.blocks, block]);
      setTab("blocs");
      setMobilePreview(false);
      setOpenId(block.id);
      notify(`${BLOCK_META[type].label} ajouté`);
      window.setTimeout(() => document.getElementById(`block-${block.id}`)?.scrollIntoView({ behavior: "smooth", block: "center" }), 80);
      flashBlock(block.id);
    },
    [entitlements.limits.blocks, notify, update],
  );

  const env = useMemo<EditorEnv>(
    () => ({ pageId, entitlements, ngMode, ngUsername: draft.profile.ngUsername, ngServer: draft.profile.ngServer, openPlus, frames }),
    [pageId, entitlements, ngMode, draft.profile.ngUsername, draft.profile.ngServer, openPlus, frames],
  );
  const context = useMemo(
    () => ({ features: entitlements.features, verified, partner, blockedDomains, badges, frames }),
    [entitlements.features, verified, partner, blockedDomains, badges, frames],
  );
  const limits = useMemo(() => ({ imageMb: entitlements.limits.imageMb, mediaMb: entitlements.limits.mediaMb }), [entitlements.limits]);

  // Aperçu interactif : un clic sur un bloc l'ouvre dans la colonne d'édition ; sur ordinateur, ses poignées le redimensionnent.
  const gridPreview = device === "desktop" && entitlements.features.advancedLayout && draft.theme.layout !== "stack";
  const editing: EditingHooks = {
    selectedId: openId,
    grid: gridPreview,
    columns: draft.theme.columns,
    onSelect: (id) => {
      setTab("blocs");
      setMobilePreview(false);
      setOpenId(id);
      requestAnimationFrame(() => document.getElementById(`block-${id}`)?.scrollIntoView({ behavior: "smooth", block: "center" }));
    },
    onResize: (id, patch) => update("blocks", draftRef.current.blocks.map((b) => (b.id === id ? { ...b, ...patch } : b))),
  };

  return (
    <EditorEnvProvider value={env}>
    <UploadLimits.Provider value={limits}>
    <div className="flex h-dvh flex-col bg-ink-950">
      {/* Barre supérieure */}
      <header className="flex h-14 shrink-0 items-center gap-3 border-b border-ink-800 px-3 sm:px-4">
        <div className="hidden sm:block">
          <Logo href="/dashboard" />
        </div>
        <a
          href="/dashboard"
          className="inline-flex h-8 items-center gap-1.5 rounded-lg px-2 text-sm text-ink-300 transition hover:bg-ink-800 hover:text-ink-100"
          title="Mon espace"
        >
          <LayoutDashboard size={16} /> <span className="hidden xl:inline">Mon espace</span>
        </a>
        <PageSwitcher pages={pages} currentId={pageId} />
        <a
          href={`/${slug}`}
          target="_blank"
          rel="noopener noreferrer"
          className="ml-0 hidden min-w-0 items-center gap-1.5 truncate rounded-lg px-2 py-1 font-mono text-xs text-ink-400 transition hover:text-ink-100 md:inline-flex lg:ml-4"
        >
          {host}/<span className="text-brand-300">{slug}</span>
        </a>
        <div className="ml-auto flex items-center gap-2">
          <div className="flex items-center">
            <button
              type="button"
              onClick={undo}
              disabled={!canUndo}
              className="flex h-8 w-8 items-center justify-center rounded-md text-ink-300 transition hover:bg-ink-800 hover:text-ink-100 disabled:opacity-30"
              aria-label="Annuler"
              title="Annuler (Ctrl+Z)"
            >
              <Undo2 size={16} />
            </button>
            <button
              type="button"
              onClick={redo}
              disabled={!canRedo}
              className="flex h-8 w-8 items-center justify-center rounded-md text-ink-300 transition hover:bg-ink-800 hover:text-ink-100 disabled:opacity-30"
              aria-label="Rétablir"
              title="Rétablir (Ctrl+Maj+Z)"
            >
              <Redo2 size={16} />
            </button>
          </div>
          <PaletteButton compact />
          <button
            type="button"
            onClick={() => setShowShortcuts(true)}
            className="ui-press hidden h-8 w-8 items-center justify-center rounded-md text-ink-400 transition hover:bg-ink-800 hover:text-ink-100 md:flex"
            aria-label="Raccourcis clavier"
            title="Raccourcis clavier (?)"
          >
            <Keyboard size={16} />
          </button>
          <SaveIndicator state={save} />
          {entitlements.admin && (
            <a
              href="/admin"
              className="hidden h-8 items-center gap-1.5 rounded-lg border border-claim/40 px-2.5 text-xs font-semibold text-claim transition hover:bg-claim/10 sm:inline-flex"
            >
              <Shield size={14} /> Admin
            </a>
          )}
          <a
            href={`/${slug}`}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => markStep(slug, "visited")}
            className="inline-flex items-center gap-1.5 whitespace-nowrap rounded-lg bg-ink-100 px-3 py-1.5 text-sm font-semibold text-ink-950 transition hover:bg-white"
          >
            <ExternalLink size={15} /> <span className="hidden sm:inline">Voir ma page</span>
          </a>
          <form action="/api/auth/logout" method="post">
            <button
              type="submit"
              className="flex h-8 w-8 items-center justify-center rounded-lg text-ink-400 transition hover:bg-ink-800 hover:text-ink-100"
              aria-label="Se déconnecter"
              title="Se déconnecter"
            >
              <LogOut size={16} />
            </button>
          </form>
        </div>
      </header>

      <div className="flex min-h-0 flex-1">
        {/* Colonne d'édition */}
        <aside
          className={`${mobilePreview ? "hidden" : "flex"} w-full min-w-0 flex-col border-ink-800 lg:flex lg:w-[460px] lg:border-r xl:w-[500px]`}
        >
          <nav className="relative flex shrink-0 gap-1 border-b border-ink-800 px-2 py-2" aria-label="Sections de l'éditeur">
            {/* Fond de l'onglet actif, qui glisse d'un onglet à l'autre */}
            <span
              className="pointer-events-none absolute inset-y-2 left-2 rounded-lg bg-ink-800 shadow-[inset_0_-2px_0_#22c9e8] transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]"
              style={{
                width: `calc((100% - 1rem - ${(TABS.length - 1) * 0.25}rem) / ${TABS.length})`,
                transform: `translateX(calc(${TABS.findIndex((t) => t.key === tab)} * (100% + 0.25rem)))`,
              }}
              aria-hidden="true"
            />
            {TABS.map(({ key, label, icon: Icon }) => (
              <button
                key={key}
                type="button"
                onClick={() => setTab(key)}
                aria-current={tab === key ? "page" : undefined}
                className={`group relative flex flex-1 items-center justify-center gap-1.5 rounded-lg px-2 py-2 text-sm font-medium transition-colors ${
                  tab === key ? "text-ink-100" : "text-ink-400 hover:text-ink-200"
                }`}
              >
                <Icon size={16} className={`${tab === key ? "text-brand-300" : ""}`} />
                <span className="hidden min-[400px]:inline">{label}</span>
              </button>
            ))}
          </nav>

          {suspended && (
            <p role="alert" className="flex shrink-0 gap-2 border-b border-danger/30 bg-danger/10 px-4 py-2.5 text-xs text-red-100">
              <ShieldAlert size={15} className="mt-px shrink-0 text-danger" />
              <span>
                Ta page est suspendue par la modération et n&apos;est plus visible.
                {suspended.reason && <> Motif : {suspended.reason}</>}
              </span>
            </p>
          )}
          {showAnnouncement && (
            <p role="status" className="flex shrink-0 items-start gap-2 border-b border-brand-500/20 bg-brand-500/10 px-4 py-2.5 text-xs text-ink-100">
              <Megaphone size={15} className="mt-px shrink-0 text-brand-300" />
              <span className="min-w-0 flex-1">{announcement}</span>
              <button type="button" onClick={() => setShowAnnouncement(false)} className="shrink-0 text-ink-400 hover:text-ink-100" aria-label="Masquer l'annonce">
                <X size={14} />
              </button>
            </p>
          )}
          {(save.status === "invalid" || save.status === "error") && (
            <p role="alert" className="flex shrink-0 gap-2 border-b border-gold/20 bg-gold/10 px-4 py-2.5 text-xs text-amber-100">
              <CircleAlert size={15} className="mt-px shrink-0 text-gold" />
              {save.status === "invalid" ? `${save.message.replace(/[.!]?$/, ".")} Corrige-le pour reprendre la sauvegarde.` : save.message}
            </p>
          )}

          <div key={tab} className="scrollbar-thin min-h-0 flex-1 animate-fade overflow-y-auto p-4 pb-24 lg:pb-6">
            {tab === "blocs" && <GettingStarted slug={slug} profile={draft.profile} blocks={draft.blocks} onGo={setTab} />}
            {tab === "blocs" && (
              <BlocksPanel
                blocks={draft.blocks}
                onChange={(blocks) => update("blocks", blocks)}
                theme={draft.theme}
                openId={openId}
                onOpenChange={setOpenId}
              />
            )}
            {tab === "profil" && <ProfilePanel profile={draft.profile} owner={owner} onChange={(profile) => update("profile", profile)} />}
            {tab === "apparence" && (
              <ThemePanel
                theme={draft.theme}
                onChange={(theme) => update("theme", theme)}
                slug={slug}
                customCss={draft.customCss}
                onCustomCssChange={(css) => update("customCss", css)}
              />
            )}
            {tab === "apparence" && role === "owner" && (
              <BrandKitCard pageId={pageId} otherPages={pages.filter((p) => p.role === "owner" && p.id !== pageId).length} saved={save.status === "saved"} />
            )}
            {tab === "reglages" && (
              <SettingsPanel
                pageId={pageId}
                role={role}
                label={label}
                slug={slug}
                host={host}
                appUrl={appUrl}
                published={draft.published}
                options={draft.options}
                onOptionsChange={(options) => update("options", options)}
                onPublishedChange={(published) => {
                  update("published", published);
                  if (published) {
                    celebrate();
                    toast("Ta page est en ligne !", {
                      tone: "celebrate",
                      description: `${host}/${slug}`,
                      action: { label: "Voir", onClick: () => window.open(`/${slug}`, "_blank", "noopener") },
                    });
                  } else {
                    toast("Ta page est maintenant privée", { tone: "info", description: "Elle n'est visible que par toi et ton équipe." });
                  }
                }}
                onSlugChange={setSlug}
                blocks={draft.blocks}
                previewRules={previewRules}
                onPreviewRules={setPreviewRules}
              />
            )}
          </div>
        </aside>

        {/* Aperçu en direct */}
        <section
          className={`${mobilePreview ? "flex" : "hidden"} min-w-0 flex-1 flex-col bg-[radial-gradient(circle_at_50%_0%,#1b1b28,transparent_60%)] lg:flex`}
          aria-label="Aperçu de la page"
        >
          <div className="hidden shrink-0 items-center justify-center gap-1 pt-4 lg:flex">
            <div className="flex rounded-lg border border-ink-800 bg-ink-900 p-0.5">
              {(
                [
                  ["mobile", Smartphone, "Mobile"],
                  ["desktop", Monitor, "Ordinateur"],
                ] as const
              ).map(([key, Icon, label]) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setDevice(key)}
                  aria-pressed={device === key}
                  className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1 text-xs font-medium transition ${
                    device === key ? "bg-ink-750 text-ink-100" : "text-ink-400 hover:text-ink-200"
                  }`}
                >
                  <Icon size={14} /> {label}
                </button>
              ))}
            </div>
          </div>
          <div className="flex min-h-0 flex-1 items-start justify-center p-3 lg:p-6">
            <div
              className={`relative h-full w-full overflow-hidden border border-ink-700 bg-ink-900 shadow-2xl shadow-black/50 transition-[max-width,border-radius,padding] duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] lg:max-w-[var(--preview-width)] ${
                device === "mobile" ? "lg:rounded-[2.2rem] lg:p-2" : ""
              } rounded-2xl`}
              style={{ "--preview-width": device === "mobile" ? "400px" : "100%" } as React.CSSProperties}
            >
              {/* Fondu enchaîné quand le changement passe par une transition (thème de départ choisi).
                  Posé sur la zone qui défile : la capture reste découpée à l'écran de l'aperçu. */}
              <ViewTransition>
                <div className={`scrollbar-thin h-full overflow-y-auto overflow-x-hidden ${device === "mobile" ? "lg:rounded-[1.8rem]" : ""} rounded-xl`}>
                  <PageRenderer
                    page={previewPage}
                    owner={owner}
                    context={context}
                    banners={automated.banners}
                    mode="preview"
                    premiumName={entitlements.premiumName}
                    editing={editing}
                  />
                </div>
              </ViewTransition>
            </div>
          </div>
        </section>
      </div>

      {/* Bascule édition / aperçu sur mobile */}
      <div className="fixed inset-x-0 bottom-4 z-40 flex justify-center lg:hidden">
        <div className="flex rounded-full border border-ink-700 bg-ink-850/95 p-1 shadow-2xl shadow-black/60 backdrop-blur">
          <button
            type="button"
            onClick={() => setMobilePreview(false)}
            aria-pressed={!mobilePreview}
            className={`inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-medium transition ${!mobilePreview ? "bg-ink-100 text-ink-950" : "text-ink-300"}`}
          >
            <PenLine size={15} /> Éditer
          </button>
          <button
            type="button"
            onClick={() => setMobilePreview(true)}
            aria-pressed={mobilePreview}
            className={`inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-medium transition ${mobilePreview ? "bg-ink-100 text-ink-950" : "text-ink-300"}`}
          >
            <Eye size={15} /> Aperçu
          </button>
        </div>
      </div>

      <EditorPalette
        slug={slug}
        appUrl={appUrl}
        pageId={pageId}
        pages={pages}
        blockTypes={blockTypes}
        onTab={(next) => {
          setTab(next);
          setMobilePreview(false);
        }}
        onAddBlock={addBlock}
        onUndo={undo}
        onRedo={redo}
        onDevice={setDevice}
        onCopyLink={() => void navigator.clipboard.writeText(`${appUrl}/${slug}`).then(() => notify("Lien copié"))}
        onAutomations={() => {
          setTab("reglages");
          setMobilePreview(false);
          window.setTimeout(() => document.querySelector('[aria-label="Automatisations"]')?.scrollIntoView({ behavior: "smooth", block: "start" }), 80);
        }}
      />
      {showShortcuts && <ShortcutsHelp onClose={closeShortcuts} />}
      {showWelcome && (
        <WelcomeModal
          url={`${appUrl}/${slug}`}
          slug={slug}
          onClose={() => {
            setShowWelcome(false);
            window.history.replaceState(null, "", window.location.pathname);
          }}
          onGo={(next) => {
            setMobilePreview(false);
            if (next === "automations") {
              setTab("reglages");
              window.setTimeout(() => document.querySelector('[aria-label="Automatisations"]')?.scrollIntoView({ behavior: "smooth", block: "start" }), 120);
            } else {
              setTab(next);
            }
          }}
        />
      )}
    </div>
    </UploadLimits.Provider>
    </EditorEnvProvider>
  );
}

/** Passe d'une page à l'autre sans repasser par « Mon espace ». */
function PageSwitcher({ pages, currentId }: { pages: PageSwitchItem[]; currentId: string }) {
  const [open, setOpen] = useState(false);
  const current = pages.find((p) => p.id === currentId);
  if (pages.length < 2 || !current) return null;
  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        aria-haspopup="menu"
        className="inline-flex h-8 max-w-[11rem] items-center gap-1.5 rounded-lg border border-ink-700 px-2 text-sm text-ink-200 transition hover:border-ink-500"
      >
        <img src={current.avatar} alt="" className="h-5 w-5 shrink-0 rounded-full object-cover" />
        <span className="truncate">{current.name}</span>
        <ChevronDown size={14} className="shrink-0 text-ink-400" />
      </button>
      {open && (
        <>
          <button type="button" className="fixed inset-0 z-40 cursor-default" aria-hidden="true" tabIndex={-1} onClick={() => setOpen(false)} />
          <ul role="menu" className="absolute top-10 left-0 z-50 w-64 overflow-hidden rounded-lg border border-ink-700 bg-ink-900 py-1 shadow-2xl shadow-black/60">
            {pages.map((p) => (
              <li key={p.id} role="none">
                <a
                  role="menuitem"
                  href={`/dashboard/pages/${p.id}`}
                  aria-current={p.id === currentId ? "page" : undefined}
                  className={`flex items-center gap-2.5 px-3 py-2 text-sm transition hover:bg-ink-800 ${p.id === currentId ? "text-white" : "text-ink-300"}`}
                >
                  <img src={p.avatar} alt="" className="h-6 w-6 shrink-0 rounded-full object-cover" />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate">{p.name}</span>
                    <span className="block truncate font-mono text-[11px] text-ink-500">/{p.slug}</span>
                  </span>
                  {p.role !== "owner" && <span className="text-[10px] uppercase text-ink-500">{p.role === "editor" ? "Équipe" : "Lecture"}</span>}
                </a>
              </li>
            ))}
            <li role="none" className="mt-1 border-t border-ink-800 pt-1">
              <a role="menuitem" href="/dashboard" className="block px-3 py-2 text-sm text-brand-300 hover:bg-ink-800">
                Toutes mes pages
              </a>
            </li>
          </ul>
        </>
      )}
    </div>
  );
}

function SaveIndicator({ state }: { state: SaveState }) {
  const base = "inline-flex items-center gap-1.5 rounded-lg px-2 py-1 text-xs animate-fade";
  const busy = state.status === "pending" || state.status === "saving";
  const failed = state.status === "error" || state.status === "invalid";
  // Clé par famille d'état : l'icône rejoue son animation à chaque changement.
  return (
    <span key={busy ? "busy" : failed ? "failed" : "saved"} className={`${base} ${failed ? "text-danger" : "text-ink-400"}`} title={failed ? state.message : undefined} aria-live="polite">
      {busy ? (
        <>
          <LoaderCircle size={14} className="animate-spin" /> <span className="hidden sm:inline">Enregistrement…</span>
        </>
      ) : failed ? (
        <>
          <CircleAlert size={14} className="animate-pop" /> <span className="hidden sm:inline">{state.status === "invalid" ? "À corriger" : "Non enregistré"}</span>
        </>
      ) : (
        <>
          <CircleCheck size={14} className="animate-pop text-mint" /> <span className="hidden sm:inline">Enregistré</span>
        </>
      )}
    </span>
  );
}

const SHORTCUTS: { keys: string[]; label: string }[] = [
  { keys: ["Ctrl", "K"], label: "Palette de commandes : ajouter un bloc, changer d'onglet ou de page" },
  { keys: ["Ctrl", "Z"], label: "Annuler la dernière modification" },
  { keys: ["Ctrl", "Maj", "Z"], label: "Rétablir" },
  { keys: ["Ctrl", "S"], label: "Vérifier l'enregistrement (tout est enregistré automatiquement)" },
  { keys: ["?"], label: "Afficher ou masquer cette aide" },
  { keys: ["Échap"], label: "Fermer une fenêtre" },
];

/** Aide des raccourcis clavier (touche « ? »). */
function ShortcutsHelp({ onClose }: { onClose: () => void }) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const dialog = ref.current;
    if (dialog && !dialog.open) dialog.showModal();
    const onCancel = (event: Event) => {
      event.preventDefault();
      onClose();
    };
    dialog?.addEventListener("cancel", onCancel);
    return () => dialog?.removeEventListener("cancel", onCancel);
  }, [onClose]);
  return (
    <dialog
      ref={ref}
      aria-label="Raccourcis clavier"
      className="m-auto w-[min(94vw,480px)] rounded-2xl border border-ink-600 bg-ink-900 p-0 text-ink-100 shadow-2xl shadow-black/70 backdrop:bg-ink-950/70 backdrop:backdrop-blur-sm"
      onClick={(event) => event.target === ref.current && onClose()}
    >
      <div className="animate-pop p-5">
        <div className="flex items-center justify-between">
          <p className="font-display text-lg font-bold">Raccourcis clavier</p>
          <button type="button" onClick={onClose} className="ui-press rounded-md p-1.5 text-ink-400 hover:bg-ink-800 hover:text-ink-100" aria-label="Fermer">
            <X size={16} />
          </button>
        </div>
        <ul className="ui-stagger mt-4 space-y-2.5">
          {SHORTCUTS.map(({ keys, label }) => (
            <li key={label} className="flex items-center justify-between gap-4 text-sm">
              <span className="text-ink-300">{label}</span>
              <span className="flex shrink-0 gap-1">
                {keys.map((k) => (
                  <kbd key={k} className="min-w-7 rounded-md border border-ink-600 border-b-[3px] bg-ink-800 px-1.5 py-0.5 text-center font-mono text-[11px] text-ink-100">
                    {k}
                  </kbd>
                ))}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </dialog>
  );
}
