"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { CornerDownLeft, Search, Sparkles, X } from "lucide-react";
import { BLOCK_META, type BlockCategory, type BlockType } from "@/lib/blocks";
import { BLOCK_ICONS } from "./BlocksPanel";

const CATEGORIES: { key: BlockCategory; label: string; color: string }[] = [
  { key: "liens", label: "Liens", color: "#22c9e8" },
  { key: "boutique", label: "Boutique", color: "#f472b6" },
  { key: "contenu", label: "Contenu", color: "#a78bfa" },
  { key: "interactif", label: "Interactif", color: "#fb923c" },
  { key: "médias", label: "Médias", color: "#ff6467" },
  { key: "discord", label: "Discord", color: "#7c85ff" },
  { key: "jeux", label: "Jeux vidéo", color: "#00bc7d" },
  { key: "nationsglory", label: "NationsGlory", color: "#ffc247" },
];
/** Couleur de chaque catégorie de blocs (galerie, liste des blocs). */
export const CATEGORY_COLOR = Object.fromEntries(CATEGORIES.map((c) => [c.key, c.color])) as Record<BlockCategory, string>;

/** Les blocs qu'on ajoute le plus souvent, en tête de la galerie. */
const POPULAR: BlockType[] = ["link", "socials", "discord", "image", "shop", "contact", "countdown"];

const fold = (s: string) => s.normalize("NFD").replace(/\p{M}/gu, "").toLowerCase();

/**
 * Galerie d'ajout de blocs : recherche instantanée, catégories en pastilles, navigation au clavier
 * (flèches, Entrée, Échap). Remplace l'ancienne liste dépliée sous les blocs.
 */
export function BlockPicker({ types, onPick, onClose }: { types: BlockType[]; onPick: (type: BlockType) => void; onClose: () => void }) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<BlockCategory | null>(null);
  const [active, setActive] = useState(0);

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    if (!dialog.open) dialog.showModal();
    requestAnimationFrame(() => inputRef.current?.focus());
    const onCancel = (event: Event) => {
      event.preventDefault();
      onClose();
    };
    dialog.addEventListener("cancel", onCancel);
    return () => dialog.removeEventListener("cancel", onCancel);
  }, [onClose]);

  const results = useMemo(() => {
    const words = fold(query).split(/\s+/).filter(Boolean);
    return types.filter((type) => {
      const meta = BLOCK_META[type];
      if (category && meta.category !== category) return false;
      if (!words.length) return true;
      const hay = fold(`${meta.label} ${meta.description} ${CATEGORIES.find((c) => c.key === meta.category)?.label ?? ""} ${type}`);
      return words.every((w) => hay.includes(w));
    });
  }, [types, query, category]);

  // Sans recherche ni filtre, les populaires d'abord.
  const ordered = useMemo(() => {
    if (query || category) return results;
    const popular = POPULAR.filter((t) => results.includes(t));
    return [...popular, ...results.filter((t) => !popular.includes(t))];
  }, [results, query, category]);
  const popularCount = query || category ? 0 : POPULAR.filter((t) => results.includes(t)).length;

  useEffect(() => {
    listRef.current?.querySelector(`[data-index="${active}"]`)?.scrollIntoView({ block: "nearest" });
  }, [active]);

  function onKeyDown(event: React.KeyboardEvent) {
    // Dans le champ de recherche rempli, gauche et droite déplacent le curseur du texte.
    if ((event.key === "ArrowLeft" || event.key === "ArrowRight") && event.target === inputRef.current && query) return;
    const columns = window.matchMedia("(min-width: 640px)").matches ? 2 : 1;
    const moves: Record<string, number> = { ArrowDown: columns, ArrowUp: -columns, ArrowRight: 1, ArrowLeft: -1 };
    if (event.key in moves) {
      event.preventDefault();
      setActive((i) => Math.min(ordered.length - 1, Math.max(0, i + moves[event.key])));
    } else if (event.key === "Enter" && ordered[active]) {
      event.preventDefault();
      onPick(ordered[active]);
    }
  }

  return (
    <dialog
      ref={dialogRef}
      aria-label="Ajouter un bloc"
      className="m-auto h-[min(86dvh,720px)] w-[min(96vw,720px)] overflow-hidden rounded-2xl border border-ink-600 bg-ink-900 p-0 text-ink-100 shadow-2xl shadow-black/70 backdrop:bg-ink-950/75 backdrop:backdrop-blur-sm"
      onClick={(event) => event.target === dialogRef.current && onClose()}
      onKeyDown={onKeyDown}
    >
      <div className="animate-pop flex h-full flex-col">
        <div className="flex items-center gap-3 border-b border-ink-700 px-4">
          <Search size={18} className="shrink-0 text-ink-400" aria-hidden="true" />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setActive(0);
            }}
            placeholder="Chercher un bloc : lien, skin, agenda, Discord…"
            className="h-14 min-w-0 flex-1 bg-transparent text-base outline-none placeholder:text-ink-500 focus-visible:shadow-none focus-visible:outline-none"
            aria-controls="block-picker-list"
            autoComplete="off"
            spellCheck={false}
          />
          <button type="button" onClick={onClose} className="ui-press rounded-md p-1.5 text-ink-400 hover:bg-ink-800 hover:text-ink-100" aria-label="Fermer">
            <X size={18} />
          </button>
        </div>

        <div className="scrollbar-thin flex shrink-0 gap-1.5 overflow-x-auto border-b border-ink-800 px-4 py-2.5" role="tablist" aria-label="Catégories">
          <button
            type="button"
            role="tab"
            aria-selected={category === null}
            onClick={() => {
              setCategory(null);
              setActive(0);
            }}
            className={`ui-press shrink-0 rounded-full border px-3 py-1 text-xs font-semibold transition ${
              category === null ? "border-ink-200 bg-ink-100 text-ink-950" : "border-ink-700 text-ink-300 hover:border-ink-500"
            }`}
          >
            Tous
          </button>
          {CATEGORIES.filter((c) => types.some((t) => BLOCK_META[t].category === c.key)).map((c) => (
            <button
              key={c.key}
              type="button"
              role="tab"
              aria-selected={category === c.key}
              onClick={() => {
                setCategory(category === c.key ? null : c.key);
                setActive(0);
              }}
              className={`ui-press inline-flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-semibold transition ${
                category === c.key ? "text-ink-950" : "border-ink-700 text-ink-300 hover:border-ink-500"
              }`}
              style={category === c.key ? { background: c.color, borderColor: c.color } : undefined}
            >
              <span className="h-2 w-2 rounded-full" style={{ background: category === c.key ? "#020618" : c.color }} aria-hidden="true" />
              {c.label}
            </button>
          ))}
        </div>

        <div ref={listRef} id="block-picker-list" role="listbox" aria-label="Blocs" className="scrollbar-thin min-h-0 flex-1 overflow-y-auto p-3">
          {ordered.length === 0 && (
            <p className="py-16 text-center text-sm text-ink-400">
              Aucun bloc ne correspond à « {query} ». Essaie « lien », « vidéo » ou « jeu ».
            </p>
          )}
          {popularCount > 0 && (
            <p className="hud-label flex items-center gap-1.5 px-1 pb-2 text-[10px] text-claim">
              <Sparkles size={12} /> Populaires
            </p>
          )}
          <div className="grid gap-2 sm:grid-cols-2">
            {ordered.map((type, i) => {
              const meta = BLOCK_META[type];
              const Icon = BLOCK_ICONS[type];
              const color = CATEGORY_COLOR[meta.category];
              const selected = i === active;
              return (
                <div key={type} className="contents">
                  {popularCount > 0 && i === popularCount && (
                    <p className="hud-label col-span-full px-1 pt-3 pb-1 text-[10px] text-ink-500">Tous les blocs</p>
                  )}
                  <button
                    type="button"
                    role="option"
                    aria-selected={selected}
                    data-index={i}
                    onMouseMove={() => setActive(i)}
                    onClick={() => onPick(type)}
                    className={`ui-press group flex items-start gap-3 rounded-xl border p-3 text-left transition ${
                      selected ? "border-ink-500 bg-ink-800" : "border-ink-800 bg-ink-900 hover:border-ink-600"
                    }`}
                    style={{ animation: `rise 0.4s var(--ease-out-expo) ${Math.min(i, 12) * 22}ms both` }}
                  >
                    <span
                      className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl"
                      style={{ background: `linear-gradient(135deg, ${color}33, ${color}12)`, color, boxShadow: selected ? `0 0 0 1px ${color}66, 0 8px 24px -10px ${color}` : undefined }}
                    >
                      <Icon size={20} />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center gap-2 text-sm font-semibold text-ink-100">
                        {meta.label}
                        {selected && <CornerDownLeft size={12} className="ml-auto shrink-0 text-ink-500" aria-hidden="true" />}
                      </span>
                      <span className="mt-0.5 block text-xs leading-snug text-ink-400">{meta.description}</span>
                    </span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
        <p className="shrink-0 border-t border-ink-800 px-4 py-2 text-[11px] text-ink-500">
          Flèches pour choisir · Entrée pour ajouter · Échap pour fermer · Ctrl+K pour toutes les commandes
        </p>
      </div>
    </dialog>
  );
}
