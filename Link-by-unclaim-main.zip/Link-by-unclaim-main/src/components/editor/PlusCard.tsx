"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowRight, Check, Gift, LoaderCircle, Lock } from "lucide-react";
import { PlusMark } from "@/components/brand/Logo";
import { FEATURES, FEATURE_KEYS, modeTier, type Entitlements } from "@/lib/features";
import { tierName } from "@/lib/plans";

const nf = new Intl.NumberFormat("fr-FR");
// Fuseau fixe : la carte est rendue côté serveur (page Abonnement) puis hydratée, la date doit être la même des deux côtés.
const day = (iso: string) => new Date(iso).toLocaleDateString("fr-FR", { dateStyle: "long", timeZone: "Europe/Paris" });

/** Carte de l'offre payante : statut, fonctions incluses, limites et échange d'un code. */
export function PlusCard({ entitlements: e }: { entitlements: Entitlements }) {
  const router = useRouter();
  const [code, setCode] = useState("");
  const [state, setState] = useState<{ status: "idle" | "sending" | "done" | "error"; text?: string }>({ status: "idle" });

  const premiumFeatures = FEATURE_KEYS.filter((k) => modeTier(e.modes[k]) !== null);
  const current = tierName(e.tier, e.premiumName);
  if (!premiumFeatures.length && !e.premium) return null;

  // Pas de paiement en ligne : tout est offert, il n'y a rien à acheter ni de code à saisir.
  if (e.freeForAll) {
    return (
      <section id="plus" className="hud-panel scroll-mt-4 space-y-2 rounded-[2px] border border-claim/40 bg-[linear-gradient(160deg,rgba(255,194,71,0.08),transparent_55%)] p-4">
        <h3 className="inline-flex items-center gap-2 font-display text-lg font-bold text-ink-100">
          <PlusMark size={26} /> Toutes les formules offertes
        </h3>
        <p className="text-xs leading-relaxed text-ink-300">
          Pour le lancement, les fonctions de {e.premiumName}, {e.premiumName} Pro et {e.premiumName} Équipe sont gratuites pour tout le monde : effets,
          musique et vidéo de fond, polices, automatisations, CSS personnalisé, notifications Discord, kit de marque… Profites-en.
        </p>
      </section>
    );
  }

  async function redeem(event: React.FormEvent) {
    event.preventDefault();
    if (!code.trim()) return;
    setState({ status: "sending" });
    const res = await fetch("/api/me/redeem", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code }),
    }).catch(() => null);
    const json = (await res?.json().catch(() => ({}))) as { error?: string; plan?: "plus" | "pro" | "team"; planExpiresAt?: string | null } | undefined;
    if (!res?.ok) {
      setState({ status: "error", text: json?.error ?? "Échange impossible, réessaie plus tard." });
      return;
    }
    setCode("");
    const name = tierName(json?.plan ?? "plus", e.premiumName);
    setState({
      status: "done",
      text: json?.planExpiresAt
        ? `${name} est actif jusqu'au ${day(json.planExpiresAt)}.`
        : `${name} est actif, sans limite de durée.`,
    });
    // Recharge les droits calculés côté serveur.
    router.refresh();
  }

  const status = e.partner
    ? "Partenaire officiel"
    : e.subscription
    ? `Abonnement · ${e.subscription.renews ? "renouvelé le" : "jusqu'au"} ${day(e.subscription.until)}`
    : e.premiumUntil
    ? `Actif jusqu'au ${day(e.premiumUntil)}`
    : e.admin
      ? "Administrateur : tout est débloqué"
      : e.premium
        ? "Actif, sans limite de durée"
        : "Offre gratuite";

  return (
    <section id="plus" className="hud-panel scroll-mt-4 space-y-4 rounded-[2px] border border-claim/40 bg-[linear-gradient(160deg,rgba(255,194,71,0.08),transparent_55%)] p-4">
      <div className="flex items-center justify-between gap-3">
        <h3 className="inline-flex items-center gap-2 font-display text-lg font-bold text-ink-100">
          <PlusMark size={26} /> {current}
        </h3>
        <span
          className={`rounded-sm px-2 py-0.5 font-mono text-[11px] font-semibold ${
            e.premium ? "bg-claim text-ink-950" : "border border-ink-600 text-ink-300"
          }`}
        >
          {status}
        </span>
      </div>

      {premiumFeatures.length > 0 && (
        <ul className="grid gap-2 sm:grid-cols-2">
          {premiumFeatures.map((k) => (
            <li key={k} className="flex gap-2 text-xs">
              {e.features[k] ? (
                <Check size={14} className="mt-px shrink-0 text-mint" aria-label="Inclus" />
              ) : (
                <Lock size={13} className="mt-px shrink-0 text-claim" aria-label="Verrouillé" />
              )}
              <span>
                <span className="block font-medium text-ink-100">
                  {FEATURES[k].label}
                  {!e.features[k] && <span className="ml-1.5 font-mono text-[10px] text-claim">{tierName(modeTier(e.modes[k])!, e.premiumName)}</span>}
                </span>
                <span className="block text-ink-400">{FEATURES[k].description}</span>
              </span>
            </li>
          ))}
        </ul>
      )}

      <dl className="grid grid-cols-3 gap-2 border-t border-ink-700 pt-3 text-center sm:grid-cols-5">
        {(
          [
            ["Blocs", nf.format(e.limits.blocks)],
            ["Fichiers", nf.format(e.limits.uploads)],
            ["Image", `${e.limits.imageMb} Mo`],
            ["Audio/vidéo", e.limits.mediaMb > 0 ? `${e.limits.mediaMb} Mo` : "—"],
            ["Stats", `${e.limits.statsDays} j`],
          ] as const
        ).map(([label, value]) => (
          <div key={label}>
            <dt className="hud-label text-[10px] text-ink-500">{label}</dt>
            <dd className="font-mono text-sm text-ink-100">{value}</dd>
          </div>
        ))}
      </dl>

      {e.tier !== "team" && (
        <a
          href="/plus"
          className="flex items-center justify-between gap-2 rounded-md border border-claim/40 px-3 py-2 text-sm font-semibold text-claim transition hover:bg-claim/10"
        >
          {e.tier === "free" ? "Voir les formules" : `Passer à ${tierName(e.tier === "plus" ? "pro" : "team", e.premiumName)}`}
          <ArrowRight size={15} aria-hidden="true" />
        </a>
      )}

      <form onSubmit={redeem} className="space-y-2 border-t border-ink-700 pt-3">
        <label htmlFor="plus-code" className="flex items-center gap-1.5 text-[0.8rem] font-medium text-ink-200">
          <Gift size={14} aria-hidden="true" /> {e.premium ? "Prolonger avec un code" : "J'ai un code"}
        </label>
        <div className="flex gap-2">
          <input
            id="plus-code"
            className="field font-mono uppercase"
            value={code}
            onChange={(ev) => {
              setCode(ev.target.value);
              if (state.status !== "sending") setState({ status: "idle" });
            }}
            placeholder="LBU-XXXX-XXXX-XXXX"
            autoComplete="off"
            spellCheck={false}
            maxLength={40}
          />
          <button
            type="submit"
            disabled={!code.trim() || state.status === "sending"}
            className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-md bg-claim px-3 text-sm font-semibold text-ink-950 transition hover:brightness-110 disabled:opacity-40"
          >
            {state.status === "sending" ? <LoaderCircle size={15} className="animate-spin" /> : "Activer"}
          </button>
        </div>
        {state.text && (
          <p className={`text-xs ${state.status === "error" ? "text-danger" : "text-mint"}`} role={state.status === "error" ? "alert" : "status"}>
            {state.text}
          </p>
        )}
        {!e.admin && (
          <a href="/plus" target="_blank" className="inline-flex items-center gap-1 text-xs text-claim hover:underline">
            {e.premium ? "Prolonger ou offrir" : "Voir les offres"} {e.premiumName} <ArrowRight size={12} />
          </a>
        )}
      </form>
    </section>
  );
}
