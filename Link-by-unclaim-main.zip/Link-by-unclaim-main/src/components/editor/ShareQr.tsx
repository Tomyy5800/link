"use client";

import { useEffect, useState } from "react";
import { Download } from "lucide-react";
import QRCode from "qrcode";

/** QR code de l'adresse de la page, à télécharger en PNG (affiches, vidéos, salons Discord). */
export function ShareQr({ url, slug }: { url: string; slug: string }) {
  const [dataUrl, setDataUrl] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    QRCode.toDataURL(url, {
      errorCorrectionLevel: "M",
      margin: 2,
      width: 640,
      color: { dark: "#020618", light: "#ffffff" },
    })
      .then((value) => !cancelled && setDataUrl(value))
      .catch(() => !cancelled && setDataUrl(null));
    return () => {
      cancelled = true;
    };
  }, [url]);

  return (
    <div className="flex items-center gap-4">
      <div className="flex h-28 w-28 shrink-0 items-center justify-center rounded-md bg-white p-1">
        {dataUrl ? (
          <img src={dataUrl} alt={`QR code vers ${url}`} width={104} height={104} className="h-full w-full" />
        ) : (
          <span className="h-full w-full animate-pulse rounded bg-ink-200" />
        )}
      </div>
      <div className="min-w-0 space-y-2">
        <p className="text-xs leading-relaxed text-ink-400">Un scan ouvre ta page. Pratique pour une miniature, un stream ou une affiche en jeu.</p>
        {dataUrl && (
          <a
            href={dataUrl}
            download={`link-${slug}.png`}
            className="inline-flex items-center gap-1.5 rounded-md border border-ink-500 px-3 py-1.5 text-xs font-medium text-ink-200 transition hover:border-ink-300"
          >
            <Download size={14} /> Télécharger le PNG
          </a>
        )}
      </div>
    </div>
  );
}
