"use client";

import { useCallback, useEffect, useState } from "react";
import { Check, CircleAlert, CircleCheck, CircleDashed, Copy, Globe, LoaderCircle, Pencil, RefreshCw, Trash2 } from "lucide-react";
import type { DomainCheck, DomainStatus } from "@/lib/domains";
import { confirmDialog } from "@/lib/confirm";
import { toast } from "@/lib/toast";
import { FeatureSection, useFeature } from "./EditorContext";

type Domain = {
  id: string;
  hostname: string;
  status: DomainStatus;
  verifiedAt: string | null;
  lastCheckAt: string | null;
  check: DomainCheck | null;
  dns: {
    txt: { type: "TXT"; name: string; value: string };
    routing: { type: "CNAME" | "A"; name: string; values: string[] }[];
    apex: boolean;
    targetMissing: boolean;
  };
};

const STATUS: Record<DomainStatus, { label: string; tone: string }> = {
  active: { label: "Actif", tone: "bg-mint/15 text-mint" },
  pending: { label: "En attente", tone: "bg-claim/15 text-claim" },
  error: { label: "À configurer", tone: "bg-danger/15 text-danger" },
};

function CopyValue({ value }: { value: string }) {
  const [done, setDone] = useState(false);
  return (
    <button
      type="button"
      onClick={() => void navigator.clipboard.writeText(value).then(() => (setDone(true), setTimeout(() => setDone(false), 1400)))}
      className="inline-flex shrink-0 items-center gap-1 rounded px-1.5 py-0.5 text-[11px] text-ink-300 transition-colors hover:bg-ink-700 hover:text-ink-100"
      aria-label={`Copier ${value}`}
    >
      {done ? <Check size={12} /> : <Copy size={12} />}
    </button>
  );
}

function Step({ step }: { step: { ok: boolean; message: string } | undefined }) {
  if (!step) return null;
  return (
    <li className="flex gap-2 text-xs">
      {step.ok ? <CircleCheck size={14} className="mt-px shrink-0 text-mint" aria-hidden="true" /> : <CircleDashed size={14} className="mt-px shrink-0 text-ink-500" aria-hidden="true" />}
      <span className={step.ok ? "text-ink-200" : "text-ink-400"}>{step.message}</span>
    </li>
  );
}

/** Domaine personnel de la page (Pro, Équipe) : ajout, enregistrements DNS, vérification réelle, remplacement. */
export function DomainsCard({ pageId }: { pageId: string }) {
  const state = useFeature("customDomains");
  const [domains, setDomains] = useState<Domain[] | null>(null);
  const [hostname, setHostname] = useState("");
  const [replacing, setReplacing] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const load = useCallback(async () => {
    const res = await fetch(`/api/me/pages/${pageId}/domains`, { cache: "no-store" }).catch(() => null);
    if (res?.ok) setDomains(((await res.json()) as { domains: Domain[] }).domains);
  }, [pageId]);

  useEffect(() => {
    if (state === "on") void load();
    // Fonction verrouillée : le formulaire est montré en aperçu, sans appel au serveur.
    else setDomains([]);
  }, [load, state]);

  async function call(key: string, method: string, url: string, body?: unknown) {
    setBusy(key);
    const res = await fetch(url, { method, headers: body ? { "Content-Type": "application/json" } : undefined, body: body ? JSON.stringify(body) : undefined }).catch(() => null);
    const json = (await res?.json().catch(() => ({}))) as { error?: string; domain?: Domain };
    setBusy(null);
    if (!res?.ok) {
      toast(json.error ?? "Action impossible.", { tone: "error" });
      return null;
    }
    return json;
  }

  async function add() {
    const json = await call("add", replacing ? "PATCH" : "POST", replacing ? `/api/me/pages/${pageId}/domains/${replacing}` : `/api/me/pages/${pageId}/domains`, { hostname });
    if (!json) return;
    toast(replacing ? "Domaine remplacé : configure ses DNS" : "Domaine ajouté : configure ses DNS", { tone: "success" });
    setHostname("");
    setReplacing(null);
    await load();
  }

  async function check(domain: Domain) {
    const json = await call(domain.id, "POST", `/api/me/pages/${pageId}/domains/${domain.id}/check`);
    if (!json?.domain) return;
    toast(json.domain.status === "active" ? `${domain.hostname} est actif` : "Configuration incomplète", {
      tone: json.domain.status === "active" ? "success" : "info",
      description: json.domain.status === "active" ? "Ta page s'affiche sur ce domaine, en HTTPS." : "Le détail de chaque contrôle est affiché sous le domaine.",
    });
    await load();
  }

  async function remove(domain: Domain) {
    const ok = await confirmDialog({ title: `Retirer ${domain.hostname} ?`, message: "Le domaine n'affichera plus ta page. Pense à supprimer ses enregistrements DNS.", confirmLabel: "Retirer", tone: "danger" });
    if (!ok) return;
    if (await call(domain.id, "DELETE", `/api/me/pages/${pageId}/domains/${domain.id}`)) await load();
  }

  if (state === "off") return null;
  return (
    <section className="space-y-4 rounded-lg border border-ink-700 bg-ink-850/60 p-4">
      <h3 className="hud-label inline-flex items-center gap-1.5 text-ink-400">
        <Globe size={13} aria-hidden="true" /> Domaine personnel
      </h3>
      <FeatureSection feature="customDomains" title="Domaine personnel">
        <div className="space-y-4">
          <p className="text-xs leading-relaxed text-ink-400">
            Affiche cette page sur ton propre nom de domaine (mondomaine.fr ou www.mondomaine.fr). Le domaine n&apos;est activé qu&apos;après la vérification de ses DNS et de
            HTTPS par nos serveurs.
          </p>
          {domains === null ? (
            <p className="inline-flex items-center gap-2 text-xs text-ink-400">
              <LoaderCircle size={13} className="animate-spin" /> Chargement…
            </p>
          ) : (
            domains.map((d) => (
              <div key={d.id} className="ui-panel-in space-y-3 rounded-md border border-ink-700 bg-ink-900 p-3">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="min-w-0 flex-1 truncate font-mono text-sm text-ink-100">{d.hostname}</span>
                  <span className={`rounded-sm px-1.5 py-px font-mono text-[10px] font-semibold ${STATUS[d.status].tone}`}>{STATUS[d.status].label}</span>
                  <button type="button" onClick={() => void check(d)} disabled={busy !== null} className="inline-flex items-center gap-1 rounded-md border border-ink-600 px-2 py-1 text-xs text-ink-200 transition-colors hover:border-ink-400 disabled:opacity-50">
                    {busy === d.id ? <LoaderCircle size={12} className="animate-spin" /> : <RefreshCw size={12} />} Vérifier
                  </button>
                  <button type="button" onClick={() => (setReplacing(d.id), setHostname(""))} className="rounded p-1 text-ink-400 transition-colors hover:text-ink-100" aria-label={`Remplacer ${d.hostname}`}>
                    <Pencil size={13} />
                  </button>
                  <button type="button" onClick={() => void remove(d)} disabled={busy !== null} className="rounded p-1 text-ink-400 transition-colors hover:text-danger" aria-label={`Retirer ${d.hostname}`}>
                    <Trash2 size={13} />
                  </button>
                </div>
                {d.dns.targetMissing && (
                  <p className="flex gap-1.5 text-xs text-claim">
                    <CircleAlert size={13} className="mt-px shrink-0" aria-hidden="true" /> L&apos;administration n&apos;a pas encore configuré la cible DNS des domaines personnels : la vérification ne peut pas aboutir pour l&apos;instant.
                  </p>
                )}
                {d.status !== "active" && (
                  <div className="space-y-1.5">
                    <p className="text-xs text-ink-300">Chez ton fournisseur de domaine, crée ces enregistrements :</p>
                    <div className="overflow-x-auto">
                      <table className="w-full min-w-[420px] text-left font-mono text-[11px]">
                        <thead>
                          <tr className="text-ink-500">
                            <th className="py-1 pr-2 font-medium">Type</th>
                            <th className="py-1 pr-2 font-medium">Nom</th>
                            <th className="py-1 font-medium">Valeur</th>
                          </tr>
                        </thead>
                        <tbody className="text-ink-200">
                          <tr className="border-t border-ink-800">
                            <td className="py-1 pr-2">TXT</td>
                            <td className="py-1 pr-2">
                              <span className="inline-flex items-center gap-1">
                                {d.dns.txt.name} <CopyValue value={d.dns.txt.name} />
                              </span>
                            </td>
                            <td className="py-1">
                              <span className="inline-flex items-center gap-1 break-all">
                                {d.dns.txt.value} <CopyValue value={d.dns.txt.value} />
                              </span>
                            </td>
                          </tr>
                          {d.dns.routing.map((r) => (
                            <tr key={r.type} className="border-t border-ink-800">
                              <td className="py-1 pr-2">{r.type}</td>
                              <td className="py-1 pr-2">{r.name}</td>
                              <td className="py-1">
                                {r.values.map((v) => (
                                  <span key={v} className="mr-2 inline-flex items-center gap-1">
                                    {v} <CopyValue value={v} />
                                  </span>
                                ))}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    <p className="text-[11px] text-ink-500">
                      {d.dns.apex
                        ? "Domaine racine : utilise l'enregistrement A (ou ALIAS/ANAME si ton fournisseur le propose)."
                        : "Sous-domaine : utilise de préférence le CNAME."}{" "}
                      La propagation DNS peut prendre de quelques minutes à quelques heures.
                    </p>
                  </div>
                )}
                {d.check && (
                  <ul className="space-y-1">
                    <Step step={d.check.ownership} />
                    <Step step={d.check.routing} />
                    <Step step={d.check.https} />
                  </ul>
                )}
              </div>
            ))
          )}
          {(domains?.length === 0 || replacing) && (
            <div className="flex items-end gap-2">
              <label className="block min-w-0 flex-1 space-y-1">
                <span className="text-[0.8rem] font-medium text-ink-200">{replacing ? "Nouveau domaine" : "Ajouter un domaine"}</span>
                <input className="field font-mono" value={hostname} placeholder="mondomaine.fr" inputMode="url" onChange={(e) => setHostname(e.target.value.trim())} />
              </label>
              <button type="button" onClick={() => void add()} disabled={!hostname || busy !== null} className="h-9 shrink-0 rounded-md bg-brand-500 px-3 text-sm font-semibold text-ink-950 transition-colors hover:bg-brand-400 disabled:opacity-40">
                {busy === "add" ? <LoaderCircle size={15} className="animate-spin" /> : replacing ? "Remplacer" : "Ajouter"}
              </button>
              {replacing && (
                <button type="button" onClick={() => setReplacing(null)} className="h-9 rounded-md px-2 text-xs text-ink-400 hover:text-ink-200">
                  Annuler
                </button>
              )}
            </div>
          )}
        </div>
      </FeatureSection>
    </section>
  );
}
