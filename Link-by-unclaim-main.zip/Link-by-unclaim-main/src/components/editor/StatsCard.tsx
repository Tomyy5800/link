"use client";

import { useEffect, useState } from "react";
import { Download, Globe, Lock, Monitor, Smartphone, Tablet } from "lucide-react";
import { BLOCK_META, blockSummary, type Block } from "@/lib/blocks";
import { useEditorEnv, useFeature } from "./EditorContext";

type Stats = {
  total: number;
  period: number;
  maxDays: number;
  days: { day: string; count: number }[];
  clicks: { blockId: string; count: number }[];
  audience: { referrers: { source: string; count: number }[]; devices: { device: string; count: number }[] } | null;
};

const PERIODS = [7, 14, 30, 90, 120];
const DEVICE_LABELS: Record<string, { label: string; icon: typeof Monitor }> = {
  mobile: { label: "Mobile", icon: Smartphone },
  tablet: { label: "Tablette", icon: Tablet },
  desktop: { label: "Ordinateur", icon: Monitor },
};

function Bars({ items }: { items: { key: string; label: React.ReactNode; count: number }[] }) {
  const max = Math.max(1, ...items.map((i) => i.count));
  return (
    <ul className="space-y-2">
      {items.map((item) => (
        <li key={item.key} className="space-y-1">
          <div className="flex items-baseline justify-between gap-3 text-xs">
            <span className="min-w-0 truncate text-ink-200">{item.label}</span>
            <span className="font-mono text-ink-300 tabular-nums">{item.count.toLocaleString("fr-FR")}</span>
          </div>
          <div className="h-1.5 overflow-hidden rounded-full bg-ink-700">
            <div className="h-full rounded-full bg-claim" style={{ width: `${(item.count / max) * 100}%` }} />
          </div>
        </li>
      ))}
    </ul>
  );
}

/** Statistiques de la page : vues uniques par jour, liens cliqués, sources et appareils (avancé). */
export function StatsCard({ blocks }: { blocks: Block[] }) {
  const { entitlements, openPlus, pageId } = useEditorEnv();
  const advanced = useFeature("advancedStats");
  const exportState = useFeature("statsExport");
  const [period, setPeriod] = useState(14);
  const [stats, setStats] = useState<Stats | null>(null);

  useEffect(() => {
    const controller = new AbortController();
    fetch(`/api/me/pages/${pageId}/stats?days=${period}`, { signal: controller.signal })
      .then((r) => (r.ok ? (r.json() as Promise<Stats>) : null))
      .then(setStats)
      .catch(() => undefined);
    return () => controller.abort();
  }, [period, pageId]);

  const maxDays = stats?.maxDays ?? entitlements.limits.statsDays;
  const periods = PERIODS.filter((p) => p <= maxDays);
  const series = stats?.days ?? Array.from({ length: period }, (_, i) => ({ day: String(i), count: 0 }));
  const max = Math.max(1, ...series.map((d) => d.count));
  const periodViews = series.reduce((sum, d) => sum + d.count, 0);
  const blocksById = new Map(blocks.map((b) => [b.id, b]));
  const clicks = (stats?.clicks ?? []).slice(0, 6);
  const totalClicks = (stats?.clicks ?? []).reduce((sum, c) => sum + c.count, 0);

  return (
    <section className="hud-panel space-y-4 rounded-[2px] border border-ink-700 bg-ink-850/60 p-4">
      <div className="flex items-center justify-between gap-2">
        <h3 className="hud-label inline-flex items-center gap-2 text-ink-400">
          Statistiques
          {exportState === "on" && (
            <a
              href={`/api/me/pages/${pageId}/stats?days=${period}&format=csv`}
              download
              className="inline-flex items-center gap-1 rounded border border-ink-700 px-1.5 py-0.5 font-sans text-[10px] tracking-normal text-ink-300 normal-case hover:border-ink-500 hover:text-ink-100"
              title="Télécharger les vues par jour (tableur)"
            >
              <Download size={11} /> CSV
            </a>
          )}
        </h3>
        <div className="flex rounded-md border border-ink-700 bg-ink-900 p-0.5" role="radiogroup" aria-label="Période">
          {periods.map((p) => (
            <button
              key={p}
              type="button"
              role="radio"
              aria-checked={period === p}
              onClick={() => setPeriod(p)}
              className={`rounded-[4px] px-2 py-0.5 font-mono text-[11px] transition ${period === p ? "bg-ink-700 text-ink-100" : "text-ink-400 hover:text-ink-200"}`}
            >
              {p} j
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-end justify-between gap-4">
        <div>
          <p className="font-display text-3xl font-bold">{stats ? stats.total.toLocaleString("fr-FR") : "—"}</p>
          <p className="text-xs text-ink-400">vues uniques au total</p>
        </div>
        <div className="text-right">
          <p className="font-mono text-lg text-ink-100">{stats ? periodViews.toLocaleString("fr-FR") : "—"}</p>
          <p className="text-xs text-ink-400">sur {period} jours</p>
        </div>
      </div>

      <div className={`flex h-24 items-end ${series.length > 40 ? "gap-px" : "gap-1"}`} role="img" aria-label={`Vues uniques des ${period} derniers jours`}>
        {series.map((d) => (
          <div key={d.day} className="group relative flex-1">
            <div
              className="w-full rounded-t-[2px] bg-brand-500/70 transition-colors group-hover:bg-brand-400"
              style={{ height: `${Math.max(3, (d.count / max) * 88)}px` }}
            />
            {stats && (
              <span className="pointer-events-none absolute bottom-full left-1/2 z-10 mb-1 hidden -translate-x-1/2 whitespace-nowrap rounded bg-ink-700 px-1.5 py-0.5 text-[0.65rem] text-ink-100 group-hover:block">
                {new Date(d.day).toLocaleDateString("fr-FR", { day: "numeric", month: "short", timeZone: "Europe/Paris" })} · {d.count}
              </span>
            )}
          </div>
        ))}
      </div>
      <p className="text-xs text-ink-400">Tes propres visites et les robots ne sont pas comptés.</p>

      <div className="space-y-2 border-t border-ink-700 pt-4">
        <div className="flex items-baseline justify-between">
          <p className="text-sm font-semibold text-ink-100">Liens les plus cliqués</p>
          <p className="font-mono text-xs text-ink-400 tabular-nums">
            {totalClicks.toLocaleString("fr-FR")} clic{totalClicks > 1 ? "s" : ""}
          </p>
        </div>
        {clicks.length === 0 ? (
          <p className="text-xs text-ink-400">Aucun clic sur la période.</p>
        ) : (
          <Bars
            items={clicks.map((c) => {
              const block = blocksById.get(c.blockId);
              return {
                key: c.blockId,
                count: c.count,
                label: block ? (
                  <>
                    {blockSummary(block)}
                    <span className="text-ink-400"> · {BLOCK_META[block.type].label}</span>
                  </>
                ) : (
                  "Bloc supprimé"
                ),
              };
            })}
          />
        )}
      </div>

      {advanced !== "off" && (
        <div className="space-y-3 border-t border-ink-700 pt-4">
          <p className="text-sm font-semibold text-ink-100">Audience</p>
          {stats?.audience ? (
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <p className="hud-label text-[10px] text-ink-500">Sources</p>
                {stats.audience.referrers.length ? (
                  <Bars
                    items={stats.audience.referrers.map((r) => ({
                      key: r.source,
                      count: r.count,
                      label: (
                        <span className="inline-flex items-center gap-1.5">
                          <Globe size={12} aria-hidden="true" /> {r.source === "direct" ? "Accès direct" : r.source}
                        </span>
                      ),
                    }))}
                  />
                ) : (
                  <p className="text-xs text-ink-400">Pas encore de données.</p>
                )}
              </div>
              <div className="space-y-2">
                <p className="hud-label text-[10px] text-ink-500">Appareils</p>
                {stats.audience.devices.length ? (
                  <Bars
                    items={stats.audience.devices.map((d) => {
                      const meta = DEVICE_LABELS[d.device];
                      const Icon = meta?.icon ?? Monitor;
                      return {
                        key: d.device,
                        count: d.count,
                        label: (
                          <span className="inline-flex items-center gap-1.5">
                            <Icon size={12} aria-hidden="true" /> {meta?.label ?? "Inconnu"}
                          </span>
                        ),
                      };
                    })}
                  />
                ) : (
                  <p className="text-xs text-ink-400">Pas encore de données.</p>
                )}
              </div>
            </div>
          ) : advanced === "locked" ? (
            <button
              type="button"
              onClick={openPlus}
              className="flex w-full items-center gap-2 rounded-md border border-dashed border-claim/40 px-3 py-3 text-left text-xs text-ink-300 transition hover:border-claim"
            >
              <Lock size={14} className="shrink-0 text-claim" aria-hidden="true" />
              D&apos;où viennent tes visiteurs (Discord, YouTube, X…) et sur quel appareil : inclus dans {entitlements.premiumName}.
            </button>
          ) : (
            <p className="text-xs text-ink-400">Chargement…</p>
          )}
        </div>
      )}
    </section>
  );
}
