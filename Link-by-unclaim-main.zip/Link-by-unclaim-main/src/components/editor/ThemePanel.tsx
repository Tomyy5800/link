"use client";

import { startTransition, useState } from "react";
import { Check, Copy, Download, RotateCcw, Upload } from "lucide-react";
import { MAX_CUSTOM_CSS, sanitizeCss } from "@/lib/css";
import {
  BG_EFFECTS,
  NAME_ANIMATIONS,
  PARTICLES,
  FONT_KEYS,
  FONT_LABELS,
  FONT_STACKS,
  GOOGLE_FONT_SUGGESTIONS,
  HEADING_ONLY_FONTS,
  THEME_PRESETS,
  backgroundStyle,
  contrastRatio,
  exportTheme,
  getPreset,
  importTheme,
  type FontKey,
  type Theme,
} from "@/lib/theme";
import { ColorField, ImageField, MediaField, RangeField, Segmented, Select, TextField, Toggle } from "@/components/ui/controls";
import { RADIO_PRESETS, RADIO_PRESET_IDS, resolveRadio } from "@/lib/radio";
import { AVATAR_FRAMES, FRAME_KEYS } from "@/lib/official-shop";
import { FeatureSection, useEditorEnv, useFeature } from "./EditorContext";

/**
 * Cadres d'avatar de la boutique officielle : seuls ceux que le propriétaire a débloqués sont
 * choisissables (le rendu public vérifie aussi la possession, côté serveur).
 */
function AvatarFramePicker({ value, onChange }: { value: Theme["avatarFrame"]; onChange: (frame: Theme["avatarFrame"]) => void }) {
  const { frames = [] } = useEditorEnv();
  const owned = FRAME_KEYS.filter((f) => frames.includes(f));
  return (
    <div className="space-y-1.5">
      <span className="flex items-center justify-between text-[0.8rem] font-medium text-ink-200">
        Cadre de profil
        <a href="/boutique" target="_blank" className="text-xs font-normal text-brand-300 hover:underline">
          Boutique officielle
        </a>
      </span>
      {owned.length === 0 ? (
        <p className="rounded-md border border-dashed border-ink-700 px-3 py-2 text-xs text-ink-400">Aucun cadre débloqué : les cadres s&apos;obtiennent dans la boutique officielle.</p>
      ) : (
        <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="Cadre de profil">
          {(["none", ...owned] as const).map((frame) => (
            <button
              key={frame}
              type="button"
              role="radio"
              aria-checked={value === frame}
              onClick={() => onChange(frame)}
              className={`flex flex-col items-center gap-1.5 rounded-md border px-2.5 py-2 text-xs transition-colors ${value === frame ? "border-brand-400 bg-brand-500/10 text-ink-100" : "border-ink-700 text-ink-400 hover:text-ink-200"}`}
            >
              {frame === "none" ? (
                <span className="block h-9 w-9 rounded-full bg-ink-700" />
              ) : (
                <span className="lbu-frame rounded-full" data-frame={frame}>
                  <span className="block h-9 w-9 rounded-full bg-ink-700" />
                </span>
              )}
              {frame === "none" ? "Aucun" : AVATAR_FRAMES[frame].label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

type Props = {
  theme: Theme;
  onChange: (theme: Theme) => void;
  slug: string;
  customCss: string;
  onCustomCssChange: (css: string) => void;
};

/** Réglages de mise en page, d'effets et de médias : ils ne détachent pas la page de son thème de départ. */
const LAYOUT_KEYS = [
  "showBanner",
  "showBadges",
  "showViews",
  "width",
  "layout",
  "columns",
  "gap",
  "rowHeight",
  "animation",
  "particles",
  "cursor",
  "cursorImage",
  "nameAnimation",
  "bioTypewriter",
  "tilt",
  "entryScreen",
  "entryText",
  "audioUrl",
  "audioVolume",
  "audioRadio",
  "audioPlayer",
  "bgVideoUrl",
] as const satisfies readonly (keyof Theme)[];
const LAYOUT_SET = new Set<string>(LAYOUT_KEYS);

/** Garde la mise en page, les effets et les médias quand on change de thème de départ. */
function keepLayout(theme: Theme): Partial<Theme> {
  return Object.fromEntries(LAYOUT_KEYS.map((k) => [k, theme[k]])) as Partial<Theme>;
}

const PARTICLE_LABELS: Record<(typeof PARTICLES)[number], string> = {
  none: "Aucune",
  snow: "Neige",
  sakura: "Pétales",
  sparkles: "Étincelles",
  fireflies: "Lucioles",
  rain: "Pluie",
  embers: "Braises",
};

const NAME_ANIMATION_LABELS: Record<(typeof NAME_ANIMATIONS)[number], string> = {
  none: "Aucune",
  rainbow: "Arc-en-ciel",
  glitch: "Glitch",
  typewriter: "Machine à écrire",
  wave: "Vague",
  shine: "Reflet",
};

/** Choix de la webradio de fond : préréglée, ou adresse https (validée avant d'être enregistrée). */
function BackgroundRadio({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const preset = RADIO_PRESET_IDS.includes(value);
  const [custom, setCustom] = useState(preset ? "" : value);
  const [showCustom, setShowCustom] = useState(!preset);
  const invalid = custom.trim() !== "" && !resolveRadio(custom.trim());
  return (
    <div className="space-y-2">
      <Select
        label="Radio"
        value={showCustom ? "custom" : value}
        onChange={(v) => {
          if (v === "custom") setShowCustom(true);
          else {
            setShowCustom(false);
            onChange(v);
          }
        }}
        options={[...RADIO_PRESET_IDS.map((id) => ({ value: id, label: RADIO_PRESETS[id].name })), { value: "custom", label: "Autre radio (adresse https)" }]}
      />
      {showCustom && (
        <TextField
          label="Adresse de la radio"
          value={custom}
          inputMode="url"
          maxLength={500}
          onChange={(v) => {
            setCustom(v);
            if (resolveRadio(v.trim())) onChange(v.trim());
          }}
          placeholder="https://radio.exemple.fr/public/ma-radio"
          error={invalid ? "Adresse https attendue (page AzuraCast ou flux audio)." : null}
        />
      )}
      <p className="text-xs text-ink-400">En direct, avec le titre en cours dans le lecteur. Tu peux aussi ajouter un bloc Radio à ta page.</p>
    </div>
  );
}

/** Schéma miniature d'une mise en page, pour le sélecteur. */
function LayoutThumb({ kind }: { kind: Theme["layout"] }) {
  const cell = "rounded-[2px] bg-current";
  if (kind === "stack") {
    return (
      <div className="mx-auto flex h-12 w-10 flex-col gap-1 opacity-80">
        <div className={`${cell} h-3`} />
        <div className={`${cell} h-2`} />
        <div className={`${cell} h-2`} />
        <div className={`${cell} h-2`} />
      </div>
    );
  }
  if (kind === "grid") {
    return (
      <div className="mx-auto grid h-12 w-16 grid-cols-3 grid-rows-3 gap-1 opacity-80">
        <div className={`${cell} col-span-3`} />
        <div className={`${cell} col-span-2 row-span-2`} />
        <div className={cell} />
        <div className={cell} />
      </div>
    );
  }
  return (
    <div className="mx-auto grid h-12 w-16 grid-cols-3 gap-1 opacity-80">
      <div className={`${cell} row-span-3`} />
      <div className={`${cell} col-span-2`} />
      <div className={cell} />
      <div className={cell} />
    </div>
  );
}

const EFFECT_LABELS: Record<(typeof BG_EFFECTS)[number], string> = {
  none: "Aucun",
  grain: "Grain",
  grid: "Grille",
  chunks: "Chunks",
  dots: "Points",
  stars: "Étoiles",
  aurora: "Aurore",
};

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="space-y-4 rounded-lg border border-ink-700 bg-ink-850/60 p-4">
      <h3 className="hud-label text-ink-400">{title}</h3>
      {children}
    </section>
  );
}

/** Polices Google Fonts : nom libre (catalogue fonts.google.com) ou suggestion. */
function GoogleFontFields({ theme, set }: { theme: Theme; set: (patch: Partial<Theme>) => void }) {
  // Aperçu des suggestions : seules les lettres de leur nom sont téléchargées (paramètre « text »).
  const letters = [...new Set(GOOGLE_FONT_SUGGESTIONS.join(""))].join("");
  const href = `https://fonts.googleapis.com/css2?${GOOGLE_FONT_SUGGESTIONS.map((f) => `family=${f.replace(/ /g, "+")}`).join("&")}&text=${encodeURIComponent(letters)}&display=swap`;
  const clean = (v: string) => v.replace(/[^A-Za-z0-9 ]/g, "").slice(0, 40);
  const chips = (value: string, onPick: (f: string) => void) => (
    <div className="flex flex-wrap gap-1.5">
      {GOOGLE_FONT_SUGGESTIONS.map((f) => (
        <button
          key={f}
          type="button"
          onClick={() => onPick(value === f ? "" : f)}
          aria-pressed={value === f}
          className={`rounded-md border px-2 py-1 text-sm transition ${value === f ? "border-brand-400 bg-brand-500/10 text-ink-100" : "border-ink-700 text-ink-300 hover:border-ink-500"}`}
          style={{ fontFamily: `"${f}", sans-serif` }}
        >
          {f}
        </button>
      ))}
    </div>
  );
  return (
    <FeatureSection feature="customFonts" title="Polices Google Fonts">
      <div className="space-y-3 rounded-md border border-ink-700 p-3">
        {href && <link rel="stylesheet" href={href} precedence="default" />}
        <p className="text-[0.8rem] font-medium text-ink-200">Polices Google Fonts</p>
        <TextField
          label="Texte"
          value={theme.googleFont}
          maxLength={40}
          onChange={(v) => set({ googleFont: clean(v) })}
          placeholder="Nom exact sur fonts.google.com, ex. Poppins"
        />
        {chips(theme.googleFont, (googleFont) => set({ googleFont }))}
        <TextField
          label="Titres et nom (facultatif)"
          value={theme.googleHeadingFont}
          maxLength={40}
          onChange={(v) => set({ googleHeadingFont: clean(v) })}
          placeholder="Vide : la police du texte"
        />
        <p className="text-xs text-ink-400">La police choisie dans la liste ci-dessus sert de secours pendant le chargement.</p>
      </div>
    </FeatureSection>
  );
}

function FontPicker({ value, onChange, fonts, label }: { value: FontKey; onChange: (f: FontKey) => void; fonts: readonly FontKey[]; label: string }) {
  return (
    <div className="space-y-1.5">
      <p className="text-[0.8rem] font-medium text-ink-200">{label}</p>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {fonts.map((font) => (
          <button
            key={font}
            type="button"
            onClick={() => onChange(font)}
            aria-pressed={value === font}
            className={`rounded-md border px-2.5 py-2 text-left transition ${
              value === font ? "border-brand-400 bg-brand-500/10" : "border-ink-600 hover:border-ink-400"
            }`}
          >
            <span className="block truncate text-base leading-tight text-ink-100" style={{ fontFamily: FONT_STACKS[font], fontSize: font === "arcade" ? 11 : undefined }}>
              Aa
            </span>
            <span className="mt-1 block truncate text-[11px] text-ink-400">{FONT_LABELS[font]}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

export function ThemePanel({ theme, onChange, slug, customCss, onCustomCssChange }: Props) {
  const [io, setIo] = useState<{ mode: "closed" | "import"; text: string; message: string | null }>({ mode: "closed", text: "", message: null });
  const [copied, setCopied] = useState(false);

  // Toute retouche visuelle détache la page de son thème de départ.
  const set = (patch: Partial<Theme>) => {
    const visual = Object.keys(patch).some((key) => !LAYOUT_SET.has(key));
    onChange({ ...theme, ...patch, ...(visual ? { preset: "custom" } : {}) });
  };
  const lowContrast = contrastRatio(theme.text, theme.bgColor) < 3;
  const layoutState = useFeature("advancedLayout");
  const effectsState = useFeature("effects");
  const mediaState = useFeature("backgroundMedia");
  const cssState = useFeature("customCss");
  const cssCheck = customCss ? sanitizeCss(customCss) : null;
  const bodyFonts = FONT_KEYS.filter((f) => !HEADING_ONLY_FONTS.includes(f));

  function download() {
    const blob = new Blob([exportTheme(theme)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `theme-${slug}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  async function copy() {
    try {
      await navigator.clipboard.writeText(exportTheme(theme));
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      setIo({ mode: "import", text: exportTheme(theme), message: "Copie impossible : sélectionne le texte ci-dessous." });
    }
  }

  function applyImport() {
    const imported = importTheme(io.text);
    if (!imported) {
      setIo({ ...io, message: "Ce texte n'est pas un thème Link by Unclaim." });
      return;
    }
    onChange({ ...imported, ...keepLayout(theme), bgImage: imported.bgImage || theme.bgImage });
    setIo({ mode: "closed", text: "", message: null });
  }

  return (
    <div className="space-y-4">
      {layoutState !== "off" && (
        <Section title="Mise en page sur ordinateur">
          <FeatureSection feature="advancedLayout" title="Mise en page avancée">
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-2">
                {(
                  [
                    ["stack", "Colonne", "Une colonne centrée, comme sur mobile."],
                    ["grid", "Grille", "Blocs en mosaïque, largeur et hauteur réglables."],
                    ["sidebar", "Profil latéral", "Profil fixe à gauche, blocs en grille à droite."],
                  ] as const
                ).map(([value, label, description]) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => set({ layout: value, ...(value !== "stack" && theme.width === "narrow" ? { width: "wide" as const } : {}) })}
                    aria-pressed={theme.layout === value}
                    title={description}
                    className={`rounded-md border px-2 pt-3 pb-2 text-center transition ${
                      theme.layout === value ? "border-brand-400 bg-brand-500/10 text-brand-300" : "border-ink-600 text-ink-400 hover:border-ink-400"
                    }`}
                  >
                    <LayoutThumb kind={value} />
                    <span className="mt-2 block text-xs font-medium text-ink-100">{label}</span>
                  </button>
                ))}
              </div>
              <p className="text-xs leading-relaxed text-ink-400">
                Sur mobile, la page reste en colonne. Règle la largeur et la hauteur de chaque bloc dans son onglet « Disposition et style », ou
                directement dans l&apos;aperçu « Ordinateur ».
              </p>
              {theme.layout !== "stack" && (
                <div className="grid grid-cols-3 gap-3">
                  <Segmented
                    label="Colonnes"
                    value={String(theme.columns) as "2" | "3" | "4"}
                    onChange={(v) => set({ columns: Number(v) as Theme["columns"] })}
                    options={[
                      { value: "2", label: "2" },
                      { value: "3", label: "3" },
                      { value: "4", label: "4" },
                    ]}
                  />
                  <Segmented
                    label="Espacement"
                    value={theme.gap}
                    onChange={(gap) => set({ gap })}
                    options={[
                      { value: "sm", label: "S" },
                      { value: "md", label: "M" },
                      { value: "lg", label: "L" },
                    ]}
                  />
                  <Segmented
                    label="Rangées"
                    value={theme.rowHeight}
                    onChange={(rowHeight) => set({ rowHeight })}
                    options={[
                      { value: "sm", label: "S" },
                      { value: "md", label: "M" },
                      { value: "lg", label: "L" },
                    ]}
                  />
                </div>
              )}
            </div>
          </FeatureSection>
          <Segmented
            label="Largeur de la page"
            value={theme.width}
            onChange={(width) => set({ width })}
            options={[
              { value: "narrow", label: "Étroite" },
              { value: "wide", label: "Large" },
              { value: "full", label: "Très large" },
            ]}
          />
        </Section>
      )}

      <Section title="Thèmes de départ">
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
          {THEME_PRESETS.map((preset) => {
            const active = theme.preset === preset.key;
            return (
              <button
                key={preset.key}
                type="button"
                // Dans une transition : l'aperçu passe d'un thème à l'autre en fondu (ViewTransition de l'éditeur).
                onClick={() => startTransition(() => onChange({ ...preset.theme, ...keepLayout(theme) }))}
                aria-pressed={active}
                className={`group relative overflow-hidden rounded-md border p-1 text-left transition ${
                  active ? "border-brand-400 ring-2 ring-brand-500/30" : "border-ink-600 hover:border-ink-400"
                }`}
              >
                <div className="flex h-14 flex-col justify-end gap-1 rounded p-2" style={backgroundStyle(preset.theme)}>
                  <span className="h-2 w-3/4 rounded-full" style={{ background: preset.theme.buttonGradient ? `linear-gradient(90deg, ${preset.theme.accent}, ${preset.theme.accent2})` : preset.theme.accent }} />
                  <span className="h-1.5 w-1/2 rounded-full opacity-60" style={{ background: preset.theme.text }} />
                </div>
                <span className="mt-1 block truncate px-1 pb-0.5 text-xs font-medium text-ink-200">{preset.label}</span>
                {active && (
                  <span className="absolute top-2 right-2 flex h-5 w-5 items-center justify-center rounded-full bg-brand-500 text-ink-950">
                    <Check size={12} strokeWidth={3} />
                  </span>
                )}
              </button>
            );
          })}
        </div>
        {theme.preset === "custom" && <p className="text-xs text-ink-400">Thème personnalisé. Choisis un thème de départ pour repartir de zéro.</p>}
      </Section>

      <Section title="Couleurs">
        <div className="grid grid-cols-2 gap-3">
          <ColorField label="Accent" value={theme.accent} onChange={(accent) => set({ accent })} />
          <ColorField label="Accent secondaire" value={theme.accent2} onChange={(accent2) => set({ accent2 })} />
          <ColorField label="Texte" value={theme.text} onChange={(text) => set({ text })} />
        </div>
        {lowContrast && (
          <p className="text-xs text-gold">Contraste faible entre le texte et le fond : ta page risque d&apos;être difficile à lire.</p>
        )}
      </Section>

      <Section title="Fond">
        <Segmented
          value={theme.bgType}
          onChange={(bgType) => set({ bgType })}
          options={[
            { value: "solid", label: "Couleur" },
            { value: "gradient", label: "Dégradé" },
            { value: "image", label: "Image" },
          ]}
        />
        <div className="grid grid-cols-2 gap-3">
          <ColorField label={theme.bgType === "gradient" ? "Début" : "Couleur"} value={theme.bgColor} onChange={(bgColor) => set({ bgColor })} />
          {theme.bgType === "gradient" && <ColorField label="Fin" value={theme.bgColor2} onChange={(bgColor2) => set({ bgColor2 })} />}
        </div>
        {theme.bgType === "gradient" && (
          <RangeField label="Angle" value={theme.bgAngle} min={0} max={360} step={5} unit="°" onChange={(bgAngle) => set({ bgAngle })} />
        )}
        {theme.bgType === "image" && (
          <>
            <ImageField label="Image de fond" value={theme.bgImage} onChange={(bgImage) => set({ bgImage })} />
            <div className="grid grid-cols-2 gap-3">
              <RangeField label="Assombrir" value={theme.bgDim} min={0} max={90} step={5} unit=" %" onChange={(bgDim) => set({ bgDim })} />
              <RangeField label="Flou" value={theme.bgBlur} min={0} max={24} unit=" px" onChange={(bgBlur) => set({ bgBlur })} />
            </div>
          </>
        )}
        <div className="space-y-1.5">
          <p className="text-[0.8rem] font-medium text-ink-200">Effet</p>
          <div className="grid grid-cols-4 gap-1.5 sm:grid-cols-7">
            {BG_EFFECTS.map((fx) => (
              <button
                key={fx}
                type="button"
                onClick={() => set({ bgEffect: fx })}
                aria-pressed={theme.bgEffect === fx}
                className={`rounded-md border px-1 py-2 text-xs transition ${
                  theme.bgEffect === fx ? "border-brand-400 bg-brand-500/10 text-ink-100" : "border-ink-600 text-ink-300 hover:border-ink-400"
                }`}
              >
                {EFFECT_LABELS[fx]}
              </button>
            ))}
          </div>
        </div>
      </Section>

      <Section title="Cartes">
        <Segmented
          label="Style"
          value={theme.cardStyle}
          onChange={(cardStyle) => set({ cardStyle, cardOpacity: null })}
          options={[
            { value: "glass", label: "Verre" },
            { value: "solid", label: "Plein" },
            { value: "outline", label: "Contour" },
            { value: "flat", label: "Discret" },
          ]}
        />
        {theme.cardStyle !== "flat" && <ColorField label="Couleur des cartes" value={theme.cardColor} onChange={(cardColor) => set({ cardColor })} />}
        <div className="space-y-1">
          <RangeField
            label="Opacité du fond"
            value={theme.cardOpacity ?? (theme.cardStyle === "solid" ? 100 : theme.cardStyle === "glass" ? 10 : theme.cardStyle === "flat" ? 6 : 0)}
            min={0}
            max={100}
            step={2}
            unit=" %"
            onChange={(cardOpacity) => set({ cardOpacity })}
          />
          {theme.cardOpacity !== null && (
            <button type="button" onClick={() => set({ cardOpacity: null })} className="text-xs text-brand-300 hover:underline">
              Revenir à la valeur du style
            </button>
          )}
        </div>
        <RangeField label="Flou derrière les cartes" value={theme.cardBlur} min={0} max={30} unit=" px" onChange={(cardBlur) => set({ cardBlur })} />
        <Segmented
          label="Ombre"
          value={theme.cardShadow}
          onChange={(cardShadow) => set({ cardShadow })}
          options={[
            { value: "none", label: "Aucune" },
            { value: "soft", label: "Douce" },
            { value: "strong", label: "Marquée" },
            { value: "glow", label: "Halo" },
          ]}
        />
      </Section>

      <Section title="Boutons">
        <Segmented
          label="Remplissage"
          value={theme.buttonFill}
          onChange={(buttonFill) => set({ buttonFill })}
          options={[
            { value: "solid", label: "Plein" },
            { value: "soft", label: "Doux" },
            { value: "outline", label: "Contour" },
          ]}
        />
        <Toggle
          label="Dégradé d'accent"
          description="Les boutons pleins passent de l'accent à l'accent secondaire."
          checked={theme.buttonGradient}
          onChange={(buttonGradient) => set({ buttonGradient })}
        />
        <Segmented
          label="Arrondis"
          value={theme.radius}
          onChange={(radius) => set({ radius })}
          options={[
            { value: "none", label: "0" },
            { value: "sm", label: "S" },
            { value: "md", label: "M" },
            { value: "lg", label: "L" },
            { value: "full", label: "Max" },
          ]}
        />
        <div className="grid grid-cols-2 gap-3">
          <Select
            label="Au survol"
            value={theme.buttonHover}
            onChange={(buttonHover) => set({ buttonHover })}
            options={[
              { value: "lift", label: "Soulever" },
              { value: "glow", label: "Halo" },
              { value: "grow", label: "Agrandir" },
              { value: "none", label: "Aucun effet" },
            ]}
          />
          <Select
            label="Texte"
            value={theme.buttonAlign}
            onChange={(buttonAlign) => set({ buttonAlign })}
            options={[
              { value: "left", label: "À gauche" },
              { value: "center", label: "Centré" },
            ]}
          />
        </div>
      </Section>

      <Section title="En-tête">
        <Segmented
          label="Disposition"
          value={theme.headerLayout}
          onChange={(headerLayout) => set({ headerLayout })}
          options={[
            { value: "classic", label: "Carte" },
            { value: "left", label: "À gauche" },
            { value: "hero", label: "Bannière" },
            { value: "minimal", label: "Épuré" },
          ]}
        />
        <div className="grid grid-cols-2 gap-3">
          <Segmented
            label="Avatar"
            value={theme.avatarShape}
            onChange={(avatarShape) => set({ avatarShape })}
            options={[
              { value: "circle", label: "Rond" },
              { value: "rounded", label: "Arrondi" },
              { value: "square", label: "Carré" },
            ]}
          />
          <Segmented
            label="Taille"
            value={theme.avatarSize}
            onChange={(avatarSize) => set({ avatarSize })}
            options={[
              { value: "sm", label: "S" },
              { value: "md", label: "M" },
              { value: "lg", label: "L" },
            ]}
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Select
            label="Contour de l'avatar"
            value={theme.avatarRing}
            onChange={(avatarRing) => set({ avatarRing })}
            options={[
              { value: "none", label: "Aucun" },
              { value: "accent", label: "Couleur d'accent" },
              { value: "gradient", label: "Dégradé" },
              { value: "glow", label: "Halo" },
            ]}
          />
          <Select
            label="Effet sur le nom"
            value={theme.nameEffect}
            onChange={(nameEffect) => set({ nameEffect })}
            options={[
              { value: "none", label: "Aucun" },
              { value: "gradient", label: "Dégradé" },
              { value: "glow", label: "Lueur" },
              { value: "shadow", label: "Ombre portée" },
            ]}
          />
        </div>
        <AvatarFramePicker value={theme.avatarFrame} onChange={(avatarFrame) => set({ avatarFrame })} />
        <Toggle label="Bannière" description="Ta bannière Discord, une image ou un dégradé de tes accents." checked={theme.showBanner} onChange={(showBanner) => set({ showBanner })} />
        <Toggle label="Badges" description="Pseudo Discord et NationsGlory sous ton nom." checked={theme.showBadges} onChange={(showBadges) => set({ showBadges })} />
        <Toggle label="Compteur de vues" description="Affiché en bas de page." checked={theme.showViews} onChange={(showViews) => set({ showViews })} />
      </Section>

      <Section title="Typographie et mise en page">
        <FontPicker label="Texte" value={theme.font} fonts={bodyFonts} onChange={(font) => set({ font })} />
        <div className="space-y-2">
          <Toggle
            label="Police différente pour les titres"
            checked={theme.headingFont !== null}
            onChange={(on) => set({ headingFont: on ? "chakra" : null })}
          />
          {theme.headingFont !== null && (
            <FontPicker label="Titres et nom" value={theme.headingFont} fonts={FONT_KEYS} onChange={(headingFont) => set({ headingFont })} />
          )}
        </div>
        <GoogleFontFields theme={theme} set={set} />
        {layoutState === "off" && (
          <Segmented
            label="Largeur de la page"
            value={theme.width}
            onChange={(width) => set({ width })}
            options={[
              { value: "narrow", label: "Étroite" },
              { value: "wide", label: "Large" },
            ]}
          />
        )}
        <Segmented
          label="Apparition des blocs"
          value={theme.animation}
          onChange={(animation) => set({ animation })}
          options={[
            { value: "none", label: "Aucune" },
            { value: "fade", label: "Fondu" },
            { value: "rise", label: "Montée" },
            { value: "pop", label: "Rebond" },
          ]}
        />
      </Section>

      {effectsState !== "off" && (
        <Section title="Effets animés">
          <FeatureSection feature="effects" title="Effets animés">
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <Select
                  label="Particules"
                  value={theme.particles}
                  onChange={(particles) => set({ particles })}
                  options={PARTICLES.map((p) => ({ value: p, label: PARTICLE_LABELS[p] }))}
                />
                <Select
                  label="Animation du nom"
                  value={theme.nameAnimation}
                  onChange={(nameAnimation) => set({ nameAnimation })}
                  options={NAME_ANIMATIONS.map((a) => ({ value: a, label: NAME_ANIMATION_LABELS[a] }))}
                />
              </div>
              <Segmented
                label="Curseur"
                value={theme.cursor}
                onChange={(cursor) => set({ cursor })}
                options={[
                  { value: "default", label: "Normal" },
                  { value: "glow", label: "Halo" },
                  { value: "trail", label: "Traînée" },
                  { value: "image", label: "Image" },
                ]}
              />
              {theme.cursor === "image" && (
                <ImageField
                  label="Image du curseur"
                  value={theme.cursorImage}
                  onChange={(cursorImage) => set({ cursorImage })}
                  hint="Petite image carrée (32 × 32 px conseillé)."
                />
              )}
              <Toggle
                label="Bio en machine à écrire"
                description="Ta bio s'écrit lettre par lettre à l'ouverture."
                checked={theme.bioTypewriter}
                onChange={(bioTypewriter) => set({ bioTypewriter })}
              />
              <Toggle label="Cartes inclinables" description="Les blocs pivotent légèrement sous la souris." checked={theme.tilt} onChange={(tilt) => set({ tilt })} />
              <p className="text-xs text-ink-400">Les effets sont coupés pour les visiteurs qui ont demandé à réduire les animations.</p>
            </div>
          </FeatureSection>
        </Section>
      )}

      {mediaState !== "off" && (
        <Section title="Musique et vidéo">
          <FeatureSection feature="backgroundMedia" title="Musique et vidéo de fond">
            <div className="space-y-4">
              <Segmented
                label="Musique de fond"
                value={theme.audioRadio ? "radio" : "file"}
                onChange={(source) => set({ audioRadio: source === "radio" ? "lyxia" : "" })}
                options={[
                  { value: "file", label: "Mon fichier" },
                  { value: "radio", label: "Une webradio" },
                ]}
              />
              {theme.audioRadio ? (
                <BackgroundRadio value={theme.audioRadio} onChange={(audioRadio) => set({ audioRadio })} />
              ) : (
                <MediaField label="Fichier audio" kind="audio" value={theme.audioUrl} onChange={(audioUrl) => set({ audioUrl })} />
              )}
              {(theme.audioUrl || theme.audioRadio) && (
                <>
                  <RangeField label="Volume de départ" value={theme.audioVolume} min={0} max={100} step={5} unit=" %" onChange={(audioVolume) => set({ audioVolume })} />
                  <Segmented
                    label="Lecteur"
                    value={theme.audioPlayer}
                    onChange={(audioPlayer) => set({ audioPlayer })}
                    options={[
                      { value: "left", label: "En bas à gauche" },
                      { value: "right", label: "En bas à droite" },
                      { value: "compact", label: "Bouton seul" },
                    ]}
                  />
                  <p className="text-xs text-ink-400">
                    Le lecteur n&apos;apparaît que sur ta page publique, pas dans cet aperçu. La musique démarre au premier clic du visiteur (ou à
                    l&apos;écran d&apos;entrée s&apos;il est activé) : les navigateurs interdisent le son automatique.
                  </p>
                </>
              )}
              <MediaField
                label="Vidéo de fond"
                kind="video"
                value={theme.bgVideoUrl}
                onChange={(bgVideoUrl) => set({ bgVideoUrl })}
                hint="Lue en boucle et sans le son derrière ta page. MP4 ou WebM."
              />
              <Toggle
                label="Écran d'entrée"
                description="Un clic pour entrer, qui permet aussi de lancer la musique (les navigateurs l'exigent)."
                checked={theme.entryScreen}
                onChange={(entryScreen) => set({ entryScreen })}
              />
              {theme.entryScreen && (
                <TextField label="Texte de l'écran d'entrée" value={theme.entryText} maxLength={60} onChange={(entryText) => set({ entryText })} />
              )}
            </div>
          </FeatureSection>
        </Section>
      )}

      {cssState !== "off" && (
        <Section title="CSS personnalisé">
          <FeatureSection feature="customCss" title="CSS personnalisé">
            <div className="space-y-2">
              <label htmlFor="custom-css" className="flex items-center justify-between text-[0.8rem] font-medium text-ink-200">
                Feuille de style de ta page
                <span className="text-[0.7rem] font-normal text-ink-400">
                  {customCss.length}/{MAX_CUSTOM_CSS}
                </span>
              </label>
              <textarea
                id="custom-css"
                className="field font-mono text-xs"
                rows={10}
                spellCheck={false}
                value={customCss}
                maxLength={MAX_CUSTOM_CSS}
                onChange={(e) => onCustomCssChange(e.target.value)}
                placeholder={'.lbu-card { border-width: 2px; }\n.lbu-cell[data-type="link"] .lbu-btn { letter-spacing: .04em; }'}
              />
              {cssCheck && !cssCheck.ok ? (
                <p className="text-xs text-danger" role="alert">
                  {cssCheck.error}
                </p>
              ) : (
                <p className="text-xs leading-relaxed text-ink-400">
                  Appliqué uniquement à ta page. Classes utiles : <code className="text-ink-200">.lbu-card</code>, <code className="text-ink-200">.lbu-btn</code>,{" "}
                  <code className="text-ink-200">.lbu-name</code>, <code className="text-ink-200">.lbu-cell[data-type=&quot;…&quot;]</code>. Les imports externes et le
                  JavaScript sont refusés ; les images doivent être en https.
                </p>
              )}
            </div>
          </FeatureSection>
        </Section>
      )}

      <Section title="Partager ou importer un thème">
        <div className="flex flex-wrap gap-2">
          <button type="button" onClick={copy} className="inline-flex items-center gap-1.5 rounded-md border border-ink-500 px-3 py-1.5 text-xs font-medium text-ink-200 transition hover:border-ink-300">
            {copied ? <Check size={14} /> : <Copy size={14} />} {copied ? "Thème copié" : "Copier le thème"}
          </button>
          <button type="button" onClick={download} className="inline-flex items-center gap-1.5 rounded-md border border-ink-500 px-3 py-1.5 text-xs font-medium text-ink-200 transition hover:border-ink-300">
            <Download size={14} /> Télécharger (.json)
          </button>
          <button
            type="button"
            onClick={() => setIo({ mode: io.mode === "import" ? "closed" : "import", text: "", message: null })}
            className="inline-flex items-center gap-1.5 rounded-md border border-ink-500 px-3 py-1.5 text-xs font-medium text-ink-200 transition hover:border-ink-300"
          >
            <Upload size={14} /> Importer
          </button>
          <button
            type="button"
            onClick={() => onChange({ ...(getPreset("unclaim")?.theme ?? theme), ...keepLayout(theme) })}
            className="inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium text-ink-400 transition hover:text-ink-100"
          >
            <RotateCcw size={14} /> Réinitialiser
          </button>
        </div>
        {io.mode === "import" && (
          <div className="space-y-2">
            <label htmlFor="theme-import" className="text-[0.8rem] font-medium text-ink-200">
              Colle un thème exporté
            </label>
            <textarea
              id="theme-import"
              className="field font-mono text-xs"
              rows={6}
              value={io.text}
              onChange={(e) => setIo({ ...io, text: e.target.value, message: null })}
              placeholder='{ "format": "link-by-unclaim/theme@2", … }'
            />
            {io.message && <p className="text-xs text-gold" role="alert">{io.message}</p>}
            <button
              type="button"
              onClick={applyImport}
              disabled={!io.text.trim()}
              className="rounded-md bg-brand-500 px-3 py-1.5 text-xs font-semibold text-ink-950 transition hover:bg-brand-400 disabled:opacity-40"
            >
              Appliquer ce thème
            </button>
          </div>
        )}
      </Section>
    </div>
  );
}
