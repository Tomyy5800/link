"use client";

import { useState } from "react";
import { Check, LoaderCircle, Lock, ShieldCheck, ShoppingBag, X } from "lucide-react";
import { BadgeIcon } from "@/components/badges/OfficialBadge";
import { formatPrice } from "@/lib/features";
import { AVATAR_FRAMES, SHOP_CATEGORIES, SHOP_CATEGORY_KEYS, type PublicShopItem, type ShopCategory } from "@/lib/official-shop";

/** Aperçu d'un article : cadre autour d'un avatar d'exemple, ou pastille du badge. */
function ItemVisual({ item }: { item: PublicShopItem }) {
  if (item.reward.type === "frame") {
    return (
      <span className="lbu-frame rounded-full" data-frame={item.reward.frame}>
        <span className="block h-20 w-20 rounded-full bg-[radial-gradient(circle_at_35%_30%,#3a4a7a,#0b1430)]" />
      </span>
    );
  }
  return (
    <span className="ui-badge-hero flex h-20 w-20 items-center justify-center rounded-2xl" style={{ background: `${item.color}1f`, color: item.color, boxShadow: `inset 0 0 0 1px ${item.color}55` }}>
      <BadgeIcon icon={item.icon} size={34} />
    </span>
  );
}

/** Boutique officielle Unclaim : catégories, fiches, et achat par Stripe (confirmé par le serveur). */
export function OfficialShop({ items, loggedIn, canPay, testMode }: { items: PublicShopItem[]; loggedIn: boolean; canPay: boolean; testMode: boolean }) {
  const categories = SHOP_CATEGORY_KEYS.filter((c) => items.some((i) => i.category === c));
  const [tab, setTab] = useState<ShopCategory | "all">("all");
  const [selected, setSelected] = useState<PublicShopItem | null>(null);
  const [accepted, setAccepted] = useState(false);
  const [state, setState] = useState<{ status: "idle" | "sending" | "error"; message?: string }>({ status: "idle" });
  const visible = tab === "all" ? items : items.filter((i) => i.category === tab);

  async function buy() {
    if (!selected || !accepted) return;
    setState({ status: "sending" });
    const res = await fetch("/api/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ kind: "item", itemId: selected.id, acceptTerms: true }),
    }).catch(() => null);
    const json = (await res?.json().catch(() => ({}))) as { url?: string; error?: string } | undefined;
    if (res?.ok && json?.url) {
      window.location.href = json.url;
      return;
    }
    setState({ status: "error", message: json?.error ?? "Le paiement n'a pas pu démarrer." });
  }

  if (!items.length) {
    return (
      <div className="rounded-xl border border-dashed border-ink-600 p-10 text-center">
        <ShoppingBag size={28} className="mx-auto text-ink-500" aria-hidden="true" />
        <p className="mt-3 font-semibold text-ink-200">Les premiers articles arrivent bientôt.</p>
        <p className="mt-1 text-sm text-ink-400">Badges exclusifs et cadres de profil seront vendus ici.</p>
      </div>
    );
  }

  return (
    <div>
      {categories.length > 1 && (
        <div role="tablist" aria-label="Catégories" className="mb-6 flex flex-wrap gap-1.5">
          {(["all", ...categories] as const).map((c) => (
            <button
              key={c}
              type="button"
              role="tab"
              aria-selected={tab === c}
              onClick={() => setTab(c)}
              className={`rounded-md border px-3 py-1.5 text-sm font-medium transition-colors duration-150 ${tab === c ? "border-brand-400 bg-brand-500/10 text-ink-100" : "border-ink-700 text-ink-400 hover:text-ink-200"}`}
            >
              {c === "all" ? "Tout" : SHOP_CATEGORIES[c].label}
            </button>
          ))}
        </div>
      )}

      <ul key={tab} className="ui-tab-in grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {visible.map((item) => (
          <li key={item.id} data-spotlight className="ui-spotlight flex flex-col rounded-xl border border-ink-700 bg-ink-900/90 p-5 transition-colors duration-200 hover:border-ink-500">
            <div className="flex items-start justify-between gap-3">
              <ItemVisual item={item} />
              <span className="rounded-sm border border-ink-700 px-1.5 py-px font-mono text-[10px] text-ink-400">{SHOP_CATEGORIES[item.category].label}</span>
            </div>
            <h3 className="mt-4 font-display text-xl font-bold">{item.name}</h3>
            {item.description && <p className="mt-1 text-sm text-ink-300">{item.description}</p>}
            {item.reward.type === "frame" && <p className="mt-1 text-xs text-ink-500">{AVATAR_FRAMES[item.reward.frame].description}</p>}
            {item.perks.length > 0 && (
              <ul className="mt-3 space-y-1.5 text-sm">
                {item.perks.map((p) => (
                  <li key={p} className="flex gap-2 text-ink-200">
                    <Check size={14} className="mt-0.5 shrink-0 text-mint" aria-hidden="true" /> {p}
                  </li>
                ))}
              </ul>
            )}
            <div className="mt-auto flex items-center justify-between gap-3 pt-5">
              <p className="font-display text-2xl font-bold tabular-nums">{formatPrice(item.priceCents)}</p>
              {item.owned ? (
                <span className="inline-flex items-center gap-1.5 rounded-md border border-mint/40 bg-mint/10 px-3 py-2 text-sm font-semibold text-mint">
                  <Check size={15} /> Dans ta collection
                </span>
              ) : !canPay ? (
                <span className="rounded-md border border-dashed border-ink-600 px-3 py-2 text-sm text-ink-400">Bientôt disponible</span>
              ) : loggedIn ? (
                <button
                  type="button"
                  onClick={() => {
                    setSelected(item);
                    setAccepted(false);
                    setState({ status: "idle" });
                  }}
                  className="rounded-md bg-brand-500 px-4 py-2 text-sm font-semibold text-ink-950 transition-colors hover:bg-brand-400"
                >
                  Acheter
                </button>
              ) : (
                <a href={`/login?next=${encodeURIComponent("/boutique")}`} className="rounded-md border border-ink-500 px-3 py-2 text-sm font-semibold text-ink-100 transition-colors hover:border-ink-300">
                  Se connecter
                </a>
              )}
            </div>
          </li>
        ))}
      </ul>

      {selected && (
        <div className="ui-overlay fixed inset-0 z-50 flex items-end justify-center bg-black/60 p-4 backdrop-blur-sm sm:items-center" role="dialog" aria-modal="true" aria-label={`Acheter ${selected.name}`} onClick={() => setSelected(null)}>
          <section className="ui-dialog hud-panel w-full max-w-md rounded-xl border border-ink-600 bg-ink-850 p-6" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="hud-label text-ink-400">Boutique officielle Unclaim</p>
                <p className="mt-1 font-display text-xl font-bold">
                  {selected.name} — {formatPrice(selected.priceCents)}
                </p>
                <p className="mt-0.5 text-xs text-ink-400">Paiement unique · ajouté à ton compte dès la confirmation du paiement</p>
              </div>
              <button type="button" onClick={() => setSelected(null)} className="rounded p-1 text-ink-400 transition-colors hover:text-ink-100" aria-label="Fermer">
                <X size={18} />
              </button>
            </div>
            {testMode && (
              <p className="mt-4 rounded-md border border-claim/40 bg-claim/10 px-3 py-2 text-xs text-ink-100">Mode test : aucun vrai paiement. Carte de test Stripe : 4242 4242 4242 4242.</p>
            )}
            <label className="mt-5 flex cursor-pointer items-start gap-3 text-sm text-ink-200">
              <input type="checkbox" checked={accepted} onChange={(e) => setAccepted(e.target.checked)} className="mt-1 h-4 w-4 shrink-0 accent-[#22c9e8]" />
              <span>
                J&apos;accepte les{" "}
                <a href="/cgv" target="_blank" className="text-brand-300 underline">
                  conditions générales de vente
                </a>
                . Je demande l&apos;accès immédiat à cet article et je reconnais perdre mon droit de rétractation de 14 jours (article L221-28 du Code de la consommation).
              </span>
            </label>
            {state.status === "error" && (
              <p className="mt-4 text-sm text-danger" role="alert">
                {state.message}
              </p>
            )}
            <button
              type="button"
              onClick={() => void buy()}
              disabled={!accepted || state.status === "sending"}
              className="mt-5 flex w-full items-center justify-center gap-2 rounded-md bg-claim px-4 py-3 font-semibold text-ink-950 transition-[filter,opacity] hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {state.status === "sending" ? <LoaderCircle size={18} className="animate-spin" /> : <Lock size={16} />} Payer {formatPrice(selected.priceCents)}
            </button>
            <p className="mt-3 flex items-center justify-center gap-1.5 text-xs text-ink-400">
              <ShieldCheck size={13} className="text-mint" aria-hidden="true" /> Paiement sécurisé par Stripe.
            </p>
          </section>
        </div>
      )}
    </div>
  );
}
