"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { CircleAlert, LoaderCircle } from "lucide-react";
import { celebrate } from "@/lib/confetti";

type OrderState = { order: { status: string; offerName: string } };

/** Suit la confirmation d'un achat de la boutique officielle (vérifiée par le serveur auprès de Stripe). */
export function ItemOrderStatus({ orderId }: { orderId: string | null }) {
  const [data, setData] = useState<OrderState | null>(null);
  const [failed, setFailed] = useState(false);
  const [tries, setTries] = useState(0);

  useEffect(() => {
    if (!orderId) return;
    let stop = false;
    const load = async () => {
      const res = await fetch(`/api/me/orders/${orderId}`, { cache: "no-store" }).catch(() => null);
      if (stop) return;
      if (!res?.ok) {
        setFailed(true);
        return;
      }
      const json = (await res.json()) as OrderState;
      setData(json);
      if (json.order.status === "pending") setTimeout(() => setTries((t) => t + 1), 2000);
      if (json.order.status === "paid") celebrate();
    };
    if (tries < 30) void load();
    return () => {
      stop = true;
    };
  }, [orderId, tries]);

  if (!orderId || failed) {
    return (
      <p className="mt-8 flex items-center gap-2 text-ink-300">
        <CircleAlert size={18} className="text-danger" /> Commande introuvable. Si tu as été débité·e, écris-nous avec la date du paiement.
      </p>
    );
  }
  if (!data || data.order.status === "pending") {
    return (
      <div className="mt-8 space-y-2" role="status">
        <p className="inline-flex items-center gap-2 text-lg font-semibold">
          <LoaderCircle size={20} className="animate-spin text-brand-300" /> Confirmation du paiement…
        </p>
        <p className="text-sm text-ink-400">{tries >= 30 ? "La confirmation tarde : l'article sera ajouté dès réception, tu peux fermer cette page." : "Quelques secondes, on attend la banque."}</p>
      </div>
    );
  }
  if (data.order.status !== "paid") {
    return (
      <p className="mt-8 flex items-center gap-2 text-ink-300">
        <CircleAlert size={18} className="text-danger" />
        {data.order.status === "refunded" ? "Cet achat a été remboursé." : "Le paiement n'a pas abouti : rien n'a été débité."}
      </p>
    );
  }
  return (
    <div className="mt-8 space-y-4">
      <h1 className="font-display text-3xl font-bold">C&apos;est à toi !</h1>
      <p className="text-ink-300">« {data.order.offerName} » est ajouté à ton compte. Active-le depuis l&apos;éditeur de ta page (Apparence) ou Mon espace › Compte.</p>
      <div className="flex flex-wrap justify-center gap-2">
        <Link href="/dashboard" className="inline-flex rounded-md bg-brand-500 px-5 py-2.5 font-semibold text-ink-950 transition-colors hover:bg-brand-400">
          Mon espace
        </Link>
        <Link href="/boutique" className="inline-flex rounded-md border border-ink-500 px-5 py-2.5 font-semibold text-ink-100 transition-colors hover:border-ink-300">
          Retour à la boutique
        </Link>
      </div>
    </div>
  );
}
