import { Castle, Globe, Mail } from "lucide-react";
import { BRAND_ICONS, type BrandIconKey } from "./brand-paths";
import type { Platform } from "@/lib/urls";

type Props = { platform: Platform | string; className?: string; size?: number };

function isBrand(key: string): key is BrandIconKey {
  return Object.prototype.hasOwnProperty.call(BRAND_ICONS, key);
}

/** Icône d'une plateforme (tracés simple-icons pour les marques, Lucide sinon). */
export function SocialIcon({ platform, className, size = 20 }: Props) {
  if (isBrand(platform)) {
    return (
      <svg viewBox="0 0 24 24" width={size} height={size} fill="currentColor" aria-hidden="true" className={className}>
        <path d={BRAND_ICONS[platform].path} />
      </svg>
    );
  }
  if (platform === "email") return <Mail size={size} className={className} aria-hidden="true" />;
  if (platform === "nationsglory") return <Castle size={size} className={className} aria-hidden="true" />;
  return <Globe size={size} className={className} aria-hidden="true" />;
}

export function DiscordLogo({ size = 20, className }: { size?: number; className?: string }) {
  return <SocialIcon platform="discord" size={size} className={className} />;
}
