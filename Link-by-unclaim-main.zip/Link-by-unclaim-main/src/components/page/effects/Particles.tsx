"use client";

import { useEffect, useRef } from "react";
import type { Theme } from "@/lib/theme";

type Kind = Exclude<Theme["particles"], "none">;

type Particle = { x: number; y: number; vx: number; vy: number; r: number; a: number; phase: number; spin: number };

const CONFIG: Record<Kind, { count: number; spawn: (w: number, h: number, first: boolean) => Particle }> = {
  snow: {
    count: 90,
    spawn: (w, h, first) => ({ x: Math.random() * w, y: first ? Math.random() * h : -10, vx: 0, vy: 0.4 + Math.random() * 0.9, r: 1 + Math.random() * 2.4, a: 0.5 + Math.random() * 0.5, phase: Math.random() * 6.28, spin: 0 }),
  },
  sakura: {
    count: 36,
    spawn: (w, h, first) => ({ x: Math.random() * w, y: first ? Math.random() * h : -20, vx: 0.3 + Math.random() * 0.6, vy: 0.6 + Math.random() * 0.8, r: 4 + Math.random() * 4, a: 0.75, phase: Math.random() * 6.28, spin: Math.random() * 6.28 }),
  },
  sparkles: {
    count: 55,
    spawn: (w, h) => ({ x: Math.random() * w, y: Math.random() * h, vx: 0, vy: -0.1 - Math.random() * 0.2, r: 1 + Math.random() * 2, a: 0, phase: Math.random() * 6.28, spin: 0 }),
  },
  fireflies: {
    count: 28,
    spawn: (w, h) => ({ x: Math.random() * w, y: Math.random() * h, vx: (Math.random() - 0.5) * 0.4, vy: (Math.random() - 0.5) * 0.4, r: 1.5 + Math.random() * 2, a: 0, phase: Math.random() * 6.28, spin: 0 }),
  },
  rain: {
    count: 120,
    spawn: (w, h, first) => ({ x: Math.random() * w, y: first ? Math.random() * h : -20, vx: -1.2, vy: 9 + Math.random() * 6, r: 10 + Math.random() * 12, a: 0.25 + Math.random() * 0.3, phase: 0, spin: 0 }),
  },
  embers: {
    count: 45,
    spawn: (w, h, first) => ({ x: Math.random() * w, y: first ? Math.random() * h : h + 10, vx: (Math.random() - 0.5) * 0.5, vy: -0.5 - Math.random() * 1.1, r: 1 + Math.random() * 2.2, a: 0.9, phase: Math.random() * 6.28, spin: 0 }),
  },
};

/** Particules en arrière-plan (canvas), aux couleurs du thème. Coupées sous prefers-reduced-motion. */
export function Particles({ kind, accent, accent2, fixed }: { kind: Kind; accent: string; accent2: string; fixed: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const config = CONFIG[kind];
    let w = 0;
    let h = 0;
    let frame = 0;
    let raf = 0;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      w = rect.width;
      h = rect.height;
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    const count = Math.round(config.count * Math.min(1, (w * h) / (1280 * 800) + 0.35));
    const particles = Array.from({ length: count }, () => config.spawn(w, h, true));
    const observer = new ResizeObserver(resize);
    observer.observe(canvas);

    const draw = () => {
      frame++;
      ctx.clearRect(0, 0, w, h);
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        p.phase += 0.02;
        if (kind === "snow") p.x += Math.sin(p.phase) * 0.4;
        if (kind === "sakura") {
          p.x += Math.sin(p.phase) * 0.6;
          p.spin += 0.02;
        }
        if (kind === "fireflies") {
          p.vx += (Math.random() - 0.5) * 0.04;
          p.vy += (Math.random() - 0.5) * 0.04;
          p.vx *= 0.98;
          p.vy *= 0.98;
        }
        p.x += p.vx;
        p.y += p.vy;

        const out = p.y > h + 30 || p.y < -40 || p.x < -40 || p.x > w + 40;
        if (out) particles[i] = config.spawn(w, h, kind === "sparkles" || kind === "fireflies");

        ctx.save();
        switch (kind) {
          case "snow":
            ctx.globalAlpha = p.a;
            ctx.fillStyle = "#ffffff";
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fill();
            break;
          case "sakura":
            ctx.globalAlpha = p.a;
            ctx.translate(p.x, p.y);
            ctx.rotate(p.spin);
            ctx.fillStyle = "#f9a8d4";
            ctx.beginPath();
            ctx.ellipse(0, 0, p.r, p.r * 0.6, 0, 0, Math.PI * 2);
            ctx.fill();
            break;
          case "sparkles": {
            const alpha = Math.max(0, Math.sin(p.phase * 1.5));
            ctx.globalAlpha = alpha;
            ctx.fillStyle = i % 2 ? accent : accent2;
            ctx.translate(p.x, p.y);
            ctx.rotate(Math.PI / 4);
            ctx.fillRect(-p.r, -p.r * 0.25, p.r * 2, p.r * 0.5);
            ctx.fillRect(-p.r * 0.25, -p.r, p.r * 0.5, p.r * 2);
            break;
          }
          case "fireflies": {
            ctx.globalAlpha = 0.35 + Math.abs(Math.sin(p.phase)) * 0.65;
            ctx.shadowColor = accent;
            ctx.shadowBlur = 12;
            ctx.fillStyle = accent;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fill();
            break;
          }
          case "rain":
            ctx.globalAlpha = p.a;
            ctx.strokeStyle = "#cbd5e1";
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p.x + p.vx * 2, p.y + p.r);
            ctx.stroke();
            break;
          case "embers":
            p.a -= 0.003;
            if (p.a <= 0) particles[i] = config.spawn(w, h, false);
            ctx.globalAlpha = Math.max(0, p.a);
            ctx.shadowColor = "#fb923c";
            ctx.shadowBlur = 8;
            ctx.fillStyle = i % 3 ? "#fb923c" : accent;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fill();
            break;
        }
        ctx.restore();
      }
      raf = requestAnimationFrame(draw);
    };

    const onVisibility = () => {
      cancelAnimationFrame(raf);
      if (document.visibilityState === "visible") raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      cancelAnimationFrame(raf);
      observer.disconnect();
      document.removeEventListener("visibilitychange", onVisibility);
      void frame;
    };
  }, [kind, accent, accent2]);

  return <canvas ref={ref} className={`pointer-events-none inset-0 z-0 h-full w-full ${fixed ? "fixed" : "absolute"}`} aria-hidden="true" />;
}
