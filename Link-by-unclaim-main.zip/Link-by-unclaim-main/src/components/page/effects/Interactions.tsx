"use client";

import { createContext, useContext, useEffect, useId, useRef, useState, type RefObject } from "react";
import { Music2, Pause, Play, Radio, Volume2, VolumeX } from "lucide-react";
import { useNowPlaying } from "../blocks/RadioBlock";
import { announcePlaying, onOtherPlaying } from "../audio-bus";
import { RichText } from "../RichText";

// Effets interactifs des pages publiques (Link+ selon l'administration).

const reduced = () => typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

/** Halo ou traînée qui suit le pointeur, à l'intérieur de la page. */
export function CursorEffect({ kind, rootRef }: { kind: "glow" | "trail"; rootRef: RefObject<HTMLElement | null> }) {
  const glowRef = useRef<HTMLDivElement>(null);
  const [dots, setDots] = useState<{ x: number; y: number; id: number }[]>([]);

  useEffect(() => {
    const root = rootRef.current;
    if (!root || reduced() || window.matchMedia("(pointer: coarse)").matches) return;
    let id = 0;
    const onMove = (e: PointerEvent) => {
      const rect = root.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      if (kind === "glow" && glowRef.current) glowRef.current.style.transform = `translate(${x - 160}px, ${y - 160}px)`;
      if (kind === "trail") setDots((d) => [...d.slice(-14), { x, y, id: id++ }]);
    };
    root.addEventListener("pointermove", onMove);
    return () => root.removeEventListener("pointermove", onMove);
  }, [kind, rootRef]);

  useEffect(() => {
    if (kind !== "trail" || !dots.length) return;
    const t = setTimeout(() => setDots((d) => d.slice(1)), 40);
    return () => clearTimeout(t);
  }, [dots, kind]);

  if (kind === "glow") {
    return (
      <div
        ref={glowRef}
        className="pointer-events-none absolute top-0 left-0 z-0 h-80 w-80 rounded-full opacity-25 blur-3xl transition-transform duration-100"
        style={{ background: "radial-gradient(circle, var(--lbu-accent), transparent 70%)" }}
        aria-hidden="true"
      />
    );
  }
  return (
    <div className="pointer-events-none absolute inset-0 z-50 overflow-hidden" aria-hidden="true">
      {dots.map((d, i) => (
        <span
          key={d.id}
          className="absolute rounded-full"
          style={{
            left: d.x - 4,
            top: d.y - 4,
            width: 8,
            height: 8,
            background: i % 2 ? "var(--lbu-accent)" : "var(--lbu-accent-2)",
            opacity: (i + 1) / dots.length,
            transform: `scale(${(i + 1) / dots.length})`,
          }}
        />
      ))}
    </div>
  );
}

/** Inclinaison 3D des cartes au survol. */
export function TiltCards({ rootRef }: { rootRef: RefObject<HTMLElement | null> }) {
  useEffect(() => {
    const root = rootRef.current;
    if (!root || reduced() || window.matchMedia("(pointer: coarse)").matches) return;
    let current: HTMLElement | null = null;
    const reset = () => {
      if (current) current.style.transform = "";
      current = null;
    };
    const onMove = (e: PointerEvent) => {
      const card = (e.target as HTMLElement).closest<HTMLElement>(".lbu-cell > .lbu-card, .lbu-cell > figure.lbu-card, .lbu-cell > section.lbu-card");
      if (card !== current) reset();
      if (!card) return;
      current = card;
      const r = card.getBoundingClientRect();
      const px = (e.clientX - r.left) / r.width - 0.5;
      const py = (e.clientY - r.top) / r.height - 0.5;
      card.style.transform = `perspective(900px) rotateX(${(-py * 6).toFixed(2)}deg) rotateY(${(px * 6).toFixed(2)}deg)`;
      card.style.transition = "transform 80ms ease-out";
    };
    root.addEventListener("pointermove", onMove);
    root.addEventListener("pointerleave", reset);
    return () => {
      reset();
      root.removeEventListener("pointermove", onMove);
      root.removeEventListener("pointerleave", reset);
    };
  }, [rootRef]);
  return null;
}

/** Vrai une fois le visiteur entré (écran d'entrée franchi, ou pas d'écran d'entrée). */
export const EnteredContext = createContext(true);

/** Texte tapé lettre par lettre (le texte complet est rendu côté serveur pour les moteurs). */
export function Typewriter({ text, speed = 45, rich }: { text: string; speed?: number; rich?: boolean }) {
  const [shown, setShown] = useState<number | null>(null);
  const entered = useContext(EnteredContext);
  useEffect(() => {
    if (reduced() || !entered) return;
    setShown(0);
    let i = 0;
    const timer = setInterval(() => {
      i++;
      setShown(i);
      if (i >= text.length) clearInterval(timer);
    }, speed);
    return () => clearInterval(timer);
  }, [text, speed, entered]);

  if (shown === null || shown >= text.length) return rich ? <RichText text={text} /> : <>{text}</>;
  const plain = text.slice(0, shown).replace(/[*_~|`]/g, "");
  return (
    <span className="whitespace-pre-line">
      {plain}
      <span className="lbu-caret" aria-hidden="true">
        |
      </span>
    </span>
  );
}

/**
 * Écran d'entrée : un clic (ou Entrée, Espace, Échap) pour entrer, ce qui permet aussi de lancer
 * la musique — les navigateurs l'exigent. La page derrière ne défile pas tant qu'il est affiché.
 */
export function EntryScreen({ text, onEnter }: { text: string; onEnter: () => void }) {
  const [open, setOpen] = useState(true);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const enterRef = useRef(onEnter);
  enterRef.current = onEnter;

  useEffect(() => {
    if (!open) return;
    buttonRef.current?.focus();
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Enter" || e.key === " " || e.key === "Escape") {
        e.preventDefault();
        setOpen(false);
        enterRef.current();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  if (!open) return null;
  return (
    <button
      ref={buttonRef}
      type="button"
      onClick={() => {
        setOpen(false);
        enterRef.current();
      }}
      className="fixed inset-0 z-[60] flex cursor-pointer flex-col items-center justify-center gap-3 bg-black/70 backdrop-blur-xl focus:outline-none"
      style={{ color: "var(--lbu-text)", fontFamily: "var(--lbu-heading-font)" }}
      aria-label={text || "Entrer sur la page"}
    >
      <span className="lbu-entry-text text-[1.2em] font-semibold tracking-wide">{text || "Clique pour entrer"}</span>
      <span className="text-[0.75em] opacity-60" style={{ fontFamily: "inherit" }}>
        ou appuie sur Entrée
      </span>
    </button>
  );
}

type PlayerProps = {
  src: string;
  volume: number;
  startRef: RefObject<(() => void) | null>;
  /** Webradio : lecture en direct (on recharge le flux à la reprise) et titre en cours. */
  live?: { name: string; nowPlaying: string | null } | null;
  position: "left" | "right" | "compact";
};

/** Musique de fond avec mini-lecteur (lecture après interaction, une seule source à la fois). */
export function AudioPlayer({ src, volume, startRef, live = null, position }: PlayerProps) {
  const id = useId();
  const audioRef = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);
  const [vol, setVol] = useState(volume / 100);
  const now = useNowPlaying(live?.nowPlaying ?? null, Boolean(live));

  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = vol;
  }, [vol]);

  const pause = () => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.pause();
    if (live) {
      // Radio : on coupe le flux pour reprendre en direct, sans retard accumulé.
      audio.removeAttribute("src");
      audio.load();
    }
    setPlaying(false);
  };
  const pauseRef = useRef(pause);
  pauseRef.current = pause;

  const play = () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (!audio.getAttribute("src")) audio.src = src;
    audio.volume = vol;
    audio
      .play()
      .then(() => {
        setPlaying(true);
        announcePlaying(id);
      })
      .catch(() => setPlaying(false));
  };
  const playRef = useRef(play);
  playRef.current = play;

  useEffect(() => onOtherPlaying(id, () => pauseRef.current()), [id]);
  useEffect(() => {
    startRef.current = () => playRef.current();
    return () => {
      startRef.current = null;
    };
  }, [startRef]);

  const toggle = () => (playing ? pause() : play());
  const side = position === "right" ? "right-4" : "left-4";
  const title = live ? (now?.title ? `${now.title}${now.artist ? ` · ${now.artist}` : ""}` : live.name) : null;

  return (
    <div className={`lbu-card fixed bottom-4 ${side} z-40 flex max-w-[calc(100vw-2rem)] items-center gap-2 px-2.5 py-2 text-[0.8rem]`}>
      <audio ref={audioRef} src={live ? undefined : src} loop={!live} preload="none" />
      <button type="button" onClick={toggle} className="lbu-icon-btn !h-8 !w-8" aria-label={playing ? "Mettre en pause" : "Lancer la musique"}>
        {playing ? <Pause size={15} /> : <Play size={15} />}
      </button>
      {position !== "compact" && (
        <>
          {title && (
            <span className="flex max-w-[11rem] min-w-0 items-center gap-1.5">
              {live ? <Radio size={13} className="shrink-0" aria-hidden="true" /> : <Music2 size={13} className="shrink-0" aria-hidden="true" />}
              <span className="truncate">{title}</span>
            </span>
          )}
          <button type="button" onClick={() => setVol((v) => (v > 0 ? 0 : volume / 100 || 0.4))} className="lbu-muted" aria-label={vol > 0 ? "Couper le son" : "Remettre le son"}>
            {vol > 0 ? <Volume2 size={16} /> : <VolumeX size={16} />}
          </button>
          <input
            type="range"
            min={0}
            max={100}
            value={Math.round(vol * 100)}
            onChange={(e) => setVol(Number(e.target.value) / 100)}
            className="w-20"
            style={{ accentColor: "var(--lbu-accent)" }}
            aria-label="Volume"
          />
        </>
      )}
    </div>
  );
}
