"use client";

import { useEffect } from "react";

/** Signale une visite au compteur (côté client : les robots et préchargements ne comptent pas). */
export function ViewBeacon({ slug }: { slug: string }) {
  useEffect(() => {
    const key = `lbu:viewed:${slug}:${new Date().toISOString().slice(0, 10)}`;
    try {
      if (sessionStorage.getItem(key)) return;
      sessionStorage.setItem(key, "1");
    } catch {
      // stockage indisponible : le serveur déduplique de toute façon
    }
    // Seul le domaine d'origine est conservé côté serveur (jamais le chemin complet).
    fetch(`/api/pages/${encodeURIComponent(slug)}/view`, {
      method: "POST",
      keepalive: true,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ referrer: document.referrer.slice(0, 300) }),
    }).catch(() => undefined);
  }, [slug]);
  return null;
}
