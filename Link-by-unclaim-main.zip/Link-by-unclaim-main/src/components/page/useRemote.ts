"use client";

import { useEffect, useState } from "react";

/**
 * Charge une ressource JSON de l'API quand elle n'a pas été préchargée par le serveur.
 * La requête est annulée si la clé change (ex. : pseudo modifié dans l'éditeur).
 */
export function useRemote<T>(url: string | null, initial: T | undefined, enabled = true) {
  const [state, setState] = useState<{ url: string | null; data: T | undefined; loading: boolean }>({
    url: initial ? url : null,
    data: initial,
    loading: false,
  });

  useEffect(() => {
    if (!url || !enabled || state.url === url) return;
    const controller = new AbortController();
    const timer = window.setTimeout(() => {
      setState((s) => ({ ...s, loading: true }));
      fetch(url, { signal: controller.signal })
        .then((res) => res.json() as Promise<T>)
        .then((data) => setState({ url, data, loading: false }))
        .catch((error: unknown) => {
          if (error instanceof DOMException && error.name === "AbortError") return;
          setState({ url, data: undefined, loading: false });
        });
    }, 350); // petit délai : on attend la fin de la frappe dans l'éditeur
    return () => {
      window.clearTimeout(timer);
      controller.abort();
    };
  }, [url, enabled, state.url]);

  return { data: state.url === url ? state.data : undefined, loading: state.loading || (state.url !== url && Boolean(url) && enabled) };
}
