"use client";

import { useEffect, useRef, useState } from "react";
import { Flag, X } from "lucide-react";

const REASONS = [
  { value: "inappropriate", label: "Contenu choquant ou inapproprié" },
  { value: "scam", label: "Arnaque ou hameçonnage" },
  { value: "impersonation", label: "Usurpation d'identité" },
  { value: "harassment", label: "Harcèlement ou haine" },
  { value: "other", label: "Autre" },
] as const;

/** Lien « Signaler » du pied de page : envoie un signalement à la modération. */
export function ReportButton({ slug }: { slug: string }) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState<string>("inappropriate");
  const [message, setMessage] = useState("");
  const [state, setState] = useState<{ status: "idle" | "sending" | "sent" | "error"; text?: string }>({ status: "idle" });

  useEffect(() => {
    const d = dialogRef.current;
    if (!d) return;
    if (open && !d.open) d.showModal();
    if (!open && d.open) d.close();
  }, [open]);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    setState({ status: "sending" });
    const res = await fetch(`/api/pages/${encodeURIComponent(slug)}/report`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reason, message }),
    }).catch(() => null);
    if (res?.ok) setState({ status: "sent" });
    else {
      const json = (await res?.json().catch(() => ({}))) as { error?: string } | undefined;
      setState({ status: "error", text: json?.error ?? "Envoi impossible, réessaie plus tard." });
    }
  }

  return (
    <>
      <button type="button" onClick={() => setOpen(true)} className="inline-flex items-center gap-1 opacity-60 transition-opacity hover:opacity-100">
        <Flag size={12} aria-hidden="true" /> Signaler
      </button>
      <dialog
        ref={dialogRef}
        onClose={() => setOpen(false)}
        className="m-auto w-[min(92vw,420px)] rounded-xl border border-white/10 bg-[#0f172b] p-0 text-left text-[15px] text-slate-100 backdrop:bg-black/70"
        aria-label="Signaler cette page"
      >
        <form onSubmit={send} className="space-y-4 p-5 font-sans">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold">Signaler cette page</h2>
            <button type="button" onClick={() => setOpen(false)} className="rounded p-1 text-slate-400 hover:text-white" aria-label="Fermer">
              <X size={16} />
            </button>
          </div>
          {state.status === "sent" ? (
            <p className="text-sm text-slate-300">Merci, la modération de Link by Unclaim va examiner cette page.</p>
          ) : (
            <>
              <fieldset className="space-y-2">
                <legend className="mb-1 text-sm text-slate-300">Quel est le problème ?</legend>
                {REASONS.map((r) => (
                  <label key={r.value} className="flex cursor-pointer items-center gap-2 text-sm">
                    <input type="radio" name="reason" value={r.value} checked={reason === r.value} onChange={() => setReason(r.value)} />
                    {r.label}
                  </label>
                ))}
              </fieldset>
              <label className="block space-y-1 text-sm">
                <span className="text-slate-300">Précisions (facultatif)</span>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  maxLength={500}
                  rows={3}
                  className="w-full rounded-md border border-slate-600 bg-[#020618] p-2 text-sm text-slate-100"
                />
              </label>
              {state.status === "error" && <p className="text-sm text-red-300">{state.text}</p>}
              <button
                type="submit"
                disabled={state.status === "sending"}
                className="w-full rounded-md bg-[#22c9e8] px-3 py-2 text-sm font-semibold text-[#021018] disabled:opacity-50"
              >
                {state.status === "sending" ? "Envoi…" : "Envoyer le signalement"}
              </button>
            </>
          )}
        </form>
      </dialog>
    </>
  );
}
