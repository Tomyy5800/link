import { Fragment, type ReactNode } from "react";
import { customEmojiUrl, type TimestampStyle } from "@/lib/discord-markup";
import { EMOJI_SHORTCODES } from "@/lib/emoji";
import { toSafeHref } from "@/lib/urls";
import { DiscordTime } from "./DiscordTime";

// Mise en forme « façon Discord », rendue sans HTML brut (aucun risque d'injection) :
// **gras**, *italique*, __souligné__, ~~barré~~, ||spoiler||, `code`, [lien](url),
// liens automatiques, dates <t:…:R>, émojis personnalisés <:nom:id>, codes :fire:,
// et en début de ligne : # titres, -# sous-texte, > citation, - liste.

const INLINE =
  /<t:(-?\d{1,13})(?::([tTdDfFR]))?>|<(a?):([a-zA-Z0-9_]{2,32}):(\d{15,22})>|\[([^\]\n]{1,200})\]\(([^)\s]{1,2048})\)|\*\*([^*\n]+?)\*\*|__([^_\n]+?)__|\*([^*\n]+?)\*|(?<![\w])_([^_\n]+?)_(?![\w])|~~([^~\n]+?)~~|\|\|([^|\n]+?)\|\||`([^`\n]+?)`|(https?:\/\/[^\s<]+[^\s<.,:;"')\]!?])|:([a-z0-9_+-]{1,32}):/g;

export function renderInline(text: string, depth = 0): ReactNode[] {
  if (depth > 4) return [text];
  const out: ReactNode[] = [];
  let last = 0;
  let key = 0;
  for (const m of text.matchAll(INLINE)) {
    const index = m.index ?? 0;
    if (index > last) out.push(text.slice(last, index));
    const k = `${depth}-${key++}`;
    const [, ts, tsStyle, animated, emojiName, emojiId, linkLabel, linkUrl, bold, underline, italic, italic2, strike, spoiler, code, auto, shortcode] = m;
    if (ts !== undefined) {
      out.push(<DiscordTime key={k} seconds={Number(ts)} style={(tsStyle as TimestampStyle) || "f"} />);
    } else if (emojiId !== undefined) {
      out.push(
        <img
          key={k}
          src={customEmojiUrl(emojiId, animated === "a")}
          alt={`:${emojiName}:`}
          title={`:${emojiName}:`}
          className="lbu-emoji"
          loading="lazy"
          draggable={false}
        />,
      );
    } else if (shortcode !== undefined) {
      out.push(EMOJI_SHORTCODES[shortcode] ?? m[0]);
    } else if (linkLabel !== undefined && linkUrl !== undefined) {
      const href = toSafeHref(linkUrl);
      out.push(
        href ? (
          <a key={k} href={href} target="_blank" rel="noopener noreferrer nofollow ugc">
            {renderInline(linkLabel, depth + 1)}
          </a>
        ) : (
          m[0]
        ),
      );
    } else if (bold !== undefined) out.push(<strong key={k}>{renderInline(bold, depth + 1)}</strong>);
    else if (underline !== undefined) out.push(<u key={k}>{renderInline(underline, depth + 1)}</u>);
    else if (italic !== undefined) out.push(<em key={k}>{renderInline(italic, depth + 1)}</em>);
    else if (italic2 !== undefined) out.push(<em key={k}>{renderInline(italic2, depth + 1)}</em>);
    else if (strike !== undefined) out.push(<s key={k}>{renderInline(strike, depth + 1)}</s>);
    else if (spoiler !== undefined)
      out.push(
        <span key={k} className="lbu-spoiler" tabIndex={0} title="Spoiler">
          {renderInline(spoiler, depth + 1)}
        </span>,
      );
    else if (code !== undefined) out.push(<code key={k}>{code}</code>);
    else if (auto !== undefined) {
      const href = toSafeHref(auto);
      out.push(
        href ? (
          <a key={k} href={href} target="_blank" rel="noopener noreferrer nofollow ugc">
            {auto.replace(/^https?:\/\/(www\.)?/, "")}
          </a>
        ) : (
          auto
        ),
      );
    }
    last = index + m[0].length;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}

type Line =
  | { kind: "p"; lines: string[] }
  | { kind: "quote"; lines: string[] }
  | { kind: "list"; items: string[] }
  | { kind: "h"; level: 1 | 2 | 3; text: string }
  | { kind: "sub"; text: string }
  | { kind: "gap" };

function toBlocks(text: string): Line[] {
  const blocks: Line[] = [];
  for (const raw of text.replace(/\r\n?/g, "\n").split("\n")) {
    const line = raw.trimEnd();
    const prev = blocks[blocks.length - 1];
    let match: RegExpMatchArray | null;
    if (!line.trim()) {
      if (prev && prev.kind !== "gap") blocks.push({ kind: "gap" });
    } else if ((match = line.match(/^(#{1,3}) (.+)$/))) {
      blocks.push({ kind: "h", level: match[1].length as 1 | 2 | 3, text: match[2] });
    } else if ((match = line.match(/^-# (.+)$/))) {
      blocks.push({ kind: "sub", text: match[1] });
    } else if ((match = line.match(/^> ?(.*)$/))) {
      if (prev?.kind === "quote") prev.lines.push(match[1]);
      else blocks.push({ kind: "quote", lines: [match[1]] });
    } else if ((match = line.match(/^\s*[-*•] (.+)$/))) {
      if (prev?.kind === "list") prev.items.push(match[1]);
      else blocks.push({ kind: "list", items: [match[1]] });
    } else if (prev?.kind === "p") {
      prev.lines.push(line);
    } else {
      blocks.push({ kind: "p", lines: [line] });
    }
  }
  while (blocks[blocks.length - 1]?.kind === "gap") blocks.pop();
  return blocks;
}

function withBreaks(lines: string[]): ReactNode {
  return lines.map((line, i) => (
    <Fragment key={i}>
      {i > 0 && <br />}
      {renderInline(line)}
    </Fragment>
  ));
}

const HEADING_CLASS = { 1: "text-[1.35em] font-bold", 2: "text-[1.18em] font-bold", 3: "text-[1.05em] font-semibold" };

export function RichText({ text, className = "" }: { text: string; className?: string }) {
  const blocks = toBlocks(text);
  if (!blocks.length) return null;
  return (
    <div className={`lbu-rich space-y-1.5 break-words ${className}`}>
      {blocks.map((block, i) => {
        switch (block.kind) {
          case "p":
            return <p key={i}>{withBreaks(block.lines)}</p>;
          // Citations et listes restent alignées à gauche, mais suivent l'alignement du bloc.
          case "quote":
            return (
              <div key={i}>
                <blockquote>{withBreaks(block.lines)}</blockquote>
              </div>
            );
          case "list":
            return (
              <div key={i}>
                <ul>
                  {block.items.map((item, j) => (
                    <li key={j}>{renderInline(item)}</li>
                  ))}
                </ul>
              </div>
            );
          case "h":
            return (
              <p key={i} className={HEADING_CLASS[block.level]}>
                {renderInline(block.text)}
              </p>
            );
          case "sub":
            return (
              <p key={i} className="lbu-muted text-[0.8em]">
                {renderInline(block.text)}
              </p>
            );
          case "gap":
            return <div key={i} className="h-1.5" aria-hidden="true" />;
        }
      })}
    </div>
  );
}
