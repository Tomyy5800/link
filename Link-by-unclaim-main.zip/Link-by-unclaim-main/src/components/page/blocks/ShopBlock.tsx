"use client";

import { useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { ArrowLeft, Check, ChevronLeft, ChevronRight, ExternalLink, LoaderCircle, Minus, Plus, ShoppingBag, Trash2 } from "lucide-react";
import type { BlockData } from "@/lib/blocks";
import { confetti } from "@/lib/confetti";
import {
  LOW_STOCK,
  MAX_QUANTITY,
  discountPercent,
  formatMoney,
  isAvailable,
  orderTotal,
  productOptions,
  type CartLine,
  type ShopProduct,
} from "@/lib/shop";
import { toSafeHref, toSafeImageSrc } from "@/lib/urls";

type View = { kind: "list" } | { kind: "product"; id: string } | { kind: "cart" } | { kind: "sent"; reference: string; contact: string };

const field =
  "w-full rounded-[calc(var(--lbu-radius,12px)*0.7)] border px-3 py-2 text-[0.9em] outline-none transition focus:border-[var(--lbu-accent)]";
const fieldStyle: CSSProperties = { background: "var(--lbu-faint)", borderColor: "var(--lbu-faint)", color: "var(--lbu-text)" };
const accentButton: CSSProperties = { background: "var(--lbu-accent-fill, var(--lbu-accent))", color: "var(--lbu-on-accent)", borderRadius: "var(--lbu-radius, 12px)" };

function images(product: ShopProduct): string[] {
  return product.images.map((src) => toSafeImageSrc(src)).filter((src): src is string => Boolean(src));
}

function Price({ product, currency, large }: { product: ShopProduct; currency: string; large?: boolean }) {
  const discount = discountPercent(product.price, product.compareAt);
  return (
    <span className={`flex flex-wrap items-baseline gap-x-2 ${large ? "text-[1.25em]" : "text-[0.92em]"}`}>
      <span className="font-bold" style={{ color: "var(--lbu-accent-ink, var(--lbu-accent))" }}>
        {product.price === null ? "Prix libre" : formatMoney(product.price, currency)}
      </span>
      {discount !== null && product.compareAt !== null && (
        <span className="lbu-muted text-[0.8em] line-through">{formatMoney(product.compareAt, currency)}</span>
      )}
    </span>
  );
}

/** Produit sans photo : son émoji en grand (ou un sac) sur un dégradé aux couleurs de la page. La
 * taille suit celle de la vignette (unités de conteneur), avec un repli fixe. */
function Placeholder({ emoji, size }: { emoji: string; size: number }) {
  return (
    <span
      className="lbu-shop-placeholder absolute inset-0 flex items-center justify-center [container-type:size]"
      style={{ background: "radial-gradient(circle at 30% 20%, var(--lbu-accent-soft), transparent 60%), linear-gradient(135deg, var(--lbu-faint), color-mix(in srgb, var(--lbu-accent) 22%, transparent))" }}
    >
      {emoji ? (
        <span className="lbu-shop-emoji leading-none" style={{ fontSize: `max(${size}px, 42cqmin)` }} aria-hidden="true">
          {emoji}
        </span>
      ) : (
        <ShoppingBag size={Math.round(size * 0.55)} style={{ color: "var(--lbu-accent)" }} aria-hidden="true" />
      )}
    </span>
  );
}

/** Vignette d'un produit : image (la deuxième apparaît au survol), étiquettes, prix. */
function ProductCard({
  product,
  currency,
  list,
  onOpen,
  onQuickAdd,
}: {
  product: ShopProduct;
  currency: string;
  list: boolean;
  onOpen: () => void;
  onQuickAdd: ((from: HTMLElement) => void) | null;
}) {
  const pics = images(product);
  const discount = discountPercent(product.price, product.compareAt);
  const available = isAvailable(product);
  const media = (
    <span className={`lbu-shop-media relative block overflow-hidden ${list ? "h-16 w-16 shrink-0 rounded-[calc(var(--lbu-radius,12px)*0.6)]" : "aspect-square w-full"}`}>
      {pics[0] ? (
        <>
          <img src={pics[0]} alt="" loading="lazy" className="lbu-shop-img absolute inset-0 h-full w-full object-cover" />
          {pics[1] && !list && <img src={pics[1]} alt="" loading="lazy" className="lbu-shop-img-alt absolute inset-0 h-full w-full object-cover" />}
        </>
      ) : (
        <Placeholder emoji={product.emoji} size={list ? 26 : 48} />
      )}
      {!list && product.badge && <span className="lbu-shop-tag absolute top-2 left-2">{product.badge}</span>}
      {!list && discount !== null && <span className="lbu-shop-tag lbu-shop-tag--deal absolute bottom-2 left-2">-{discount} %</span>}
      {!available && <span className="lbu-shop-soldout absolute inset-0 flex items-center justify-center text-[0.8em] font-bold tracking-wide uppercase">Épuisé</span>}
    </span>
  );
  return (
    <div className={`lbu-shop-item relative ${available ? "" : "lbu-shop-item--out"}`}>
      <button type="button" onClick={onOpen} className={`block w-full text-left ${list ? "flex items-center gap-3 p-2" : ""}`} aria-label={`${product.name} : voir le produit`}>
        {media}
        <span className={`block min-w-0 ${list ? "flex-1" : "p-2.5"}`}>
          {list && product.badge && <span className="lbu-shop-tag mb-1 inline-block">{product.badge}</span>}
          <span className="line-clamp-2 block text-[0.9em] leading-snug font-semibold">{product.name}</span>
          <span className="mt-1 block">
            <Price product={product} currency={currency} />
          </span>
          {available && product.stock !== null && product.stock <= LOW_STOCK && (
            <span className="mt-0.5 block text-[0.72em] font-semibold" style={{ color: "#f59e0b" }}>
              Plus que {product.stock}
            </span>
          )}
        </span>
        {list && <ChevronRight size={16} className="lbu-muted shrink-0" aria-hidden="true" />}
      </button>
      {onQuickAdd && !list && (
        <button
          type="button"
          onClick={(event) => onQuickAdd(event.currentTarget.closest(".lbu-shop-item")?.querySelector(".lbu-shop-media") as HTMLElement)}
          className="lbu-shop-quick absolute top-2 right-2 flex h-8 w-8 items-center justify-center rounded-full shadow-lg"
          style={{ background: "var(--lbu-accent-fill, var(--lbu-accent))", color: "var(--lbu-on-accent)" }}
          aria-label={`Ajouter « ${product.name} » au panier`}
        >
          <Plus size={16} />
        </button>
      )}
    </div>
  );
}

/**
 * Bloc « Boutique » : vitrine de produits (grille, carrousel ou liste), fiche produit avec
 * galerie et variantes, panier et demande de commande. Tout se passe dans le bloc (aucune
 * fenêtre par-dessus la page) : il fonctionne aussi dans l'aperçu de l'éditeur et la démo.
 * Les produits « lien » renvoient vers la boutique du vendeur (clics comptés).
 */
export function ShopBlock({ data, blockId, slug, seller, live }: { data: BlockData<"shop">; blockId: string; slug: string; seller: string; live: boolean }) {
  const products = useMemo(() => data.products.filter((p) => p.name.trim()), [data.products]);
  const orderable = products.some((p) => p.mode === "order" && p.id);
  const storageKey = `lbu:panier:${slug}:${blockId}`;
  const [view, setView] = useState<View>({ kind: "list" });
  const [cart, setCart] = useState<CartLine[]>([]);
  const [bump, setBump] = useState(0);
  const rootRef = useRef<HTMLElement>(null);
  const cartRef = useRef<HTMLButtonElement>(null);

  // Panier gardé d'une visite à l'autre (page publique seulement).
  useEffect(() => {
    if (!live) return;
    try {
      const saved = JSON.parse(window.localStorage.getItem(storageKey) ?? "[]") as CartLine[];
      if (Array.isArray(saved)) setCart(saved.filter((l) => products.some((p) => p.id === l.productId && p.mode === "order")));
    } catch {
      // stockage indisponible : panier éphémère
    }
  }, [live, storageKey, products]);

  const saveCart = (next: CartLine[]) => {
    setCart(next);
    if (!live) return;
    try {
      window.localStorage.setItem(storageKey, JSON.stringify(next));
    } catch {
      // stockage indisponible
    }
  };

  const go = (next: View) => {
    setView(next);
    // Le haut du bloc reste en vue quand on change d'écran.
    const root = rootRef.current;
    if (root && root.getBoundingClientRect().top < 0) root.scrollIntoView({ block: "start", behavior: "smooth" });
  };

  /** Le produit s'envole vers le panier, qui sautille. */
  const fly = (from: HTMLElement | null | undefined) => {
    const root = rootRef.current;
    const target = cartRef.current;
    if (!from || !root || !target || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const box = root.getBoundingClientRect();
    const a = from.getBoundingClientRect();
    const b = target.getBoundingClientRect();
    const ghost = from.cloneNode(true) as HTMLElement;
    Object.assign(ghost.style, {
      position: "absolute",
      left: `${a.left - box.left}px`,
      top: `${a.top - box.top}px`,
      width: `${a.width}px`,
      height: `${a.height}px`,
      margin: "0",
      zIndex: "20",
      pointerEvents: "none",
      borderRadius: "999px",
    });
    root.appendChild(ghost);
    const dx = b.left + b.width / 2 - (a.left + a.width / 2);
    const dy = b.top + b.height / 2 - (a.top + a.height / 2);
    ghost
      .animate(
        [
          { transform: "translate(0, 0) scale(1)", opacity: 1, borderRadius: "16px" },
          { transform: `translate(${dx * 0.55}px, ${dy * 0.55 - 40}px) scale(0.45)`, opacity: 0.9, offset: 0.55 },
          { transform: `translate(${dx}px, ${dy}px) scale(0.08)`, opacity: 0.2, borderRadius: "999px" },
        ],
        { duration: 650, easing: "cubic-bezier(0.5, 0, 0.3, 1)" },
      )
      .finished.catch(() => undefined)
      .finally(() => ghost.remove());
  };

  const add = (product: ShopProduct, option: string, quantity: number, from?: HTMLElement | null) => {
    const existing = cart.find((l) => l.productId === product.id && l.option === option);
    const limit = Math.min(MAX_QUANTITY, product.stock ?? MAX_QUANTITY);
    const next = existing
      ? cart.map((l) => (l === existing ? { ...l, quantity: Math.min(limit, l.quantity + quantity) } : l))
      : [...cart, { productId: product.id, option, quantity: Math.min(limit, quantity) }];
    saveCart(next);
    fly(from);
    window.setTimeout(() => setBump((n) => n + 1), 520);
  };

  const count = cart.reduce((n, l) => n + l.quantity, 0);
  const layout = data.layout;

  return (
    <section ref={rootRef} className="lbu-card lbu-shop relative @container p-4" aria-label={data.title || "Boutique"}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="lbu-heading flex items-center gap-2 text-[1.05em] font-bold">
            <ShoppingBag size={17} style={{ color: "var(--lbu-accent)" }} aria-hidden="true" />
            {data.title || "Boutique"}
          </p>
          {data.intro && view.kind === "list" && <p className="lbu-muted mt-1 text-[0.85em]">{data.intro}</p>}
          {/* Boutique personnelle : jamais confondue avec la boutique officielle Unclaim. */}
          <p className="lbu-muted mt-0.5 text-[0.68em]">Vendu par {seller}, vendeur indépendant · Link by Unclaim n&apos;est pas le vendeur</p>
        </div>
        {orderable && (
          <button
            ref={cartRef}
            type="button"
            onClick={() => go(view.kind === "cart" ? { kind: "list" } : { kind: "cart" })}
            className="lbu-shop-cart relative flex h-10 shrink-0 items-center gap-1.5 rounded-full px-3 text-[0.85em] font-semibold"
            aria-label={`Panier : ${count} article${count > 1 ? "s" : ""}`}
            aria-pressed={view.kind === "cart"}
          >
            <ShoppingBag size={16} aria-hidden="true" />
            <span key={bump} className={bump ? "lbu-shop-bump inline-block tabular-nums" : "inline-block tabular-nums"}>
              {count}
            </span>
          </button>
        )}
      </div>

      <div key={view.kind === "product" ? `p-${view.id}` : view.kind} className="lbu-shop-view mt-3">
        {view.kind === "list" &&
          (products.length === 0 ? (
            <p className="lbu-muted py-6 text-center text-[0.85em]">Les produits arrivent bientôt.</p>
          ) : (
            <div
              className={
                layout === "list"
                  ? "flex flex-col gap-2"
                  : layout === "carousel"
                    ? "lbu-shop-rail -mx-4 flex snap-x snap-mandatory gap-3 overflow-x-auto px-4 pb-2"
                    : "grid grid-cols-2 gap-3 @xl:grid-cols-3"
              }
            >
              {products.map((product, index) => (
                <div key={product.id || index} className={layout === "carousel" ? "w-[44%] shrink-0 snap-start @xl:w-[30%]" : ""} style={{ "--i": index } as CSSProperties}>
                  <ProductCard
                    product={product}
                    currency={data.currency}
                    list={layout === "list"}
                    onOpen={() => go({ kind: "product", id: product.id || String(index) })}
                    onQuickAdd={
                      product.mode === "order" && product.id && isAvailable(product) && productOptions(product).length === 0
                        ? (from) => add(product, "", 1, from)
                        : null
                    }
                  />
                </div>
              ))}
            </div>
          ))}

        {view.kind === "product" &&
          (() => {
            const index = products.findIndex((p, i) => (p.id || String(i)) === view.id);
            const product = products[index];
            if (!product) return null;
            return (
              <ProductSheet
                product={product}
                currency={data.currency}
                blockId={blockId}
                onBack={() => go({ kind: "list" })}
                onAdd={(option, quantity, from) => add(product, option, quantity, from)}
                onShowCart={() => go({ kind: "cart" })}
                inCart={cart.some((l) => l.productId === product.id)}
              />
            );
          })()}

        {view.kind === "cart" && (
          <CartView
            cart={cart}
            products={products}
            data={data}
            slug={slug}
            blockId={blockId}
            seller={seller}
            live={live}
            onChange={saveCart}
            onBack={() => go({ kind: "list" })}
            onSent={(reference, contact) => {
              saveCart([]);
              go({ kind: "sent", reference, contact });
            }}
          />
        )}

        {view.kind === "sent" && (
          <div className="py-6 text-center" aria-live="polite">
            <span className="lbu-shop-done mx-auto flex h-14 w-14 items-center justify-center rounded-full" style={{ background: "var(--lbu-accent-soft)", color: "var(--lbu-accent-ink, var(--lbu-accent))" }}>
              <Check size={28} aria-hidden="true" />
            </span>
            <p className="lbu-heading mt-3 text-[1.1em] font-bold">Commande envoyée !</p>
            <p className="lbu-muted mx-auto mt-1 max-w-xs text-[0.85em]">
              {seller} te recontacte à <strong style={{ color: "var(--lbu-text)" }}>{view.contact}</strong> pour le paiement et la livraison.
            </p>
            <p className="mt-2 font-mono text-[0.8em]">Référence : {view.reference}</p>
            <button type="button" onClick={() => go({ kind: "list" })} className="lbu-shop-ghost mt-4 inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-[0.85em] font-semibold">
              <ArrowLeft size={15} aria-hidden="true" /> Retour à la boutique
            </button>
          </div>
        )}
      </div>
    </section>
  );
}

/** Fiche produit : galerie, description, variante, quantité, achat ou ajout au panier. */
function ProductSheet({
  product,
  currency,
  blockId,
  onBack,
  onAdd,
  onShowCart,
  inCart,
}: {
  product: ShopProduct;
  currency: string;
  blockId: string;
  onBack: () => void;
  onAdd: (option: string, quantity: number, from: HTMLElement | null) => void;
  onShowCart: () => void;
  inCart: boolean;
}) {
  const pics = images(product);
  const options = productOptions(product);
  const [picture, setPicture] = useState(0);
  const [option, setOption] = useState(options.length === 1 ? options[0] : "");
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);
  const mediaRef = useRef<HTMLDivElement>(null);
  const available = isAvailable(product);
  const href = product.mode === "link" ? toSafeHref(product.url) : null;
  const max = Math.min(MAX_QUANTITY, product.stock ?? MAX_QUANTITY);
  const needsOption = options.length > 0 && !option;

  return (
    <div>
      <button type="button" onClick={onBack} className="lbu-shop-ghost mb-3 inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[0.8em] font-semibold">
        <ArrowLeft size={14} aria-hidden="true" /> Tous les produits
      </button>
      <div className="grid gap-4 @lg:grid-cols-[1fr_1.1fr]">
        <div>
          <div ref={mediaRef} className="lbu-shop-media relative aspect-square overflow-hidden rounded-[var(--lbu-radius,12px)]">
            {pics.length ? (
              <img key={picture} src={pics[picture]} alt={product.name} className="lbu-shop-photo absolute inset-0 h-full w-full object-cover" />
            ) : (
              <Placeholder emoji={product.emoji} size={88} />
            )}
            {pics.length > 1 && (
              <>
                <button
                  type="button"
                  onClick={() => setPicture((picture - 1 + pics.length) % pics.length)}
                  className="lbu-shop-arrow absolute top-1/2 left-2 -translate-y-1/2"
                  aria-label="Photo précédente"
                >
                  <ChevronLeft size={18} />
                </button>
                <button type="button" onClick={() => setPicture((picture + 1) % pics.length)} className="lbu-shop-arrow absolute top-1/2 right-2 -translate-y-1/2" aria-label="Photo suivante">
                  <ChevronRight size={18} />
                </button>
              </>
            )}
            {product.badge && <span className="lbu-shop-tag absolute top-2 left-2">{product.badge}</span>}
          </div>
          {pics.length > 1 && (
            <div className="mt-2 flex gap-2">
              {pics.map((src, i) => (
                <button
                  key={src}
                  type="button"
                  onClick={() => setPicture(i)}
                  className={`h-12 w-12 overflow-hidden rounded-[calc(var(--lbu-radius,12px)*0.5)] transition ${i === picture ? "ring-2 ring-[var(--lbu-accent)]" : "opacity-60 hover:opacity-100"}`}
                  aria-label={`Photo ${i + 1}`}
                  aria-pressed={i === picture}
                >
                  <img src={src} alt="" className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="min-w-0">
          <p className="lbu-heading text-[1.2em] leading-tight font-bold">{product.name}</p>
          <div className="mt-1.5 flex flex-wrap items-center gap-2">
            <Price product={product} currency={currency} large />
            {discountPercent(product.price, product.compareAt) !== null && (
              <span className="lbu-shop-tag lbu-shop-tag--deal">-{discountPercent(product.price, product.compareAt)} %</span>
            )}
          </div>
          <p className="mt-1 text-[0.78em] font-semibold" style={{ color: available ? (product.stock !== null && product.stock <= LOW_STOCK ? "#f59e0b" : "#22c55e") : "#ef4444" }}>
            {!available ? "Épuisé" : product.stock !== null && product.stock <= LOW_STOCK ? `Plus que ${product.stock} en stock` : "Disponible"}
          </p>
          {product.description && <p className="lbu-muted mt-3 text-[0.88em] leading-relaxed whitespace-pre-line">{product.description}</p>}

          {options.length > 0 && (
            <fieldset className="mt-4">
              <legend className="text-[0.8em] font-semibold">{product.optionLabel || "Option"}</legend>
              <div className="mt-1.5 flex flex-wrap gap-1.5">
                {options.map((o) => (
                  <button
                    key={o}
                    type="button"
                    onClick={() => setOption(o)}
                    aria-pressed={option === o}
                    className={`lbu-shop-chip rounded-full px-3 py-1 text-[0.82em] font-semibold ${option === o ? "lbu-shop-chip--on" : ""}`}
                  >
                    {o}
                  </button>
                ))}
              </div>
            </fieldset>
          )}

          {product.mode === "order" && available && (
            <div className="mt-4 flex items-center gap-3">
              <span className="text-[0.8em] font-semibold">Quantité</span>
              <Stepper value={quantity} min={1} max={max} onChange={setQuantity} label={product.name} />
            </div>
          )}

          <div className="mt-5 flex flex-wrap gap-2">
            {product.mode === "link" ? (
              href && available ? (
                <a
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  data-lbu-block={blockId}
                  className="lbu-button lbu-shop-buy inline-flex flex-1 items-center justify-center gap-2 px-4 py-2.5 text-[0.92em] font-semibold"
                  style={accentButton}
                >
                  {product.buttonLabel || "Acheter"} <ExternalLink size={15} aria-hidden="true" />
                </a>
              ) : (
                <span className="lbu-muted text-[0.85em]">{available ? "Lien d'achat à venir." : "Revient bientôt."}</span>
              )
            ) : available ? (
              <>
                <button
                  type="button"
                  disabled={needsOption}
                  onClick={() => {
                    onAdd(option, quantity, mediaRef.current);
                    setAdded(true);
                  }}
                  className="lbu-button lbu-shop-buy inline-flex flex-1 items-center justify-center gap-2 px-4 py-2.5 text-[0.92em] font-semibold disabled:opacity-50"
                  style={accentButton}
                >
                  {added ? <Check size={16} aria-hidden="true" /> : <Plus size={16} aria-hidden="true" />}
                  {needsOption ? `Choisis : ${(product.optionLabel || "option").toLowerCase()}` : added ? "Ajouté au panier" : product.buttonLabel || "Ajouter au panier"}
                </button>
                {(added || inCart) && (
                  <button type="button" onClick={onShowCart} className="lbu-shop-ghost inline-flex items-center gap-1.5 rounded-full px-4 py-2.5 text-[0.85em] font-semibold">
                    <ShoppingBag size={15} aria-hidden="true" /> Voir le panier
                  </button>
                )}
              </>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}

function Stepper({ value, min, max, onChange, label }: { value: number; min: number; max: number; onChange: (v: number) => void; label: string }) {
  return (
    <span className="lbu-shop-stepper inline-flex items-center rounded-full">
      <button type="button" onClick={() => onChange(Math.max(min, value - 1))} disabled={value <= min} className="flex h-8 w-8 items-center justify-center disabled:opacity-30" aria-label={`Retirer un « ${label} »`}>
        <Minus size={14} />
      </button>
      <span className="w-6 text-center text-[0.9em] font-semibold tabular-nums" aria-live="polite">
        {value}
      </span>
      <button type="button" onClick={() => onChange(Math.min(max, value + 1))} disabled={value >= max} className="flex h-8 w-8 items-center justify-center disabled:opacity-30" aria-label={`Ajouter un « ${label} »`}>
        <Plus size={14} />
      </button>
    </span>
  );
}

/** Panier et demande de commande. */
function CartView({
  cart,
  products,
  data,
  slug,
  blockId,
  seller,
  live,
  onChange,
  onBack,
  onSent,
}: {
  cart: CartLine[];
  products: ShopProduct[];
  data: BlockData<"shop">;
  slug: string;
  blockId: string;
  seller: string;
  live: boolean;
  onChange: (cart: CartLine[]) => void;
  onBack: () => void;
  onSent: (reference: string, contact: string) => void;
}) {
  const [name, setName] = useState("");
  const [contact, setContact] = useState("");
  const [note, setNote] = useState("");
  const [website, setWebsite] = useState(""); // piège à robots, invisible pour les humains
  const [state, setState] = useState<{ status: "idle" | "sending" | "error"; text?: string }>({ status: "idle" });
  const buttonRef = useRef<HTMLButtonElement>(null);

  const lines = cart
    .map((line) => ({ line, product: products.find((p) => p.id === line.productId) }))
    .filter((l): l is { line: CartLine; product: ShopProduct } => Boolean(l.product));
  const total = orderTotal(lines.map(({ line, product }) => ({ price: product.price, quantity: line.quantity })));
  const ready = lines.length > 0 && name.trim().length >= 2 && contact.trim().length >= 3;

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (!ready) return;
    if (!live) {
      setState({ status: "error", text: "Aperçu : les commandes fonctionnent sur ta page publique." });
      return;
    }
    setState({ status: "sending" });
    const res = await fetch(`/api/pages/${encodeURIComponent(slug)}/order`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ b: blockId, items: lines.map(({ line }) => ({ p: line.productId, o: line.option, q: line.quantity })), name, contact, note, website }),
    }).catch(() => null);
    const json = (await res?.json().catch(() => ({}))) as { error?: string; reference?: string };
    if (res?.ok) {
      confetti({ origin: buttonRef.current, count: 70 });
      onSent(json.reference ?? "", contact.trim());
      return;
    }
    setState({ status: "error", text: json.error ?? "Envoi impossible, réessaie dans un instant." });
  }

  if (!lines.length) {
    return (
      <div className="py-6 text-center">
        <ShoppingBag size={28} className="lbu-muted mx-auto" aria-hidden="true" />
        <p className="mt-2 font-semibold">Ton panier est vide</p>
        <button type="button" onClick={onBack} className="lbu-shop-ghost mt-3 inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-[0.85em] font-semibold">
          <ArrowLeft size={15} aria-hidden="true" /> Voir les produits
        </button>
      </div>
    );
  }

  return (
    <div>
      <button type="button" onClick={onBack} className="lbu-shop-ghost mb-3 inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[0.8em] font-semibold">
        <ArrowLeft size={14} aria-hidden="true" /> Continuer mes achats
      </button>
      <ul className="space-y-2">
        {lines.map(({ line, product }) => {
          const pic = images(product)[0];
          return (
            <li key={`${line.productId}-${line.option}`} className="lbu-shop-line flex items-center gap-3 rounded-[calc(var(--lbu-radius,12px)*0.7)] p-2">
              <span className="relative h-12 w-12 shrink-0 overflow-hidden rounded-[calc(var(--lbu-radius,12px)*0.5)]" style={{ background: "var(--lbu-accent-soft)" }}>
                {pic ? <img src={pic} alt="" className="h-full w-full object-cover" /> : <Placeholder emoji={product.emoji} size={22} />}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[0.88em] font-semibold">{product.name}</span>
                {line.option && <span className="lbu-muted block text-[0.75em]">{(product.optionLabel || "Option")} : {line.option}</span>}
                <span className="block text-[0.8em] font-semibold" style={{ color: "var(--lbu-accent-ink, var(--lbu-accent))" }}>
                  {product.price === null ? "Prix libre" : formatMoney(product.price * line.quantity, data.currency)}
                </span>
              </span>
              <Stepper
                value={line.quantity}
                min={1}
                max={Math.min(MAX_QUANTITY, product.stock ?? MAX_QUANTITY)}
                label={product.name}
                onChange={(quantity) => onChange(cart.map((l) => (l === line ? { ...l, quantity } : l)))}
              />
              <button type="button" onClick={() => onChange(cart.filter((l) => l !== line))} className="lbu-muted flex h-8 w-8 items-center justify-center rounded-full hover:text-[#ef4444]" aria-label={`Retirer « ${product.name} » du panier`}>
                <Trash2 size={15} />
              </button>
            </li>
          );
        })}
      </ul>
      <div className="mt-3 flex items-baseline justify-between border-t pt-3" style={{ borderColor: "var(--lbu-faint)" }}>
        <span className="text-[0.88em] font-semibold">Total</span>
        <span className="text-[1.15em] font-bold" style={{ color: "var(--lbu-accent-ink, var(--lbu-accent))" }}>
          {total === null ? "À convenir" : formatMoney(total, data.currency)}
        </span>
      </div>
      {data.terms && <p className="lbu-muted mt-2 text-[0.78em] whitespace-pre-line">{data.terms}</p>}

      <form onSubmit={submit} className="mt-4 space-y-2">
        <div className="grid gap-2 sm:grid-cols-2">
          <input className={field} style={fieldStyle} value={name} onChange={(e) => setName(e.target.value)} maxLength={60} placeholder="Ton nom ou pseudo" aria-label="Ton nom ou pseudo" required />
          <input
            className={field}
            style={fieldStyle}
            value={contact}
            onChange={(e) => setContact(e.target.value)}
            maxLength={120}
            placeholder="E-mail ou pseudo Discord"
            aria-label="Comment te recontacter"
            required
          />
        </div>
        <textarea
          className={`${field} min-h-[72px] resize-y`}
          style={fieldStyle}
          value={note}
          onChange={(e) => setNote(e.target.value)}
          maxLength={600}
          placeholder="Une précision ? (livraison, dédicace…)"
          aria-label="Précision pour le vendeur"
        />
        <input type="text" tabIndex={-1} autoComplete="off" value={website} onChange={(e) => setWebsite(e.target.value)} className="absolute -left-[9999px] h-0 w-0 opacity-0" aria-hidden="true" />
        <button
          ref={buttonRef}
          type="submit"
          disabled={!ready || state.status === "sending"}
          className="lbu-button inline-flex w-full items-center justify-center gap-2 px-4 py-2.5 text-[0.92em] font-semibold disabled:opacity-50"
          style={accentButton}
        >
          {state.status === "sending" ? <LoaderCircle size={16} className="animate-spin" /> : <ShoppingBag size={16} aria-hidden="true" />}
          Envoyer ma commande
        </button>
        {state.status === "error" && <p className="text-center text-[0.8em] text-[#f0b232]">{state.text}</p>}
        <p className="lbu-muted text-center text-[0.68em]">Aucun paiement en ligne : {seller} te recontacte pour régler et livrer ta commande.</p>
      </form>
    </div>
  );
}
