"use client";

import type { BlockData } from "@/lib/blocks";
import type { DiscordInvite } from "@/lib/discord-cdn";
import { parseDiscordInvite } from "@/lib/urls";
import { SocialIcon } from "@/components/icons/SocialIcon";
import { useRemote } from "../useRemote";

type Props = { data: BlockData<"discordServer">; initial?: DiscordInvite; live: boolean; fill: string; blockId: string };

const nf = new Intl.NumberFormat("fr-FR");

/** Invitation vers un serveur Discord, avec icône et nombre de membres. */
export function DiscordServerBlock({ data, initial, live, fill, blockId }: Props) {
  const code = parseDiscordInvite(data.invite);
  const { data: invite, loading } = useRemote<DiscordInvite>(
    code ? `/api/discord/invite/${encodeURIComponent(code)}` : null,
    initial,
    live,
  );

  if (!code) {
    return <div className="lbu-card p-5 text-center text-[0.9em] lbu-muted">Ajoute un lien d&apos;invitation Discord (discord.gg/…).</div>;
  }

  const guild = invite?.status === "ok" ? invite.guild : undefined;
  const name = guild?.name ?? (loading ? "Chargement…" : "Serveur Discord");

  return (
    <section className="lbu-card flex flex-col gap-3 p-4">
      <div className="flex items-center gap-3">
        {guild?.iconUrl ? (
          <img src={guild.iconUrl} alt="" width={52} height={52} className="h-13 w-13 shrink-0 rounded-[16px]" loading="lazy" />
        ) : (
          <div
            className="flex h-13 w-13 shrink-0 items-center justify-center rounded-[16px]"
            style={{ background: "#5865f2", color: "#fff" }}
          >
            <SocialIcon platform="discord" size={26} />
          </div>
        )}
        <div className="min-w-0 flex-1">
          <p className="lbu-muted text-[0.72em] font-semibold uppercase tracking-wide">Invitation à rejoindre</p>
          <p className="truncate text-[1.05em] font-bold leading-tight">{name}</p>
          {invite?.status === "ok" && invite.memberCount !== undefined && (
            <p className="lbu-muted mt-0.5 flex flex-wrap items-center gap-x-3 text-[0.8em]">
              {invite.onlineCount !== undefined && (
                <span className="inline-flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-[#23a55a]" aria-hidden="true" />
                  {nf.format(invite.onlineCount)} en ligne
                </span>
              )}
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-[#80848e]" aria-hidden="true" />
                {nf.format(invite.memberCount)} membres
              </span>
            </p>
          )}
          {invite && invite.status !== "ok" && (
            <p className="lbu-muted text-[0.8em]">{invite.status === "invalid" ? "Invitation expirée ou invalide." : "Informations indisponibles."}</p>
          )}
        </div>
      </div>
      {data.note && <p className="lbu-muted text-[0.88em]">{data.note}</p>}
      <a
        href={`https://discord.gg/${code}`}
        target="_blank"
        rel="noopener noreferrer"
        data-lbu-block={blockId}
        className="lbu-btn justify-center !min-h-11"
        data-fill={fill}
      >
        Rejoindre le serveur
      </a>
    </section>
  );
}
