"use client";

import { useEffect, useRef, useState } from "react";
import { Check, ChevronLeft, ChevronRight, Copy, Music2, X } from "lucide-react";
import { isValidBirthday, nextBirthday } from "@/lib/birthday";
import type { BlockData } from "@/lib/blocks";
import { PRESENCE_LABELS, offlinePresence, type DiscordPresence } from "@/lib/presence";
import { toSafeImageSrc } from "@/lib/urls";

// Blocs interactifs (exécutés dans le navigateur) des pages publiques et de l'aperçu.

// ─── Compte à rebours ───────────────────────────────────────────────────────

function parts(ms: number) {
  const total = Math.max(0, Math.floor(ms / 1000));
  return { days: Math.floor(total / 86400), hours: Math.floor((total % 86400) / 3600), minutes: Math.floor((total % 3600) / 60), seconds: total % 60 };
}

export function CountdownBlock({ data }: { data: BlockData<"countdown"> }) {
  const [now, setNow] = useState<number | null>(null);

  useEffect(() => {
    setNow(Date.now());
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const birthday = data.mode === "birthday";
  // Anniversaire : calculé dans le navigateur, à l'heure du visiteur (minuit local).
  const info = birthday && now !== null ? nextBirthday(data.birthday, new Date(now), data.birthYear) : null;
  const target = birthday ? (info ? info.target.getTime() : NaN) : data.target ? Date.parse(data.target) : NaN;

  if (birthday ? !isValidBirthday(data.birthday) : Number.isNaN(target)) {
    return (
      <div className="lbu-card p-5 text-center text-[0.9em] lbu-muted">
        {birthday ? "Indique ta date d'anniversaire." : "Choisis la date du compte à rebours."}
      </div>
    );
  }

  const title = data.title || (birthday ? "Mon anniversaire" : "");
  if (info?.isToday) {
    return (
      <section className="lbu-card relative overflow-hidden p-5 text-center" aria-label={title}>
        <div className="lbu-confetti" aria-hidden="true">
          {["🎉", "🎂", "✨", "🎈", "🎁", "🥳", "🎊", "✨"].map((e, i) => (
            <span key={i} style={{ left: `${8 + i * 12}%`, animationDelay: `${(i % 4) * 0.7}s` }}>
              {e}
            </span>
          ))}
        </div>
        <p className="text-[2em]" aria-hidden="true">
          🎂
        </p>
        <p className="lbu-heading text-[1.25em] font-bold" style={{ color: "var(--lbu-accent-ink)" }}>
          {data.birthdayText || "C'est mon anniversaire aujourd'hui !"}
        </p>
        {data.showAge && info.turning && <p className="lbu-muted mt-1 text-[0.9em]">{info.turning} ans aujourd&apos;hui</p>}
      </section>
    );
  }

  const ended = !birthday && now !== null && now >= target;
  const p = parts(now === null || Number.isNaN(target) ? 0 : target - now);
  const units = [
    { value: p.days, label: "jours" },
    { value: p.hours, label: "heures" },
    { value: p.minutes, label: "min" },
    { value: p.seconds, label: "s" },
  ];
  const when =
    now === null || Number.isNaN(target)
      ? ""
      : birthday
        ? `Le ${new Date(target).toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })}${data.showAge && info?.turning ? ` · ${info.turning} ans` : ""}`
        : new Date(target).toLocaleString("fr-FR", { dateStyle: "full", timeStyle: "short" });

  return (
    <section className="lbu-card p-4 text-center" aria-label={title || "Compte à rebours"}>
      {title && (
        <p className="lbu-heading text-[1.05em] font-bold">
          {birthday && <span aria-hidden="true">🎂 </span>}
          {title}
        </p>
      )}
      {ended ? (
        <p className="mt-1 text-[1.3em] font-bold" style={{ color: "var(--lbu-accent-ink)" }}>
          {data.endedText || "C'est parti !"}
        </p>
      ) : data.style === "inline" ? (
        <p className="mt-1 text-[1.25em] font-bold tabular-nums" aria-live="off" suppressHydrationWarning>
          {now === null ? "…" : `${p.days} j ${String(p.hours).padStart(2, "0")} h ${String(p.minutes).padStart(2, "0")} min ${String(p.seconds).padStart(2, "0")} s`}
        </p>
      ) : (
        <div className="mt-3 grid grid-cols-4 gap-2" aria-live="off">
          {units.map((u) => (
            <div key={u.label} className="rounded-[10px] py-2" style={{ background: "var(--lbu-faint)" }}>
              <p className="lbu-heading text-[1.5em] font-bold leading-none tabular-nums" suppressHydrationWarning>
                {now === null ? "–" : String(u.value).padStart(2, "0")}
              </p>
              <p className="lbu-muted mt-1 text-[0.7em] uppercase tracking-wide">{u.label}</p>
            </div>
          ))}
        </div>
      )}
      <p className="lbu-muted mt-2 min-h-[1.2em] text-[0.75em] first-letter:uppercase" suppressHydrationWarning>
        {when}
      </p>
    </section>
  );
}

// ─── À copier ───────────────────────────────────────────────────────────────

export function CopyBlock({ data }: { data: BlockData<"copy"> }) {
  const [copied, setCopied] = useState(false);
  if (!data.value.trim()) {
    return <div className="lbu-card p-5 text-center text-[0.9em] lbu-muted">Indique la valeur à copier.</div>;
  }

  async function copy() {
    try {
      await navigator.clipboard.writeText(data.value);
    } catch {
      const area = document.createElement("textarea");
      area.value = data.value;
      document.body.appendChild(area);
      area.select();
      document.execCommand("copy");
      area.remove();
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1600);
  }

  return (
    <div className="lbu-card flex items-center gap-3 p-3 pl-4">
      <div className="min-w-0 flex-1">
        {data.label && <p className="lbu-muted text-[0.72em] font-semibold uppercase tracking-wide">{data.label}</p>}
        <p className="truncate font-mono text-[0.95em] font-semibold">{data.value}</p>
        {data.hint && <p className="lbu-muted truncate text-[0.75em]">{data.hint}</p>}
      </div>
      <button
        type="button"
        onClick={copy}
        className="lbu-btn !min-h-10 !w-auto shrink-0 !px-3 !py-2 text-[0.85em]"
        data-fill="soft"
        aria-label={`Copier ${data.label || "la valeur"}`}
      >
        {copied ? <Check size={16} aria-hidden="true" /> : <Copy size={16} aria-hidden="true" />}
        <span aria-live="polite">{copied ? "Copié" : "Copier"}</span>
      </button>
    </div>
  );
}

// ─── Galerie ────────────────────────────────────────────────────────────────

export function GalleryBlock({ data }: { data: BlockData<"gallery"> }) {
  const images = data.images
    .map((img) => ({ ...img, src: toSafeImageSrc(img.url) }))
    .filter((img): img is typeof img & { src: string } => Boolean(img.src));
  const [open, setOpen] = useState<number | null>(null);
  const dialogRef = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    if (open !== null && !dialog.open) dialog.showModal();
    if (open === null && dialog.open) dialog.close();
  }, [open]);

  if (!images.length) {
    return <div className="lbu-card p-5 text-center text-[0.9em] lbu-muted">Ajoute des images à la galerie.</div>;
  }

  const go = (delta: number) => setOpen((i) => (i === null ? i : (i + delta + images.length) % images.length));

  return (
    <>
      {data.layout === "carousel" ? (
        <div className="lbu-card overflow-hidden p-1.5">
          <ul className="flex snap-x snap-mandatory gap-1.5 overflow-x-auto" style={{ scrollbarWidth: "thin" }}>
            {images.map((img, i) => (
              <li key={i} className="w-[78%] shrink-0 snap-center">
                <button type="button" onClick={() => setOpen(i)} className="block w-full overflow-hidden" style={{ borderRadius: "calc(var(--lbu-card-radius) - 6px)" }}>
                  <img src={img.src} alt={img.alt} loading="lazy" referrerPolicy="no-referrer" className="aspect-[4/3] w-full object-cover" />
                </button>
              </li>
            ))}
          </ul>
        </div>
      ) : (
        <ul className={`grid gap-1.5 ${data.columns === 3 ? "grid-cols-3" : "grid-cols-2"}`}>
          {images.map((img, i) => (
            <li key={i}>
              <button type="button" onClick={() => setOpen(i)} className="lbu-card block w-full overflow-hidden transition-opacity hover:opacity-90">
                <img src={img.src} alt={img.alt} loading="lazy" referrerPolicy="no-referrer" className="aspect-square w-full object-cover" />
              </button>
            </li>
          ))}
        </ul>
      )}

      <dialog
        ref={dialogRef}
        onClose={() => setOpen(null)}
        onClick={(e) => e.target === dialogRef.current && setOpen(null)}
        onKeyDown={(e) => {
          if (e.key === "ArrowRight") go(1);
          if (e.key === "ArrowLeft") go(-1);
        }}
        className="m-auto max-h-[92vh] max-w-[92vw] bg-transparent p-0 backdrop:bg-black/80"
        aria-label="Image agrandie"
      >
        {open !== null && (
          <figure className="relative">
            <img src={images[open].src} alt={images[open].alt} referrerPolicy="no-referrer" className="max-h-[86vh] max-w-[92vw] rounded-xl object-contain" />
            {images[open].alt && <figcaption className="mt-2 text-center text-sm text-white/80">{images[open].alt}</figcaption>}
            <div className="absolute top-2 right-2 flex gap-1">
              {images.length > 1 && (
                <>
                  <button type="button" onClick={() => go(-1)} className="rounded-full bg-black/60 p-2 text-white" aria-label="Image précédente">
                    <ChevronLeft size={18} />
                  </button>
                  <button type="button" onClick={() => go(1)} className="rounded-full bg-black/60 p-2 text-white" aria-label="Image suivante">
                    <ChevronRight size={18} />
                  </button>
                </>
              )}
              <button type="button" onClick={() => setOpen(null)} className="rounded-full bg-black/60 p-2 text-white" aria-label="Fermer">
                <X size={18} />
              </button>
            </div>
          </figure>
        )}
      </dialog>
    </>
  );
}

// ─── Statut Discord en direct ───────────────────────────────────────────────

export function PresenceBlock({
  data,
  discordId,
  username,
  live,
  preview,
}: {
  data: BlockData<"discordPresence">;
  discordId: string;
  username: string;
  live: boolean;
  preview: boolean;
}) {
  const [presence, setPresence] = useState<DiscordPresence | null>(null);

  useEffect(() => {
    if (!live) return;
    let stopped = false;
    const load = () =>
      fetch(`/api/discord/presence/${discordId}`)
        .then(async (r) => {
          // 400/404 : compte inconnu de Link by Unclaim (aperçu de démonstration…) → non suivi.
          if (r.status === 400 || r.status === 404) return { ...offlinePresence(false) };
          if (!r.ok) throw new Error(String(r.status));
          return (await r.json()) as DiscordPresence;
        })
        .then((p) => {
          // En cas de panne passagère, on garde le dernier statut connu.
          if (!stopped) setPresence((prev) => (p.unavailable && prev && !prev.unavailable ? prev : p));
        })
        .catch(() => {
          if (!stopped) setPresence((prev) => prev ?? { ...offlinePresence(true), unavailable: true });
        });
    void load();
    const timer = window.setInterval(() => {
      if (document.visibilityState === "visible") void load();
    }, 30_000);
    return () => {
      stopped = true;
      window.clearInterval(timer);
    };
  }, [discordId, live]);

  if (presence && !presence.monitored) {
    if (!preview) return null;
    return (
      <div className="lbu-card p-4 text-[0.85em] lbu-muted">
        Pour afficher ton statut en direct, rejoins le serveur Discord de Lanyard (discord.gg/lanyard) avec le compte @{username}.
      </div>
    );
  }
  if (presence?.unavailable) {
    if (!preview) return null;
    return <div className="lbu-card p-4 text-[0.85em] lbu-muted">Statut Discord momentanément indisponible (Lanyard ne répond pas).</div>;
  }

  const status = presence?.status ?? "offline";
  const meta = PRESENCE_LABELS[status];
  const activity = data.showActivity ? presence?.activities[0] : undefined;
  const spotify = data.showSpotify ? presence?.spotify : null;

  return (
    <section className="lbu-card space-y-3 p-4" aria-label="Statut Discord">
      <div className="flex items-center gap-2.5">
        <span className="relative flex h-3 w-3">
          {status === "online" && <span className="absolute inline-flex h-full w-full animate-ping rounded-full opacity-50 motion-reduce:animate-none" style={{ background: meta.color }} />}
          <span className="relative inline-flex h-3 w-3 rounded-full" style={{ background: meta.color }} />
        </span>
        <p className="font-semibold">{presence ? meta.label : "Statut Discord"}</p>
        {presence?.customStatus && (
          <p className="lbu-muted min-w-0 truncate text-[0.85em]">
            {presence.customStatus.emoji ? `${presence.customStatus.emoji} ` : ""}
            {presence.customStatus.text}
          </p>
        )}
      </div>
      {activity && (
        <p className="text-[0.88em]">
          <span className="lbu-muted">{activity.kind} </span>
          <span className="font-semibold">{activity.name}</span>
          {activity.details && <span className="lbu-muted block truncate text-[0.9em]">{activity.details}</span>}
        </p>
      )}
      {spotify && (
        <a
          href={spotify.trackUrl ?? undefined}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-3 rounded-[10px] p-2 transition-opacity hover:opacity-90"
          style={{ background: "var(--lbu-faint)" }}
        >
          {spotify.albumArt ? (
            <img src={spotify.albumArt} alt="" width={44} height={44} className="h-11 w-11 rounded-md object-cover" referrerPolicy="no-referrer" />
          ) : (
            <span className="flex h-11 w-11 items-center justify-center rounded-md" style={{ background: "#1db954", color: "#000" }}>
              <Music2 size={18} aria-hidden="true" />
            </span>
          )}
          <span className="min-w-0">
            <span className="lbu-muted block text-[0.7em] uppercase tracking-wide">Écoute sur Spotify</span>
            <span className="block truncate text-[0.9em] font-semibold">{spotify.song}</span>
            <span className="lbu-muted block truncate text-[0.8em]">{spotify.artist}</span>
          </span>
        </a>
      )}
    </section>
  );
}
