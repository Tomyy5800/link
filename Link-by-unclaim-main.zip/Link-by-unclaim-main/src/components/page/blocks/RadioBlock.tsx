"use client";

import { useCallback, useEffect, useId, useRef, useState } from "react";
import { ExternalLink, Headphones, LoaderCircle, Pause, Play, Radio, Volume2, VolumeX } from "lucide-react";
import type { BlockData } from "@/lib/blocks";
import { normalizeNowPlaying, resolveRadio, type NowPlaying } from "@/lib/radio";
import { DiscordLogo } from "@/components/icons/SocialIcon";
import { announcePlaying, onOtherPlaying } from "../audio-bus";

/** Titre en cours d'une radio AzuraCast, rafraîchi toutes les 20 s quand la page est visible. */
export function useNowPlaying(url: string | null, enabled: boolean): NowPlaying | null {
  const [state, setState] = useState<NowPlaying | null>(null);
  useEffect(() => {
    if (!url || !enabled) return;
    let stop = false;
    const load = () => {
      if (document.visibilityState !== "visible") return;
      fetch(url, { cache: "no-store" })
        .then((r) => (r.ok ? r.json() : null))
        .then((json) => {
          if (!stop && json) setState(normalizeNowPlaying(json));
        })
        .catch(() => undefined);
    };
    load();
    const timer = window.setInterval(load, 20_000);
    document.addEventListener("visibilitychange", load);
    return () => {
      stop = true;
      window.clearInterval(timer);
      document.removeEventListener("visibilitychange", load);
    };
  }, [url, enabled]);
  return state;
}

/** Webradio en direct : lecture, titre en cours, pochette, auditeurs, animateur. */
export function RadioBlock({ data, live }: { data: BlockData<"radio">; live: boolean }) {
  const id = useId();
  const station = resolveRadio(data.station, data.name);
  const audioRef = useRef<HTMLAudioElement>(null);
  const [status, setStatus] = useState<"idle" | "loading" | "playing" | "error">("idle");
  const [volume, setVolume] = useState(0.8);
  const [muted, setMuted] = useState(false);
  const now = useNowPlaying(station?.nowPlaying ?? null, live);
  const [tick, setTick] = useState(0);

  // Avance la barre de progression entre deux mises à jour du titre en cours.
  useEffect(() => {
    setTick(0);
    if (!now?.duration) return;
    const timer = window.setInterval(() => setTick((t) => t + 1), 1000);
    return () => window.clearInterval(timer);
  }, [now]);

  const stop = useCallback(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.pause();
    // Couper le téléchargement du flux : à la reprise, on repart sur le direct.
    audio.removeAttribute("src");
    audio.load();
    setStatus("idle");
  }, []);

  useEffect(() => onOtherPlaying(id, stop), [id, stop]);
  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = muted ? 0 : volume;
  }, [volume, muted]);

  useEffect(() => {
    if (status !== "playing" || !station || !("mediaSession" in navigator)) return;
    navigator.mediaSession.metadata = new MediaMetadata({
      title: now?.title ?? station.name,
      artist: now?.artist ?? station.name,
      album: station.name,
      artwork: now?.art ? [{ src: now.art, sizes: "512x512" }] : [],
    });
  }, [status, now, station]);

  if (!station) {
    return <div className="lbu-card p-5 text-center text-[0.9em] lbu-muted">Choisis une radio dans l&apos;éditeur.</div>;
  }

  async function toggle() {
    const audio = audioRef.current;
    if (!audio || !station) return;
    if (status === "playing" || status === "loading") {
      stop();
      return;
    }
    setStatus("loading");
    audio.src = now?.stream ?? station.stream;
    audio.volume = muted ? 0 : volume;
    try {
      await audio.play();
      announcePlaying(id);
      setStatus("playing");
    } catch {
      setStatus("error");
    }
  }

  const elapsed = now?.elapsed != null ? Math.min((now.duration ?? Infinity), now.elapsed + tick) : null;
  const progress = now?.duration && elapsed != null ? Math.min(100, (elapsed / now.duration) * 100) : null;
  const playing = status === "playing";

  return (
    <section className="lbu-card overflow-hidden" aria-label={`Radio ${station.name}`}>
      <div className="flex items-center gap-3.5 p-4">
        <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-[12px]" style={{ background: "var(--lbu-faint)" }}>
          {data.showNowPlaying && now?.art ? (
            <img src={now.art} alt="" className="h-full w-full object-cover" loading="lazy" />
          ) : (
            <span className="flex h-full w-full items-center justify-center" style={{ color: "var(--lbu-accent-ink)" }}>
              <Radio size={28} aria-hidden="true" />
            </span>
          )}
        </div>
        <div className="min-w-0 flex-1">
          <p className="flex items-center gap-2 text-[0.72em] font-semibold uppercase tracking-[0.12em]">
            <span className={`inline-block h-2 w-2 rounded-full ${now?.online === false ? "bg-gray-400" : "bg-red-500"} ${playing ? "animate-pulse" : ""}`} aria-hidden="true" />
            <span className="lbu-muted">{now?.online === false ? "Hors ligne" : now?.live.isLive ? `En direct · ${now.live.streamer ?? "animateur"}` : "En direct"}</span>
          </p>
          <p className="lbu-heading truncate text-[1.05em] font-bold leading-tight">{station.name}</p>
          {data.showNowPlaying && now?.title ? (
            <p className="truncate text-[0.88em]">
              {now.title}
              {now.artist && <span className="lbu-muted"> · {now.artist}</span>}
            </p>
          ) : (
            station.tagline && <p className="lbu-muted truncate text-[0.85em]">{station.tagline}</p>
          )}
        </div>
        <button
          type="button"
          onClick={toggle}
          className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full transition-[filter] hover:brightness-110"
          style={{ background: "var(--lbu-accent)", color: "var(--lbu-on-accent)" }}
          aria-label={playing ? `Arrêter ${station.name}` : `Écouter ${station.name}`}
        >
          {status === "loading" ? <LoaderCircle size={22} className="animate-spin" /> : playing ? <Pause size={22} /> : <Play size={22} className="ml-0.5" />}
        </button>
        <audio ref={audioRef} preload="none" onError={() => status !== "idle" && setStatus("error")} onPlaying={() => setStatus("playing")} />
      </div>

      {data.showNowPlaying && progress != null && (
        <div className="mx-4 h-1 overflow-hidden rounded-full" style={{ background: "var(--lbu-faint)" }} aria-hidden="true">
          <div className="h-full rounded-full transition-[width] duration-1000 ease-linear" style={{ width: `${progress}%`, background: "var(--lbu-accent)" }} />
        </div>
      )}

      {status === "error" && <p className="px-4 pt-2 text-[0.8em] text-red-400">La radio ne répond pas pour le moment. Réessaie dans un instant.</p>}

      <div className="flex flex-wrap items-center gap-x-4 gap-y-2 px-4 pt-3 pb-4 text-[0.8em]">
        {playing && (
          <span className="flex items-center gap-1.5">
            <button type="button" onClick={() => setMuted((m) => !m)} className="lbu-muted" aria-label={muted ? "Remettre le son" : "Couper le son"}>
              {muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
            </button>
            <input
              type="range"
              min={0}
              max={100}
              value={Math.round((muted ? 0 : volume) * 100)}
              onChange={(e) => {
                setMuted(false);
                setVolume(Number(e.target.value) / 100);
              }}
              className="w-24"
              style={{ accentColor: "var(--lbu-accent)" }}
              aria-label="Volume"
            />
          </span>
        )}
        {data.showListeners && now?.listeners != null && (
          <span className="lbu-muted inline-flex items-center gap-1.5">
            <Headphones size={14} aria-hidden="true" /> {now.listeners} auditeur{now.listeners > 1 ? "s" : ""}
          </span>
        )}
        <span className="ml-auto flex items-center gap-3">
          {station.site && (
            <a href={station.site} target="_blank" rel="noopener noreferrer" className="lbu-muted inline-flex items-center gap-1 hover:underline">
              Site <ExternalLink size={12} aria-hidden="true" />
            </a>
          )}
          {station.discord && (
            <a href={station.discord} target="_blank" rel="noopener noreferrer" className="lbu-muted inline-flex items-center gap-1 hover:underline">
              <DiscordLogo size={13} /> Discord
            </a>
          )}
        </span>
      </div>

      {data.showHistory && now && now.history.length > 0 && (
        <div className="border-t px-4 py-3 text-[0.8em]" style={{ borderColor: "var(--lbu-card-border)" }}>
          <p className="lbu-muted mb-1.5 uppercase tracking-[0.1em] text-[0.85em]">Déjà passés</p>
          <ol className="space-y-1">
            {now.history.slice(0, 3).map((h, i) => (
              <li key={i} className="truncate">
                {h.title}
                {h.artist && <span className="lbu-muted"> · {h.artist}</span>}
              </li>
            ))}
          </ol>
        </div>
      )}
    </section>
  );
}
