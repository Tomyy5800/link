"use client";

import { Castle, Clock3 } from "lucide-react";
import type { BlockData } from "@/lib/blocks";
import { formatNgDate, ngServerMeta, type NgProfile } from "@/lib/nationsglory-shared";
import { isValidMcUsername } from "@/lib/urls";
import { useRemote } from "../useRemote";

type Props = {
  data: BlockData<"nationsglory">;
  username: string;
  servers: string[];
  initial?: NgProfile;
  live: boolean;
  /** Aperçu de l'éditeur : messages détaillés pour le propriétaire. */
  preview: boolean;
  compact?: boolean;
};

/** Carte de profil NationsGlory : pays, rang et dernière connexion sur chaque serveur choisi. */
export function NationsGloryBlock({ data, username, servers, initial, live, preview, compact }: Props) {
  const valid = isValidMcUsername(username) && servers.length > 0;
  const { data: profile, loading } = useRemote<NgProfile>(
    valid ? `/api/nationsglory/user/${encodeURIComponent(username)}?servers=${servers.join(",")}` : null,
    initial,
    live,
  );

  if (!valid) {
    return (
      <div className="lbu-card p-5 text-center text-[0.9em] lbu-muted">
        Indique ton pseudo NationsGlory pour afficher ton profil de jeu.
      </div>
    );
  }

  const ok = profile?.status === "ok";
  const lastLogin = (profile?.servers ?? [])
    .filter((s) => s.lastLoginOn)
    .sort((a, b) => (a.lastLoginOn! < b.lastLoginOn! ? 1 : -1))[0];
  const publicMessage =
    profile?.status === "not_found" ? "Ce joueur n'a pas été vu sur ces serveurs depuis 90 jours." : "Données de jeu indisponibles pour le moment.";

  return (
    <section className="lbu-card overflow-hidden" aria-label={`Profil NationsGlory de ${profile?.username ?? username}`}>
      <header className="flex items-center gap-3 p-4">
        <img
          src={`/api/skin/${encodeURIComponent(username)}?type=face&size=64`}
          alt=""
          width={44}
          height={44}
          className="pixelated h-11 w-11 shrink-0 rounded-[10px] bg-black/20"
          loading="lazy"
        />
        <div className="min-w-0 flex-1">
          <p className="lbu-heading truncate text-[1.05em] font-bold leading-tight">{profile?.username ?? username}</p>
          <p className="lbu-muted flex items-center gap-1.5 text-[0.78em]">
            <Castle size={13} aria-hidden="true" /> NationsGlory
            {profile?.mock && <span className="lbu-chip !py-0 !text-[0.85em]">démo</span>}
          </p>
        </div>
      </header>

      {loading && !profile && (
        <div className="space-y-2 px-4 pb-4" aria-busy="true">
          {servers.map((s) => (
            <div key={s} className="h-10 animate-pulse rounded-lg" style={{ background: "var(--lbu-faint)" }} />
          ))}
        </div>
      )}

      {profile && !ok && <p className="lbu-muted px-4 pb-4 text-[0.85em]">{preview ? (profile.message ?? publicMessage) : publicMessage}</p>}

      {ok && (
        <ul className="space-y-1.5 px-4 pb-4">
          {profile.servers.map((entry) => {
            const meta = ngServerMeta(entry.server);
            return (
              <li
                key={entry.server}
                className={`rounded-[10px] px-3 py-2 ${compact ? "space-y-1" : "flex items-center gap-3"}`}
                style={{ background: "var(--lbu-faint)" }}
              >
                <span className="flex shrink-0 items-center gap-2">
                  <span className="h-2.5 w-2.5 rounded-full" style={{ background: meta.color }} aria-hidden="true" />
                  <span className="text-[0.75em] font-semibold uppercase tracking-wide">{meta.label}</span>
                </span>
                <span className="flex min-w-0 flex-1 items-center gap-2 text-[0.9em]">
                  {entry.flagUrl && (
                    <img src={entry.flagUrl} alt="" height={14} className="h-3.5 w-auto shrink-0 rounded-[2px]" loading="lazy" referrerPolicy="no-referrer" />
                  )}
                  <span className="truncate font-medium">
                    {entry.status === "not_found" ? (
                      <span className="lbu-muted">Pas vu depuis 90 jours</span>
                    ) : entry.status === "unavailable" ? (
                      <span className="lbu-muted">Indisponible</span>
                    ) : (
                      (entry.countryName ?? <span className="lbu-muted">Sans pays</span>)
                    )}
                  </span>
                  {data.showRole && entry.role && <span className="lbu-chip ml-auto shrink-0">{entry.role}</span>}
                </span>
              </li>
            );
          })}
        </ul>
      )}

      {ok && data.showLastLogin && lastLogin?.lastLoginOn && (
        <p className="lbu-muted flex items-center gap-1.5 border-t px-4 py-2.5 text-[0.78em]" style={{ borderColor: "var(--lbu-faint)" }}>
          <Clock3 size={13} aria-hidden="true" />
          Dernière connexion le {formatNgDate(lastLogin.lastLoginOn)} sur {ngServerMeta(lastLogin.server).label}
        </p>
      )}
    </section>
  );
}
