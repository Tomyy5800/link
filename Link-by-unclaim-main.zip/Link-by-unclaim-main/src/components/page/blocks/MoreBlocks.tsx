"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";
import { ArrowUpRight, CalendarPlus, ChevronDown, MapPin, Music2, ShieldAlert } from "lucide-react";
import type { BlockData, MusicPlatform } from "@/lib/blocks";
import { relativeTime } from "@/lib/discord-markup";
import { toSafeHref, toSafeImageSrc } from "@/lib/urls";
import { BRAND_ICONS } from "@/components/icons/brand-paths";
import { DiscordTime } from "../DiscordTime";

const EXTERNAL = { target: "_blank", rel: "noopener noreferrer nofollow ugc" } as const;

// ─── Écouter partout ────────────────────────────────────────────────────────

export const MUSIC_LABELS: Record<MusicPlatform, string> = {
  spotify: "Spotify",
  applemusic: "Apple Music",
  deezer: "Deezer",
  youtubemusic: "YouTube Music",
  youtube: "YouTube",
  soundcloud: "SoundCloud",
  tidal: "Tidal",
  bandcamp: "Bandcamp",
  other: "Écouter",
};

function PlatformIcon({ platform, size = 20 }: { platform: MusicPlatform; size?: number }) {
  const brand = BRAND_ICONS[platform as keyof typeof BRAND_ICONS];
  if (!brand) return <Music2 size={size} aria-hidden="true" />;
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} fill="currentColor" aria-hidden="true">
      <path d={brand.path} />
    </svg>
  );
}

/** Un morceau et un lien par plateforme de streaming (à la manière des « smart links »). */
export function MusicBlock({ data, blockId }: { data: BlockData<"music">; blockId: string }) {
  const links = data.links.map((l) => ({ ...l, href: toSafeHref(l.url) })).filter((l): l is typeof l & { href: string } => Boolean(l.href));
  const cover = toSafeImageSrc(data.cover);
  if (!links.length && !data.title) return <div className="lbu-card p-5 text-center text-[0.9em] lbu-muted">Ajoute un morceau et ses liens d&apos;écoute.</div>;
  return (
    <section className="lbu-card overflow-hidden" aria-label={`Écouter ${data.title}`}>
      <div className="flex items-center gap-4 p-4">
        {cover ? (
          <img src={cover} alt="" className="h-20 w-20 shrink-0 rounded-[12px] object-cover shadow-lg" loading="lazy" />
        ) : (
          <span className="flex h-20 w-20 shrink-0 items-center justify-center rounded-[12px]" style={{ background: "var(--lbu-faint)", color: "var(--lbu-accent-ink)" }}>
            <Music2 size={30} aria-hidden="true" />
          </span>
        )}
        <div className="min-w-0">
          <p className="lbu-muted text-[0.72em] font-semibold uppercase tracking-[0.12em]">Écouter partout</p>
          <p className="lbu-heading truncate text-[1.1em] font-bold leading-tight">{data.title || "Sans titre"}</p>
          {data.artist && <p className="lbu-muted truncate text-[0.9em]">{data.artist}</p>}
        </div>
      </div>
      <ul className="divide-y" style={{ borderColor: "var(--lbu-card-border)" }}>
        {links.map((link, i) => (
          <li key={i} style={{ borderColor: "var(--lbu-card-border)" }} className="border-t">
            <a href={link.href} {...EXTERNAL} data-lbu-block={blockId} className="flex items-center gap-3 px-4 py-2.5 transition hover:bg-[var(--lbu-faint)]">
              <PlatformIcon platform={link.platform} />
              <span className="flex-1 text-[0.92em] font-medium">{MUSIC_LABELS[link.platform]}</span>
              <span className="lbu-chip !py-0.5 !text-[0.75em]">Écouter</span>
            </a>
          </li>
        ))}
      </ul>
    </section>
  );
}

// ─── Agenda ─────────────────────────────────────────────────────────────────

type EventItem = BlockData<"events">["items"][number];

/** Fichier .ics d'un événement, pour l'ajouter à son agenda (Google, Apple, Outlook). */
function downloadIcs(item: EventItem) {
  const stamp = (d: Date) => d.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
  const start = new Date(item.start);
  const end = item.end ? new Date(item.end) : new Date(start.getTime() + 60 * 60 * 1000);
  const escape = (v: string) => v.replace(/[\\,;]/g, (c) => `\\${c}`).replace(/\n/g, "\\n");
  const lines = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Link by Unclaim//FR",
    "BEGIN:VEVENT",
    `UID:${stamp(start)}-${Math.random().toString(36).slice(2)}@link.unclaim`,
    `DTSTAMP:${stamp(new Date())}`,
    `DTSTART:${stamp(start)}`,
    `DTEND:${stamp(end)}`,
    `SUMMARY:${escape(item.title)}`,
    ...(item.location ? [`LOCATION:${escape(item.location)}`] : []),
    ...(item.url ? [`URL:${item.url}`] : []),
    "END:VEVENT",
    "END:VCALENDAR",
  ];
  const blob = new Blob([lines.join("\r\n")], { type: "text/calendar" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `${item.title.replace(/[^\p{L}\p{N}]+/gu, "-").slice(0, 40) || "evenement"}.ics`;
  a.click();
  URL.revokeObjectURL(a.href);
}

/** Prochains événements (streams, guerres, sorties), à l'heure du visiteur. */
export function EventsBlock({ data, blockId }: { data: BlockData<"events">; blockId: string }) {
  const [now, setNow] = useState<number | null>(null);
  useEffect(() => {
    setNow(Date.now());
    const timer = window.setInterval(() => setNow(Date.now()), 30_000);
    return () => window.clearInterval(timer);
  }, []);

  const reference = now ?? 0;
  const items = data.items
    .filter((i) => i.title.trim() && !Number.isNaN(Date.parse(i.start)))
    .map((i) => ({ ...i, startMs: Date.parse(i.start), endMs: i.end ? Date.parse(i.end) : Date.parse(i.start) + 60 * 60 * 1000 }))
    .filter((i) => !data.hidePast || now === null || i.endMs > reference)
    .sort((a, b) => a.startMs - b.startMs);

  if (!items.length) {
    return now === null ? null : <div className="lbu-card p-5 text-center text-[0.9em] lbu-muted">Aucun événement à venir.</div>;
  }

  return (
    <section className="lbu-card p-4" aria-label={data.title || "Agenda"}>
      {data.title && <p className="lbu-heading mb-3 text-[1.05em] font-bold">{data.title}</p>}
      <ol className="space-y-2.5">
        {items.map((item, i) => {
          const date = new Date(item.startMs);
          const ongoing = now !== null && item.startMs <= reference && item.endMs > reference;
          const past = now !== null && item.endMs <= reference;
          const href = item.url ? toSafeHref(item.url) : null;
          return (
            <li key={i} className={`flex gap-3 ${past ? "opacity-50" : ""}`}>
              <div className="flex w-12 shrink-0 flex-col items-center justify-center rounded-[10px] py-1.5" style={{ background: "var(--lbu-faint)" }}>
                <span className="lbu-heading text-[1.25em] leading-none font-bold" suppressHydrationWarning>
                  {date.toLocaleDateString("fr-FR", { day: "numeric", ...(now === null ? { timeZone: "Europe/Paris" } : {}) })}
                </span>
                <span className="lbu-muted mt-0.5 text-[0.65em] uppercase" suppressHydrationWarning>
                  {date.toLocaleDateString("fr-FR", { month: "short", ...(now === null ? { timeZone: "Europe/Paris" } : {}) }).replace(".", "")}
                </span>
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-semibold">
                  {href ? (
                    <a href={href} {...EXTERNAL} data-lbu-block={blockId} className="hover:underline">
                      {item.title}
                    </a>
                  ) : (
                    item.title
                  )}
                </p>
                <p className="lbu-muted text-[0.82em]">
                  <DiscordTime seconds={Math.floor(item.startMs / 1000)} style="t" />
                  {" · "}
                  {ongoing ? (
                    <span className="font-semibold" style={{ color: "var(--lbu-accent-ink)" }}>
                      en cours
                    </span>
                  ) : (
                    <span suppressHydrationWarning>{now === null ? "" : relativeTime(item.startMs - reference)}</span>
                  )}
                </p>
                {item.location && (
                  <p className="lbu-muted flex items-center gap-1 truncate text-[0.8em]">
                    <MapPin size={12} aria-hidden="true" /> {item.location}
                  </p>
                )}
              </div>
              {data.showAddToCalendar && !past && (
                <button type="button" onClick={() => downloadIcs(item)} className="lbu-icon-btn !h-8 !w-8 self-center" aria-label={`Ajouter « ${item.title} » à mon agenda`} title="Ajouter à mon agenda">
                  <CalendarPlus size={15} />
                </button>
              )}
            </li>
          );
        })}
      </ol>
    </section>
  );
}

// ─── Dossier de liens ───────────────────────────────────────────────────────

/** Plusieurs liens rangés sous un titre, dépliés au clic. */
export function CollectionBlock({ data, blockId, fill }: { data: BlockData<"collection">; blockId: string; fill: string }) {
  const links = data.links.map((l) => ({ ...l, href: toSafeHref(l.url) })).filter((l): l is typeof l & { href: string } => Boolean(l.href) && Boolean(l.label.trim()));
  if (!links.length) return <div className="lbu-card p-5 text-center text-[0.9em] lbu-muted">Ajoute des liens à ce dossier.</div>;
  return (
    <details className="lbu-card lbu-collection group overflow-hidden" open={data.open}>
      <summary className="flex cursor-pointer list-none items-center gap-3 px-4 py-3.5 marker:hidden">
        <span className="min-w-0 flex-1">
          <span className="lbu-heading block truncate font-bold">{data.title || "Mes liens"}</span>
          {data.description && <span className="lbu-muted block truncate text-[0.82em]">{data.description}</span>}
        </span>
        <span className="lbu-chip !py-0.5 !text-[0.75em]">{links.length}</span>
        <ChevronDown size={18} className="shrink-0 transition-transform group-open:rotate-180" aria-hidden="true" />
      </summary>
      <ul className="space-y-2 px-3 pb-3">
        {links.map((link, i) => (
          <li key={i}>
            <a href={link.href} {...EXTERNAL} data-lbu-block={blockId} className="lbu-btn !min-h-11 !py-2 text-[0.92em]" data-fill={fill}>
              {link.emoji && (
                <span className="w-6 shrink-0 text-center text-[1.15em]" aria-hidden="true">
                  {link.emoji}
                </span>
              )}
              <span className="lbu-btn-label min-w-0 flex-1 truncate text-left">{link.label}</span>
              <ArrowUpRight size={16} className="shrink-0 opacity-60" aria-hidden="true" />
            </a>
          </li>
        ))}
      </ul>
    </details>
  );
}

// ─── Contenu sensible ───────────────────────────────────────────────────────

/** Demande confirmation avant d'ouvrir un lien marqué « contenu sensible ». */
export function SensitiveLink({ href, className, children, blockId, fill, highlight, attention }: {
  href: string;
  className: string;
  children: ReactNode;
  blockId: string;
  fill: string;
  highlight: boolean;
  attention: string;
}) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  return (
    <>
      <a
        href={href}
        {...EXTERNAL}
        className={className}
        data-fill={fill}
        data-highlight={highlight}
        data-attention={attention}
        onClick={(e) => {
          e.preventDefault();
          dialogRef.current?.showModal();
        }}
      >
        {children}
      </a>
      <dialog
        ref={dialogRef}
        className="m-auto w-[min(92vw,380px)] rounded-xl border border-white/10 bg-[#0f172b] p-5 text-left text-[15px] text-slate-100 backdrop:bg-black/70"
        aria-label="Contenu sensible"
      >
        <p className="flex items-center gap-2 font-semibold">
          <ShieldAlert size={18} className="text-amber-300" aria-hidden="true" /> Contenu sensible
        </p>
        <p className="mt-2 text-sm text-slate-300">Ce lien peut mener à un contenu réservé à un public averti. Tu confirmes vouloir l&apos;ouvrir ?</p>
        <div className="mt-4 flex justify-end gap-2 text-sm">
          <button type="button" onClick={() => dialogRef.current?.close()} className="rounded-md px-3 py-2 text-slate-300 hover:text-white">
            Annuler
          </button>
          <a
            href={href}
            {...EXTERNAL}
            data-lbu-block={blockId}
            onClick={() => dialogRef.current?.close()}
            className="rounded-md bg-[#22c9e8] px-3 py-2 font-semibold text-[#021018]"
          >
            Continuer
          </a>
        </div>
      </dialog>
    </>
  );
}
