"use client";

import { Crown, Flag, Users } from "lucide-react";
import type { BlockData } from "@/lib/blocks";
import { formatNgDate, ngServerMeta, type NgCountry } from "@/lib/nationsglory-shared";
import { useRemote } from "../useRemote";

type Props = { data: BlockData<"ngCountry">; initial?: NgCountry; live: boolean; preview: boolean };

const nf = new Intl.NumberFormat("fr-FR");
const n = (v: number | null) => (v === null ? "—" : nf.format(v));

/** Fiche d'un pays NationsGlory : drapeau, chef, membres, power, claims, MMR et score. */
export function NgCountryBlock({ data, initial, live, preview }: Props) {
  const target = (data.countryId || data.country).trim();
  const meta = ngServerMeta(data.server);
  const { data: info, loading } = useRemote<NgCountry>(
    target ? `/api/nationsglory/country/${data.server}/${encodeURIComponent(target)}` : null,
    initial,
    live,
  );

  if (!target) {
    return <div className="lbu-card p-5 text-center text-[0.9em] lbu-muted">Choisis ton pays et son serveur.</div>;
  }

  const ok = info?.status === "ok";
  const name = ok ? info.name : data.country || "Pays";
  const message =
    info?.status === "gone"
      ? "Ce pays a été dissous."
      : info?.status === "not_found"
        ? "Pays introuvable sur ce serveur."
        : preview
          ? (info?.message ?? "Données indisponibles.")
          : "Données du pays indisponibles pour le moment.";

  return (
    <section className="lbu-card overflow-hidden" aria-label={`Pays ${name} sur ${meta.label}`}>
      <header className="flex items-center gap-3 p-4">
        {ok && info.flagUrl ? (
          <img src={info.flagUrl} alt="" className="h-10 w-auto max-w-16 shrink-0 rounded-[4px] object-contain" loading="lazy" referrerPolicy="no-referrer" />
        ) : (
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-[10px]" style={{ background: meta.color, color: "#0b0b10" }}>
            <Flag size={20} aria-hidden="true" />
          </span>
        )}
        <div className="min-w-0 flex-1">
          <p className="lbu-heading truncate text-[1.1em] font-bold leading-tight">{name}</p>
          <p className="lbu-muted flex flex-wrap items-center gap-x-2 text-[0.78em]">
            <span className="font-semibold uppercase tracking-wide" style={{ color: meta.color }}>
              {meta.label}
            </span>
            {ok && info.membersCount !== null && (
              <span className="inline-flex items-center gap-1">
                <Users size={13} aria-hidden="true" /> {n(info.membersCount)} membre{info.membersCount > 1 ? "s" : ""}
              </span>
            )}
            {info?.mock && <span className="lbu-chip !py-0 !text-[0.85em]">démo</span>}
          </p>
        </div>
      </header>

      {loading && !info && <div className="mx-4 mb-4 h-10 animate-pulse rounded-lg" style={{ background: "var(--lbu-faint)" }} />}
      {info && !ok && <p className="lbu-muted px-4 pb-4 text-[0.85em]">{message}</p>}

      {ok && info.badges.length + info.tags.length > 0 && (
        <ul className="flex flex-wrap gap-1.5 px-4 pb-3">
          {info.badges.map((b) => (
            <li key={b} className="lbu-chip" style={{ background: "var(--lbu-accent-soft)", color: "var(--lbu-text)" }}>
              {b}
            </li>
          ))}
          {info.tags.map((t) => (
            <li key={t} className="lbu-chip">
              {t}
            </li>
          ))}
        </ul>
      )}

      {ok && data.showDescription && info.description && (
        <p className="lbu-muted line-clamp-3 px-4 pb-3 text-[0.88em] whitespace-pre-line">{info.description}</p>
      )}

      {ok && info.leader && (
        <p className="flex items-center gap-2 px-4 pb-3 text-[0.9em]">
          <Crown size={15} aria-hidden="true" style={{ color: "var(--lbu-accent-ink)" }} />
          <span className="lbu-muted">Chef</span>
          <img src={`/api/skin/${encodeURIComponent(info.leader)}?type=face&size=32`} alt="" width={20} height={20} className="pixelated h-5 w-5 rounded-[4px]" loading="lazy" />
          <span className="font-semibold">{info.leader}</span>
        </p>
      )}

      {ok && data.showMembers && info.members.length > 0 && (
        <ul className="flex flex-wrap gap-1.5 px-4 pb-4" aria-label="Membres">
          {info.members
            .filter((m) => m.username !== info.leader)
            .slice(0, 12)
            .map((m) => (
              <li key={m.username} className="lbu-chip !gap-1.5 !pl-1" title={m.role ?? undefined}>
                <img src={`/api/skin/${encodeURIComponent(m.username)}?type=face&size=32`} alt="" width={16} height={16} className="pixelated h-4 w-4 rounded-[3px]" loading="lazy" />
                {m.username}
              </li>
            ))}
        </ul>
      )}

      {ok && (
        <dl className="grid grid-cols-2">
          {[
            { label: "Power", value: info.power === null ? "—" : `${n(info.power)} / ${n(info.powerMax)}` },
            { label: "Claims", value: n(info.claims) },
            { label: "MMR", value: n(info.mmr) },
            { label: "Score", value: n(info.score) },
          ].map((stat, i) => (
            <div
              key={stat.label}
              className="min-w-0 px-4 py-3"
              style={{ borderTop: "1px solid var(--lbu-faint)", borderRight: i % 2 === 0 ? "1px solid var(--lbu-faint)" : undefined }}
            >
              <dt className="lbu-muted truncate text-[0.72em] uppercase tracking-wide">{stat.label}</dt>
              <dd className="truncate text-[0.95em] font-semibold tabular-nums">{stat.value}</dd>
            </div>
          ))}
        </dl>
      )}

      {ok && info.createdOn && (
        <p className="lbu-muted border-t px-4 py-2.5 text-[0.75em]" style={{ borderColor: "var(--lbu-faint)" }}>
          Fondé le {formatNgDate(info.createdOn)}
        </p>
      )}
    </section>
  );
}
