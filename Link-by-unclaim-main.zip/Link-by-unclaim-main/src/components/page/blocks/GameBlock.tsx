"use client";

import { useEffect, useState } from "react";
import { ExternalLink, Gamepad2 } from "lucide-react";
import type { BlockData } from "@/lib/blocks";
import { cleanGameId, gameInfo, type GameProfile } from "@/lib/games";
import { isValidMcUsername, toSafeHref } from "@/lib/urls";

type LiveState = { status: "idle" | "loading" | "missing" | "error" } | { status: "ok"; profile: GameProfile };

/** Profil de jeu : données publiques en direct (jeux avec API) et/ou carte remplie à la main. */
export function GameBlock({ data, blockId, preview }: { data: BlockData<"game">; blockId: string; preview: boolean }) {
  const info = gameInfo(data.game);
  const name = data.game === "other" ? data.customName.trim() || "Jeu" : info.name;
  const liveId = info.live && data.showLive ? cleanGameId(data.game, data.username) : null;
  const [live, setLive] = useState<LiveState>({ status: "idle" });

  useEffect(() => {
    if (!liveId) {
      setLive({ status: "idle" });
      return;
    }
    const controller = new AbortController();
    setLive({ status: "loading" });
    const timer = setTimeout(() => {
      fetch(`/api/games/${data.game}?id=${encodeURIComponent(data.username.trim())}`, { signal: controller.signal })
        .then(async (res) => {
          if (res.status === 404) return setLive({ status: "missing" });
          if (!res.ok) return setLive({ status: "error" });
          const json = (await res.json()) as { profile: GameProfile };
          setLive({ status: "ok", profile: json.profile });
        })
        .catch(() => undefined);
    }, preview ? 500 : 0);
    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [liveId, data.game, data.username, preview]);

  const profile = live.status === "ok" ? live.profile : null;
  const username = data.username.trim();
  const mcFace = info.minecraft && isValidMcUsername(username) ? `/api/skin/${encodeURIComponent(username)}?type=face&size=128` : null;
  const avatar = profile?.avatar ?? mcFace;
  const href = toSafeHref(data.url) ?? profile?.url ?? (username && info.profileUrl ? info.profileUrl(username) : null);
  const stats = [...(profile?.stats ?? []), ...data.stats.filter((s) => s.label.trim() && s.value.trim())].slice(0, 6);
  const cols = stats.length % 3 === 0 ? 3 : 2;

  if (!username) {
    return <div className="lbu-card p-5 text-center text-[0.9em] lbu-muted">Indique ton pseudo {name}.</div>;
  }

  return (
    <section className="lbu-card overflow-hidden" aria-label={`Profil ${name}`}>
      <div className="flex items-center gap-3 p-4">
        <div className="relative shrink-0">
          {avatar ? (
            <img
              src={avatar}
              alt=""
              className="h-14 w-14 rounded-[12px] object-cover"
              style={info.minecraft && !profile?.avatar ? { imageRendering: "pixelated" } : undefined}
              loading="lazy"
            />
          ) : (
            <span className="flex h-14 w-14 items-center justify-center rounded-[12px]" style={{ background: `${info.color}26`, color: info.color }}>
              <Gamepad2 size={26} aria-hidden="true" />
            </span>
          )}
          {profile?.online && <span className="absolute -right-0.5 -bottom-0.5 h-3.5 w-3.5 rounded-full bg-[#3ba55d] shadow-[0_0_0_2px_rgba(0,0,0,0.55)]" title="En ligne" />}
        </div>
        <div className="min-w-0 flex-1">
          <p className="inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[0.7em] font-semibold" style={{ background: `${info.color}22`, color: info.color }}>
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: info.color }} aria-hidden="true" />
            {name}
          </p>
          <p className="lbu-heading mt-1 truncate text-[1.1em] font-bold">{profile?.name ?? username}</p>
          {(data.rank || profile?.subtitle) && (
            <p className="lbu-muted truncate text-[0.82em]">{[data.rank, profile?.subtitle].filter(Boolean).join(" · ")}</p>
          )}
          {live.status === "loading" && <p className="lbu-muted text-[0.75em]">Chargement du profil…</p>}
          {preview && live.status === "missing" && <p className="text-[0.75em] text-[#f0b232]">Joueur introuvable : vérifie le pseudo.</p>}
          {preview && live.status === "error" && <p className="lbu-muted text-[0.75em]">Service du jeu indisponible pour le moment.</p>}
        </div>
      </div>
      {stats.length > 0 && (
        <dl className={`grid ${cols === 3 ? "grid-cols-3" : "grid-cols-2"}`}>
          {stats.map((s, i) => (
            <div
              key={`${s.label}-${s.value}`}
              className="px-3 py-2.5 text-center"
              style={{ borderTop: "1px solid var(--lbu-faint)", borderLeft: i % cols ? "1px solid var(--lbu-faint)" : undefined }}
            >
              <dt className="lbu-muted text-[0.68em] uppercase tracking-wide">{s.label}</dt>
              <dd className="lbu-heading text-[1.05em] font-bold tabular-nums">{s.value}</dd>
            </div>
          ))}
        </dl>
      )}
      {href && (
        <a
          href={href}
          target="_blank"
          rel="noopener noreferrer nofollow"
          data-lbu-block={blockId}
          style={{ color: "var(--lbu-accent-ink)", borderTop: "1px solid var(--lbu-faint)" }}
          className="flex items-center justify-center gap-1.5 px-4 py-2.5 text-[0.85em] font-semibold transition hover:opacity-80"
        >
          Voir le profil {name} <ExternalLink size={13} aria-hidden="true" />
        </a>
      )}
    </section>
  );
}
