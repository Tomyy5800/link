"use client";

import { useEffect, useRef, useState } from "react";
import { Rotate3d } from "lucide-react";
import type { BlockData } from "@/lib/blocks";
import { isValidMcUsername } from "@/lib/urls";

type Props = { data: BlockData<"skin">; username: string; compact?: boolean };

/**
 * Skin Minecraft en 3D (skinview3d / WebGL), texture servie par /api/skin.
 * La bibliothèque n'est chargée qu'à l'affichage du bloc ; en cas d'échec (WebGL
 * indisponible…), on retombe sur le rendu 2D du serveur de skins NationsGlory.
 */
export function SkinBlock({ data, username, compact }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [failed, setFailed] = useState(false);
  const [ready, setReady] = useState(false);
  const valid = isValidMcUsername(username);
  const height = compact ? Math.min(data.height, 280) : data.height;

  useEffect(() => {
    if (!valid || !canvasRef.current || !containerRef.current) return;
    let disposed = false;
    let cleanup = () => {};
    setReady(false);
    setFailed(false);

    (async () => {
      try {
        const skinview3d = await import("skinview3d");
        if (disposed || !canvasRef.current || !containerRef.current) return;
        const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        const width = containerRef.current.clientWidth || 300;

        const viewer = new skinview3d.SkinViewer({
          canvas: canvasRef.current,
          width,
          height,
          pixelRatio: "match-device",
          fov: 50,
          zoom: compact ? 0.82 : 0.9,
        });
        viewer.controls.enableZoom = false;
        viewer.controls.enablePan = false;
        viewer.autoRotate = data.autoRotate && !reduceMotion;
        viewer.autoRotateSpeed = 1.2;

        const Animations = {
          idle: skinview3d.IdleAnimation,
          walk: skinview3d.WalkingAnimation,
          run: skinview3d.RunningAnimation,
          fly: skinview3d.FlyingAnimation,
          wave: skinview3d.WaveAnimation,
          crouch: skinview3d.CrouchAnimation,
        } as const;
        if (data.animation !== "none" && !reduceMotion) {
          viewer.animation = new Animations[data.animation]();
          if (viewer.animation) viewer.animation.speed = data.animation === "run" ? 0.8 : 1;
        }
        if (data.showName) viewer.nameTag = username;

        await viewer.loadSkin(`/api/skin/${encodeURIComponent(username)}?type=skin`);
        if (disposed) {
          viewer.dispose();
          return;
        }
        setReady(true);

        // Redimensionnement fluide et pause du rendu hors de l'écran.
        const resize = new ResizeObserver(([entry]) => {
          const w = Math.round(entry.contentRect.width);
          if (w > 0) viewer.setSize(w, height);
        });
        resize.observe(containerRef.current);
        const visibility = new IntersectionObserver(([entry]) => {
          viewer.renderPaused = !entry.isIntersecting;
        });
        visibility.observe(containerRef.current);

        cleanup = () => {
          resize.disconnect();
          visibility.disconnect();
          viewer.dispose();
        };
      } catch {
        if (!disposed) setFailed(true);
      }
    })();

    return () => {
      disposed = true;
      cleanup();
    };
  }, [valid, username, height, compact, data.animation, data.autoRotate, data.showName]);

  if (!valid) {
    return (
      <div className="lbu-card flex items-center justify-center p-6 text-center text-[0.9em] lbu-muted" style={{ minHeight: 160 }}>
        Indique un pseudo NationsGlory pour afficher le skin.
      </div>
    );
  }

  return (
    <figure className="lbu-card relative overflow-hidden" style={{ height }}>
      <div ref={containerRef} className="absolute inset-0">
        {failed ? (
          <img
            src={`/api/skin/${encodeURIComponent(username)}?type=body&size=256`}
            alt={`Skin de ${username}`}
            className="pixelated mx-auto h-full w-auto object-contain p-4"
          />
        ) : (
          <canvas
            ref={canvasRef}
            className={`block cursor-grab touch-pan-y transition-opacity duration-500 active:cursor-grabbing ${ready ? "opacity-100" : "opacity-0"}`}
            aria-label={`Skin 3D de ${username}, fais-le pivoter en le faisant glisser`}
            role="img"
          />
        )}
      </div>
      {!ready && !failed && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="h-10 w-10 animate-spin rounded-full border-2 border-current border-t-transparent opacity-40" />
        </div>
      )}
      <figcaption className="pointer-events-none absolute inset-x-0 bottom-0 flex items-center justify-between gap-2 px-4 pb-3 text-[0.8em]">
        <span className="font-semibold">{data.label || username}</span>
        {ready && (
          <span className="lbu-muted inline-flex items-center gap-1">
            <Rotate3d size={14} aria-hidden="true" /> 3D
          </span>
        )}
      </figcaption>
    </figure>
  );
}
