"use client";

import { useState } from "react";
import { Check, LoaderCircle, Send } from "lucide-react";
import type { BlockData } from "@/lib/blocks";

/** Formulaire de contact : le message arrive dans « Mon espace » du propriétaire et de son équipe. */
export function ContactBlock({ data, blockId, slug, live }: { data: BlockData<"contact">; blockId: string; slug: string; live: boolean }) {
  const [name, setName] = useState("");
  const [contact, setContact] = useState("");
  const [message, setMessage] = useState("");
  const [website, setWebsite] = useState(""); // piège à robots, invisible pour les humains
  const [state, setState] = useState<{ status: "idle" | "sending" | "sent" | "error"; text?: string }>({ status: "idle" });

  const needsContact = data.contactField === "required";
  const ready = name.trim().length >= 2 && message.trim().length >= 5 && (!needsContact || contact.trim().length >= 3);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (!ready) return;
    if (!live) {
      setState({ status: "error", text: "Aperçu : l'envoi fonctionne sur ta page publique." });
      return;
    }
    setState({ status: "sending" });
    const res = await fetch(`/api/pages/${encodeURIComponent(slug)}/contact`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ b: blockId, name, contact, message, website }),
    }).catch(() => null);
    if (res?.ok) {
      setState({ status: "sent" });
      return;
    }
    const json = (await res?.json().catch(() => ({}))) as { error?: string };
    setState({ status: "error", text: json.error ?? "Envoi impossible, réessaie dans un instant." });
  }

  const field =
    "w-full rounded-[calc(var(--lbu-radius,12px)*0.7)] border px-3 py-2 text-[0.9em] outline-none transition focus:border-[var(--lbu-accent)]";
  const fieldStyle = { background: "var(--lbu-faint)", borderColor: "var(--lbu-faint)", color: "var(--lbu-text)" };

  if (state.status === "sent") {
    return (
      <section className="lbu-card p-5 text-center" aria-live="polite">
        <span className="mx-auto flex h-10 w-10 items-center justify-center rounded-full" style={{ background: "var(--lbu-accent-soft)", color: "var(--lbu-accent-ink)" }}>
          <Check size={20} aria-hidden="true" />
        </span>
        <p className="lbu-heading mt-2 font-bold">{data.successText || "Merci ! Ton message a bien été envoyé."}</p>
      </section>
    );
  }

  return (
    <section className="lbu-card p-4" aria-label={data.title || "Me contacter"}>
      {data.title && <p className="lbu-heading text-[1.05em] font-bold">{data.title}</p>}
      {data.intro && <p className="lbu-muted mt-1 text-[0.85em]">{data.intro}</p>}
      <form onSubmit={submit} className="mt-3 space-y-2">
        <div className={`grid gap-2 ${data.contactField === "hidden" ? "" : "sm:grid-cols-2"}`}>
          <input className={field} style={fieldStyle} value={name} onChange={(e) => setName(e.target.value)} maxLength={60} placeholder="Ton nom ou pseudo" aria-label="Ton nom ou pseudo" required />
          {data.contactField !== "hidden" && (
            <input
              className={field}
              style={fieldStyle}
              value={contact}
              onChange={(e) => setContact(e.target.value)}
              maxLength={120}
              placeholder={needsContact ? "E-mail ou pseudo Discord" : "E-mail ou Discord (facultatif)"}
              aria-label="Comment te répondre"
              required={needsContact}
            />
          )}
        </div>
        <textarea
          className={`${field} min-h-[96px] resize-y`}
          style={fieldStyle}
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          maxLength={2000}
          placeholder="Ton message"
          aria-label="Ton message"
          required
        />
        <input
          type="text"
          tabIndex={-1}
          autoComplete="off"
          value={website}
          onChange={(e) => setWebsite(e.target.value)}
          className="absolute -left-[9999px] h-0 w-0 opacity-0"
          aria-hidden="true"
        />
        <button
          type="submit"
          disabled={!ready || state.status === "sending"}
          className="lbu-button inline-flex w-full items-center justify-center gap-2 px-4 py-2.5 text-[0.9em] font-semibold disabled:opacity-50"
          style={{ background: "var(--lbu-accent-fill, var(--lbu-accent))", color: "var(--lbu-on-accent)", borderRadius: "var(--lbu-radius, 12px)" }}
        >
          {state.status === "sending" ? <LoaderCircle size={16} className="animate-spin" /> : <Send size={15} aria-hidden="true" />}
          {data.buttonLabel || "Envoyer"}
        </button>
        {state.status === "error" && <p className="text-center text-[0.8em] text-[#f0b232]">{state.text}</p>}
        <p className="lbu-muted text-center text-[0.68em]">Ton message est transmis au propriétaire de la page, jamais publié.</p>
      </form>
    </section>
  );
}
