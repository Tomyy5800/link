"use client";

import { useEffect, useMemo, useState } from "react";
import { Lock } from "lucide-react";
import type { BlockData } from "@/lib/blocks";
import { describeEmbed, widgetDocument } from "@/lib/embeds";
import { resolveEmbedSrc } from "@/lib/urls";

const ASPECTS: Record<string, string | undefined> = { "16:9": "16 / 9", "4:3": "4 / 3", "1:1": "1 / 1", "9:16": "9 / 16" };

type Props = {
  data: BlockData<"embed">;
  allowIframe: boolean;
  allowHtml: boolean;
  blockedDomains: string[];
  preview: boolean;
  premiumName: string;
};

/** Lecteur intégré : fournisseurs reconnus, iframe libre ou widget HTML isolé. */
export function EmbedBlock({ data, allowIframe, allowHtml, blockedDomains, preview, premiumName }: Props) {
  const [host, setHost] = useState<string | null>(null);
  // Twitch exige le domaine de la page parente, connu seulement dans le navigateur.
  useEffect(() => setHost(window.location.hostname), []);
  const info = useMemo(() => describeEmbed(data, { iframe: allowIframe, html: allowHtml }, blockedDomains), [data, allowIframe, allowHtml, blockedDomains]);

  if (info.kind === "locked" || info.kind === "empty" || info.kind === "blocked") {
    if (!preview) return null;
    return (
      <div className="lbu-card flex items-center justify-center gap-2 p-5 text-center text-[0.9em] lbu-muted">
        {info.kind === "locked" && <Lock size={15} aria-hidden="true" />}
        {info.kind === "locked" ? `${info.reason} font partie de ${premiumName}.` : info.reason}
      </div>
    );
  }

  const ratio = ASPECTS[data.aspect];
  const fixed = data.height ?? (info.kind === "frame" ? info.height : undefined) ?? (info.kind === "html" ? 320 : undefined);
  const sizing = ratio ? { aspectRatio: ratio } : fixed ? { height: fixed } : { aspectRatio: (info.kind === "frame" && info.aspect) || "16 / 9" };
  const title = data.title || (info.kind === "frame" ? `Intégration ${info.label}` : "Widget");

  return (
    <figure className="lbu-card overflow-hidden p-1.5">
      <div className="overflow-hidden" style={{ ...sizing, maxWidth: "100%", borderRadius: "calc(var(--lbu-card-radius) - 6px)" }}>
        {info.kind === "html" ? (
          <iframe
            srcDoc={widgetDocument(data.html)}
            title={title}
            className="h-full w-full border-0"
            loading="lazy"
            sandbox="allow-scripts allow-popups allow-popups-to-escape-sandbox allow-forms"
            referrerPolicy="no-referrer"
          />
        ) : (
          host && (
            <iframe
              src={resolveEmbedSrc(info.src, host)}
              title={title}
              className="h-full w-full border-0"
              loading="lazy"
              allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
              referrerPolicy="strict-origin-when-cross-origin"
              sandbox="allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox allow-presentation allow-forms"
            />
          )
        )}
      </div>
      {data.title && <figcaption className="lbu-muted px-2 pt-2 pb-1 text-[0.8em]">{data.title}</figcaption>}
    </figure>
  );
}
