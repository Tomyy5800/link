"use client";

import { ChevronDown, ChevronLeft, ChevronRight, ChevronUp, Pencil } from "lucide-react";

export type EditingHooks = {
  selectedId: string | null;
  onSelect: (id: string) => void;
  onResize: (id: string, patch: { colSpan?: number | null; rowSpan?: number }) => void;
  /** La grille sur ordinateur est-elle active (largeur et hauteur réglables) ? */
  grid: boolean;
  columns: number;
};

/** Barre d'outils posée sur un bloc dans l'aperçu : sélection et redimensionnement. */
export function CellControls({ id, span, rows, editing }: { id: string; span: number; rows: number; editing: EditingHooks }) {
  const selected = editing.selectedId === id;
  const btn =
    "flex h-6 w-6 items-center justify-center rounded text-white/90 hover:bg-white/20 disabled:opacity-30 disabled:hover:bg-transparent";
  return (
    <div
      className={`lbu-cell-tools absolute top-1.5 right-1.5 z-20 flex items-center gap-0.5 rounded-md bg-[#020618]/90 p-0.5 font-sans text-[11px] shadow-lg ring-1 ring-white/15 ${
        selected ? "opacity-100" : ""
      }`}
    >
      {editing.grid && (
        <>
          <button type="button" className={btn} disabled={span <= 1} onClick={() => editing.onResize(id, { colSpan: span - 1 })} aria-label="Réduire la largeur">
            <ChevronLeft size={13} />
          </button>
          <span className="w-7 text-center tabular-nums text-white/80" title="Colonnes × rangées">
            {span}×{rows}
          </span>
          <button type="button" className={btn} disabled={span >= editing.columns} onClick={() => editing.onResize(id, { colSpan: span + 1 })} aria-label="Augmenter la largeur">
            <ChevronRight size={13} />
          </button>
          <button type="button" className={btn} disabled={rows <= 1} onClick={() => editing.onResize(id, { rowSpan: rows - 1 })} aria-label="Réduire la hauteur">
            <ChevronUp size={13} />
          </button>
          <button type="button" className={btn} disabled={rows >= 4} onClick={() => editing.onResize(id, { rowSpan: rows + 1 })} aria-label="Augmenter la hauteur">
            <ChevronDown size={13} />
          </button>
        </>
      )}
      <button type="button" className={btn} onClick={() => editing.onSelect(id)} aria-label="Modifier ce bloc">
        <Pencil size={12} />
      </button>
    </div>
  );
}
