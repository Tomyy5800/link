// Une seule source audio à la fois sur une page : musique de fond, radio, etc.
// Chaque lecteur annonce qu'il démarre ; les autres se mettent en pause.

const EVENT = "lbu:audio";

export function announcePlaying(id: string) {
  window.dispatchEvent(new CustomEvent<string>(EVENT, { detail: id }));
}

/** Appelle `pause` quand un autre lecteur de la page démarre. Renvoie la fonction de désabonnement. */
export function onOtherPlaying(id: string, pause: () => void): () => void {
  const handler = (event: Event) => {
    if ((event as CustomEvent<string>).detail !== id) pause();
  };
  window.addEventListener(EVENT, handler);
  return () => window.removeEventListener(EVENT, handler);
}
