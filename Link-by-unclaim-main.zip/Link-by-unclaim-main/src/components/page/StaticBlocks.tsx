import { ArrowUpRight, ChevronDown, ShieldAlert, UserPlus } from "lucide-react";
import type { BlockData } from "@/lib/blocks";
import type { OwnerProfile } from "@/lib/page-schema";
import type { Theme } from "@/lib/theme";
import { PLATFORMS, detectPlatform, isPlatform, toSafeHref, toSafeImageSrc } from "@/lib/urls";
import { DiscordLogo, SocialIcon } from "@/components/icons/SocialIcon";
import { SensitiveLink } from "./blocks/MoreBlocks";
import { RichText } from "./RichText";

// Blocs sans interactivité : rendus aussi bien côté serveur que dans l'aperçu de l'éditeur.

const EXTERNAL = { target: "_blank", rel: "noopener noreferrer nofollow ugc" } as const;
const ALIGN = { left: "text-left", center: "text-center", right: "text-right" } as const;

export function HeadingBlock({ data }: { data: BlockData<"heading"> }) {
  if (!data.text) return null;
  const size = { sm: 1, md: 1.2, lg: 1.55 }[data.size];
  return (
    <h2
      className={`lbu-heading px-1 pt-2 font-bold tracking-tight ${ALIGN[data.align]}`}
      style={{ fontSize: `calc(${size}em * var(--lbu-heading-scale, 1))` }}
    >
      {data.text}
    </h2>
  );
}

export function TextBlock({ data }: { data: BlockData<"text"> }) {
  if (!data.text.trim()) return null;
  return (
    <div className={`lbu-card px-5 py-4 text-[0.95em] ${ALIGN[data.align]}`}>
      <RichText text={data.text} />
    </div>
  );
}

export function LinkBlock({ data, theme, blockId }: { data: BlockData<"link">; theme: Theme; blockId: string }) {
  const href = toSafeHref(data.url);
  const platform = data.icon === "auto" ? detectPlatform(data.url) : data.icon;
  const label = data.label || (href ? href.replace(/^https?:\/\/(www\.)?|^mailto:/g, "") : "Lien");
  const thumb = toSafeImageSrc(data.thumbnail);
  const featured = data.layout === "featured" && Boolean(thumb);

  // Vignette, émoji ou icône de la plateforme, dans cet ordre.
  const leading = featured ? null : thumb ? (
    <img src={thumb} alt="" className="h-10 w-10 shrink-0 rounded-[calc(var(--lbu-radius)*0.6)] object-cover" loading="lazy" />
  ) : data.emoji ? (
    <span className="flex h-9 w-9 shrink-0 items-center justify-center text-[1.35em]" aria-hidden="true">
      {data.emoji}
    </span>
  ) : platform !== "none" ? (
    <span className="flex h-9 w-9 shrink-0 items-center justify-center" aria-hidden="true">
      <SocialIcon platform={platform} size={22} />
    </span>
  ) : null;

  const content = (
    <>
      {featured && <img src={thumb!} alt="" className="lbu-btn-cover" loading="lazy" />}
      <span className="flex w-full min-w-0 items-center gap-3">
        {leading}
        <span className="lbu-btn-label min-w-0 flex-1 text-left">
          <span className="block truncate">
            {featured && data.emoji ? `${data.emoji} ` : ""}
            {label}
          </span>
          {data.description && <span className="block truncate text-[0.8em] font-normal opacity-75">{data.description}</span>}
        </span>
        {data.sensitive ? (
          <ShieldAlert size={17} className="shrink-0 opacity-70" aria-label="Contenu sensible" />
        ) : (
          <ArrowUpRight size={18} className="shrink-0 opacity-60" aria-hidden="true" />
        )}
      </span>
    </>
  );
  const className = `lbu-btn ${featured ? "lbu-btn--featured" : ""}`;
  if (!href) {
    return (
      <div className={`${className} opacity-60`} data-fill={theme.buttonFill} aria-disabled="true">
        {content}
      </div>
    );
  }
  if (data.sensitive) {
    return (
      <SensitiveLink href={href} className={className} blockId={blockId} fill={theme.buttonFill} highlight={data.highlight} attention={data.animation}>
        {content}
      </SensitiveLink>
    );
  }
  return (
    <a href={href} {...EXTERNAL} className={className} data-fill={theme.buttonFill} data-highlight={data.highlight} data-attention={data.animation} data-lbu-block={blockId}>
      {content}
    </a>
  );
}

export function SocialsBlock({ data, blockId }: { data: BlockData<"socials">; blockId: string }) {
  const items = data.items
    .map((item) => ({ ...item, href: toSafeHref(item.url) }))
    .filter((item): item is typeof item & { href: string } => Boolean(item.href));
  if (!items.length) return null;

  if (data.style === "pills") {
    return (
      <ul className="flex flex-wrap justify-center gap-2">
        {items.map((item, i) => (
          <li key={i}>
            <a href={item.href} {...EXTERNAL} data-lbu-block={blockId} className="lbu-chip !gap-2 !px-3 !py-1.5 !text-[0.85em] hover:!text-[var(--lbu-text)]">
              <SocialIcon platform={item.platform} size={16} />
              {isPlatform(item.platform) ? PLATFORMS[item.platform].label : item.platform}
            </a>
          </li>
        ))}
      </ul>
    );
  }
  return (
    <ul className="flex flex-wrap justify-center gap-2.5">
      {items.map((item, i) => (
        <li key={i}>
          <a
            href={item.href}
            {...EXTERNAL}
            data-lbu-block={blockId}
            className="lbu-icon-btn"
            aria-label={isPlatform(item.platform) ? PLATFORMS[item.platform].label : item.platform}
            title={isPlatform(item.platform) ? PLATFORMS[item.platform].label : item.platform}
          >
            <SocialIcon platform={item.platform} size={20} />
          </a>
        </li>
      ))}
    </ul>
  );
}

export function ImageBlock({ data, blockId }: { data: BlockData<"image">; blockId: string }) {
  const src = toSafeImageSrc(data.url);
  if (!src) {
    return <div className="lbu-card p-5 text-center text-[0.9em] lbu-muted">Ajoute une image.</div>;
  }
  const aspect = { auto: undefined, square: "1 / 1", video: "16 / 9", portrait: "4 / 5" }[data.aspect];
  const href = toSafeHref(data.href);
  const img = (
    <img
      src={src}
      alt={data.alt}
      loading="lazy"
      referrerPolicy="no-referrer"
      className="block h-full w-full object-cover"
      style={{ aspectRatio: aspect }}
    />
  );
  return (
    <figure className="lbu-card overflow-hidden">
      {href ? (
        <a href={href} {...EXTERNAL} data-lbu-block={blockId} className="block transition-opacity hover:opacity-90">
          {img}
        </a>
      ) : (
        img
      )}
      {data.caption && <figcaption className="lbu-muted px-4 py-2.5 text-center text-[0.82em]">{data.caption}</figcaption>}
    </figure>
  );
}

export function DividerBlock({ data }: { data: BlockData<"divider"> }) {
  if (data.style === "space") return <div className="h-4" aria-hidden="true" />;
  if (data.style === "dots") {
    return (
      <div className="flex justify-center gap-2 py-2" aria-hidden="true">
        {[0, 1, 2].map((i) => (
          <span key={i} className="h-1.5 w-1.5 rounded-full" style={{ background: "var(--lbu-muted)" }} />
        ))}
      </div>
    );
  }
  return <hr className="my-2 border-0 border-t" style={{ borderColor: "var(--lbu-faint)" }} />;
}

/** Carte façon « profil Discord » : bannière, avatar, pseudo et bouton d'ajout en ami. */
export function DiscordProfileBlock({
  data,
  owner,
  theme,
  blockId,
}: {
  data: BlockData<"discord">;
  owner: OwnerProfile;
  theme: Theme;
  blockId: string;
}) {
  const bannerColor = owner.accentColor ?? theme.accent;
  return (
    <section className="lbu-card overflow-hidden" aria-label="Profil Discord">
      {data.showBanner && (
        <div
          className="h-20 bg-cover bg-center"
          style={{
            backgroundColor: bannerColor,
            backgroundImage: owner.bannerUrl ? `url("${owner.bannerUrl}")` : undefined,
          }}
        />
      )}
      <div className={`flex items-end gap-3 px-4 ${data.showBanner ? "-mt-8" : "pt-4"}`}>
        <img
          src={owner.avatarUrl}
          alt=""
          width={72}
          height={72}
          className="h-[72px] w-[72px] shrink-0 rounded-full border-4 object-cover"
          style={{ borderColor: "var(--lbu-card-border)", background: bannerColor }}
        />
        <span className="mb-1 ml-auto inline-flex items-center gap-1.5 rounded-full bg-[#5865f2] px-2.5 py-1 text-[0.72em] font-semibold text-white">
          <DiscordLogo size={13} /> Discord
        </span>
      </div>
      <div className="px-4 pb-4 pt-2">
        <p className="text-[1.1em] font-bold leading-tight">{owner.globalName ?? owner.discordUsername}</p>
        {owner.discordUsername && <p className="lbu-muted text-[0.85em]">@{owner.discordUsername}</p>}
        {data.note && <p className="mt-2 text-[0.88em]">{data.note}</p>}
        {data.showFriendButton && (
          <a
            href={`https://discord.com/users/${owner.discordId}`}
            {...EXTERNAL}
            data-lbu-block={blockId}
            className="lbu-btn mt-3 justify-center !min-h-10 !py-2 text-[0.9em]"
            data-fill={theme.buttonFill}
          >
            <UserPlus size={17} aria-hidden="true" /> Voir le profil Discord
          </a>
        )}
      </div>
    </section>
  );
}

export function FaqBlock({ data }: { data: BlockData<"faq"> }) {
  const items = data.items.filter((item) => item.question.trim());
  if (!items.length) return <div className="lbu-card p-5 text-center text-[0.9em] lbu-muted">Ajoute une première question.</div>;
  return (
    <div className="lbu-card divide-y" style={{ borderColor: "var(--lbu-card-border)" }}>
      {items.map((item, i) => (
        <details key={i} className="group px-4 py-3" style={{ borderColor: "var(--lbu-faint)" }}>
          <summary className="flex cursor-pointer list-none items-center justify-between gap-3 font-semibold [&::-webkit-details-marker]:hidden">
            {item.question}
            <ChevronDown size={16} className="shrink-0 opacity-60 transition-transform group-open:rotate-180" aria-hidden="true" />
          </summary>
          {item.answer.trim() && <RichText text={item.answer} className="lbu-muted mt-2 text-[0.92em]" />}
        </details>
      ))}
    </div>
  );
}

export function BadgesBlock({ data }: { data: BlockData<"badges"> }) {
  const items = data.items.map((i) => i.trim()).filter(Boolean);
  if (!items.length) return null;
  const style = {
    soft: { background: "var(--lbu-accent-soft)", color: "var(--lbu-text)", border: "1px solid transparent" },
    outline: { background: "transparent", color: "var(--lbu-text)", border: "1px solid var(--lbu-accent-line)" },
    solid: { background: "var(--lbu-accent-fill)", color: "var(--lbu-on-accent)", border: "1px solid transparent" },
  }[data.style];
  return (
    <section className="space-y-2 text-center" aria-label={data.title || "Badges"}>
      {data.title && <p className="lbu-muted text-[0.75em] font-semibold uppercase tracking-[0.12em]">{data.title}</p>}
      <ul className="flex flex-wrap justify-center gap-1.5">
        {items.map((item, i) => (
          <li key={i} className="rounded-full px-3 py-1 text-[0.85em] font-medium" style={style}>
            {item}
          </li>
        ))}
      </ul>
    </section>
  );
}
