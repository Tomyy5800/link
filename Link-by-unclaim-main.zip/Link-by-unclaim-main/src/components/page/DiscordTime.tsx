"use client";

import { useEffect, useState } from "react";
import { formatDiscordTimestamp, type TimestampStyle } from "@/lib/discord-markup";

/**
 * Date Discord (<t:…>) : rendue d'abord en heure de Paris (identique côté serveur et navigateur),
 * puis dans le fuseau du visiteur une fois la page montée. Le style relatif (« dans 3 jours ») dépend de l'instant :
 * avant le montage on écrit la date complète, ensuite le relatif, qui se met à jour tout seul.
 */
export function DiscordTime({ seconds, style }: { seconds: number; style: TimestampStyle }) {
  // null tant que la page n'est pas montée : le premier rendu ne lit ni l'heure ni le fuseau du visiteur.
  const [now, setNow] = useState<number | null>(null);

  useEffect(() => {
    setNow(Date.now());
    if (style !== "R") return;
    const timer = window.setInterval(() => setNow(Date.now()), 30_000);
    return () => window.clearInterval(timer);
  }, [style]);

  const date = new Date(seconds * 1000);
  const text = now === null ? formatDiscordTimestamp(seconds, style === "R" ? "f" : style, 0, "Europe/Paris") : formatDiscordTimestamp(seconds, style, now);
  const full = date.toLocaleString("fr-FR", { dateStyle: "full", timeStyle: "short", ...(now === null ? { timeZone: "Europe/Paris" } : {}) });
  return (
    <time className="lbu-time" dateTime={Number.isNaN(date.getTime()) ? undefined : date.toISOString()} title={full} suppressHydrationWarning>
      {text}
    </time>
  );
}
