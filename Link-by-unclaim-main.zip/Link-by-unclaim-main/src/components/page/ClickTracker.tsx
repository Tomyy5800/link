"use client";

import { useEffect } from "react";

/**
 * Compte les clics sur les liens de la page : chaque lien porte data-lbu-block (l'id du bloc).
 * Envoi par sendBeacon, qui survit à la navigation vers le lien.
 */
export function ClickTracker({ slug }: { slug: string }) {
  useEffect(() => {
    const url = `/api/pages/${encodeURIComponent(slug)}/click`;
    const onClick = (event: MouseEvent) => {
      if (event.button > 1) return;
      const link = (event.target as Element | null)?.closest?.("a[data-lbu-block]");
      const blockId = link?.getAttribute("data-lbu-block");
      if (!blockId) return;
      const body = JSON.stringify({ b: blockId });
      if (!navigator.sendBeacon?.(url, body)) {
        fetch(url, { method: "POST", body, keepalive: true }).catch(() => undefined);
      }
    };
    document.addEventListener("click", onClick, { capture: true });
    document.addEventListener("auxclick", onClick, { capture: true });
    return () => {
      document.removeEventListener("click", onClick, { capture: true });
      document.removeEventListener("auxclick", onClick, { capture: true });
    };
  }, [slug]);
  return null;
}
