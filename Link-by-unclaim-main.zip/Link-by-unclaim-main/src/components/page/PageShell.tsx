"use client";

import { useEffect, useRef, useState, type CSSProperties, type ReactNode } from "react";
import { resolveRadio } from "@/lib/radio";
import type { Theme } from "@/lib/theme";
import { toSafeImageSrc } from "@/lib/urls";
import { Particles } from "./effects/Particles";
import { AudioPlayer, CursorEffect, EnteredContext, EntryScreen, TiltCards } from "./effects/Interactions";
import type { RenderMode } from "./types";

type Props = {
  theme: Theme;
  mode: RenderMode;
  effects: boolean;
  media: boolean;
  style: CSSProperties;
  attrs: Record<string, string>;
  children: ReactNode;
};

/** Racine d'une page : porte les variables du thème et branche effets et médias côté navigateur. */
export function PageShell({ theme, mode, effects, media, style, attrs, children }: Props) {
  const rootRef = useRef<HTMLDivElement>(null);
  const startAudio = useRef<(() => void) | null>(null);
  const fixed = mode === "public";
  const cursorImage = effects && theme.cursor === "image" ? toSafeImageSrc(theme.cursorImage) : null;

  // Musique de fond : webradio (prioritaire) ou fichier importé.
  const radio = media && theme.audioRadio ? resolveRadio(theme.audioRadio) : null;
  const audioSrc = radio?.stream ?? (media && theme.audioUrl ? theme.audioUrl : "");
  // Le lecteur ne s'affiche que sur la vraie page : dans l'aperçu de l'éditeur, il gênait l'édition.
  const player = Boolean(audioSrc) && mode === "public";
  // L'écran d'entrée n'apparaît que s'il est activé (il n'est plus imposé par la musique).
  const showEntry = media && mode === "public" && theme.entryScreen;
  const [entered, setEntered] = useState(!showEntry);

  // Sans écran d'entrée, la musique démarre à la première interaction avec la page.
  useEffect(() => {
    if (!player || showEntry) return;
    const start = () => {
      startAudio.current?.();
      cleanup();
    };
    const events = ["pointerdown", "keydown", "touchstart"] as const;
    const cleanup = () => events.forEach((e) => window.removeEventListener(e, start));
    events.forEach((e) => window.addEventListener(e, start, { once: true, passive: true }));
    return cleanup;
  }, [player, showEntry]);

  return (
    <EnteredContext.Provider value={entered}>
      <div
        ref={rootRef}
        className="lbu-page"
        style={{ ...style, ...(cursorImage ? { cursor: `url("${cursorImage}") 6 6, auto` } : {}) }}
        {...attrs}
        data-waiting={entered ? undefined : "true"}
      >
        {media && theme.bgVideoUrl && (
          <video
            className={`lbu-video ${fixed ? "fixed" : "absolute"}`}
            src={theme.bgVideoUrl}
            autoPlay
            muted
            loop
            playsInline
            preload="metadata"
            aria-hidden="true"
          />
        )}
        {effects && theme.particles !== "none" && <Particles kind={theme.particles} accent={theme.accent} accent2={theme.accent2} fixed={fixed} />}
        {effects && (theme.cursor === "glow" || theme.cursor === "trail") && <CursorEffect kind={theme.cursor} rootRef={rootRef} />}
        {effects && theme.tilt && <TiltCards rootRef={rootRef} />}
        {children}
        {player && (
          <AudioPlayer
            src={audioSrc}
            volume={theme.audioVolume}
            startRef={startAudio}
            position={theme.audioPlayer}
            live={radio ? { name: radio.name, nowPlaying: radio.nowPlaying } : null}
          />
        )}
        {showEntry && (
          <EntryScreen
            text={theme.entryText}
            onEnter={() => {
              setEntered(true);
              startAudio.current?.();
            }}
          />
        )}
      </div>
    </EnteredContext.Provider>
  );
}
