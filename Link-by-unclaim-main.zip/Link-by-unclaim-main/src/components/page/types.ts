import type { DiscordInvite } from "@/lib/discord-cdn";
import type { FeatureFlags } from "@/lib/features";
import type { NgCountry, NgProfile } from "@/lib/nationsglory-shared";
import type { OwnerProfile, PageContext, PageView } from "@/lib/page-schema";

/** Données externes préchargées côté serveur (évite un aller-retour au premier affichage). */
export type PageExtras = {
  ng?: Record<string, NgProfile>;
  countries?: Record<string, NgCountry>;
  invites?: Record<string, DiscordInvite>;
};

/** public : page réelle · preview : aperçu de l'éditeur · demo : vitrine statique de la landing. */
export type RenderMode = "public" | "preview" | "demo";

export type RenderContext = {
  page: PageView;
  owner: OwnerProfile;
  extras: PageExtras;
  mode: RenderMode;
  features: FeatureFlags;
  blockedDomains: string[];
};

export type { PageContext };

/** Clé de préchargement d'un profil NationsGlory (pseudo + serveurs). */
export const ngProfileKey = (username: string, servers: string[]) => `${username.toLowerCase()}@${servers.join(",")}`;

/** Clé de préchargement d'un pays NationsGlory (serveur + identifiant ou nom). */
export const ngCountryKey = (server: string, country: string) => `${server}:${country.trim().toLowerCase()}`;
