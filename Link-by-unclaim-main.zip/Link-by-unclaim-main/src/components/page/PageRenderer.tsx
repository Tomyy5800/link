import type { CSSProperties } from "react";
import { BadgeCheck, CalendarClock, Castle, Eye } from "lucide-react";
import type { AutomationBanner } from "@/lib/automations";
import type { PublicBadge } from "@/lib/badges";
import { BadgeList } from "@/components/badges/OfficialBadge";
import { isValidBirthday } from "@/lib/birthday";
import { DEFAULT_BLOCK_STYLE, isWithinSchedule, type Block } from "@/lib/blocks";
import { sanitizeCss, scopeCss } from "@/lib/css";
import { describeEmbed } from "@/lib/embeds";
import type { FeatureFlags } from "@/lib/features";
import type { OwnerProfile, PageContext, PageView } from "@/lib/page-schema";
import { backgroundStyle, googleFontsHref, themeVars, type Theme } from "@/lib/theme";
import { resolveRadio } from "@/lib/radio";
import { isValidMcUsername, parseDiscordInvite, toSafeHref, toSafeImageSrc } from "@/lib/urls";
import { DiscordLogo } from "@/components/icons/SocialIcon";
import { CellControls, type EditingHooks } from "./CellControls";
import { ClickTracker } from "./ClickTracker";
import { DiscordServerBlock } from "./blocks/DiscordServerBlock";
import { ContactBlock } from "./blocks/ContactBlock";
import { EmbedBlock } from "./blocks/EmbedBlock";
import { GameBlock } from "./blocks/GameBlock";
import { CopyBlock, CountdownBlock, GalleryBlock, PresenceBlock } from "./blocks/InteractiveBlocks";
import { CollectionBlock, EventsBlock, MusicBlock } from "./blocks/MoreBlocks";
import { NationsGloryBlock } from "./blocks/NationsGloryBlock";
import { RadioBlock } from "./blocks/RadioBlock";
import { NgCountryBlock } from "./blocks/NgCountryBlock";
import { ShopBlock } from "./blocks/ShopBlock";
import { SkinBlock } from "./blocks/SkinBlock";
import { Typewriter } from "./effects/Interactions";
import { PageShell } from "./PageShell";
import { AgeGate, ShareButton } from "./PageTools";
import { ReportButton } from "./ReportButton";
import { RichText } from "./RichText";
import {
  BadgesBlock,
  DiscordProfileBlock,
  DividerBlock,
  FaqBlock,
  HeadingBlock,
  ImageBlock,
  LinkBlock,
  SocialsBlock,
  TextBlock,
} from "./StaticBlocks";
import { ngCountryKey, ngProfileKey, type PageExtras, type RenderContext, type RenderMode } from "./types";

const nf = new Intl.NumberFormat("fr-FR");

const AVATAR_SHAPE: Record<Theme["avatarShape"], string> = {
  circle: "rounded-full",
  rounded: "rounded-[24%]",
  square: "rounded-none",
};
const AVATAR_PX: Record<Theme["avatarSize"], number> = { sm: 80, md: 112, lg: 144 };
const MAX_WIDTH: Record<Theme["width"], number> = { narrow: 560, wide: 920, full: 1200 };
const GAP: Record<Theme["gap"], string> = { sm: "8px", md: "12px", lg: "20px" };
const ROW: Record<Theme["rowHeight"], string> = { sm: "96px", md: "128px", lg: "168px" };

/** Réglages du thème ramenés à ce que le propriétaire a le droit d'utiliser. */
export function effectiveTheme(theme: Theme, features: FeatureFlags): Theme {
  return {
    ...theme,
    layout: features.advancedLayout ? theme.layout : "stack",
    ...(features.effects ? {} : { particles: "none", cursor: "default", nameAnimation: "none", bioTypewriter: false, tilt: false }),
    ...(features.backgroundMedia ? {} : { entryScreen: false, audioUrl: "", audioRadio: "", bgVideoUrl: "" }),
    ...(features.customFonts ? {} : { googleFont: "", googleHeadingFont: "" }),
  } as Theme;
}

export function avatarFor(page: PageView, owner: OwnerProfile): { src: string; pixelated: boolean } {
  const { profile } = page;
  if (profile.avatarSource === "custom") {
    const src = toSafeImageSrc(profile.avatarUrl);
    if (src) return { src, pixelated: false };
  }
  if (profile.avatarSource === "nationsglory" && profile.ngUsername) {
    return { src: `/api/skin/${encodeURIComponent(profile.ngUsername)}?type=face&size=128`, pixelated: true };
  }
  return { src: owner.avatarUrl, pixelated: false };
}

function Avatar({ page, theme, owner, overlap, frame }: { page: PageView; theme: Theme; owner: OwnerProfile; overlap: boolean; frame: string | null }) {
  const inner = <AvatarImage page={page} theme={theme} owner={owner} overlap={overlap && !frame} />;
  if (!frame) return inner;
  // Cadre de la boutique officielle (débloqué par le propriétaire, vérifié côté serveur).
  return (
    <span className={`lbu-frame ${AVATAR_SHAPE[theme.avatarShape]}`} data-frame={frame} title="Cadre de la boutique Unclaim">
      {inner}
    </span>
  );
}

function AvatarImage({ page, theme, owner, overlap }: { page: PageView; theme: Theme; owner: OwnerProfile; overlap: boolean }) {
  const avatar = avatarFor(page, owner);
  const size = AVATAR_PX[theme.avatarSize];
  const shape = AVATAR_SHAPE[theme.avatarShape];
  const ring: CSSProperties =
    theme.avatarRing === "accent"
      ? { boxShadow: "0 0 0 3px var(--lbu-accent)" }
      : theme.avatarRing === "glow"
        ? { boxShadow: "0 0 0 2px var(--lbu-accent), 0 0 32px var(--lbu-accent-glow)" }
        : theme.avatarRing === "none" && overlap
          ? { outline: "5px solid var(--lbu-card-border)" }
          : {};
  const img = (
    <img
      src={avatar.src}
      alt={`Avatar de ${page.profile.displayName}`}
      width={size}
      height={size}
      className={`block object-cover shadow-xl ${shape} ${avatar.pixelated ? "pixelated" : ""}`}
      style={{ width: size, height: size, background: owner.accentColor ?? theme.accent, ...ring }}
    />
  );
  if (theme.avatarRing !== "gradient") return img;
  return (
    <span className={`inline-block p-[3px] ${shape}`} style={{ background: "linear-gradient(135deg, var(--lbu-accent), var(--lbu-accent-2))" }}>
      {img}
    </span>
  );
}

function Banner({ page, owner, tall }: { page: PageView; owner: OwnerProfile; tall?: boolean }) {
  const banner = toSafeImageSrc(page.profile.bannerUrl) ?? owner.bannerUrl;
  return (
    <div
      className={`bg-cover bg-center ${tall ? "h-40 sm:h-48" : "h-28 sm:h-32"}`}
      style={{
        backgroundColor: "var(--lbu-accent)",
        backgroundImage: banner ? `url("${banner.replace(/"/g, "%22")}")` : "linear-gradient(135deg, var(--lbu-accent), var(--lbu-accent-2))",
      }}
      aria-hidden="true"
    />
  );
}

function NameText({ name, theme }: { name: string; theme: Theme }) {
  if (theme.nameAnimation === "typewriter") return <Typewriter text={name} speed={70} />;
  if (theme.nameAnimation === "wave") {
    return (
      <>
        {[...name].map((ch, i) => (
          <span key={i} className="lbu-wave" style={{ "--i": i } as CSSProperties}>
            {ch === " " ? " " : ch}
          </span>
        ))}
      </>
    );
  }
  return <>{name}</>;
}

function ProfileHeader({
  page,
  theme,
  owner,
  verified,
  partner,
  badges,
  frame,
  inSidebar,
}: {
  page: PageView;
  theme: Theme;
  owner: OwnerProfile;
  verified: boolean;
  partner: boolean;
  badges: PublicBadge[];
  frame: string | null;
  inSidebar: boolean;
}) {
  const { profile } = page;
  const layout = inSidebar && theme.headerLayout === "hero" ? "classic" : theme.headerLayout;
  const half = AVATAR_PX[theme.avatarSize] / 2;
  const left = layout === "left";
  const banner = theme.showBanner && layout !== "minimal";
  // Les badges « vérifié » et « partenaire » remplacent les anciennes mentions à côté du nom.
  const hasBadge = (key: string) => badges.some((b) => b.key === key);

  const text = (
    <>
      <h1
        className={`lbu-heading lbu-name mt-4 flex flex-wrap items-center gap-x-2 font-bold leading-tight tracking-tight break-words ${left ? "" : "justify-center"}`}
        data-effect={theme.nameEffect}
        data-anim={theme.nameAnimation}
        data-text={profile.displayName}
        style={{ fontSize: "calc(1.65em * var(--lbu-heading-scale, 1))" }}
      >
        <span className="lbu-name-text" data-text={profile.displayName}>
          <NameText name={profile.displayName} theme={theme} />
        </span>
        {verified && (
          <span title="Compte vérifié par Link by Unclaim" className="inline-flex" style={{ color: "var(--lbu-accent-ink)" }}>
            <BadgeCheck size={22} aria-label="Compte vérifié" />
          </span>
        )}
        {partner && !hasBadge("partenaire") && (
          <span
            title="Partenaire officiel de Link by Unclaim"
            className="lbu-chip !px-2 !py-0.5 font-semibold tracking-wide uppercase"
            style={{ fontSize: "0.4em", color: "var(--lbu-accent-ink)" }}
          >
            Partenaire
          </span>
        )}
      </h1>
      {profile.pronouns && <p className="lbu-muted mt-0.5 text-[0.85em]">{profile.pronouns}</p>}
      {badges.length > 0 && (
        <BadgeList badges={badges.filter((b) => b.key !== "verifie" || !verified)} variant="page" className={`mt-3 ${left ? "" : "justify-center"}`} />
      )}
      {theme.showBadges && (owner.discordUsername || profile.ngUsername) && (
        <div className={`mt-3 flex flex-wrap gap-1.5 ${left ? "" : "justify-center"}`}>
          {owner.discordUsername && (
            <span className="lbu-chip">
              <DiscordLogo size={13} /> {owner.discordUsername}
            </span>
          )}
          {profile.ngUsername && (
            <span className="lbu-chip">
              <Castle size={13} aria-hidden="true" /> {profile.ngUsername}
              {owner.ngAccount?.toLowerCase() === profile.ngUsername.toLowerCase() && (
                <span title="Compte NationsGlory vérifié par une connexion NationsGlory" className="inline-flex" style={{ color: "var(--lbu-accent-ink)" }}>
                  <BadgeCheck size={13} aria-label="Compte NationsGlory vérifié" />
                </span>
              )}
            </span>
          )}
        </div>
      )}
      {profile.bio.trim() && (
        <div className={`mt-4 max-w-prose text-[0.95em] ${left ? "" : "mx-auto"}`}>
          {theme.bioTypewriter ? <Typewriter text={profile.bio} rich /> : <RichText text={profile.bio} />}
        </div>
      )}
    </>
  );

  if (layout === "minimal" || layout === "hero") {
    return (
      <header className="text-center">
        {layout === "hero" && theme.showBanner && (
          <div className="overflow-hidden" style={{ borderRadius: "var(--lbu-card-radius)" }}>
            <Banner page={page} owner={owner} tall />
          </div>
        )}
        <div className="flex justify-center" style={{ marginTop: layout === "hero" && theme.showBanner ? -half : 8 }}>
          <Avatar page={page} theme={theme} owner={owner} overlap={false} frame={frame} />
        </div>
        <div className="px-2 pb-2">{text}</div>
      </header>
    );
  }

  return (
    <header className={`lbu-card overflow-hidden ${left ? "text-left" : "text-center"}`}>
      {banner && <Banner page={page} owner={owner} />}
      <div className="px-5 pb-6" style={{ paddingTop: banner ? 0 : 28 }}>
        <div className={`flex ${left ? "justify-start" : "justify-center"}`} style={{ marginTop: banner ? -half : 0 }}>
          <Avatar page={page} theme={theme} owner={owner} overlap={banner} frame={frame} />
        </div>
        {text}
      </div>
    </header>
  );
}

/** Un bloc incomplet ou non autorisé n'apparaît que dans l'aperçu de l'éditeur. */
function hasContent(block: Block, page: PageView, ctx: RenderContext): boolean {
  switch (block.type) {
    case "heading":
    case "text":
      return block.data.text.trim() !== "";
    case "link":
      return toSafeHref(block.data.url) !== null;
    case "socials":
      return block.data.items.some((item) => toSafeHref(item.url) !== null);
    case "image":
      return toSafeImageSrc(block.data.url) !== null;
    case "discordServer":
      return parseDiscordInvite(block.data.invite) !== null;
    case "nationsglory":
    case "skin":
      return isValidMcUsername(block.data.username || page.profile.ngUsername);
    case "embed": {
      const kind = describeEmbed(block.data, { iframe: ctx.features.customEmbeds, html: ctx.features.htmlWidgets }, ctx.blockedDomains).kind;
      return kind === "frame" || kind === "html";
    }
    case "countdown":
      if (block.data.mode === "birthday") return isValidBirthday(block.data.birthday);
      return block.data.target !== "" && !Number.isNaN(Date.parse(block.data.target));
    case "gallery":
      return block.data.images.some((img) => toSafeImageSrc(img.url) !== null);
    case "faq":
      return block.data.items.some((item) => item.question.trim() !== "");
    case "badges":
      return block.data.items.some((item) => item.trim() !== "");
    case "copy":
      return block.data.value.trim() !== "";
    case "ngCountry":
      return (block.data.countryId || block.data.country).trim() !== "";
    case "discordPresence":
      return ctx.features.presence && Boolean(ctx.owner.discordId);
    case "radio":
      return resolveRadio(block.data.station) !== null;
    case "music":
      return block.data.links.some((l) => toSafeHref(l.url) !== null);
    case "events": {
      const now = Date.now();
      return block.data.items.some((i) => {
        const start = Date.parse(i.start);
        if (!i.title.trim() || Number.isNaN(start)) return false;
        const end = i.end ? Date.parse(i.end) : start + 60 * 60 * 1000;
        return !block.data.hidePast || end > now;
      });
    }
    case "collection":
      return block.data.links.some((l) => l.label.trim() !== "" && toSafeHref(l.url) !== null);
    case "discord":
      return Boolean(ctx.owner.discordId);
    case "game":
      return block.data.username.trim() !== "";
    case "shop":
      return ctx.features.shop && block.data.products.some((p) => p.name.trim() !== "");
    case "contact":
    case "divider":
      return true;
  }
}

function BlockView({ block, ctx, compact, premiumName }: { block: Block; ctx: RenderContext; compact: boolean; premiumName: string }) {
  const { page, owner, extras, mode, features } = ctx;
  const live = mode !== "demo";
  const preview = mode === "preview";
  switch (block.type) {
    case "heading":
      return <HeadingBlock data={block.data} />;
    case "text":
      return <TextBlock data={block.data} />;
    case "link":
      return <LinkBlock data={block.data} theme={page.theme} blockId={block.id} />;
    case "socials":
      return <SocialsBlock data={block.data} blockId={block.id} />;
    case "image":
      return <ImageBlock data={block.data} blockId={block.id} />;
    case "divider":
      return <DividerBlock data={block.data} />;
    case "faq":
      return <FaqBlock data={block.data} />;
    case "badges":
      return <BadgesBlock data={block.data} />;
    case "discord":
      if (!owner.discordId) return preview ? <NeedsDiscord what="ton profil Discord" /> : null;
      return <DiscordProfileBlock data={block.data} owner={owner} theme={page.theme} blockId={block.id} />;
    case "discordServer": {
      const code = parseDiscordInvite(block.data.invite);
      return (
        <DiscordServerBlock data={block.data} initial={code ? extras.invites?.[code] : undefined} live={live} fill={page.theme.buttonFill} blockId={block.id} />
      );
    }
    case "nationsglory": {
      const username = block.data.username || page.profile.ngUsername;
      const servers = block.data.servers.length ? block.data.servers : [page.profile.ngServer];
      return (
        <NationsGloryBlock
          data={block.data}
          username={username}
          servers={servers}
          initial={extras.ng?.[ngProfileKey(username, servers)]}
          live={live}
          preview={preview}
          compact={compact}
        />
      );
    }
    case "ngCountry":
      return (
        <NgCountryBlock
          data={block.data}
          initial={extras.countries?.[ngCountryKey(block.data.server, block.data.countryId || block.data.country)]}
          live={live}
          preview={preview}
        />
      );
    case "skin":
      return <SkinBlock data={block.data} username={block.data.username || page.profile.ngUsername} compact={compact} />;
    case "embed":
      return (
        <EmbedBlock
          data={block.data}
          allowIframe={features.customEmbeds}
          allowHtml={features.htmlWidgets}
          blockedDomains={ctx.blockedDomains}
          preview={preview}
          premiumName={premiumName}
        />
      );
    case "countdown":
      return <CountdownBlock data={block.data} />;
    case "gallery":
      return <GalleryBlock data={block.data} />;
    case "copy":
      return <CopyBlock data={block.data} />;
    case "discordPresence":
      if (!features.presence) return null;
      if (!owner.discordId) return preview ? <NeedsDiscord what="ton statut Discord" /> : null;
      return (
        <PresenceBlock data={block.data} discordId={owner.discordId} username={owner.discordUsername ?? owner.globalName ?? "toi"} live={live} preview={preview} />
      );
    case "radio":
      return <RadioBlock data={block.data} live={live} />;
    case "music":
      return <MusicBlock data={block.data} blockId={block.id} />;
    case "events":
      return <EventsBlock data={block.data} blockId={block.id} />;
    case "collection":
      return <CollectionBlock data={block.data} blockId={block.id} fill={page.theme.buttonFill} />;
    case "game":
      return <GameBlock data={block.data} blockId={block.id} preview={mode === "preview"} />;
    case "contact":
      return <ContactBlock data={block.data} blockId={block.id} slug={page.slug} live={mode === "public"} />;
    case "shop":
      if (!features.shop) {
        // Aperçu de l'éditeur : la boutique existe mais n'est pas visible (boutiques fermées ou formule).
        return preview ? (
          <div className="lbu-card flex items-center gap-3 p-4 text-[0.85em] lbu-muted">
            Boutique en pause : elle est conservée mais n&apos;apparaît pas sur ta page publique pour l&apos;instant.
          </div>
        ) : null;
      }
      return <ShopBlock data={block.data} blockId={block.id} slug={page.slug} seller={page.profile.displayName} live={mode === "public"} />;
  }
}

/** Aperçu de l'éditeur : bloc Discord sur un compte sans identité Discord rattachée. */
function NeedsDiscord({ what }: { what: string }) {
  return (
    <div className="lbu-card flex items-center gap-3 p-4 text-[0.85em] lbu-muted">
      <DiscordLogo size={18} />
      <span>
        Pour afficher {what}, rattache un compte Discord à ton compte Unclaim (Mon espace › Compte). Ce bloc reste masqué en attendant.
      </span>
    </div>
  );
}

function scheduleLabel(block: Block): string {
  // Fuseau fixe : l'aperçu de l'éditeur est rendu côté serveur puis hydraté, le texte doit être le même des deux côtés.
  const fmt = (iso: string) => new Date(iso).toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short", timeZone: "Europe/Paris" });
  if (block.startsAt && block.endsAt) return `Du ${fmt(block.startsAt)} au ${fmt(block.endsAt)}`;
  if (block.startsAt) return `À partir du ${fmt(block.startsAt)}`;
  return `Jusqu'au ${fmt(block.endsAt!)}`;
}

/** Colonnes occupées sur ordinateur (bornées par la grille). */
export function desktopSpan(block: Pick<Block, "colSpan" | "width">, columns: number): number {
  const fallback = block.width === "half" ? Math.max(1, Math.floor(columns / 2)) : columns;
  return Math.min(columns, Math.max(1, block.colSpan ?? fallback));
}

/** Bandeaux posés par les automatisations, en haut de la page. */
function Banners({ banners, mode }: { banners: AutomationBanner[]; mode: RenderMode }) {
  if (!banners.length) return null;
  return (
    <div className="lbu-cell lbu-cell--header flex flex-col gap-2" role="region" aria-label="Annonces">
      {banners.map((b) => {
        const content = (
          <>
            {b.style === "live" && <span className="lbu-banner-dot" aria-hidden="true" />}
            <span className="min-w-0 flex-1">{b.text}</span>
            {b.url && <span className="lbu-banner-go" aria-hidden="true">→</span>}
          </>
        );
        return b.url ? (
          <a key={b.id} href={b.url} target="_blank" rel="noopener noreferrer" className="lbu-banner" data-style={b.style} tabIndex={mode === "demo" ? -1 : undefined}>
            {content}
          </a>
        ) : (
          <p key={b.id} className="lbu-banner" data-style={b.style}>
            {content}
          </p>
        );
      })}
    </div>
  );
}

type Props = {
  page: PageView;
  owner: OwnerProfile;
  context: PageContext;
  /** Bandeaux des automatisations actives. */
  banners?: AutomationBanner[];
  extras?: PageExtras;
  mode: RenderMode;
  /** Masque le pied de page (aperçu compact de la landing). */
  bare?: boolean;
  premiumName?: string;
  /** Aperçu de l'éditeur : sélection et redimensionnement des blocs. */
  editing?: EditingHooks;
  /** Adresse du site, pour les liens absolus quand la page est servie sur un domaine personnel. */
  siteUrl?: string;
};

/** Rendu complet d'une page Link by Unclaim (publique, aperçu de l'éditeur ou démo). */
export function PageRenderer({ page, owner, context, banners = [], extras = {}, mode, bare, premiumName = "Link+", editing, siteUrl }: Props) {
  const { features } = context;
  const theme = effectiveTheme(page.theme, features);
  const ctx: RenderContext = { page, owner, extras, mode, features, blockedDomains: context.blockedDomains };
  const now = Date.now();
  const columns = theme.layout === "stack" ? 2 : theme.columns;
  const blocks = page.blocks
    .map((b) => ({
      ...b,
      style: features.blockStyles ? b.style : DEFAULT_BLOCK_STYLE,
      ...(features.scheduling ? {} : { startsAt: null, endsAt: null }),
    }))
    .filter((b) => b.visible && (mode === "preview" || (hasContent(b, page, ctx) && isWithinSchedule(b, now))));
  const imageBg = theme.bgType === "image" && theme.bgImage;
  const css = features.customCss && page.customCss ? sanitizeCss(page.customCss) : null;
  const sidebar = theme.layout === "sidebar";
  const fontsHref = googleFontsHref(theme);

  const cells = blocks.map((block, i) => {
    const span = desktopSpan(block, columns);
    const rows = theme.layout === "stack" ? 1 : block.rowSpan;
    const scheduled = mode === "preview" && (block.startsAt || block.endsAt);
    const outside = scheduled && !isWithinSchedule(block, now);
    const st = block.style;
    return (
      <div
        key={block.id}
        className={`lbu-cell ${outside ? "opacity-50" : ""} ${editing?.selectedId === block.id ? "lbu-cell--selected" : ""}`}
        data-type={block.type}
        data-block={block.id}
        data-surface={st.surface}
        data-align={st.align}
        data-valign={st.valign}
        data-hide={st.hideOn}
        data-text={st.text ? "custom" : undefined}
        style={
          {
            "--m-span": block.width === "half" ? 1 : 2,
            "--d-span": span,
            "--d-rows": rows,
            "--cell-bg": st.color,
            ...(st.text ? { "--cell-text": st.text } : {}),
            animationDelay: `${Math.min(i + 1, 12) * 45}ms`,
          } as CSSProperties
        }
      >
        {scheduled && (
          <span
            className="absolute -top-2 left-2 z-10 inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-semibold"
            style={{ background: "var(--lbu-accent)", color: "var(--lbu-on-accent)" }}
            title={scheduleLabel(block)}
          >
            <CalendarClock size={11} aria-hidden="true" /> {outside ? "Programmé" : "En cours"}
          </span>
        )}
        {editing && <CellControls id={block.id} span={span} rows={rows} editing={editing} />}
        <BlockView block={block} ctx={ctx} compact={block.width === "half" || span === 1} premiumName={premiumName} />
      </div>
    );
  });

  const frame = theme.avatarFrame !== "none" && context.frames?.includes(theme.avatarFrame) ? theme.avatarFrame : null;
  const header = (
    <ProfileHeader
      page={page}
      theme={theme}
      owner={owner}
      verified={context.verified}
      partner={Boolean(context.partner)}
      badges={context.badges ?? []}
      frame={frame}
      inSidebar={sidebar}
    />
  );

  return (
    <PageShell
      theme={theme}
      mode={mode}
      effects={features.effects}
      media={features.backgroundMedia}
      style={
        {
          ...themeVars(theme),
          "--lbu-cols": columns,
          "--lbu-gap": GAP[theme.gap],
          "--lbu-row": ROW[theme.rowHeight],
          "--lbu-max": `${theme.layout === "stack" ? Math.min(MAX_WIDTH[theme.width], MAX_WIDTH.wide) : Math.max(MAX_WIDTH[theme.width], MAX_WIDTH.wide)}px`,
        } as CSSProperties
      }
      attrs={{
        "data-mode": mode,
        "data-page": page.slug,
        "data-layout": theme.layout,
        "data-hover": theme.buttonHover,
        "data-btn-align": theme.buttonAlign,
        "data-anim": theme.animation,
        ...(editing ? { "data-editing": "true" } : {}),
      }}
    >
      <div className="lbu-bg" style={{ ...backgroundStyle(theme), ...(imageBg && theme.bgBlur ? { filter: `blur(${theme.bgBlur}px)`, transform: "scale(1.06)" } : {}) }} aria-hidden="true" />
      {imageBg && <div className="lbu-dim" style={{ background: `rgba(0,0,0,${theme.bgDim / 100})` }} aria-hidden="true" />}
      {theme.bgEffect !== "none" && <div className="lbu-fx" data-fx={theme.bgEffect} aria-hidden="true" />}

      <main className={`lbu-main relative ${mode === "preview" ? "py-8" : "py-10 sm:py-14"}`}>
        {sidebar ? (
          <div className="lbu-sidebar-wrap">
            <aside className="lbu-side">{header}</aside>
            <div className="lbu-grid lbu-enter">
              <Banners banners={banners} mode={mode} />
              {cells}
            </div>
          </div>
        ) : (
          <div className="lbu-grid lbu-enter">
            <Banners banners={banners} mode={mode} />
            <div className="lbu-cell lbu-cell--header">{header}</div>
            {cells}
          </div>
        )}

        {!bare && (
          <footer className="mt-10 flex flex-col items-center gap-2 text-[0.78em] lbu-muted">
            {theme.showViews && page.views > 0 && (
              <span className="inline-flex items-center gap-1.5">
                <Eye size={14} aria-hidden="true" /> {nf.format(page.views)} vue{page.views > 1 ? "s" : ""}
              </span>
            )}
            <span className="inline-flex items-center gap-3">
              {!features.removeBranding && (
                <a href={siteUrl ? `${siteUrl}/` : "/"} className="font-semibold opacity-80 transition-opacity hover:opacity-100" target={mode === "preview" ? "_blank" : undefined}>
                  Link <span className="font-normal opacity-70">by</span> Unclaim
                </a>
              )}
              {mode === "public" && <ReportButton slug={page.slug} />}
            </span>
          </footer>
        )}
      </main>
      {mode === "public" && <ClickTracker slug={page.slug} />}
      {mode === "public" && page.options.shareButton && <ShareButton title={page.options.seoTitle || page.profile.displayName} />}
      {mode === "public" && page.options.ageGate && <AgeGate slug={page.slug} />}
      {fontsHref && <link rel="stylesheet" href={fontsHref} precedence="default" />}
      {css?.ok && css.css && <style dangerouslySetInnerHTML={{ __html: scopeCss(css.css, `.lbu-page[data-page="${page.slug}"]`) }} />}
    </PageShell>
  );
}
