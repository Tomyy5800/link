import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { cache } from "react";
import { Lock, Pencil, ShieldAlert } from "lucide-react";
import { Logo } from "@/components/brand/Logo";
import { PageRenderer } from "@/components/page/PageRenderer";
import { ViewBeacon } from "@/components/page/ViewBeacon";
import { toOwnerProfile } from "@/lib/discord-cdn";
import { applyAutomations, type AutomationBanner } from "@/lib/automations";
import { activeRedirect } from "@/lib/page-schema";
import { publicBadgesOf } from "@/lib/server/badges";
import { prisma } from "@/lib/server/db";
import { pageContextFrom, suspension } from "@/lib/server/entitlements";
import { env } from "@/lib/server/env";
import { framesOf } from "@/lib/server/official-shop";
import { getPageBySlug } from "@/lib/server/pages";
import { loadPageExtras } from "@/lib/server/prefetch";
import { getPresence } from "@/lib/server/presence";
import { getSettings } from "@/lib/server/settings";
import { getCurrentUser } from "@/lib/server/unclaim-auth";
import { syncFromUnclaim } from "@/lib/server/unclaim-auth/sync";
import { plainText } from "@/lib/text";

// Page publique, partagée par /<adresse>, /profil/<adresse> et les domaines personnels.

export const loadPublicPage = cache(async (slug: string) => {
  const data = await getPageBySlug(slug);
  if (!data) return null;
  // Profil Discord resynchronisé depuis Unclaim Auth s'il date de plus de 6 h.
  const user = await syncFromUnclaim(data.user);
  // Un compte bloqué dans Unclaim Auth n'a plus de page publique.
  if (user.banned) return null;
  return { ...data, user, owner: toOwnerProfile(user), suspended: suspension(user, data) };
});

export type PublicPageData = NonNullable<Awaited<ReturnType<typeof loadPublicPage>>>;

/** Métadonnées (titre, aperçu de lien). `domain` : page servie sur un domaine personnel. */
export function publicMetadata(data: PublicPageData | null, opts: { domain?: string } = {}): Metadata {
  if (!data || !data.page.published) return { title: "Page introuvable", robots: { index: false, follow: false } };
  if (data.suspended) return { title: "Page suspendue", robots: { index: false, follow: false } };
  const { page } = data;
  const title = page.options.seoTitle || page.profile.displayName;
  const description = page.options.seoDescription || plainText(page.profile.bio).slice(0, 200) || `La page de ${title} sur Link by Unclaim.`;
  const canonical = opts.domain ? `https://${opts.domain}/` : `/${page.slug}`;
  return {
    title: opts.domain ? { absolute: title } : title,
    description,
    ...(page.options.noindex || page.options.ageGate ? { robots: { index: false, follow: false } } : {}),
    alternates: { canonical },
    openGraph: { title, description, type: "profile", url: canonical, siteName: "Link by Unclaim", locale: "fr_FR" },
    twitter: { card: "summary_large_image", title, description },
  };
}

function SuspendedNotice({ isOwner, reason, scope }: { isOwner: boolean; reason: string; scope: "account" | "page" }) {
  return (
    <div className="bg-hud flex min-h-screen flex-col items-center justify-center gap-6 px-4 text-center">
      <Logo />
      <div className="max-w-md">
        <p className="inline-flex items-center gap-2 font-mono text-sm tracking-[0.14em] text-claim">
          <ShieldAlert size={15} aria-hidden="true" /> PAGE SUSPENDUE
        </p>
        <h1 className="mt-2 font-display text-2xl font-bold">Cette page n&apos;est pas disponible</h1>
        <p className="mt-2 text-ink-300">
          {isOwner
            ? scope === "account"
              ? "Ton compte a été suspendu par la modération de Link by Unclaim."
              : "Ta page a été suspendue par la modération de Link by Unclaim."
            : "Elle a été suspendue par la modération de Link by Unclaim."}
        </p>
        {isOwner && reason && (
          <p className="mt-4 rounded-md border border-ink-600 bg-ink-900/70 px-4 py-3 text-left text-sm text-ink-200">
            <span className="hud-label mb-1 block">Motif</span>
            {reason}
          </p>
        )}
      </div>
      <Link href={isOwner ? "/dashboard" : "/"} className="rounded-md border border-ink-500 px-5 py-2.5 font-semibold text-ink-200 transition hover:border-ink-300">
        {isOwner ? "Retour à l'éditeur" : "Accueil"}
      </Link>
    </div>
  );
}

/** Rendu complet d'une page publique (null : rien à afficher, l'appelant répond 404). */
export async function PublicPageView({ data, domain }: { data: PublicPageData; domain?: string }) {
  // Sur un domaine personnel, aucune session n'existe : la page est toujours vue comme un visiteur.
  const viewer = domain ? null : await getCurrentUser();

  // Propriétaire et collaborateurs : page privée visible, redirection et statistiques ignorées.
  const isOwner =
    viewer?.id === data.user.id ||
    (viewer ? Boolean(await prisma.pageMember.findUnique({ where: { pageId_userId: { pageId: data.pageId, userId: viewer.id } }, select: { id: true } })) : false);
  if (data.suspended) return <SuspendedNotice isOwner={isOwner} reason={data.suspended.reason} scope={data.suspended.scope} />;

  const settings = await getSettings();
  const [badges, frames] = await Promise.all([publicBadgesOf(data.user), framesOf(data.user)]);
  const context = { ...pageContextFrom(data.user, settings), badges, frames };

  // Redirection temporaire (Link+) : les visiteurs partent directement vers l'adresse choisie.
  const redirectTo = context.features.redirect ? activeRedirect(data.page.options) : null;
  if (redirectTo && !isOwner && data.page.published) redirect(redirectTo);

  // Automatisations : évaluées ici, à l'heure de la page ; les règles ne partent jamais au navigateur.
  let page = data.page;
  let banners: AutomationBanner[] = [];
  const rules = context.features.automations ? data.page.options.automations.filter((r) => r.enabled) : [];
  if (rules.length) {
    const watchesLive = rules.some((r) => r.trigger.type === "live") && data.owner.discordId;
    const presence = watchesLive ? await getPresence(data.owner.discordId!).catch(() => null) : null;
    const result = applyAutomations(data.page, rules, {
      now: new Date(),
      timeZone: data.page.options.timezone,
      live: { on: Boolean(presence?.streaming), url: presence?.streaming?.url ?? null },
    });
    page = result.page;
    banners = result.banners;
  }
  page = { ...page, options: { ...page.options, automations: [] } };

  const extras = await loadPageExtras(page);

  return (
    <>
      {!data.page.published && (
        <div className="fixed inset-x-0 top-0 z-50 flex items-center justify-center gap-2 bg-ink-900/90 px-4 py-2 text-sm text-ink-200 backdrop-blur">
          <Lock size={14} aria-hidden="true" /> Page privée : elle n&apos;est visible que par toi et ton équipe.
        </div>
      )}

      {redirectTo && isOwner && (
        <div className="fixed inset-x-0 top-0 z-50 flex items-center justify-center gap-2 bg-claim px-4 py-2 text-sm font-medium text-ink-950">
          Redirection active : tes visiteurs sont envoyés vers {new URL(redirectTo).host}. Toi et ton équipe voyez la page.
        </div>
      )}

      <PageRenderer
        page={page}
        owner={data.owner}
        context={context}
        banners={banners}
        extras={extras}
        mode="public"
        premiumName={settings.premiumName}
        siteUrl={domain ? env.appUrl : undefined}
      />

      {data.page.published && !isOwner && <ViewBeacon slug={data.page.slug} />}

      {isOwner && (
        <Link
          href={`/dashboard/pages/${data.pageId}`}
          className={`fixed left-4 z-50 inline-flex items-center gap-2 rounded-full bg-ink-100 px-4 py-2.5 text-sm font-semibold text-ink-950 shadow-2xl shadow-black/40 transition hover:bg-white ${data.page.published && !redirectTo ? "top-4" : "top-14"}`}
        >
          <Pencil size={15} aria-hidden="true" /> Modifier la page
        </Link>
      )}
    </>
  );
}

/** Le compte connecté peut-il voir cette page privée ? */
export async function canViewPrivate(data: PublicPageData): Promise<boolean> {
  const viewer = await getCurrentUser();
  if (!viewer) return false;
  if (viewer.id === data.user.id) return true;
  return Boolean(await prisma.pageMember.findUnique({ where: { pageId_userId: { pageId: data.pageId, userId: viewer.id } }, select: { id: true } }));
}
