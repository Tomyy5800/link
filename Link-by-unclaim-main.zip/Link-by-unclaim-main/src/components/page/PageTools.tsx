"use client";

import { useEffect, useRef, useState } from "react";
import { Check, Copy, Download, QrCode, Share2, ShieldAlert, X } from "lucide-react";
import { SocialIcon } from "@/components/icons/SocialIcon";

/** Destinations de partage rapide (ouvertes dans un nouvel onglet). */
const SHARE_TARGETS: { key: "x" | "whatsapp" | "telegram" | "facebook" | "reddit"; label: string; color: string; href: (url: string, text: string) => string }[] = [
  { key: "whatsapp", label: "WhatsApp", color: "#25D366", href: (u, t) => `https://wa.me/?text=${encodeURIComponent(`${t} ${u}`)}` },
  { key: "x", label: "X", color: "#f8fafc", href: (u, t) => `https://x.com/intent/post?url=${encodeURIComponent(u)}&text=${encodeURIComponent(t)}` },
  { key: "telegram", label: "Telegram", color: "#26A5E4", href: (u, t) => `https://t.me/share/url?url=${encodeURIComponent(u)}&text=${encodeURIComponent(t)}` },
  { key: "facebook", label: "Facebook", color: "#0866FF", href: (u) => `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(u)}` },
  { key: "reddit", label: "Reddit", color: "#FF4500", href: (u, t) => `https://www.reddit.com/submit?url=${encodeURIComponent(u)}&title=${encodeURIComponent(t)}` },
];

/**
 * Bouton « Partager » : partage natif sur téléphone ; sinon une fenêtre avec le QR code (à
 * télécharger), le lien à copier et le partage en un clic vers les réseaux.
 */
export function ShareButton({ title }: { title: string }) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const [qr, setQr] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [url, setUrl] = useState("");

  async function share() {
    const current = window.location.href.split("#")[0];
    setUrl(current);
    if (navigator.share && window.matchMedia("(pointer: coarse)").matches) {
      await navigator.share({ title, url: current }).catch(() => undefined);
      return;
    }
    dialogRef.current?.showModal();
    if (!qr) {
      const QRCode = (await import("qrcode")).default;
      setQr(await QRCode.toDataURL(current, { margin: 1, width: 440, color: { dark: "#020618", light: "#ffffff" } }));
    }
  }

  const copy = () =>
    void navigator.clipboard.writeText(url).then(() => {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    });

  const display = url.replace(/^https?:\/\//, "");

  return (
    <>
      <button
        type="button"
        onClick={share}
        className="lbu-icon-btn lbu-share-btn fixed top-4 right-4 z-40 !h-10 !w-10 shadow-lg backdrop-blur"
        aria-label="Partager cette page"
        title="Partager"
      >
        <Share2 size={17} />
      </button>
      <dialog
        ref={dialogRef}
        className="lbu-share-sheet m-auto mb-0 w-full max-w-none rounded-t-2xl border border-white/10 bg-[#0b1224] p-0 text-[15px] text-slate-100 backdrop:bg-black/70 backdrop:backdrop-blur-sm sm:mb-auto sm:w-[min(92vw,380px)] sm:rounded-2xl"
        aria-label="Partager"
        onClick={(event) => event.target === dialogRef.current && dialogRef.current?.close()}
      >
        <div className="p-5">
          <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-white/20 sm:hidden" aria-hidden="true" />
          <div className="flex items-center justify-between">
            <div className="min-w-0">
              <p className="font-semibold">Partager</p>
              <p className="truncate text-xs text-slate-400">{title}</p>
            </div>
            <button type="button" onClick={() => dialogRef.current?.close()} className="rounded-md p-1.5 text-slate-400 transition hover:bg-white/10 hover:text-white" aria-label="Fermer">
              <X size={16} />
            </button>
          </div>

          <div className="relative mx-auto mt-4 h-[200px] w-[200px] overflow-hidden rounded-xl bg-white p-2 shadow-[0_0_40px_-10px_rgba(34,201,232,0.6)]">
            {qr ? (
              <img src={qr} alt="QR code de la page" width={184} height={184} className="lbu-share-qr h-full w-full" />
            ) : (
              <span className="flex h-full w-full items-center justify-center">
                <QrCode size={40} className="animate-pulse text-slate-400" />
              </span>
            )}
          </div>
          {qr && (
            <a href={qr} download="qr-code.png" className="mx-auto mt-2 flex w-fit items-center gap-1.5 text-xs text-slate-400 underline-offset-4 hover:text-white hover:underline">
              <Download size={13} /> Télécharger le QR code
            </a>
          )}

          <div className="mt-4 flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 p-1.5 pl-3">
            <span className="min-w-0 flex-1 truncate font-mono text-xs text-slate-300">{display}</span>
            <button
              type="button"
              onClick={copy}
              className={`inline-flex shrink-0 items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-semibold transition-colors ${
                copied ? "bg-[#00bc7d] text-white" : "bg-[#22c9e8] text-[#021018] hover:brightness-110"
              }`}
            >
              {copied ? <Check size={14} /> : <Copy size={14} />} {copied ? "Copié !" : "Copier"}
            </button>
          </div>

          <ul className="mt-4 grid grid-cols-5 gap-2">
            {SHARE_TARGETS.map((target) => (
              <li key={target.key}>
                <a
                  href={url ? target.href(url, title) : "#"}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex flex-col items-center gap-1.5 text-[11px] text-slate-400 transition hover:text-white"
                >
                  <span
                    className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-white/5 transition-colors duration-200 group-hover:border-white/25 group-hover:bg-white/10"
                    style={{ color: target.color }}
                  >
                    <SocialIcon platform={target.key} size={20} />
                  </span>
                  {target.label}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </dialog>
    </>
  );
}

/** Avertissement « réservé aux 18 ans et plus », mémorisé le temps de la visite. */
export function AgeGate({ slug }: { slug: string }) {
  const key = `lbu:age:${slug}`;
  const [open, setOpen] = useState(true);
  useEffect(() => {
    try {
      if (sessionStorage.getItem(key)) setOpen(false);
    } catch {
      // stockage indisponible : l'avertissement reste affiché
    }
  }, [key]);
  useEffect(() => {
    if (!open) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, [open]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/85 p-4 backdrop-blur-xl" role="dialog" aria-modal="true" aria-labelledby="age-title">
      <div className="w-full max-w-sm rounded-xl border border-white/10 bg-[#0f172b] p-6 text-center font-sans text-slate-100">
        <ShieldAlert size={32} className="mx-auto text-amber-300" aria-hidden="true" />
        <p id="age-title" className="mt-3 text-lg font-semibold">
          Contenu réservé aux adultes
        </p>
        <p className="mt-2 text-sm text-slate-300">Cette page peut contenir du contenu réservé aux personnes de 18 ans et plus.</p>
        <div className="mt-5 grid gap-2">
          <button
            type="button"
            autoFocus
            onClick={() => {
              try {
                sessionStorage.setItem(key, "1");
              } catch {
                // sans stockage, la confirmation vaut pour cet affichage
              }
              setOpen(false);
            }}
            className="rounded-md bg-[#22c9e8] px-3 py-2.5 text-sm font-semibold text-[#021018]"
          >
            J&apos;ai 18 ans ou plus
          </button>
          <a href="/" className="rounded-md border border-white/15 px-3 py-2.5 text-sm text-slate-300 hover:text-white">
            Quitter
          </a>
        </div>
      </div>
    </div>
  );
}
