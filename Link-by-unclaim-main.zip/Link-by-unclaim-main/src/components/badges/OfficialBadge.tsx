import type { CSSProperties } from "react";
import {
  BadgeCheck,
  Castle,
  Code,
  Crown,
  Flag,
  Flame,
  Gamepad2,
  Gavel,
  Gem,
  Handshake,
  Heart,
  Hourglass,
  Leaf,
  Moon,
  Music,
  Palette,
  Rocket,
  Shield,
  Sparkles,
  Star,
  Sun,
  Swords,
  Trophy,
  Zap,
  type LucideIcon,
} from "lucide-react";
import type { PublicBadge } from "@/lib/badges";

// Affichage des badges officiels (pages publiques, page staff, espace, administration).
// Composant sans état : ce qu'il montre (dont le sceau) vient toujours du serveur.

const ICONS: Record<string, LucideIcon> = {
  crown: Crown,
  shield: Shield,
  code: Code,
  gavel: Gavel,
  star: Star,
  handshake: Handshake,
  "badge-check": BadgeCheck,
  rocket: Rocket,
  hourglass: Hourglass,
  gem: Gem,
  sparkles: Sparkles,
  heart: Heart,
  flame: Flame,
  trophy: Trophy,
  zap: Zap,
  music: Music,
  gamepad: Gamepad2,
  palette: Palette,
  castle: Castle,
  swords: Swords,
  flag: Flag,
  leaf: Leaf,
  moon: Moon,
  sun: Sun,
};

export function BadgeIcon({ icon, size = 14, className }: { icon: string; size?: number; className?: string }) {
  const Icon = ICONS[icon] ?? Star;
  return <Icon size={size} className={className} aria-hidden="true" />;
}

/** Sceau « badge officiel validé » : distinct de la coche « compte vérifié ». */
export function OfficialSeal({ size = 12 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" className="ui-badge-seal shrink-0" role="img" aria-label="Badge officiel validé par Unclaim">
      <title>Badge officiel validé par Unclaim</title>
      <path d="M8 .8 9.9 2.3l2.4-.2.6 2.3 2.1 1.2-.9 2.2.9 2.2-2.1 1.2-.6 2.3-2.4-.2L8 15.2l-1.9-1.5-2.4.2-.6-2.3L1 10.4 1.9 8.2 1 6l2.1-1.2.6-2.3 2.4.2Z" fill="#ffc247" />
      <path d="m5.2 8.2 1.9 1.9 3.8-4" fill="none" stroke="#020618" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

type Variant = "page" | "app";

/**
 * Un badge : pastille colorée, nom, et sceau s'il est validé. `page` reprend le style de la page
 * publique (thème du propriétaire) ; `app` celui de l'interface Link by Unclaim.
 */
export function OfficialBadge({ badge, variant = "app", compact = false }: { badge: PublicBadge; variant?: Variant; compact?: boolean }) {
  const label = `${badge.name}${badge.description ? ` — ${badge.description}` : ""}${badge.validated ? " (badge officiel validé)" : ""}`;
  const style = { "--badge": badge.color } as CSSProperties;
  const icon = badge.imageUrl ? (
    <img src={badge.imageUrl} alt="" width={16} height={16} className="h-4 w-4 shrink-0 rounded-sm object-cover" />
  ) : (
    <BadgeIcon icon={badge.icon} size={compact ? 12 : 14} className="ui-badge-icon shrink-0" />
  );
  return (
    <span
      className={`ui-badge ${variant === "page" ? "lbu-chip ui-badge--page" : "ui-badge--app"} ${compact ? "ui-badge--compact" : ""}`}
      style={style}
      title={label}
      aria-label={label}
      tabIndex={0}
    >
      <span className="ui-badge-glyph">{icon}</span>
      {!compact && <span className="truncate">{badge.name}</span>}
      {badge.validated && <OfficialSeal size={compact ? 10 : 12} />}
    </span>
  );
}

export function BadgeList({ badges, variant = "app", compact, className = "" }: { badges: PublicBadge[]; variant?: Variant; compact?: boolean; className?: string }) {
  if (!badges.length) return null;
  return (
    <ul className={`flex flex-wrap gap-1.5 ${className}`} aria-label="Badges officiels">
      {badges.map((b) => (
        <li key={b.key} className="min-w-0">
          <OfficialBadge badge={b} variant={variant} compact={compact} />
        </li>
      ))}
    </ul>
  );
}
