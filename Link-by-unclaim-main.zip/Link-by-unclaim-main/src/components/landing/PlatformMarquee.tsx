import { SocialIcon } from "@/components/icons/SocialIcon";
import { BRAND_ICONS } from "@/components/icons/brand-paths";

const PLATFORMS = [
  "discord",
  "twitch",
  "youtube",
  "tiktok",
  "instagram",
  "x",
  "kick",
  "spotify",
  "steam",
  "bluesky",
  "threads",
  "reddit",
  "soundcloud",
  "github",
] as const satisfies readonly (keyof typeof BRAND_ICONS)[];

/** Couleur de marque lisible sur fond nuit (les logos noirs passent en clair). */
function brandColor(platform: (typeof PLATFORMS)[number]): string {
  const hex = BRAND_ICONS[platform].hex;
  return hex === "#000000" || hex === "#181717" ? "#f8fafc" : hex;
}

/** Bandeau des plateformes, en défilement continu (pause au survol). */
export function PlatformMarquee() {
  const row = (hidden: boolean) => (
    <ul className="ui-marquee-track gap-10" aria-hidden={hidden || undefined}>
      {PLATFORMS.map((platform) => (
        <li
          key={platform}
          className="group flex shrink-0 items-center gap-2.5 text-ink-500 transition-colors hover:text-[var(--brand)]"
          style={{ "--brand": brandColor(platform) } as React.CSSProperties}
        >
          <SocialIcon platform={platform} size={22} className="transition-transform duration-300 group-hover:scale-125" />
          <span className="font-display text-lg font-semibold">{BRAND_ICONS[platform].title}</span>
        </li>
      ))}
    </ul>
  );
  return (
    <div className="ui-marquee gap-10 py-2" style={{ "--gap": "2.5rem" } as React.CSSProperties}>
      {row(false)}
      {row(true)}
    </div>
  );
}
