"use client";

import { useEffect, useRef, useState } from "react";
import { ChunkField } from "./ChunkField";

const COLS = 38;
const ROWS = 22;
const AMBER = 0xffc247;
const SIGNAL = 0x22c9e8;

/** Relief de l'île : collines douces, bords sous l'eau (fonction déterministe, sans bruit aléatoire). */
function heightAt(col: number, row: number): number {
  const x = col - COLS / 2;
  const z = row - ROWS / 2;
  const hills = 0.5 + 0.5 * Math.sin(x * 0.33) * Math.cos(z * 0.41) + 0.35 * Math.sin((x + z) * 0.19) + 0.25 * Math.cos((x - z * 1.3) * 0.27);
  const edge = Math.max(0, 1 - Math.hypot(x / (COLS * 0.55), z / (ROWS * 0.62)) ** 2.2);
  return Math.max(0.12, 0.25 + hills * 1.9 * edge);
}

/** Couleur selon l'altitude : eaux profondes, plaines, hauteurs (palette nuit de la charte). */
function terrainColor(h: number): number {
  if (h < 0.35) return 0x0d3554;
  if (h < 0.8) return 0x1a5277;
  if (h < 1.3) return 0x23709a;
  if (h < 1.8) return 0x2f8fbb;
  return 0x6cc9e6;
}

/**
 * Fond 3D de la landing : un territoire en chunks qui ondule, se soulève sous le pointeur et se
 * revendique d'un clic (des territoires grandissent aussi tout seuls). three.js est chargé à la
 * demande ; en attendant, ou sans WebGL, la grille 2D (ChunkField) prend le relais. Rendu figé si
 * le visiteur a demandé moins d'animations, en pause hors de l'écran.
 */
export function VoxelTerritory({ className = "", hint = false }: { className?: string; hint?: boolean }) {
  const hostRef = useRef<HTMLDivElement>(null);
  const [ready, setReady] = useState(false);
  const [claims, setClaims] = useState(0);
  const claimRef = useRef(setClaims);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    let disposed = false;
    let cleanup = () => {};

    void (async () => {
      const THREE = await import("three");
      if (disposed) return;
      let renderer: InstanceType<typeof THREE.WebGLRenderer>;
      try {
        renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "low-power" });
      } catch {
        return; // pas de WebGL : la grille 2D reste affichée
      }
      const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
      renderer.setClearColor(0x000000, 0);
      const canvas = renderer.domElement;
      canvas.setAttribute("aria-hidden", "true");
      canvas.style.cssText = "position:absolute;inset:0;width:100%;height:100%;opacity:0;transition:opacity 1.2s ease";
      host.appendChild(canvas);

      const scene = new THREE.Scene();
      scene.fog = new THREE.Fog(0x020618, 20, 44);
      const camera = new THREE.PerspectiveCamera(36, 1, 0.1, 100);
      scene.add(new THREE.HemisphereLight(0xbff3ff, 0x06142e, 1.7));
      const sun = new THREE.DirectionalLight(0xffffff, 2.2);
      sun.position.set(10, 18, 8);
      scene.add(sun);
      // Contre-jour cyan : les arêtes des chunks s'allument.
      const rim = new THREE.DirectionalLight(SIGNAL, 1.6);
      rim.position.set(-10, 7, -16);
      scene.add(rim);
      const glow = new THREE.PointLight(AMBER, 14, 14, 1.4);
      scene.add(glow);

      const geometry = new THREE.BoxGeometry(0.9, 1, 0.9);
      geometry.translate(0, 0.5, 0);
      // Liseré sombre sur chaque face : on lit bien la grille des chunks.
      const tile = document.createElement("canvas");
      tile.width = tile.height = 64;
      const tileCtx = tile.getContext("2d")!;
      tileCtx.fillStyle = "#ffffff";
      tileCtx.fillRect(0, 0, 64, 64);
      tileCtx.strokeStyle = "rgba(2,6,24,0.55)";
      tileCtx.lineWidth = 6;
      tileCtx.strokeRect(3, 3, 58, 58);
      const texture = new THREE.CanvasTexture(tile);
      texture.colorSpace = THREE.SRGBColorSpace;
      const material = new THREE.MeshStandardMaterial({ map: texture, roughness: 0.55, metalness: 0.1 });
      const count = COLS * ROWS;
      const mesh = new THREE.InstancedMesh(geometry, material, count);
      const group = new THREE.Group();
      group.add(mesh);
      // Île décalée vers le centre de l'écran : le texte est à gauche, le téléphone à droite.
      group.position.x = -1.5;
      scene.add(group);

      const heights = new Float32Array(count);
      const lift = new Float32Array(count);
      const claimed = new Map<number, number>(); // index → couleur
      const base = new THREE.Color();
      for (let i = 0; i < count; i++) {
        heights[i] = heightAt(i % COLS, Math.floor(i / COLS));
        mesh.setColorAt(i, base.setHex(terrainColor(heights[i])));
      }
      // Territoires revendiqués : couleur poussée au-delà de 1, ils paraissent lumineux.
      const paint = (i: number) => {
        const owned = claimed.get(i);
        mesh.setColorAt(i, owned === undefined ? base.setHex(terrainColor(heights[i])) : base.setHex(owned).multiplyScalar(1.7));
      };
      const neighbors = (i: number) => {
        const c = i % COLS;
        const r = Math.floor(i / COLS);
        return [
          [c + 1, r],
          [c - 1, r],
          [c, r + 1],
          [c, r - 1],
        ]
          .filter(([cc, rr]) => cc >= 0 && rr >= 0 && cc < COLS && rr < ROWS)
          .map(([cc, rr]) => rr * COLS + cc);
      };
      const claim = (i: number, color = AMBER) => {
        if (heights[i] < 0.35) return false; // l'eau ne se revendique pas
        claimed.set(i, color);
        lift[i] = Math.max(lift[i], 1.6);
        paint(i);
        if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
        return true;
      };
      // Deux territoires de départ et un chunk « relié » au signal.
      for (const seed of [Math.floor(ROWS * 0.45) * COLS + Math.floor(COLS * 0.62), Math.floor(ROWS * 0.6) * COLS + Math.floor(COLS * 0.34)]) {
        claim(seed);
        neighbors(seed).forEach((n) => claim(n));
      }
      claim(Math.floor(ROWS * 0.35) * COLS + Math.floor(COLS * 0.47), SIGNAL);
      mesh.instanceColor!.needsUpdate = true;

      // Pointeur : survol (le chunk se soulève, ses voisins suivent) et clic pour revendiquer.
      const raycaster = new THREE.Raycaster();
      const pointer = new THREE.Vector2(9, 9);
      const tilt = { x: 0, y: 0 };
      let hovered = -1;
      let userClaims = 0;
      const toPointer = (event: PointerEvent) => {
        const rect = host.getBoundingClientRect();
        pointer.set(((event.clientX - rect.left) / rect.width) * 2 - 1, -((event.clientY - rect.top) / rect.height) * 2 + 1);
        tilt.x = pointer.x;
        tilt.y = pointer.y;
        return event.clientY >= rect.top && event.clientY <= rect.bottom;
      };
      const pick = () => {
        raycaster.setFromCamera(pointer, camera);
        return raycaster.intersectObject(mesh)[0]?.instanceId ?? -1;
      };
      const onMove = (event: PointerEvent) => {
        if (!toPointer(event)) pointer.set(9, 9);
      };
      const section = host.parentElement ?? host;
      const onDown = (event: PointerEvent) => {
        if (event.button !== 0 || (event.target as Element).closest("a, button, input, textarea, select, label, dialog, [role='dialog']")) return;
        toPointer(event);
        const index = pick();
        if (index < 0 || !claim(index)) return;
        neighbors(index).forEach((n) => (lift[n] = Math.max(lift[n], 0.8)));
        userClaims++;
        claimRef.current?.(userClaims);
        if (reduced) render();
      };
      window.addEventListener("pointermove", onMove, { passive: true });
      section.addEventListener("pointerdown", onDown);

      const dummy = new THREE.Object3D();
      let width = 1;
      let height = 1;
      const resize = () => {
        const rect = host.getBoundingClientRect();
        width = Math.max(1, rect.width);
        height = Math.max(1, rect.height);
        renderer.setSize(width, height, false);
        camera.aspect = width / height;
        // Plus l'écran est étroit, plus la caméra recule pour garder l'île entière.
        const distance = width < 700 ? 30 : 24;
        camera.position.set(0, distance * 0.72, distance);
        camera.lookAt(0, 0, 0);
        camera.updateProjectionMatrix();
        if (reduced) render();
      };

      let frame = 0;
      let last = performance.now();
      let nextGrowth = 0;
      let visible = true;
      let bounded = false;
      const render = (now = performance.now()) => {
        const t = now / 1000;
        const dt = Math.min(3, (now - last) / 16.7);
        last = now;
        if (!reduced) {
          hovered = pick();
          if (hovered >= 0) {
            lift[hovered] = Math.max(lift[hovered], 1.1);
            for (const n of neighbors(hovered)) lift[n] = Math.max(lift[n], 0.45);
          }
          // Croissance spontanée des territoires, chunk contigu après chunk contigu.
          if (now > nextGrowth && claimed.size < count * 0.22) {
            const owned = [...claimed.keys()];
            const from = owned[Math.floor(Math.random() * owned.length)];
            const free = neighbors(from).filter((n) => !claimed.has(n));
            if (free.length) claim(free[Math.floor(Math.random() * free.length)], claimed.get(from));
            nextGrowth = now + 900 + Math.random() * 900;
          }
          group.rotation.y += ((Math.sin(t * 0.12) * 0.35 + tilt.x * 0.18) - group.rotation.y) * 0.04 * dt;
          group.rotation.x += ((-tilt.y * 0.06) - group.rotation.x) * 0.04 * dt;
        }
        let gx = 0;
        let gz = 0;
        let glowCount = 0;
        for (let i = 0; i < count; i++) {
          const col = i % COLS;
          const row = Math.floor(i / COLS);
          const wave = reduced ? 0 : Math.sin(t * 1.1 + col * 0.35 + row * 0.22) * 0.06;
          const owned = claimed.has(i);
          dummy.position.set(col - COLS / 2 + 0.5, 0, row - ROWS / 2 + 0.5);
          dummy.scale.set(1, heights[i] + wave + lift[i] * 0.55 + (owned ? 0.12 : 0), 1);
          dummy.updateMatrix();
          mesh.setMatrixAt(i, dummy.matrix);
          lift[i] *= reduced ? 0 : 0.92 ** dt;
          if (owned && claimed.get(i) === AMBER) {
            gx += dummy.position.x;
            gz += dummy.position.z;
            glowCount++;
          }
        }
        mesh.instanceMatrix.needsUpdate = true;
        // three.js garde la sphère englobante du premier test de pointeur (cubes pas encore
        // placés) : on la recalcule une fois l'île posée, avec de la marge pour les soulèvements.
        if (!bounded) {
          mesh.computeBoundingSphere();
          if (mesh.boundingSphere) mesh.boundingSphere.radius += 4;
          bounded = true;
        }
        if (glowCount) glow.position.set(gx / glowCount, 3.5, gz / glowCount);
        renderer.render(scene, camera);
      };
      const loop = (now: number) => {
        render(now);
        frame = visible && document.visibilityState === "visible" ? requestAnimationFrame(loop) : 0;
      };
      const wake = () => {
        if (reduced || frame || !visible || document.visibilityState !== "visible") return;
        last = performance.now();
        frame = requestAnimationFrame(loop);
      };

      const resizeObserver = new ResizeObserver(resize);
      resizeObserver.observe(host);
      const io = new IntersectionObserver(([entry]) => {
        visible = Boolean(entry?.isIntersecting);
        wake();
      });
      io.observe(host);
      document.addEventListener("visibilitychange", wake);
      resize();
      render();
      // Premier rendu fait : la carte apparaît en fondu (la grille 2D s'efface).
      window.setTimeout(() => {
        canvas.style.opacity = "1";
        setReady(true);
      }, 30);
      wake();

      cleanup = () => {
        cancelAnimationFrame(frame);
        resizeObserver.disconnect();
        io.disconnect();
        document.removeEventListener("visibilitychange", wake);
        window.removeEventListener("pointermove", onMove);
        section.removeEventListener("pointerdown", onDown);
        geometry.dispose();
        texture.dispose();
        material.dispose();
        mesh.dispose();
        renderer.dispose();
        canvas.remove();
      };
    })();

    return () => {
      disposed = true;
      cleanup();
    };
  }, []);

  return (
    <>
      <div ref={hostRef} className={`pointer-events-none absolute inset-0 overflow-hidden ${className}`} aria-hidden="true">
        {!ready && <ChunkField />}
      </div>
      {hint && ready && (
        <p className="pointer-events-none absolute bottom-4 left-6 hidden items-center gap-2 rounded-full border border-ink-700 bg-ink-950/70 px-3 py-1.5 text-[11px] text-ink-300 backdrop-blur animate-fade lg:flex">
          <span className="h-2 w-2 rounded-[2px] bg-claim" aria-hidden="true" />
          {claims ? (
            <span key={claims} className="animate-pop">
              {claims} chunk{claims > 1 ? "s" : ""} revendiqué{claims > 1 ? "s" : ""} : la carte est à toi
            </span>
          ) : (
            "Clique sur la carte pour revendiquer des chunks"
          )}
        </p>
      )}
    </>
  );
}
