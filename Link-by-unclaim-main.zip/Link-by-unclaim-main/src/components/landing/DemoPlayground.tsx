"use client";

import { useEffect, useRef, useState, type CSSProperties } from "react";
import { Cake, Eye, MailOpen, Palette } from "lucide-react";
import { ALL_FEATURES } from "@/lib/features";
import type { OwnerProfile, PageView } from "@/lib/page-schema";
import { backgroundStyle, getPreset } from "@/lib/theme";
import { PageRenderer } from "@/components/page/PageRenderer";
import type { PageExtras } from "@/components/page/types";

/** Styles proposés sous la démo (clés de THEME_PRESETS). */
const PICKS = ["unclaim", "neon", "sakura", "sunset", "arcade", "ocean", "royaume", "cyber"] as const;
const AUTO_DELAY = 4200;
/** Durée de la révélation d'un nouveau style ; l'ancien reste dessous un peu plus longtemps. */
const REVEAL_MS = 850;

type Demo = { page: PageView; owner: OwnerProfile; extras: PageExtras };

/** Bulle de notification qui flotte autour du téléphone. */
function Bubble({ className, delay, children }: { className: string; delay: string; children: React.ReactNode }) {
  return (
    <div
      className={`ui-motion pointer-events-none absolute z-20 hidden items-center gap-2 rounded-xl border border-ink-600/80 bg-ink-850/90 px-3 py-2 text-xs font-medium text-ink-100 shadow-2xl shadow-black/50 backdrop-blur-md xl:flex ${className}`}
      style={{ animation: `pop 0.6s var(--ease-spring) ${delay} both, float 6s ease-in-out calc(${delay} + 0.6s) infinite` }}
      aria-hidden="true"
    >
      {children}
    </div>
  );
}

/**
 * Démo de la landing : une vraie page rendue par le même moteur que les pages publiques, dans un
 * téléphone qui s'incline sous le pointeur. Le style change d'un clic : le nouveau se dévoile en
 * cercle par-dessus l'ancien, sans jamais sortir de l'écran du téléphone. Les styles défilent
 * tout seuls tant que le visiteur n'a pas choisi.
 */
export function DemoPlayground({ demo }: { demo: Demo }) {
  const [preset, setPreset] = useState<string>("unclaim");
  /** Style précédent, gardé sous le nouveau le temps de la révélation. */
  const [previous, setPrevious] = useState<string | null>(null);
  const [reveal, setReveal] = useState(0);
  const [auto, setAuto] = useState(true);
  const presetRef = useRef(preset);
  presetRef.current = preset;
  const rootRef = useRef<HTMLDivElement>(null);
  const hovered = useRef(false);
  const lastScroll = useRef(0);
  const revealTimer = useRef<number | undefined>(undefined);
  const screenRef = useRef<HTMLDivElement>(null);

  const apply = (key: string) => {
    if (key === presetRef.current) return;
    setPrevious(presetRef.current);
    setPreset(key);
    setReveal((n) => n + 1);
    window.clearTimeout(revealTimer.current);
    revealTimer.current = window.setTimeout(() => setPrevious(null), REVEAL_MS + 80);
  };

  // Le nouveau style s'ouvre en cercle depuis le haut de l'écran. Animé sur place (sans recréer la
  // page) : ce que le visiteur fait dans le téléphone (panier, défilement) est conservé.
  useEffect(() => {
    if (!reveal || !screenRef.current || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    screenRef.current.animate(
      [
        { clipPath: "circle(0px at 50% 120px)", filter: "brightness(1.3) saturate(1.25)" },
        { clipPath: "circle(150% at 50% 120px)", filter: "none" },
      ],
      { duration: REVEAL_MS, easing: "cubic-bezier(0.16, 1, 0.3, 1)" },
    );
  }, [reveal]);

  const choose = (key: string) => {
    setAuto(false);
    apply(key);
  };

  useEffect(() => () => window.clearTimeout(revealTimer.current), []);

  useEffect(() => {
    if (!auto || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let visible = false;
    const observer = new IntersectionObserver(([entry]) => (visible = Boolean(entry?.isIntersecting)), { threshold: 0.35 });
    if (rootRef.current) observer.observe(rootRef.current);
    const onScroll = () => (lastScroll.current = Date.now());
    window.addEventListener("scroll", onScroll, { passive: true });
    const timer = window.setInterval(() => {
      // Pas pendant un défilement, ni sous le pointeur, ni hors de l'écran.
      if (!visible || hovered.current || Date.now() - lastScroll.current < 600 || document.visibilityState !== "visible") return;
      apply(PICKS[(PICKS.indexOf(presetRef.current as (typeof PICKS)[number]) + 1) % PICKS.length]);
    }, AUTO_DELAY);
    return () => {
      window.clearInterval(timer);
      observer.disconnect();
      window.removeEventListener("scroll", onScroll);
    };
  }, [auto]);

  const themeOf = (key: string) => ({ ...(getPreset(key)?.theme ?? demo.page.theme), width: "narrow" as const });
  const theme = themeOf(preset);
  const screen = (key: string) => (
    <PageRenderer
      page={{ ...demo.page, theme: themeOf(key) }}
      owner={demo.owner}
      context={{ features: ALL_FEATURES, verified: true, blockedDomains: [] }}
      extras={demo.extras}
      mode="demo"
      bare
    />
  );

  return (
    <div
      ref={rootRef}
      className="relative mx-auto w-full max-w-[400px]"
      onPointerEnter={() => (hovered.current = true)}
      onPointerLeave={() => (hovered.current = false)}
      // Le visiteur joue avec la page (boutique, liens…) : les styles cessent de défiler.
      onPointerDown={() => setAuto(false)}
    >
      {/* Halo aux couleurs du style choisi */}
      <div
        className="pointer-events-none absolute -inset-10 -z-10 rounded-full opacity-50 blur-3xl transition-[background] duration-700"
        style={{ background: `radial-gradient(closest-side, ${theme.accent}55, transparent)` }}
        aria-hidden="true"
      />

      <div data-tilt="6" className="ui-tilt relative z-0">
        <div className="hud-panel relative overflow-hidden rounded-[2.2rem] border border-ink-600 bg-ink-900 p-2 shadow-[0_30px_60px_-24px_#000000dd]">
          <div className="scrollbar-thin relative isolate h-[600px] overflow-x-hidden overflow-y-auto rounded-[1.8rem] sm:h-[640px]">
            {/* L'ancien style reste dessous, figé, pendant que le nouveau s'ouvre en cercle. */}
            {previous && (
              <div className="absolute inset-x-0 top-0" aria-hidden="true" inert>
                {screen(previous)}
              </div>
            )}
            <div ref={screenRef} className="relative">
              {screen(preset)}
            </div>
          </div>
        </div>
      </div>

      {/* Après le téléphone dans le document : elles passent au-dessus de son relief 3D. */}
      <Bubble className="-left-28 top-16" delay="0.9s">
        <span className="ui-live-dot text-mint" /> <Eye size={14} className="text-mint" /> +1 visite · à l&apos;instant
      </Bubble>
      <Bubble className="-right-24 top-44" delay="1.5s">
        <span className="ui-live-dot text-red-500" /> Kaelis est en live
      </Bubble>
      <Bubble className="-left-32 top-[400px]" delay="2.1s">
        <MailOpen size={14} className="text-brand-300" /> Nouveau message
      </Bubble>
      <Bubble className="-right-20 top-[520px]" delay="2.7s">
        <Cake size={14} className="text-claim" /> Anniversaire dans 3 jours
      </Bubble>

      <div className="mt-5">
        <p className="hud-label flex items-center justify-center gap-2 text-ink-400">
          <Palette size={12} aria-hidden="true" /> Essaie un style
        </p>
        <div className="mt-3 flex flex-wrap justify-center gap-2" role="radiogroup" aria-label="Style de la page de démonstration">
          {PICKS.map((key) => {
            const p = getPreset(key);
            if (!p) return null;
            const active = key === preset;
            return (
              <button
                key={key}
                type="button"
                role="radio"
                aria-checked={active}
                onClick={() => choose(key)}
                className={`ui-press group inline-flex items-center gap-2 rounded-full border py-1 pr-3 pl-1 text-xs font-semibold transition ${
                  active ? "border-ink-200 bg-ink-800 text-ink-100" : "border-ink-700 bg-ink-900/70 text-ink-400 hover:border-ink-500 hover:text-ink-200"
                }`}
              >
                <span
                  className="relative h-6 w-6 rounded-full ring-1 ring-white/15"
                  style={{ ...(backgroundStyle(p.theme) as CSSProperties) }}
                  aria-hidden="true"
                >
                  <span className="absolute inset-[7px] rounded-full" style={{ background: p.theme.accent }} />
                </span>
                {p.label}
              </button>
            );
          })}
        </div>
        {auto && <p className="mt-2 text-center text-[11px] text-ink-500">Les styles défilent tout seuls · clique pour choisir</p>}
      </div>
    </div>
  );
}
