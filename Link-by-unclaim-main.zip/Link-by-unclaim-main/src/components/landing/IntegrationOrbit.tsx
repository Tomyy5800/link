import type { CSSProperties } from "react";
import { Castle, Gamepad2, Radio } from "lucide-react";
import { LogoMark } from "@/components/brand/Logo";
import { SocialIcon } from "@/components/icons/SocialIcon";
import { BRAND_ICONS } from "@/components/icons/brand-paths";

type Brand = keyof typeof BRAND_ICONS;
type Item = { key: string; label: string; color: string; brand?: Brand; icon?: typeof Castle };

const brand = (key: Brand): Item => {
  const hex = BRAND_ICONS[key].hex;
  return { key, brand: key, label: BRAND_ICONS[key].title, color: hex === "#000000" || hex === "#181717" ? "#f8fafc" : hex };
};

// Trois anneaux, du plus proche (réseaux) au plus lointain (soutien, musique, jeux).
const RINGS: { radius: number; duration: number; reverse?: boolean; items: Item[] }[] = [
  { radius: 118, duration: 38, items: ["discord", "twitch", "youtube", "tiktok", "instagram", "x"].map((k) => brand(k as Brand)) },
  {
    radius: 192,
    duration: 56,
    reverse: true,
    items: [
      ...(["spotify", "steam", "kick", "reddit", "bluesky", "telegram"] as Brand[]).map(brand),
      { key: "nationsglory", label: "NationsGlory", color: "#ffc247", icon: Castle },
      { key: "radio", label: "Webradios", color: "#22c9e8", icon: Radio },
    ],
  },
  {
    radius: 266,
    duration: 80,
    items: [
      ...(["github", "soundcloud", "threads", "patreon", "kofi", "applemusic", "deezer", "snapchat", "pinterest"] as Brand[]).map(brand),
      { key: "games", label: "Chess.com, Lichess, Roblox…", color: "#00bc7d", icon: Gamepad2 },
    ],
  },
];

/**
 * Les plateformes en orbite autour de Link : trois anneaux qui tournent à des vitesses différentes,
 * logos toujours droits (contre-rotation), pause au survol. CSS seulement.
 */
export function IntegrationOrbit() {
  return (
    <div className="ui-orbit-wrap relative mx-auto h-[600px] w-[600px] max-w-none [zoom:0.56] sm:[zoom:0.85] lg:[zoom:1]" aria-hidden="true">
      {/* Halo central */}
      <div className="absolute inset-[30%] rounded-full bg-brand-500/20 blur-3xl" />
      {RINGS.map((ring) => (
        <div
          key={ring.radius}
          className="ui-orbit"
          style={{ width: ring.radius * 2, height: ring.radius * 2, "--dur": `${ring.duration}s`, "--dir": ring.reverse ? "reverse" : "normal", "--counter": ring.reverse ? "normal" : "reverse" } as CSSProperties}
        >
          {ring.items.map((item, i) => {
            const Icon = item.icon;
            return (
              <span
                key={item.key}
                className="ui-orbit-item"
                style={{ "--a": `${(360 / ring.items.length) * i}deg`, "--r": `${ring.radius}px` } as CSSProperties}
              >
                <span className="ui-orbit-badge" style={{ color: item.color, "--glow": `${item.color}55` } as CSSProperties} title={item.label}>
                  {item.brand ? <SocialIcon platform={item.brand} size={20} /> : Icon ? <Icon size={20} /> : null}
                </span>
              </span>
            );
          })}
        </div>
      ))}
      {/* Le cœur : Link */}
      <div className="absolute top-1/2 left-1/2 flex h-24 w-24 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-3xl border border-brand-500/40 bg-ink-900 shadow-[0_0_60px_-10px_rgba(34,201,232,0.7)]">
        <LogoMark size={56} tile={false} />
      </div>
    </div>
  );
}
