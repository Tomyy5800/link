import { PlusMark } from "@/components/brand/Logo";

/**
 * Carte de membre Link+ « holographique » : elle s'incline sous le pointeur (data-tilt) et ses
 * reflets irisés suivent la lumière (data-spotlight fournit --mx / --my). CSS seulement.
 */
export function HoloCard({ name, tagline }: { name: string; tagline: string }) {
  return (
    <div data-tilt="14" data-spotlight className="ui-tilt ui-holo relative aspect-[1.586] w-full max-w-[380px] select-none" aria-hidden="true">
      <div className="ui-holo-face absolute inset-0 flex flex-col justify-between overflow-hidden rounded-2xl border border-white/15 p-6">
        <div className="flex items-start justify-between">
          <PlusMark size={44} />
          <span className="font-mono text-[10px] tracking-[0.2em] text-white/70">MEMBRE</span>
        </div>
        <div>
          <p className="font-mono text-xs tracking-[0.25em] text-white/60">•••• •••• •••• 2026</p>
          <p className="mt-2 font-display text-2xl font-bold text-white">{name}</p>
          <p className="text-xs text-white/70">{tagline}</p>
        </div>
        {/* Reflets irisés et éclat, positionnés par le pointeur */}
        <span className="ui-holo-sheen pointer-events-none absolute inset-0" />
        <span className="ui-holo-glare pointer-events-none absolute inset-0" />
      </div>
    </div>
  );
}
