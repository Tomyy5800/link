"use client";

import { useCallback, useEffect, useRef, useState, type CSSProperties } from "react";
import { ArrowRight, ChevronLeft, ChevronRight, Eye, X } from "lucide-react";
import { ALL_FEATURES } from "@/lib/features";
import type { OwnerProfile } from "@/lib/page-schema";
import type { Showcase } from "@/lib/showcase";
import { backgroundStyle, getPreset, rgba } from "@/lib/theme";
import { PageRenderer } from "@/components/page/PageRenderer";
import type { PageExtras } from "@/components/page/types";

/** Miniature stylisée d'une page : fond, avatar, nom et boutons aux couleurs du thème. */
function Thumbnail({ preset }: { preset: string }) {
  const theme = getPreset(preset)?.theme;
  if (!theme) return null;
  const card = theme.cardStyle === "glass" ? rgba("#ffffff", 0.12) : theme.cardStyle === "outline" ? "transparent" : theme.cardColor;
  const radius = theme.radius === "full" ? 999 : theme.radius === "none" ? 2 : 8;
  return (
    <div className="relative flex h-44 flex-col items-center justify-center gap-2 overflow-hidden px-6" style={backgroundStyle(theme) as CSSProperties} aria-hidden="true">
      <span
        className="h-10 w-10 shadow-lg transition-transform duration-500 group-hover:scale-110"
        style={{ background: `linear-gradient(135deg, ${theme.accent}, ${theme.accent2})`, borderRadius: theme.avatarShape === "circle" ? 999 : theme.avatarShape === "square" ? 2 : 10 }}
      />
      <span className="h-2 w-20 rounded-full opacity-90" style={{ background: theme.text }} />
      <span className="h-1.5 w-14 rounded-full opacity-50" style={{ background: theme.text }} />
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          className="h-5 w-full max-w-[11rem] transition-transform duration-500 group-hover:translate-y-[-2px]"
          style={{
            background: theme.buttonFill === "solid" ? theme.accent : theme.buttonFill === "soft" ? rgba(theme.accent, 0.22) : card,
            border: theme.buttonFill === "outline" || theme.cardStyle === "outline" ? `1.5px solid ${theme.accent}` : "none",
            borderRadius: radius,
            transitionDelay: `${i * 40}ms`,
          }}
        />
      ))}
    </div>
  );
}

/**
 * Modèles de la landing : miniatures inclinables, et un aperçu en direct (vraie page d'exemple)
 * qu'on parcourt avec les flèches avant de choisir.
 */
export function TemplateGallery({
  showcases,
  owner,
  extras,
  loggedIn,
}: {
  showcases: Showcase[];
  owner: OwnerProfile;
  extras: PageExtras;
  loggedIn: boolean;
}) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const [open, setOpen] = useState<number | null>(null);

  const show = useCallback((index: number) => {
    setOpen(index);
    if (!dialogRef.current?.open) dialogRef.current?.showModal();
  }, []);
  const close = useCallback(() => dialogRef.current?.close(), []);
  const step = useCallback((delta: number) => setOpen((i) => (i === null ? i : (i + delta + showcases.length) % showcases.length)), [showcases.length]);

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "ArrowRight") step(1);
      if (event.key === "ArrowLeft") step(-1);
    };
    const onClose = () => setOpen(null);
    dialog.addEventListener("keydown", onKey);
    dialog.addEventListener("close", onClose);
    return () => {
      dialog.removeEventListener("keydown", onKey);
      dialog.removeEventListener("close", onClose);
    };
  }, [step]);

  const current = open === null ? null : showcases[open];
  const target = (id: string) => {
    const path = `/dashboard/nouvelle?modele=${id}`;
    return loggedIn ? path : `/login?next=${encodeURIComponent(path)}`;
  };

  return (
    <>
      <ul className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        {showcases.map((s, i) => (
          <li key={s.id} className="ui-reveal">
            <button
              type="button"
              onClick={() => show(i)}
              data-tilt="8"
              data-spotlight
              className="ui-tilt ui-spotlight group block h-full w-full overflow-hidden rounded-lg border border-ink-700 bg-ink-900 text-left"
            >
              <span className="relative block">
                <Thumbnail preset={s.preset} />
                <span className="absolute inset-0 flex items-center justify-center bg-ink-950/0 opacity-0 transition duration-300 group-hover:bg-ink-950/40 group-hover:opacity-100 group-focus-visible:opacity-100">
                  <span className="inline-flex translate-y-2 items-center gap-1.5 rounded-full bg-ink-100 px-3 py-1.5 text-xs font-semibold text-ink-950 transition duration-300 group-hover:translate-y-0">
                    <Eye size={14} /> Aperçu en direct
                  </span>
                </span>
              </span>
              <span className="block p-4">
                <span className="block font-display text-lg font-semibold">{s.name}</span>
                <span className="mt-1 block text-sm text-ink-300">{s.description}</span>
              </span>
            </button>
          </li>
        ))}
      </ul>

      <dialog
        ref={dialogRef}
        aria-label={current ? `Aperçu du modèle ${current.name}` : "Aperçu du modèle"}
        className="m-auto w-[min(96vw,980px)] overflow-visible bg-transparent p-0 text-ink-100 backdrop:bg-ink-950/80 backdrop:backdrop-blur-sm"
        onClick={(event) => {
          if (event.target === dialogRef.current) close();
        }}
      >
        {current && open !== null && (
          <div key={current.id} className="animate-pop relative grid items-center gap-6 rounded-2xl border border-ink-600 bg-ink-900 p-5 shadow-2xl shadow-black/70 md:grid-cols-[1fr_360px] md:p-8">
            <div className="order-2 md:order-1">
              <p className="hud-label text-brand-300">
                Modèle {open + 1}/{showcases.length}
              </p>
              <h3 className="mt-2 font-display text-3xl font-bold">{current.name}</h3>
              <p className="mt-2 text-ink-300">{current.description}</p>
              <p className="mt-4 text-sm text-ink-400">
                Les blocs et le thème sont placés pour toi ; tu remplaces les exemples par tes liens en quelques minutes, et tout reste modifiable.
              </p>
              <div className="mt-6 flex flex-wrap gap-2">
                <a
                  href={target(current.id)}
                  className="ui-press ui-shine inline-flex items-center gap-2 rounded-md bg-brand-500 px-4 py-2.5 font-semibold text-ink-950 transition hover:bg-brand-400"
                >
                  Utiliser ce modèle <ArrowRight size={17} />
                </a>
                <button type="button" onClick={() => step(-1)} className="ui-press rounded-md border border-ink-600 p-2.5 text-ink-200 hover:border-ink-400" aria-label="Modèle précédent">
                  <ChevronLeft size={18} />
                </button>
                <button type="button" onClick={() => step(1)} className="ui-press rounded-md border border-ink-600 p-2.5 text-ink-200 hover:border-ink-400" aria-label="Modèle suivant">
                  <ChevronRight size={18} />
                </button>
              </div>
              <p className="mt-3 hidden text-xs text-ink-500 md:block">← → pour passer d&apos;un modèle à l&apos;autre · Échap pour fermer</p>
            </div>
            <div className="order-1 mx-auto w-full max-w-[360px] md:order-2">
              <div className="overflow-hidden rounded-[2rem] border border-ink-600 bg-ink-950 p-1.5">
                <div className="scrollbar-thin h-[min(62vh,560px)] overflow-y-auto overflow-x-hidden rounded-[1.6rem]">
                  <PageRenderer
                    page={current.page}
                    owner={{
                      ...owner,
                      globalName: current.page.profile.displayName,
                      discordUsername: current.page.profile.displayName.toLowerCase().replace(/[^a-z0-9]+/g, "."),
                    }}
                    context={{ features: ALL_FEATURES, verified: false, blockedDomains: [] }}
                    extras={extras}
                    mode="demo"
                    bare
                  />
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={close}
              className="ui-press absolute -top-3 -right-3 flex h-9 w-9 items-center justify-center rounded-full border border-ink-600 bg-ink-850 text-ink-200 shadow-lg hover:text-white"
              aria-label="Fermer l'aperçu"
            >
              <X size={16} />
            </button>
          </div>
        )}
      </dialog>
    </>
  );
}
