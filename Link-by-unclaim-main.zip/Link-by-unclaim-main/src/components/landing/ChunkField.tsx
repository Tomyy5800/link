"use client";

import { useEffect, useRef } from "react";

const CELL = 32;
const RADIUS = 120;
const CLAIM_LIFE = 5200;

type Claim = { i: number; born: number; color: string };

/**
 * Fond vivant du hero : la grille des chunks s'illumine sous le pointeur et des territoires se
 * revendiquent tout seuls, chunk après chunk. Canvas en pause hors de l'écran ; image fixe si le
 * visiteur a demandé moins d'animations.
 */
export function ChunkField({ className = "" }: { className?: string }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let width = 0;
    let height = 0;
    let cols = 0;
    let rows = 0;
    let heat = new Float32Array(0);
    let claims: Claim[] = [];
    let nextClaim = 0;
    let frame = 0;
    let last = performance.now();
    let onScreen = true;
    const pointer = { x: -1e4, y: -1e4 };

    const cellAt = (col: number, row: number) => (col < 0 || row < 0 || col >= cols || row >= rows ? -1 : row * cols + col);

    // Un territoire grandit par contiguïté, comme sur NationsGlory.
    const spawn = (now: number) => {
      if (!cols || !rows) return;
      let index = -1;
      if (claims.length && Math.random() < 0.7) {
        const from = claims[Math.floor(Math.random() * claims.length)];
        const col = from.i % cols;
        const row = Math.floor(from.i / cols);
        const [dc, dr] = [[1, 0], [-1, 0], [0, 1], [0, -1]][Math.floor(Math.random() * 4)];
        index = cellAt(col + dc, row + dr);
      }
      if (index < 0 || claims.some((c) => c.i === index)) {
        index = Math.floor(Math.random() * cols * rows);
      }
      claims.push({ i: index, born: now, color: Math.random() < 0.82 ? "255,194,71" : "34,201,232" });
    };

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = rect.width;
      height = rect.height;
      canvas.width = Math.max(1, Math.round(width * dpr));
      canvas.height = Math.max(1, Math.round(height * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      cols = Math.ceil(width / CELL);
      rows = Math.ceil(height / CELL);
      heat = new Float32Array(cols * rows);
      claims = [];
      const now = performance.now();
      for (let k = 0; k < 9; k++) spawn(now - Math.random() * CLAIM_LIFE * 0.6);
      if (reduced) draw(now, 0);
    };

    const draw = (now: number, dt: number) => {
      ctx.clearRect(0, 0, width, height);
      // Chaleur laissée par le pointeur
      const decay = 0.93 ** dt;
      const pc = Math.floor(pointer.x / CELL);
      const pr = Math.floor(pointer.y / CELL);
      const reach = Math.ceil(RADIUS / CELL);
      for (let r = pr - reach; r <= pr + reach; r++) {
        for (let c = pc - reach; c <= pc + reach; c++) {
          const index = cellAt(c, r);
          if (index < 0) continue;
          const dist = Math.hypot(c * CELL + CELL / 2 - pointer.x, r * CELL + CELL / 2 - pointer.y);
          if (dist < RADIUS) heat[index] = Math.max(heat[index], (1 - dist / RADIUS) ** 1.6);
        }
      }
      for (let index = 0; index < heat.length; index++) {
        const h = heat[index];
        if (h < 0.015) {
          heat[index] = 0;
          continue;
        }
        const x = (index % cols) * CELL;
        const y = Math.floor(index / cols) * CELL;
        ctx.fillStyle = `rgba(34,201,232,${(h * 0.2).toFixed(3)})`;
        ctx.fillRect(x + 2, y + 2, CELL - 4, CELL - 4);
        if (h > 0.35) {
          ctx.strokeStyle = `rgba(79,216,239,${(h * 0.55).toFixed(3)})`;
          ctx.strokeRect(x + 2.5, y + 2.5, CELL - 5, CELL - 5);
        }
        heat[index] = h * decay;
      }
      // Chunks revendiqués : apparition rebondie, maintien, disparition lente
      claims = claims.filter((claim) => now - claim.born < CLAIM_LIFE);
      for (const claim of claims) {
        const age = now - claim.born;
        const appear = Math.min(1, age / 320);
        const fade = Math.min(1, (CLAIM_LIFE - age) / 1400);
        const alpha = Math.max(0, Math.min(appear, fade)) * 0.34;
        // Rebond (easeOutBack) : le chunk dépasse un peu sa taille avant de se poser
        const t = appear - 1;
        const scale = 1 + 2.70158 * t ** 3 + 1.70158 * t ** 2;
        const size = (CELL - 6) * Math.max(0, scale);
        const x = (claim.i % cols) * CELL + CELL / 2 - size / 2;
        const y = Math.floor(claim.i / cols) * CELL + CELL / 2 - size / 2;
        ctx.fillStyle = `rgba(${claim.color},${alpha.toFixed(3)})`;
        ctx.fillRect(x, y, size, size);
      }
    };

    const loop = (now: number) => {
      const dt = Math.min(3, (now - last) / 16.7);
      last = now;
      if (now > nextClaim) {
        spawn(now);
        nextClaim = now + 420 + Math.random() * 700;
      }
      draw(now, dt);
      frame = onScreen && document.visibilityState === "visible" ? requestAnimationFrame(loop) : 0;
    };
    const wake = () => {
      if (reduced || frame || !onScreen || document.visibilityState !== "visible") return;
      last = performance.now();
      frame = requestAnimationFrame(loop);
    };

    const onMove = (event: PointerEvent) => {
      const rect = canvas.getBoundingClientRect();
      pointer.x = event.clientX - rect.left;
      pointer.y = event.clientY - rect.top;
    };
    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(canvas);
    const visibility = new IntersectionObserver(([entry]) => {
      onScreen = Boolean(entry?.isIntersecting);
      wake();
    });
    visibility.observe(canvas);
    window.addEventListener("pointermove", onMove, { passive: true });
    document.addEventListener("visibilitychange", wake);
    resize();
    wake();

    return () => {
      cancelAnimationFrame(frame);
      resizeObserver.disconnect();
      visibility.disconnect();
      window.removeEventListener("pointermove", onMove);
      document.removeEventListener("visibilitychange", wake);
    };
  }, []);

  return <canvas ref={ref} aria-hidden="true" className={`pointer-events-none absolute inset-0 h-full w-full ${className}`} />;
}
