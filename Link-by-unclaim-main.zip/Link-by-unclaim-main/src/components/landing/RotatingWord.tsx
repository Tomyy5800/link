"use client";

import { useEffect, useState } from "react";

/**
 * Mot qui change toutes les quelques secondes (glissement et flou). Tous les mots occupent la
 * même case de grille : la largeur est celle du plus long, rien ne bouge autour.
 * Décoratif : le titre porte aussi la phrase complète pour les lecteurs d'écran.
 */
export function RotatingWord({ words, interval = 2600, className = "" }: { words: string[]; interval?: number; className?: string }) {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const timer = window.setInterval(() => setIndex((i) => (i + 1) % words.length), interval);
    return () => window.clearInterval(timer);
  }, [words.length, interval]);

  return (
    <span className={`inline-grid ${className}`} aria-hidden="true">
      {words.map((word, i) => {
        const state = i === index ? "in" : i === (index - 1 + words.length) % words.length ? "out" : "wait";
        return (
          <span
            key={word}
            className="col-start-1 row-start-1 whitespace-nowrap transition-[opacity,transform,filter] duration-700 ease-[cubic-bezier(0.16,1,0.3,1)]"
            style={{
              opacity: state === "in" ? 1 : 0,
              transform: state === "in" ? "none" : state === "out" ? "translateY(-0.45em)" : "translateY(0.45em)",
              filter: state === "in" ? "none" : "blur(6px)",
            }}
          >
            {word}
          </span>
        );
      })}
    </span>
  );
}
