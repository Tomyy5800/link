import type { CSSProperties } from "react";

/**
 * Titre dont les mots montent un à un quand il entre à l'écran (animation liée au défilement,
 * sans script ; texte normal là où ce n'est pas pris en charge). Le texte reste lisible tel quel
 * par les lecteurs d'écran.
 */
export function SplitWords({ text, className = "" }: { text: string; className?: string }) {
  const words = text.split(" ");
  return (
    <span className={`ui-words ${className}`}>
      {words.map((word, i) => (
        <span key={i} className="ui-word" style={{ "--i": i } as CSSProperties}>
          {word}
          {i < words.length - 1 ? " " : ""}
        </span>
      ))}
    </span>
  );
}
