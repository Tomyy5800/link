import type { CSSProperties, ReactNode } from "react";
import { CalendarClock, Castle, Gamepad2, Mail, ShoppingBag, Trophy } from "lucide-react";
import { DiscordLogo } from "@/components/icons/SocialIcon";

// Petites illustrations animées des cartes « Fonctionnalités » de la landing (CSS seulement).

export type FeatureVisualKind =
  | "assistant"
  | "automations"
  | "team"
  | "games"
  | "radio"
  | "discord"
  | "nationsglory"
  | "contact"
  | "shop"
  | "orders"
  | "schedule"
  | "agenda"
  | "style"
  | "blocks"
  | "stats";

const cycle = (delay: number, duration = 7): CSSProperties => ({ animation: `ui-cycle-in ${duration}s var(--ease-out-expo) ${delay}s infinite both` });

function Frame({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div className={`ui-visual relative flex h-28 items-center justify-center overflow-hidden rounded-md border border-ink-700/80 bg-ink-950/60 ${className}`} aria-hidden="true">
      {children}
    </div>
  );
}

export function FeatureVisual({ kind }: { kind: FeatureVisualKind }) {
  switch (kind) {
    case "assistant":
      return (
        <Frame className="flex-col items-stretch justify-center gap-1.5 px-4 text-[11px]">
          <span className="w-fit rounded-lg rounded-bl-sm bg-ink-800 px-2.5 py-1 text-ink-200" style={cycle(0)}>
            Salut ! Tu fais quoi en ligne ?
          </span>
          <span className="ml-auto w-fit rounded-lg rounded-br-sm bg-brand-500 px-2.5 py-1 font-medium text-ink-950" style={cycle(0.9)}>
            Je streame sur Twitch 🎮
          </span>
          <span className="w-fit rounded-lg rounded-bl-sm bg-ink-800 px-2.5 py-1.5 text-ink-300" style={cycle(1.8)}>
            <span className="ui-typing text-ink-400">
              <span />
              <span />
              <span />
            </span>
          </span>
        </Frame>
      );
    case "automations":
      return (
        <Frame className="flex-col gap-2 px-5">
          <span
            className="flex w-full items-center gap-2 rounded-md border border-red-500/50 bg-red-500/15 px-2.5 py-1.5 text-[11px] font-semibold text-red-100"
            style={{ animation: "ui-banner-cycle 6s var(--ease-out-expo) infinite both" }}
          >
            <span className="ui-live-dot text-red-500" /> En live maintenant · viens dire bonjour
          </span>
          <span className="h-5 w-full rounded-md bg-ink-800" />
          <span className="h-5 w-3/4 rounded-md bg-ink-800/70" />
        </Frame>
      );
    case "team":
      return (
        <Frame>
          <div className="flex -space-x-3">
            {["#22c9e8", "#ffc247", "#00bc7d", "#ff6467", "#5865f2"].map((color, i) => (
              <span
                key={color}
                className="flex h-11 w-11 items-center justify-center rounded-full border-2 border-ink-950 text-xs font-bold text-ink-950"
                style={{ background: color, animation: `float 4s ease-in-out ${i * 0.25}s infinite` }}
              >
                {"KNLAM"[i]}
              </span>
            ))}
          </div>
        </Frame>
      );
    case "games":
      return (
        <Frame className="gap-2 px-3">
          {[
            { icon: Gamepad2, label: "Steam", color: "#8fe6f6" },
            { icon: Trophy, label: "1 842 Elo", color: "#ffc247" },
            { icon: Castle, label: "Blue", color: "#00bc7d" },
          ].map(({ icon: Icon, label, color }, i) => (
            <span key={label} className="flex flex-col items-center gap-1 rounded-md border border-ink-700 bg-ink-900 px-2.5 py-2 text-[10px] font-semibold text-ink-200" style={cycle(i * 0.5, 6)}>
              <Icon size={18} style={{ color }} />
              {label}
            </span>
          ))}
        </Frame>
      );
    case "radio":
      return (
        <Frame className="gap-3 px-4">
          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-md bg-gradient-to-br from-brand-500 to-claim text-ink-950" style={{ animation: "ui-hue 12s linear infinite" }}>
            <span className="ui-eq h-5">
              <span />
              <span />
              <span />
              <span />
            </span>
          </span>
          <span className="min-w-0 text-[11px] leading-snug">
            <span className="flex items-center gap-1.5 font-semibold text-red-300">
              <span className="ui-live-dot text-red-500" /> En direct
            </span>
            <span className="block truncate text-ink-100">LyxiaRadio · Nuit électro</span>
            <span className="block text-ink-500">214 auditeurs</span>
          </span>
        </Frame>
      );
    case "discord":
      return (
        <Frame className="gap-3">
          <span className="relative flex h-12 w-12 items-center justify-center rounded-full bg-blurple text-white">
            <DiscordLogo size={24} />
            <span className="absolute -right-0.5 -bottom-0.5 h-4 w-4 rounded-full border-[3px] border-ink-950 bg-mint" />
          </span>
          <span className="text-[11px] leading-snug">
            <span className="block font-semibold text-ink-100">En ligne</span>
            <span className="block text-ink-400">Joue à Minecraft</span>
          </span>
        </Frame>
      );
    case "nationsglory":
      return (
        <Frame>
          <div className="grid grid-cols-6 gap-1">
            {Array.from({ length: 18 }, (_, i) => {
              const claimed = [2, 3, 7, 8, 9, 14].includes(i);
              return (
                <span
                  key={i}
                  className={`h-4 w-4 rounded-[2px] ${claimed ? "bg-claim" : "border border-ink-600"}`}
                  style={claimed ? { animation: `pop 0.5s var(--ease-spring) ${i * 0.08}s both, ui-bump 4s ease-in-out ${1 + i * 0.3}s infinite` } : undefined}
                />
              );
            })}
          </div>
        </Frame>
      );
    case "contact":
      return (
        <Frame>
          <span className="relative">
            <Mail size={40} className="text-brand-300" />
            <span
              className="absolute -top-2 -right-3 flex h-5 min-w-5 items-center justify-center rounded-full bg-claim px-1 font-mono text-[10px] font-bold text-ink-950"
              style={{ animation: "ui-bump 3.2s ease-in-out infinite" }}
            >
              3
            </span>
          </span>
        </Frame>
      );
    case "shop":
      return (
        <Frame className="gap-2.5 px-4">
          {(
            [
              ["🧥", "39 €", "49 €", "#22c9e8"],
              ["🗺️", "15 €", "", "#ffc247"],
              ["✨", "6 €", "", "#f472b6"],
            ] as const
          ).map(([emoji, price, old, color], i) => (
            <span
              key={price}
              className="relative flex w-[4.6rem] flex-col items-center rounded-lg border border-ink-700 bg-ink-900 pt-2.5 pb-1.5"
              style={{ animation: `float 5s ease-in-out ${i * 0.4}s infinite` }}
            >
              <span className="text-[26px] leading-none drop-shadow-[0_6px_10px_rgba(0,0,0,0.45)]">{emoji}</span>
              <span className="mt-1.5 flex items-baseline gap-1 font-mono text-[10px] font-bold" style={{ color }}>
                {price}
                {old && <span className="text-[8px] font-normal text-ink-500 line-through">{old}</span>}
              </span>
              {old && <span className="absolute -top-1.5 -left-1.5 rounded-full bg-red-500 px-1 text-[8px] font-bold text-white">-20%</span>}
            </span>
          ))}
          <span className="relative ml-1 flex h-11 w-11 items-center justify-center rounded-full border border-pink-400/40 bg-pink-400/10 text-pink-300">
            <ShoppingBag size={19} />
            <span
              className="absolute -top-1 -right-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-pink-400 px-1 font-mono text-[10px] font-bold text-ink-950"
              style={{ animation: "ui-bump 2.6s ease-in-out infinite" }}
            >
              3
            </span>
          </span>
        </Frame>
      );
    case "orders":
      return (
        <Frame className="flex-col items-stretch justify-center gap-1.5 px-3">
          {(
            [
              ["Lina", "Nouvelle", "bg-brand-500/20 text-brand-200"],
              ["Max", "Acceptée", "bg-claim/20 text-claim"],
              ["Sora", "Terminée", "bg-mint/20 text-mint"],
            ] as const
          ).map(([name, status, tone], i) => (
            <span key={name} className="flex items-center gap-2 rounded-md bg-ink-900 px-2 py-1 text-[10px]" style={cycle(i * 0.6, 6)}>
              <span className="h-1.5 w-1.5 rounded-full bg-pink-400" />
              <span className="flex-1 text-ink-200">{name}</span>
              <span className={`rounded-full px-1.5 font-semibold ${tone}`}>{status}</span>
            </span>
          ))}
        </Frame>
      );
    case "schedule":
      return (
        <Frame className="gap-3">
          <CalendarClock size={30} className="text-claim" />
          <span className="flex flex-col gap-1">
            <span className="h-3 w-20 rounded-sm bg-ink-700" />
            <span className="h-3 w-20 rounded-sm bg-brand-500/70" style={{ animation: "ui-cycle-in 4s var(--ease-out-expo) infinite both" }} />
            <span className="h-3 w-14 rounded-sm bg-ink-700" />
          </span>
        </Frame>
      );
    case "agenda":
      return (
        <Frame className="gap-1.5">
          {[
            ["02", "jours"],
            ["14", "h"],
            ["37", "min"],
          ].map(([value, unit]) => (
            <span key={unit} className="flex w-14 flex-col items-center rounded-md border border-ink-700 bg-ink-900 py-1.5">
              <span className="font-display text-xl font-bold tabular-nums text-ink-100">{value}</span>
              <span className="text-[9px] tracking-wider text-ink-500 uppercase">{unit}</span>
            </span>
          ))}
        </Frame>
      );
    case "style":
      return (
        <Frame className="gap-2 px-4">
          {[
            ["#020618", "#22c9e8"],
            ["#050505", "#c6f432"],
            ["#fff1f5", "#d6336c"],
            ["#120458", "#ffd319"],
            ["#021b2b", "#4fd1c5"],
            ["#1a0b10", "#e9b949"],
          ].map(([bg, accent], i) => (
            <span
              key={bg}
              className="flex h-16 w-10 flex-col items-center justify-end gap-1 rounded-md border border-white/10 pb-2"
              style={{ background: bg, animation: `float 5s ease-in-out ${i * 0.3}s infinite` }}
            >
              <span className="h-1.5 w-6 rounded-full" style={{ background: accent }} />
              <span className="h-1.5 w-4 rounded-full opacity-60" style={{ background: accent }} />
            </span>
          ))}
        </Frame>
      );
    case "blocks":
      return (
        <Frame>
          <div className="grid grid-cols-4 gap-1.5">
            {Array.from({ length: 8 }, (_, i) => (
              <span
                key={i}
                className={`h-6 rounded-[3px] ${i % 3 === 0 ? "w-14 bg-brand-500/70" : "w-6 bg-ink-700"}`}
                style={cycle(i * 0.18, 6)}
              />
            ))}
          </div>
        </Frame>
      );
    case "stats":
      return (
        <Frame className="items-end gap-1.5 px-5 pb-4">
          {[38, 52, 44, 66, 58, 80, 72, 95, 84, 100].map((h, i) => (
            <span
              key={i}
              className="w-4 origin-bottom rounded-t-[2px] bg-gradient-to-t from-brand-600 to-brand-300"
              style={{ height: `${h * 0.72}px`, animation: `ui-bar 1.8s var(--ease-out-expo) ${i * 0.12}s infinite alternate` }}
            />
          ))}
        </Frame>
      );
  }
}
