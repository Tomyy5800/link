"use client";

import { useEffect, useRef, useState } from "react";
import { Check, Link2, Palette, Radio, Share2, UserRound } from "lucide-react";
import type { AutomationBanner } from "@/lib/automations";
import { ALL_FEATURES } from "@/lib/features";
import type { OwnerProfile, PageView } from "@/lib/page-schema";
import { getPreset } from "@/lib/theme";
import { smoothScrollTo } from "@/lib/scroll";
import { PageRenderer } from "@/components/page/PageRenderer";
import type { PageExtras } from "@/components/page/types";

type Demo = { page: PageView; owner: OwnerProfile; extras: PageExtras };

const STEPS = [
  { icon: UserRound, kicker: "Ton profil", title: "Ton nom, ton avatar, ta bio.", text: "Connecte-toi, ou laisse l'assistant IA tout préparer en discutant : ton pseudo, ton avatar et ta bannière sont repris tout seuls." },
  { icon: Link2, kicker: "Tes liens", title: "Tous tes réseaux, en un clic.", text: "Colle une adresse : la plateforme est reconnue et son icône s'ajoute. Glisse les blocs pour les ranger." },
  { icon: Palette, kicker: "Ton style", title: "Un thème, et tout change.", text: "Douze ambiances, des polices, des effets animés, une mosaïque sur grand écran. Tu peux tout retoucher." },
  { icon: Radio, kicker: "Une page vivante", title: "Elle se met à jour toute seule.", text: "En live ? Un bandeau apparaît. Ton anniversaire ? Confettis. Les visites se comptent sous tes yeux." },
  { icon: Share2, kicker: "Partage", title: "Un seul lien, partout.", text: "Bio Discord, Twitch, TikTok, Instagram : colle ton lien, ou affiche le QR code en fin de stream." },
];

const LIVE: AutomationBanner = { id: "story-live", text: "En live maintenant : viens dire bonjour !", style: "live", url: "https://twitch.tv" };

/**
 * « Ta page en cinq gestes » : la section reste fixée pendant le défilement et la page se construit
 * dans le téléphone, étape par étape. Changements d'état seulement (pas d'animation liée au
 * défilement image par image) : fluide même sur un petit appareil.
 */
export function BuildStory({ demo, host }: { demo: Demo; host: string }) {
  const sectionRef = useRef<HTMLElement>(null);
  const [step, setStep] = useState(0);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    let frame = 0;
    const measure = () => {
      frame = 0;
      const section = sectionRef.current;
      if (!section) return;
      const rect = section.getBoundingClientRect();
      const total = rect.height - window.innerHeight;
      const p = Math.min(1, Math.max(0, -rect.top / Math.max(1, total)));
      setProgress(p);
      setStep(Math.min(STEPS.length - 1, Math.floor(p * STEPS.length * 0.999)));
    };
    const onScroll = () => {
      if (!frame) frame = requestAnimationFrame(measure);
    };
    measure();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      cancelAnimationFrame(frame);
    };
  }, []);

  // La page du téléphone, selon l'étape.
  const links = demo.page.blocks.filter((b) => b.type === "socials" || b.type === "link");
  const styled = step >= 2 ? { ...(getPreset("aurora")?.theme ?? demo.page.theme), width: "narrow" as const } : demo.page.theme;
  const page: PageView = { ...demo.page, theme: styled, blocks: step >= 1 ? links : [] };

  const jump = (index: number) => {
    const section = sectionRef.current;
    if (!section) return;
    const total = section.offsetHeight - window.innerHeight;
    smoothScrollTo(section.offsetTop + (total * (index + 0.5)) / STEPS.length);
  };

  return (
    <section ref={sectionRef} id="comment" className="relative scroll-mt-20" style={{ height: `${STEPS.length * 85 + 40}vh` }} aria-label="Ta page en cinq gestes">
      <div className="sticky top-0 flex h-dvh items-center overflow-hidden">
        {/* Halo qui prend la couleur de l'étape */}
        <div
          className="pointer-events-none absolute top-1/2 right-[12%] h-[620px] w-[620px] -translate-y-1/2 rounded-full opacity-40 blur-3xl transition-[background] duration-1000"
          style={{ background: `radial-gradient(closest-side, ${styled.accent}66, transparent)` }}
          aria-hidden="true"
        />
        <div className="relative mx-auto grid w-full max-w-6xl grid-cols-1 items-center gap-8 px-4 sm:px-6 lg:grid-cols-[1fr_400px] lg:gap-16">
          <div>
            <p className="hud-label text-claim">Ta page en cinq gestes</p>
            {/* Rail de progression : on peut cliquer une étape */}
            <ol className="mt-5 flex gap-2" aria-label="Étapes">
              {STEPS.map((s, i) => {
                const Icon = s.icon;
                const state = i < step ? "done" : i === step ? "current" : "next";
                return (
                  <li key={s.kicker} className="flex-1">
                    <button
                      type="button"
                      onClick={() => jump(i)}
                      aria-current={state === "current" ? "step" : undefined}
                      className="group w-full text-left"
                      title={s.kicker}
                    >
                      <span className="block h-1 overflow-hidden rounded-full bg-ink-700">
                        <span
                          className="block h-full rounded-full bg-gradient-to-r from-brand-500 to-claim transition-[width] duration-300"
                          style={{ width: state === "done" ? "100%" : state === "current" ? `${Math.max(8, (progress * STEPS.length - i) * 100)}%` : "0%" }}
                        />
                      </span>
                      <span
                        className={`mt-2 hidden items-center gap-1.5 text-[11px] font-semibold transition-colors sm:flex ${
                          state === "next" ? "text-ink-500 group-hover:text-ink-300" : "text-ink-100"
                        }`}
                      >
                        {state === "done" ? <Check size={12} className="text-mint" /> : <Icon size={12} className={state === "current" ? "text-brand-300" : ""} />}
                        {s.kicker}
                      </span>
                    </button>
                  </li>
                );
              })}
            </ol>
            {/* Textes empilés : celui de l'étape en cours apparaît, les autres s'effacent */}
            <div className="relative mt-5 min-h-[170px] sm:mt-8 sm:min-h-[220px]">
              {STEPS.map((s, i) => (
                <div
                  key={s.kicker}
                  className="absolute inset-0 transition-[opacity,transform,filter] duration-700 ease-[cubic-bezier(0.16,1,0.3,1)]"
                  style={{
                    opacity: i === step ? 1 : 0,
                    transform: i === step ? "none" : i < step ? "translateY(-24px)" : "translateY(24px)",
                    filter: i === step ? "none" : "blur(6px)",
                  }}
                  aria-hidden={i !== step}
                >
                  <p className="font-mono text-sm text-brand-300">0{i + 1}</p>
                  <h2 className="mt-2 font-display text-3xl font-bold tracking-tight text-balance sm:text-5xl">{s.title}</h2>
                  <p className="mt-3 max-w-md leading-relaxed text-ink-300 sm:mt-4 sm:text-lg">{s.text}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Le téléphone */}
          <div className="relative mx-auto w-full max-w-[300px] sm:max-w-[400px]">
            <div className="hud-panel relative overflow-hidden rounded-[2.2rem] border border-ink-600 bg-ink-900 p-2 shadow-[0_30px_60px_-24px_#000000dd]">
              <div className="relative h-[40dvh] overflow-hidden rounded-[1.8rem] sm:h-[min(68vh,620px)]">
                <PageRenderer
                  page={page}
                  owner={demo.owner}
                  context={{ features: ALL_FEATURES, verified: true, blockedDomains: [] }}
                  extras={demo.extras}
                  banners={step >= 3 ? [LIVE] : []}
                  mode="demo"
                  bare
                />
                {/* Balayage lumineux à chaque étape */}
                <span key={step} className="ui-scan pointer-events-none absolute inset-0" aria-hidden="true" />
                {/* Étape 5 : carte de partage */}
                <div
                  className={`absolute inset-x-4 bottom-4 rounded-2xl border border-white/15 bg-ink-950/90 p-4 shadow-2xl backdrop-blur transition-[opacity,transform] duration-500 ease-[cubic-bezier(0.34,1.56,0.64,1)] ${
                    step >= 4 ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-8 opacity-0"
                  }`}
                  aria-hidden={step < 4}
                >
                  <div className="flex items-center gap-3">
                    <span className="grid h-16 w-16 shrink-0 grid-cols-5 gap-0.5 rounded-lg bg-white p-1.5" aria-hidden="true">
                      {Array.from({ length: 25 }, (_, i) => (
                        <span key={i} className={`rounded-[1px] ${[0, 1, 2, 4, 5, 7, 9, 10, 12, 13, 15, 18, 19, 20, 22, 23, 24].includes(i) ? "bg-ink-950" : ""}`} />
                      ))}
                    </span>
                    <div className="min-w-0">
                      <p className="truncate font-mono text-sm text-brand-300">
                        {host}/{demo.page.slug}
                      </p>
                      <p className="mt-1 inline-flex items-center gap-1 rounded-full bg-mint/15 px-2 py-0.5 text-[11px] font-semibold text-mint">
                        <Check size={11} /> Lien copié
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
