"use client";

import { useEffect, useId, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Check, CircleAlert, LoaderCircle, Sparkles } from "lucide-react";
import { confetti } from "@/lib/confetti";
import { SLUG_MAX, validateSlug } from "@/lib/slug";

type Status =
  | { kind: "idle" }
  | { kind: "checking" }
  | { kind: "free"; slug: string }
  | { kind: "taken"; message: string; suggestions: string[] }
  | { kind: "invalid"; message: string };

const EXAMPLES = ["kaelis", "nation-blue", "team-orion", "lyxia", "le-bastion", "studio.nova"];

/** Garde ce que la saisie peut devenir : minuscules, chiffres et séparateurs. */
function tidy(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/\s+/g, "-")
    .replace(/[^a-z0-9._-]/g, "")
    .slice(0, SLUG_MAX);
}

async function isFree(slug: string, signal: AbortSignal): Promise<{ available: boolean; error?: string }> {
  const res = await fetch(`/api/slugs/check?slug=${encodeURIComponent(slug)}`, { signal });
  if (res.status === 429) return { available: false, error: "Doucement : réessaie dans quelques secondes." };
  return (await res.json()) as { available: boolean; error?: string };
}

/** Exemples qui s'écrivent tout seuls dans le champ vide. */
function useTypedPlaceholder(active: boolean): string {
  const [text, setText] = useState(EXAMPLES[0]);
  useEffect(() => {
    if (!active || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let word = 0;
    let length = EXAMPLES[0].length;
    let deleting = true;
    let timer = 0;
    const step = () => {
      if (deleting) {
        length--;
        if (length === 0) {
          deleting = false;
          word = (word + 1) % EXAMPLES.length;
        }
      } else {
        length++;
      }
      const target = EXAMPLES[word];
      setText(target.slice(0, length));
      let delay = deleting ? 40 : 85;
      if (!deleting && length === target.length) {
        deleting = true;
        delay = 1800;
      }
      timer = window.setTimeout(step, delay);
    };
    timer = window.setTimeout(step, 1800);
    return () => window.clearTimeout(timer);
  }, [active]);
  return text;
}

/**
 * « Revendique ton adresse » : le visiteur tape le lien qu'il veut, la disponibilité s'affiche
 * en direct, avec des variantes libres si elle est prise. Le bouton mène à la création de la
 * page (après connexion), l'adresse déjà remplie.
 */
export function ClaimBox({
  host,
  loggedIn,
  size = "lg",
  autoFocus = false,
  initialValue = "",
}: {
  host: string;
  loggedIn: boolean;
  size?: "lg" | "md";
  autoFocus?: boolean;
  /** Adresse déjà saisie (page 404 : l'adresse visitée). */
  initialValue?: string;
}) {
  const router = useRouter();
  const inputId = useId();
  const statusId = useId();
  const boxRef = useRef<HTMLFormElement>(null);
  const [value, setValue] = useState(() => tidy(initialValue));
  const [focused, setFocused] = useState(false);
  const [status, setStatus] = useState<Status>({ kind: "idle" });
  const [going, setGoing] = useState(false);
  const celebrated = useRef<string | null>(null);
  const placeholder = useTypedPlaceholder(!focused && value === "");

  useEffect(() => {
    if (!value) {
      setStatus({ kind: "idle" });
      return;
    }
    const local = validateSlug(value);
    if (!local.ok) {
      setStatus({ kind: "invalid", message: local.error });
      return;
    }
    const controller = new AbortController();
    setStatus({ kind: "checking" });
    const timer = window.setTimeout(async () => {
      try {
        const result = await isFree(local.slug, controller.signal);
        if (result.available) {
          setStatus({ kind: "free", slug: local.slug });
          if (celebrated.current !== local.slug && boxRef.current) {
            celebrated.current = local.slug;
            confetti({ origin: boxRef.current, count: 36, spread: 110, power: 0.75 });
          }
          return;
        }
        // Prise : on cherche quelques variantes libres.
        const base = local.slug.slice(0, SLUG_MAX - 4);
        const candidates = [`${base}-tv`, `${base}-off`, `its-${base}`.slice(0, SLUG_MAX), `${base}${new Date().getFullYear() % 100}`, `le-${base}`.slice(0, SLUG_MAX)];
        const suggestions: string[] = [];
        for (const candidate of candidates) {
          if (suggestions.length >= 3 || !validateSlug(candidate).ok) continue;
          const check = await isFree(candidate, controller.signal).catch(() => ({ available: false }));
          if (check.available) suggestions.push(candidate);
        }
        setStatus({ kind: "taken", message: result.error ?? "Cette adresse est déjà prise.", suggestions });
      } catch {
        // requête annulée : une saisie plus récente a pris le relais
      }
    }, 380);
    return () => {
      window.clearTimeout(timer);
      controller.abort();
    };
  }, [value]);

  function claim(event: React.FormEvent) {
    event.preventDefault();
    if (status.kind !== "free") return;
    setGoing(true);
    try {
      localStorage.setItem("lbu:claim", status.slug);
    } catch {
      // stockage indisponible : l'adresse passe quand même dans l'URL
    }
    const target = `/dashboard/nouvelle?adresse=${encodeURIComponent(status.slug)}`;
    router.push(loggedIn ? target : `/login?next=${encodeURIComponent(target)}`);
  }

  const large = size === "lg";
  const tone =
    status.kind === "free" ? "border-mint/70 shadow-[0_0_0_4px_rgb(0_188_125/0.15)]" : status.kind === "taken" || status.kind === "invalid" ? "border-danger/60" : focused ? "border-brand-400 shadow-[0_0_0_4px_rgb(34_201_232/0.15)]" : "border-ink-500";

  return (
    <form ref={boxRef} onSubmit={claim} className="w-full max-w-xl" aria-label="Revendiquer une adresse">
      <label htmlFor={inputId} className="sr-only">
        Adresse de ta page
      </label>
      <div className={`flex items-center gap-2 rounded-xl border bg-ink-900/90 p-1.5 pl-4 backdrop-blur transition-[border-color,box-shadow] duration-300 ${tone}`}>
        <span className={`shrink-0 font-mono text-ink-400 ${large ? "text-base" : "text-sm"}`}>{host}/</span>
        <input
          id={inputId}
          value={value}
          onChange={(e) => setValue(tidy(e.target.value))}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          placeholder={placeholder}
          autoFocus={autoFocus}
          autoComplete="off"
          autoCapitalize="off"
          spellCheck={false}
          maxLength={SLUG_MAX}
          aria-describedby={statusId}
          aria-invalid={status.kind === "invalid" || status.kind === "taken" ? true : undefined}
          className={`w-0 min-w-0 flex-1 bg-transparent font-mono font-semibold text-brand-300 outline-none placeholder:text-ink-600 focus-visible:shadow-none focus-visible:outline-none ${large ? "py-2.5 text-base" : "py-2 text-sm"}`}
        />
        <span className="flex w-6 shrink-0 justify-center" aria-hidden="true">
          {status.kind === "checking" && <LoaderCircle size={18} className="animate-spin text-ink-400" />}
          {status.kind === "free" && <Check size={18} className="animate-pop text-mint" />}
          {(status.kind === "taken" || status.kind === "invalid") && <CircleAlert size={18} className="animate-pop text-danger" />}
        </span>
        <button
          type="submit"
          disabled={status.kind !== "free" || going}
          className={`ui-press ui-shine inline-flex shrink-0 items-center gap-2 rounded-lg bg-brand-500 font-semibold text-ink-950 transition hover:bg-brand-400 disabled:cursor-not-allowed disabled:bg-ink-700 disabled:text-ink-400 ${large ? "px-4 py-2.5" : "px-3 py-2 text-sm"}`}
        >
          {going ? <LoaderCircle size={17} className="animate-spin" /> : <Sparkles size={17} />}
          <span className="hidden sm:inline">Revendiquer</span>
        </button>
      </div>
      <div id={statusId} aria-live="polite" className="mt-2.5 min-h-6 text-sm">
        {status.kind === "idle" && <p className="text-ink-400">Tape l&apos;adresse que tu veux : on te dit tout de suite si elle est libre.</p>}
        {status.kind === "checking" && <p className="text-ink-400">Vérification…</p>}
        {status.kind === "invalid" && <p className="text-danger">{status.message}</p>}
        {status.kind === "free" && (
          <p className="animate-rise font-medium text-mint">
            {host}/{status.slug} est libre. Revendique-la avant quelqu&apos;un d&apos;autre !
          </p>
        )}
        {status.kind === "taken" && (
          <div className="animate-rise flex flex-wrap items-center gap-2">
            <span className="text-danger">{status.message}</span>
            {status.suggestions.length > 0 && <span className="text-ink-400">Libres :</span>}
            {status.suggestions.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setValue(s)}
                className="ui-press rounded-md border border-mint/40 bg-mint/10 px-2 py-0.5 font-mono text-xs text-mint hover:bg-mint/20"
              >
                {s}
              </button>
            ))}
          </div>
        )}
      </div>
    </form>
  );
}
