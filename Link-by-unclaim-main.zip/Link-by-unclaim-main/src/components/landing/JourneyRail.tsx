"use client";

import { useEffect, useState } from "react";

/** Les étapes du parcours de l'accueil, dans l'ordre de la page. */
const CHAPTERS = [
  { id: "accueil", label: "Ta page" },
  { id: "comment", label: "Comment ça marche" },
  { id: "fonctionnalites", label: "Fonctionnalités" },
  { id: "integrations", label: "Intégrations" },
  { id: "modeles", label: "Modèles" },
  { id: "linkplus", label: "Link+" },
  { id: "questions", label: "Questions" },
  { id: "commencer", label: "C'est parti" },
] as const;

/**
 * Rail de parcours de l'accueil (grands écrans) : une ligne qui se remplit au défilement et un
 * point par étape. L'étape en cours grossit et affiche son nom un instant ; un clic y mène en
 * douceur (ancres gérées par le défilement amorti). Les autres noms apparaissent au survol.
 */
export function JourneyRail({ premiumName }: { premiumName: string }) {
  const [active, setActive] = useState(0);

  useEffect(() => {
    const onScroll = () => {
      const line = window.innerHeight * 0.45;
      let current = 0;
      CHAPTERS.forEach(({ id }, index) => {
        const top = document.getElementById(id)?.getBoundingClientRect().top;
        if (top !== undefined && top <= line) current = index;
      });
      setActive(current);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  return (
    <nav aria-label="Parcours de la page" className="fixed top-1/2 right-5 z-30 hidden -translate-y-1/2 xl:block">
      <div className="relative">
        {/* Ligne du parcours, remplie selon le défilement de la page (repli : elle suit l'étape en cours) */}
        <span className="pointer-events-none absolute top-1.5 bottom-1.5 left-1/2 w-px -translate-x-1/2 bg-white/10" aria-hidden="true">
          <span
            className="ui-journey-fill absolute inset-0 origin-top bg-gradient-to-b from-brand-400 via-brand-300 to-claim transition-transform duration-700"
            style={{ transform: `scaleY(${active / (CHAPTERS.length - 1)})` }}
          />
        </span>
        <ol className="relative flex flex-col gap-5">
          {CHAPTERS.map(({ id, label }, index) => {
            const state = index === active ? "active" : index < active ? "done" : "next";
            const name = id === "linkplus" ? premiumName : label;
            return (
              <li key={id} className="group relative flex items-center justify-center">
                <a
                  href={`#${id}`}
                  aria-current={state === "active" ? "step" : undefined}
                  className={`relative flex h-3 w-3 items-center justify-center rounded-full transition-all duration-500 ${
                    state === "active"
                      ? "scale-150 bg-brand-300 shadow-[0_0_0_4px_rgba(34,201,232,0.18),0_0_18px_#22c9e8]"
                      : state === "done"
                        ? "bg-brand-500/80 hover:bg-brand-400"
                        : "border border-white/25 bg-ink-950 hover:border-white/60"
                  }`}
                >
                  <span className="sr-only">
                    {String(index + 1).padStart(2, "0")} · {name}
                  </span>
                </a>
                <span
                  key={state === "active" ? `on-${index}` : "off"}
                  className={`pointer-events-none absolute right-6 flex items-center gap-2 rounded-full border border-white/10 bg-ink-950/80 px-3 py-1 text-xs font-semibold whitespace-nowrap backdrop-blur-md transition-opacity duration-300 ${
                    state === "active" ? "ui-journey-label text-ink-50" : "text-ink-300 opacity-0 group-hover:opacity-100"
                  }`}
                  aria-hidden="true"
                >
                  <span className="font-mono text-[10px] text-brand-300">{String(index + 1).padStart(2, "0")}</span>
                  {name}
                </span>
              </li>
            );
          })}
        </ol>
      </div>
    </nav>
  );
}
