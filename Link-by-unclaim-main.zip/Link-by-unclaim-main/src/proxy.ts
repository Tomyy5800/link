import { NextResponse, type NextRequest } from "next/server";
import { hostFromHeaders, isCustomHost, siteHost } from "./lib/custom-host";

// Domaines personnels : une requête arrivée sur un autre nom d'hôte que celui du site
// (APP_URL) est réécrite vers /domaine/<hôte>, qui affiche la page reliée à ce domaine après
// vérification en base. Inactif tant que CUSTOM_DOMAIN_CNAME ou CUSTOM_DOMAIN_IPV4 n'est pas
// défini : sans configuration, le site se comporte exactement comme avant.
// Les routes /api et les fichiers statiques ne sont jamais réécrits.
export function proxy(request: NextRequest) {
  const headers = new Headers(request.headers);
  // Cet en-tête n'est posé que par le proxy : une valeur envoyée par le navigateur est ignorée.
  headers.delete("x-lbu-domain");
  const enabled = Boolean((process.env.CUSTOM_DOMAIN_CNAME ?? "").trim() || (process.env.CUSTOM_DOMAIN_IPV4 ?? "").trim());
  const host = hostFromHeaders(request.headers);
  if (!enabled || !isCustomHost(host, siteHost(process.env.APP_URL))) return NextResponse.next({ request: { headers } });

  headers.set("x-lbu-domain", host);
  const url = request.nextUrl.clone();
  const path = request.nextUrl.pathname === "/" ? "" : request.nextUrl.pathname;
  url.pathname = `/domaine/${encodeURIComponent(host)}${path}`;
  return NextResponse.rewrite(url, { request: { headers } });
}

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico|icon.svg|manifest.webmanifest|robots.txt|sitemap.xml).*)"],
};
