// Défilement programmé : passe par Lenis quand il amortit la page (pages vitrine), sinon par le
// défilement natif du navigateur.

type Scroller = { scrollTo: (target: number, options?: { duration?: number }) => void };

let current: Scroller | null = null;

export function registerScroller(scroller: Scroller | null): void {
  current = scroller;
}

export function smoothScrollTo(top: number): void {
  if (current) current.scrollTo(top, { duration: 1.2 });
  else window.scrollTo({ top, behavior: "smooth" });
}
