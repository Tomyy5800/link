// Assistant de création (partagé serveur / navigateur) : une conversation de quelques questions
// qui produit un brouillon de page, prévisualisé en direct puis créé en un clic.
//
// Deux moteurs produisent le même brouillon : Claude (langage naturel, si une clé API est
// configurée) et un assistant guidé local, sans dépendance externe. Le brouillon est toujours
// nettoyé ici avant d'être affiché ou enregistré : rien de ce qu'il contient n'est cru sur parole.
import { createBlock, type Block } from "./blocks";
import { GAME_IDS, gameInfo, type GameId } from "./games";
import { THEME_PRESETS, getPreset, parseTheme, type Theme } from "./theme";
import { detectPlatform, isValidMcUsername, normalizeUrl, parseDiscordInvite } from "./urls";

export const ASSISTANT_TEMPLATES = ["joueur", "streamer", "createur", "communaute", "minimal"] as const;
export type AssistantTemplate = (typeof ASSISTANT_TEMPLATES)[number];

export type AssistantDraft = {
  displayName: string;
  pronouns: string;
  /** Présentation (mise en forme Discord autorisée). */
  bio: string;
  /** Adresse proposée (validée à la création). */
  slug: string;
  template: AssistantTemplate;
  /** Thème de départ (clé de THEME_PRESETS). */
  preset: string;
  links: { label: string; url: string; emoji: string }[];
  /** Profils sur les réseaux (adresses complètes). */
  socials: string[];
  games: { game: GameId; username: string; rank: string }[];
  ngUsername: string;
  discordInvite: string;
  /** IP d'un serveur de jeu, à copier en un clic. */
  serverIp: string;
  radio: boolean;
  /** Anniversaire « MM-JJ » (compte à rebours qui revient chaque année). */
  birthday: string;
  contact: boolean;
  events: boolean;
};

export type ChatMessage = { role: "user" | "assistant"; content: string };

export type AssistantTurn = {
  reply: string;
  /** Réponses rapides proposées sous la conversation. */
  quickReplies: string[];
  draft: AssistantDraft;
  /** Assez d'informations pour créer la page. */
  ready: boolean;
};

export const MAX_ASSISTANT_MESSAGES = 24;
export const MAX_ASSISTANT_CHARS = 1500;

export const EMPTY_DRAFT: Readonly<AssistantDraft> = {
  displayName: "",
  pronouns: "",
  bio: "",
  slug: "",
  template: "minimal",
  preset: "unclaim",
  links: [],
  socials: [],
  games: [],
  ngUsername: "",
  discordInvite: "",
  serverIp: "",
  radio: false,
  birthday: "",
  contact: false,
  events: false,
};

const TEMPLATE_PRESET: Record<AssistantTemplate, string> = {
  joueur: "nations",
  streamer: "neon",
  createur: "aurora",
  communaute: "unclaim",
  minimal: "midnight",
};

const str = (v: unknown, max: number) => (typeof v === "string" ? v.replace(/\s+/g, " ").trim().slice(0, max) : "");

/** Adresse https publique, ou rien. */
function safeUrl(v: unknown): string {
  const url = normalizeUrl(str(v, 500));
  return url && /^https:\/\//.test(url) ? url : "";
}

/** Nettoie un brouillon venu du modèle ou du navigateur : longueurs, adresses, valeurs connues. */
export function sanitizeDraft(raw: unknown): AssistantDraft {
  const d = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const template = ASSISTANT_TEMPLATES.includes(d.template as AssistantTemplate) ? (d.template as AssistantTemplate) : "minimal";
  const preset = typeof d.preset === "string" && getPreset(d.preset) ? d.preset : TEMPLATE_PRESET[template];
  const links = (Array.isArray(d.links) ? d.links : [])
    .map((l) => {
      const o = (l && typeof l === "object" ? l : {}) as Record<string, unknown>;
      return { label: str(o.label, 60), url: safeUrl(o.url), emoji: str(o.emoji, 8) };
    })
    .filter((l) => l.url)
    .slice(0, 8);
  const socials = [...new Set((Array.isArray(d.socials) ? d.socials : []).map(safeUrl).filter(Boolean))].slice(0, 12);
  const games = (Array.isArray(d.games) ? d.games : [])
    .map((g) => {
      const o = (g && typeof g === "object" ? g : {}) as Record<string, unknown>;
      const game = GAME_IDS.includes(o.game as GameId) ? (o.game as GameId) : null;
      return game ? { game, username: str(o.username, 60), rank: str(o.rank, 40) } : null;
    })
    .filter((g): g is AssistantDraft["games"][number] => g !== null && g.username !== "")
    .slice(0, 4);
  const ng = str(d.ngUsername, 16);
  const invite = str(d.discordInvite, 120);
  const birthday = str(d.birthday, 5);
  return {
    displayName: str(d.displayName, 48),
    pronouns: str(d.pronouns, 24),
    bio: typeof d.bio === "string" ? d.bio.trim().slice(0, 280) : "",
    slug: str(d.slug, 30).toLowerCase().replace(/[^a-z0-9-]/g, ""),
    template,
    preset,
    links,
    socials,
    games,
    ngUsername: isValidMcUsername(ng) ? ng : "",
    discordInvite: parseDiscordInvite(invite) ? invite : "",
    serverIp: str(d.serverIp, 100).replace(/[^\w.:-]/g, ""),
    radio: d.radio === true,
    birthday: /^(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/.test(birthday) ? birthday : "",
    contact: d.contact === true,
    events: d.events === true,
  };
}

/** Page construite à partir du brouillon : profil, thème et blocs (validés par les schémas habituels). */
export function buildPageFromDraft(draft: AssistantDraft, ctx: { hasDiscord: boolean }): {
  displayName: string;
  pronouns: string;
  bio: string;
  preset: string;
  theme: Theme;
  blocks: Block[];
} {
  const base = getPreset(draft.preset)?.theme ?? parseTheme({});
  const grid = draft.template === "joueur" || draft.template === "streamer" || draft.template === "communaute";
  const theme: Theme = grid ? { ...base, layout: "grid", width: "wide" } : base;
  const blocks: Block[] = [];
  const half = <T extends Block>(b: T): T => ({ ...b, width: "half" });

  if (ctx.hasDiscord && draft.template !== "communaute") blocks.push(createBlock("discord", {}));
  if (draft.socials.length) {
    blocks.push(createBlock("socials", { items: draft.socials.map((url) => ({ platform: detectPlatform(url), url })), style: draft.socials.length > 5 ? "icons" : "pills" }));
  }
  draft.links.forEach((link, i) => {
    const live = draft.template === "streamer" && i === 0 && /twitch|kick|youtube/.test(link.url);
    blocks.push(
      createBlock("link", {
        label: link.label || new URL(link.url).hostname.replace(/^www\./, ""),
        url: link.url,
        emoji: link.emoji,
        highlight: live,
        animation: live ? "pulse" : "none",
      }),
    );
  });
  if (draft.discordInvite) blocks.push(createBlock("discordServer", { invite: draft.discordInvite, note: draft.template === "communaute" ? "Rejoins-nous" : "" }));
  if (draft.serverIp) blocks.push(createBlock("copy", { label: "IP du serveur", value: draft.serverIp }));
  if (draft.ngUsername) {
    blocks.push(half(createBlock("nationsglory", { username: draft.ngUsername })), half(createBlock("skin", { username: draft.ngUsername, animation: "idle" })));
  }
  for (const g of draft.games) {
    blocks.push(createBlock("game", { game: g.game, username: g.username, rank: g.rank }));
  }
  if (draft.events) blocks.push(createBlock("events", { title: draft.template === "streamer" ? "Planning des streams" : "Prochains événements" }));
  if (draft.radio) blocks.push(createBlock("radio", { station: "lyxia" }));
  if (draft.birthday) blocks.push(createBlock("countdown", { mode: "birthday", birthday: draft.birthday, title: "Mon anniversaire" }));
  if (draft.contact) blocks.push(createBlock("contact", { title: draft.template === "communaute" ? "Recrutement et partenariats" : "Me contacter" }));
  if (!blocks.length) blocks.push(createBlock("socials", { items: [] }), createBlock("link", { label: "Mon site", url: "" }));

  return { displayName: draft.displayName, pronouns: draft.pronouns, bio: draft.bio, preset: draft.preset, theme, blocks };
}

// ─── Assistant guidé local (sans clé API) ──────────────────────────────────

const MONTHS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];

const GAME_ALIASES: [RegExp, GameId | "nationsglory"][] = [
  [/nations\s?glory|\bng\b/i, "nationsglory"],
  [/minecraft|\bmc\b/i, "minecraft"],
  [/paladium/i, "paladium"],
  [/hypixel/i, "hypixel"],
  [/wolfy/i, "wolfy"],
  [/chess(?:\.com)?|échecs/i, "chesscom"],
  [/lichess/i, "lichess"],
  [/steam/i, "steam"],
  [/roblox/i, "roblox"],
  [/valorant|valo\b/i, "valorant"],
  [/league of legends|\blol\b/i, "lol"],
  [/fortnite/i, "fortnite"],
  [/rocket\s?league|\brl\b/i, "rocketleague"],
  [/brawl\s?stars/i, "brawlstars"],
  [/clash\s?royale/i, "clashroyale"],
  [/\bosu!?/i, "osu"],
  [/genshin/i, "genshin"],
];

const SOCIAL_HANDLES: [RegExp, (h: string) => string][] = [
  [/\btwitch\b/i, (h) => `https://twitch.tv/${h}`],
  [/\btiktok\b/i, (h) => `https://www.tiktok.com/@${h}`],
  [/\binsta(?:gram)?\b/i, (h) => `https://instagram.com/${h}`],
  [/\byoutube\b|\byt\b/i, (h) => `https://youtube.com/@${h}`],
  [/\btwitter\b/i, (h) => `https://x.com/${h}`],
  [/\bkick\b/i, (h) => `https://kick.com/${h}`],
];

const PRESET_WORDS: [RegExp, string][] = [
  [/néon|neon|fluo|flashy/i, "neon"],
  [/sakura|rose|japon|kawaii|pastel/i, "sakura"],
  [/aurore|doux|calme|nature|vert/i, "aurora"],
  [/océan|ocean|mer|bleu|eau/i, "ocean"],
  [/arcade|rétro|retro|pixel|8.?bit/i, "arcade"],
  [/cyber|futur|tech|hacker/i, "cyber"],
  [/papier|clair|blanc|minimal|sobre|simple/i, "paper"],
  [/couchant|orange|chaud|soleil/i, "sunset"],
  [/royaume|médiéval|medieval|or\b|roi|fantasy/i, "royaume"],
  [/nations|guerre|militaire|carte/i, "nations"],
  [/sombre|noir|nuit|minuit|dark/i, "midnight"],
  [/unclaim|défaut|peu importe|comme tu veux/i, "unclaim"],
];

function detectTemplate(text: string): AssistantTemplate {
  if (/nations\s?glory|\bng\b|\bpays\b|\bnation\b|faction|paladium/i.test(text)) return "joueur";
  if (/stream|twitch|kick|\blive\b|en direct/i.test(text)) return "streamer";
  if (/serveur|communaut|équipe|equipe|\bteam\b|asso|clan|guilde|e-?sport|staff|recrut/i.test(text)) return "communaute";
  if (/musique|vidéo|video|youtube|tiktok|dessin|art|photo|créat|creat|podcast|montage/i.test(text)) return "createur";
  return "minimal";
}

function extractUrls(text: string): string[] {
  const found = text.match(/(?:https?:\/\/|www\.)[^\s,;<>"']+|\b(?:discord\.gg|twitch\.tv|tiktok\.com|instagram\.com|youtube\.com|youtu\.be|x\.com|twitter\.com|kick\.com|github\.com|bsky\.app)\/[^\s,;<>"']+/gi) ?? [];
  return found.map((u) => normalizeUrl(u.replace(/[.)]+$/, ""))).filter((u): u is string => Boolean(u) && /^https:\/\//.test(u!));
}

function extractBirthday(text: string): string {
  const m = text.match(/(\d{1,2})(?:er)?\s+(janvier|février|fevrier|mars|avril|mai|juin|juillet|août|aout|septembre|octobre|novembre|décembre|decembre)/i);
  if (!m) return "";
  const month = MONTHS.findIndex((name) => name.normalize("NFD").replace(/\p{M}/gu, "") === m[2].toLowerCase().normalize("NFD").replace(/\p{M}/gu, "")) + 1;
  const day = Number(m[1]);
  if (!month || day < 1 || day > 31) return "";
  return `${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

/** Jeux et pseudos dans une phrase libre : « Minecraft Notch, Paladium Steve, Valorant Kae#EUW ». */
export function extractGames(text: string): { games: AssistantDraft["games"]; ngUsername: string } {
  const games: AssistantDraft["games"] = [];
  let ngUsername = "";
  for (const part of text.split(/[,;\n]|\bet\b/)) {
    for (const [alias, game] of GAME_ALIASES) {
      const m = part.match(new RegExp(`(?:${alias.source})\\s*[:\\-–]?\\s*(?:en tant que |pseudo |sous le pseudo )?@?([\\w#.\\-]{2,40})`, "i"));
      if (!m) continue;
      const username = m[1];
      if (/^(et|je|j|moi|aussi|sur|le|la|les|non)$/i.test(username)) continue;
      if (game === "nationsglory") {
        if (isValidMcUsername(username)) ngUsername = username;
      } else if (!games.some((g) => g.game === game)) {
        games.push({ game, username, rank: "" });
      }
      break;
    }
  }
  return { games: games.slice(0, 4), ngUsername };
}

const QUESTIONS = [
  "Quel nom veux-tu afficher en haut de ta page ?",
  "Présente-toi en une ou deux phrases : que fais-tu ? (stream, NationsGlory, serveur, musique, création…)",
  "Colle tes liens : réseaux, Discord, site… Tu peux aussi écrire « twitch kaelis, tiktok kaelis ». Sinon, réponds « aucun ».",
  "Tu joues à quoi ? Écris le jeu et ton pseudo, par exemple « Minecraft Notch, Paladium Steve, NationsGlory Kaelis ». Sinon, « non ».",
  "Dernière question : quelle ambiance pour ta page ? (néon, sombre, pastel, rétro, océan…)",
];

/** Un tour de l'assistant guidé : le brouillon est recalculé à partir de toute la conversation. */
export function localAssistantTurn(messages: ChatMessage[], ctx: { name: string }): AssistantTurn {
  const answers = messages.filter((m) => m.role === "user").map((m) => m.content.trim());
  // Brouillon neuf : les listes ne doivent jamais être partagées avec EMPTY_DRAFT.
  const draft: AssistantDraft = { ...EMPTY_DRAFT, links: [], socials: [], games: [] };
  const skip = (v: string | undefined) => !v || /^(non|aucun|aucune|rien|passer|skip|-)$/i.test(v.trim());

  draft.displayName = answers[0] ? answers[0].split("\n")[0].slice(0, 48) : ctx.name.slice(0, 48);
  if (answers[1] && !skip(answers[1])) {
    draft.bio = answers[1].slice(0, 280);
    draft.template = detectTemplate(answers[1]);
    draft.birthday = extractBirthday(answers[1]);
    draft.radio = /radio|lyxia/i.test(answers[1]);
    draft.contact = /contact|partenariat|recrut|collab|business|pro\b/i.test(answers[1]) || draft.template === "communaute";
    draft.events = /planning|agenda|événement|evenement|tournoi|soirée/i.test(answers[1]) || draft.template === "streamer";
    const ip = answers[1].match(/\b(?:play|mc|jouer)\.[a-z0-9-]+\.[a-z]{2,}\b/i);
    if (ip) draft.serverIp = ip[0];
  }
  draft.preset = TEMPLATE_PRESET[draft.template];

  // Liens : toute la conversation (on peut en ajouter à tout moment), plus « plateforme pseudo ».
  const urls = extractUrls(answers.join("\n"));
  if (answers[2] && !skip(answers[2])) {
    for (const part of answers[2].split(/[,;\n]/)) {
      if (/https?:\/\/|\.\w{2,}\//.test(part)) continue;
      for (const [re, build] of SOCIAL_HANDLES) {
        const m = part.match(new RegExp(`(?:${re.source})\\s*[:\\-]?\\s*@?([A-Za-z0-9_.]{2,30})`, "i"));
        if (m) {
          urls.push(build(m[1]));
          break;
        }
      }
    }
  }
  for (const url of [...new Set(urls)]) {
    if (parseDiscordInvite(url)) {
      draft.discordInvite ||= url;
      continue;
    }
    const platform = detectPlatform(url);
    if (platform === "website" || platform === "email") {
      draft.links.push({ label: new URL(url).hostname.replace(/^www\./, ""), url, emoji: "🔗" });
    } else {
      draft.socials.push(url);
    }
  }
  // Streamer : le live en premier bouton.
  const live = draft.socials.find((u) => /twitch\.tv|kick\.com/.test(u));
  if (draft.template === "streamer" && live) draft.links.unshift({ label: "Regarder le live", url: live, emoji: "🔴" });

  if (answers[3] && !skip(answers[3])) {
    const { games, ngUsername } = extractGames(answers.slice(3).join("\n"));
    draft.games = games;
    draft.ngUsername = ngUsername;
    if ((games.length || ngUsername) && draft.template === "minimal") draft.template = ngUsername ? "joueur" : "createur";
  }
  if (answers[4]) draft.preset = PRESET_WORDS.find(([re]) => re.test(answers[4]))?.[1] ?? draft.preset;

  const step = Math.min(answers.length, QUESTIONS.length);
  const ready = answers.length >= QUESTIONS.length;
  const clean = sanitizeDraft(draft);

  if (answers.length === 0) {
    return {
      reply: `Salut ${ctx.name} ! Je crée ta page avec toi en cinq questions, deux minutes chrono. ${QUESTIONS[0]}`,
      quickReplies: [ctx.name].filter(Boolean),
      draft: clean,
      ready: false,
    };
  }
  if (!ready) {
    const intro = step === 1 ? `Enchanté, ${clean.displayName} ! ` : step === 2 ? "Noté. " : step === 3 ? "Parfait, c'est ajouté. " : "Super. ";
    const quick: string[][] = [
      [],
      ["Je stream sur Twitch", "Je joue à NationsGlory", "Je gère un serveur Discord", "Je crée des vidéos"],
      ["Aucun"],
      ["Non", "Minecraft …", "NationsGlory …"],
      THEME_PRESETS.slice(0, 6).map((p) => p.label),
    ];
    return { reply: intro + QUESTIONS[step], quickReplies: quick[step] ?? [], draft: clean, ready: false };
  }
  return {
    reply:
      answers.length === QUESTIONS.length
        ? "Ta page est prête ! Regarde l'aperçu, choisis ton adresse et crée-la : tu pourras tout ajuster ensuite dans l'éditeur. Tu peux encore m'envoyer des liens ou des jeux à ajouter."
        : "C'est ajouté si c'était un lien ou un jeu. Pour le reste, crée ta page : l'éditeur te laisse tout modifier.",
    quickReplies: [],
    draft: clean,
    ready: true,
  };
}

/** Résumé lisible d'un brouillon (liste de ce qui sera créé). */
export function describeDraft(draft: AssistantDraft): string[] {
  const out: string[] = [];
  if (draft.socials.length) out.push(`${draft.socials.length} réseau${draft.socials.length > 1 ? "x" : ""}`);
  if (draft.links.length) out.push(`${draft.links.length} lien${draft.links.length > 1 ? "s" : ""}`);
  if (draft.discordInvite) out.push("serveur Discord");
  if (draft.ngUsername) out.push(`profil NationsGlory (${draft.ngUsername})`);
  for (const g of draft.games) out.push(`${gameInfo(g.game).name} (${g.username})`);
  if (draft.serverIp) out.push("IP du serveur");
  if (draft.events) out.push("agenda");
  if (draft.radio) out.push("radio");
  if (draft.birthday) out.push("anniversaire");
  if (draft.contact) out.push("formulaire de contact");
  return out;
}
