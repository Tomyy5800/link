// Programme partenaires (partagé serveur / navigateur) : profils acceptés et avantages.

export const PARTNER_KINDS = {
  createur: "Créateur ou streamer",
  serveur: "Serveur de jeu ou communauté Discord",
  nation: "Pays ou faction (NationsGlory, Paladium…)",
  esport: "Équipe e-sport ou structure de jeu",
  association: "Association ou événement",
  marque: "Marque ou média",
  autre: "Autre",
} as const;

export type PartnerKind = keyof typeof PARTNER_KINDS;
export const PARTNER_KIND_KEYS = Object.keys(PARTNER_KINDS) as PartnerKind[];

/** Avantages affichés sur /partenaires et dans « Mon espace » (les limites viennent des réglages). */
export function partnerPerks(limits: { pages: number; members: number }, premiumName: string): { title: string; text: string }[] {
  return [
    { title: "Badge « Partenaire officiel »", text: "À côté de ton nom, sur toutes tes pages." },
    { title: `${premiumName} inclus`, text: "Toutes les fonctions avancées, sans paiement, tant que le partenariat dure." },
    { title: `${limits.pages} pages et ${limits.members} collaborateurs`, text: "Une page par projet, par équipe ou par événement, gérées à plusieurs." },
    { title: "Mise en avant", text: "Ta page dans l'annuaire des partenaires et, au choix de l'équipe, sur l'accueil." },
    { title: "Contact direct", text: "Un interlocuteur de l'équipe pour tes idées, tes besoins et tes événements." },
  ];
}

export const PARTNER_STATUS_LABELS = { pending: "En cours d'examen", accepted: "Acceptée", refused: "Refusée" } as const;
