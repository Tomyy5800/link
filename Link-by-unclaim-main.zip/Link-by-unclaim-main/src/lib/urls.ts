// Utilitaires d'URL partagés entre serveur et navigateur.
// Toute URL fournie par un utilisateur passe par ici avant d'être enregistrée ou affichée.

const DOMAIN_LIKE = /^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?([/?#].*)?$/i;

/**
 * Normalise une URL saisie par l'utilisateur.
 * - "" reste "" (champ vide autorisé pendant l'édition)
 * - "exemple.fr/x" devient "https://exemple.fr/x"
 * - seules les URL http(s) et mailto: sont acceptées ; le reste renvoie null.
 */
export function normalizeUrl(input: string): string | null {
  const value = input.trim();
  if (!value) return "";
  if (value.length > 2048) return null;

  if (/^mailto:/i.test(value)) {
    const address = value.slice(7);
    return /^[^\s@<>()]+@[^\s@<>()]+\.[^\s@<>()]+$/.test(address) ? `mailto:${address}` : null;
  }

  let candidate = value;
  if (!/^[a-z][a-z0-9+.-]*:/i.test(candidate)) {
    if (candidate.startsWith("//") || !DOMAIN_LIKE.test(candidate)) return null;
    candidate = `https://${candidate}`;
  }

  try {
    const url = new URL(candidate);
    if (url.protocol !== "http:" && url.protocol !== "https:") return null;
    if (!url.hostname) return null;
    return url.toString();
  } catch {
    return null;
  }
}

/** Retourne un href sûr pour l'affichage, ou null si l'URL n'est pas utilisable. */
export function toSafeHref(input: string | null | undefined): string | null {
  if (!input) return null;
  const normalized = normalizeUrl(input);
  return normalized ? normalized : null;
}

/** URL d'image : http(s) ou image importée sur la plateforme (/api/uploads/…). */
export function normalizeImageUrl(input: string): string | null {
  const value = input.trim();
  if (!value) return "";
  if (/^\/api\/uploads\/[a-z0-9]+$/i.test(value)) return value;
  const normalized = normalizeUrl(value);
  if (normalized === null || normalized.startsWith("mailto:")) return null;
  return normalized;
}

export function toSafeImageSrc(input: string | null | undefined): string | null {
  if (!input) return null;
  const normalized = normalizeImageUrl(input);
  return normalized ? normalized : null;
}

export function hostnameOf(input: string): string {
  try {
    return new URL(input).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
}

// ─── Plateformes sociales ────────────────────────────────────────────────────

export const PLATFORMS = {
  discord: { label: "Discord", hosts: ["discord.gg", "discord.com", "discordapp.com"] },
  youtube: { label: "YouTube", hosts: ["youtube.com", "youtu.be", "m.youtube.com"] },
  twitch: { label: "Twitch", hosts: ["twitch.tv", "m.twitch.tv"] },
  kick: { label: "Kick", hosts: ["kick.com"] },
  tiktok: { label: "TikTok", hosts: ["tiktok.com"] },
  instagram: { label: "Instagram", hosts: ["instagram.com"] },
  x: { label: "X (Twitter)", hosts: ["x.com", "twitter.com"] },
  bluesky: { label: "Bluesky", hosts: ["bsky.app"] },
  threads: { label: "Threads", hosts: ["threads.net", "threads.com"] },
  reddit: { label: "Reddit", hosts: ["reddit.com"] },
  github: { label: "GitHub", hosts: ["github.com"] },
  spotify: { label: "Spotify", hosts: ["open.spotify.com", "spotify.com"] },
  soundcloud: { label: "SoundCloud", hosts: ["soundcloud.com"] },
  steam: { label: "Steam", hosts: ["steamcommunity.com", "store.steampowered.com"] },
  patreon: { label: "Patreon", hosts: ["patreon.com"] },
  kofi: { label: "Ko-fi", hosts: ["ko-fi.com"] },
  paypal: { label: "PayPal", hosts: ["paypal.me", "paypal.com"] },
  telegram: { label: "Telegram", hosts: ["t.me", "telegram.me"] },
  snapchat: { label: "Snapchat", hosts: ["snapchat.com"] },
  facebook: { label: "Facebook", hosts: ["facebook.com", "fb.com"] },
  pinterest: { label: "Pinterest", hosts: ["pinterest.com", "pinterest.fr"] },
  nationsglory: { label: "NationsGlory", hosts: ["nationsglory.fr"] },
  email: { label: "E-mail", hosts: [] },
  website: { label: "Site web", hosts: [] },
} as const satisfies Record<string, { label: string; hosts: readonly string[] }>;

export type Platform = keyof typeof PLATFORMS;
export const PLATFORM_KEYS = Object.keys(PLATFORMS) as Platform[];

export function isPlatform(value: string): value is Platform {
  return Object.prototype.hasOwnProperty.call(PLATFORMS, value);
}

/** Devine la plateforme d'une URL à partir de son domaine. */
export function detectPlatform(input: string): Platform {
  if (/^mailto:/i.test(input.trim())) return "email";
  const host = hostnameOf(normalizeUrl(input) ?? "");
  if (!host) return "website";
  for (const key of PLATFORM_KEYS) {
    const hosts: readonly string[] = PLATFORMS[key].hosts;
    if (hosts.some((h) => host === h || host.endsWith(`.${h}`))) return key;
  }
  return "website";
}

// ─── Intégrations (iframes) ──────────────────────────────────────────────────

/** Jeton remplacé dans le navigateur par le domaine de la page (exigé par Twitch). */
export const PARENT_TOKEN = "__LBU_PARENT__";

export type EmbedInfo = {
  provider: string;
  label: string;
  src: string;
  /** Rapport largeur / hauteur (ex. "16 / 9") ou hauteur fixe en px. */
  aspect?: string;
  height?: number;
};

const yt = (id: string): EmbedInfo => ({ provider: "youtube", label: "YouTube", src: `https://www.youtube-nocookie.com/embed/${id}`, aspect: "16 / 9" });

/**
 * Transforme une URL publique en URL d'intégration pour une liste fermée de fournisseurs.
 * Toute autre URL renvoie null : elle n'est intégrable qu'en mode « iframe libre ».
 */
export function toEmbed(input: string): EmbedInfo | null {
  const normalized = normalizeUrl(input);
  if (!normalized || normalized.startsWith("mailto:")) return null;
  let url: URL;
  try {
    url = new URL(normalized);
  } catch {
    return null;
  }
  const host = url.hostname.replace(/^(www|m)\./, "");
  const parts = url.pathname.split("/").filter(Boolean);
  const ytId = /^[\w-]{11}$/;

  // YouTube (vidéo, short, direct, playlist)
  if (host === "youtu.be" && parts[0] && ytId.test(parts[0])) return yt(parts[0]);
  if (host === "youtube.com" || host === "music.youtube.com") {
    const v = url.searchParams.get("v");
    if (parts[0] === "watch" && v && ytId.test(v)) return yt(v);
    if (["shorts", "live", "embed"].includes(parts[0] ?? "") && parts[1] && ytId.test(parts[1])) return yt(parts[1]);
    const list = url.searchParams.get("list");
    if (parts[0] === "playlist" && list && /^[\w-]{10,64}$/.test(list)) {
      return { provider: "youtube", label: "YouTube", src: `https://www.youtube-nocookie.com/embed/videoseries?list=${list}`, aspect: "16 / 9" };
    }
  }

  // Twitch (chaîne, vidéo, clip, chat)
  const tw = (path: string): EmbedInfo => ({ provider: "twitch", label: "Twitch", src: path, aspect: "16 / 9" });
  if (host === "clips.twitch.tv" && parts[0] && /^[\w-]{3,100}$/.test(parts[0])) {
    return tw(`https://clips.twitch.tv/embed?clip=${parts[0]}&parent=${PARENT_TOKEN}`);
  }
  if (host === "twitch.tv") {
    if (parts[0] === "videos" && parts[1] && /^\d+$/.test(parts[1])) return tw(`https://player.twitch.tv/?video=${parts[1]}&parent=${PARENT_TOKEN}&autoplay=false`);
    if (parts[1] === "clip" && parts[2] && /^[\w-]{3,100}$/.test(parts[2])) return tw(`https://clips.twitch.tv/embed?clip=${parts[2]}&parent=${PARENT_TOKEN}`);
    if (parts[1] === "chat" && /^\w{3,25}$/.test(parts[0] ?? "")) {
      return { provider: "twitch", label: "Chat Twitch", src: `https://www.twitch.tv/embed/${parts[0].toLowerCase()}/chat?parent=${PARENT_TOKEN}&darkpopout`, height: 480 };
    }
    if (parts.length === 1 && /^\w{3,25}$/.test(parts[0])) return tw(`https://player.twitch.tv/?channel=${parts[0].toLowerCase()}&parent=${PARENT_TOKEN}&autoplay=false&muted=true`);
  }

  // Kick
  if (host === "kick.com" && parts.length === 1 && /^[\w-]{2,30}$/.test(parts[0])) {
    return { provider: "kick", label: "Kick", src: `https://player.kick.com/${parts[0].toLowerCase()}?autoplay=false`, aspect: "16 / 9" };
  }

  // Spotify
  if (host === "open.spotify.com") {
    const p = parts[0]?.startsWith("intl-") ? parts.slice(1) : parts;
    const [type, id] = p;
    if (type && id && /^(track|album|playlist|episode|show|artist)$/.test(type) && /^[A-Za-z0-9]{10,40}$/.test(id)) {
      return { provider: "spotify", label: "Spotify", src: `https://open.spotify.com/embed/${type}/${id}`, height: type === "track" || type === "episode" ? 152 : 352 };
    }
  }

  // Deezer
  if (host === "deezer.com") {
    const p = /^[a-z]{2}$/.test(parts[0] ?? "") ? parts.slice(1) : parts;
    const [type, id] = p;
    if (type && id && /^(track|album|playlist|artist)$/.test(type) && /^\d{1,15}$/.test(id)) {
      return { provider: "deezer", label: "Deezer", src: `https://widget.deezer.com/widget/dark/${type}/${id}`, height: type === "track" ? 152 : 380 };
    }
  }

  // Apple Music
  if (host === "music.apple.com" && parts.length >= 3 && /^[a-z]{2}$/.test(parts[0]) && /^(album|playlist|song)$/.test(parts[1])) {
    const tail = parts.map(encodeURIComponent).join("/");
    return { provider: "applemusic", label: "Apple Music", src: `https://embed.music.apple.com/${tail}${url.search}`, height: parts[1] === "song" ? 175 : 450 };
  }

  // SoundCloud
  if (host === "soundcloud.com" && parts.length >= 2) {
    const clean = `https://soundcloud.com/${parts.join("/")}`;
    return { provider: "soundcloud", label: "SoundCloud", src: `https://w.soundcloud.com/player/?url=${encodeURIComponent(clean)}&visual=false&show_comments=false`, height: 166 };
  }

  // Vimeo
  if (host === "vimeo.com" && parts[0] && /^\d{5,12}$/.test(parts[0])) {
    return { provider: "vimeo", label: "Vimeo", src: `https://player.vimeo.com/video/${parts[0]}`, aspect: "16 / 9" };
  }

  // Dailymotion
  if ((host === "dailymotion.com" && parts[0] === "video" && parts[1]) || (host === "dai.ly" && parts[0])) {
    const id = (host === "dai.ly" ? parts[0] : parts[1]).split("_")[0];
    if (/^[a-zA-Z0-9]{5,12}$/.test(id)) return { provider: "dailymotion", label: "Dailymotion", src: `https://www.dailymotion.com/embed/video/${id}`, aspect: "16 / 9" };
  }

  // Streamable
  if (host === "streamable.com" && parts[0] && /^[a-z0-9]{4,12}$/i.test(parts[0])) {
    return { provider: "streamable", label: "Streamable", src: `https://streamable.com/e/${parts[0]}`, aspect: "16 / 9" };
  }

  // TikTok
  if (host === "tiktok.com" && parts[1] === "video" && parts[2] && /^\d{8,25}$/.test(parts[2])) {
    return { provider: "tiktok", label: "TikTok", src: `https://www.tiktok.com/embed/v2/${parts[2]}`, height: 740 };
  }

  // X (Twitter)
  if ((host === "x.com" || host === "twitter.com") && parts[1] === "status" && parts[2] && /^\d{5,25}$/.test(parts[2])) {
    return { provider: "x", label: "Post X", src: `https://platform.twitter.com/embed/Tweet.html?id=${parts[2]}&theme=dark&dnt=true`, height: 560 };
  }

  // Instagram
  if (host === "instagram.com" && (parts[0] === "p" || parts[0] === "reel") && parts[1] && /^[\w-]{5,40}$/.test(parts[1])) {
    return { provider: "instagram", label: "Instagram", src: `https://www.instagram.com/${parts[0]}/${parts[1]}/embed`, height: 620 };
  }

  // Widget de serveur Discord (Paramètres du serveur → Widget)
  if ((host === "discord.com" || host === "discordapp.com") && parts[0] === "widget") {
    const id = url.searchParams.get("id");
    if (id && /^\d{15,22}$/.test(id)) {
      return { provider: "discordwidget", label: "Widget Discord", src: `https://discord.com/widget?id=${id}&theme=dark`, height: 420 };
    }
  }

  // Google Maps (lien « Intégrer une carte »)
  if (host === "google.com" && parts[0] === "maps" && parts[1] === "embed") {
    return { provider: "maps", label: "Google Maps", src: normalized, aspect: "4 / 3" };
  }

  return null;
}

/** URL finale d'une intégration : remplace le domaine parent exigé par Twitch. */
export function resolveEmbedSrc(src: string, parentHost: string): string {
  return src.split(PARENT_TOKEN).join(encodeURIComponent(parentHost));
}

/** URL acceptée en mode « iframe libre » : https uniquement. */
export function toCustomFrame(input: string): string | null {
  const normalized = normalizeUrl(input);
  if (!normalized || !normalized.startsWith("https://")) return null;
  return normalized;
}

// ─── Invitations Discord ─────────────────────────────────────────────────────

/** Extrait le code d'une invitation Discord (discord.gg/abc, discord.com/invite/abc ou abc). */
export function parseDiscordInvite(input: string): string | null {
  const value = input.trim();
  if (!value) return null;
  const match =
    value.match(/^(?:https?:\/\/)?(?:www\.)?(?:discord\.gg|discord(?:app)?\.com\/invite)\/([a-zA-Z0-9-]{2,32})\/?$/) ??
    value.match(/^([a-zA-Z0-9-]{2,32})$/);
  return match ? match[1] : null;
}

// ─── Minecraft / NationsGlory ────────────────────────────────────────────────

export const MC_USERNAME = /^[A-Za-z0-9_]{2,16}$/;

export function isValidMcUsername(value: string): boolean {
  return MC_USERNAME.test(value);
}
