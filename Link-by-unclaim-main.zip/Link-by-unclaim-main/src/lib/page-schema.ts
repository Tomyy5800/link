// Forme des données d'une page, partagée entre l'API, le rendu public et l'éditeur.
import { z } from "zod";
import { DEFAULT_TIMEZONE, MAX_AUTOMATIONS, automationSchema, isValidTimeZone } from "./automations";
import type { PublicBadge } from "./badges";
import { MAX_BLOCKS, blockSchema, type Block } from "./blocks";
import { MAX_CUSTOM_CSS } from "./css";
import type { FeatureFlags } from "./features";
import { themeSchema, type Theme } from "./theme";
import { MC_USERNAME, normalizeImageUrl } from "./urls";

const imageUrl = z
  .string()
  .max(2048)
  .refine((v) => normalizeImageUrl(v) !== null, "URL d'image invalide")
  .transform((v) => normalizeImageUrl(v) ?? "");

export const profileSchema = z.object({
  displayName: z.string().trim().min(1, "Le nom affiché est obligatoire.").max(48),
  pronouns: z.string().trim().max(40).default(""),
  bio: z.string().max(600).default(""),
  avatarSource: z.enum(["discord", "nationsglory", "custom"]).default("discord"),
  avatarUrl: imageUrl.default(""),
  bannerUrl: imageUrl.default(""),
  ngUsername: z
    .string()
    .trim()
    .max(16)
    .refine((v) => v === "" || MC_USERNAME.test(v), "Pseudo NationsGlory invalide (2 à 16 caractères : lettres, chiffres, _).")
    .default(""),
  /** Serveur NationsGlory principal (slug de l'API v1). */
  ngServer: z.string().regex(/^[a-z0-9-]{2,24}$/, "Serveur invalide").default("blue"),
});

export type Profile = z.infer<typeof profileSchema>;

/** Options de la page : référencement, partage, avertissement 18+, redirection temporaire. */
export const pageOptionsSchema = z.object({
  /** Titre affiché dans Google et les aperçus de lien (vide : le nom affiché). */
  seoTitle: z.string().trim().max(70).default(""),
  /** Description pour Google et les aperçus de lien (vide : la présentation). */
  seoDescription: z.string().trim().max(160).default(""),
  /** Ne pas apparaître dans les moteurs de recherche. */
  noindex: z.boolean().default(false),
  /** Bouton « Partager » en haut de la page. */
  shareButton: z.boolean().default(true),
  /** Avertissement « contenu réservé aux 18 ans et plus » avant d'afficher la page. */
  ageGate: z.boolean().default(false),
  /** Redirection temporaire (live, sortie…) : https uniquement. */
  redirectUrl: z
    .string()
    .trim()
    .max(2048)
    .refine((v) => v === "" || /^https:\/\/[^\s]+$/.test(v), "Adresse https attendue")
    .default(""),
  /** Fin de la redirection (vide : jusqu'à désactivation). */
  redirectUntil: z
    .string()
    .max(40)
    .refine((v) => v === "" || !Number.isNaN(Date.parse(v)), "Date invalide")
    .default(""),
  /** Automatisations : règles « quand… alors… » évaluées à l'affichage. */
  automations: z.array(automationSchema).max(MAX_AUTOMATIONS, `${MAX_AUTOMATIONS} automatisations au maximum`).default([]),
  /** Fuseau horaire des automatisations (créneaux, anniversaire). */
  timezone: z.string().max(60).refine(isValidTimeZone, "Fuseau horaire inconnu").default(DEFAULT_TIMEZONE),
  /** Après un changement d'adresse, les anciennes adresses redirigent vers la nouvelle. */
  redirectOldSlugs: z.boolean().default(true),
});

export type PageOptions = z.infer<typeof pageOptionsSchema>;
export const DEFAULT_PAGE_OPTIONS: PageOptions = pageOptionsSchema.parse({});

export function parsePageOptions(raw: string | null | undefined): PageOptions {
  try {
    const value = JSON.parse(raw || "{}") as Record<string, unknown>;
    const parsed = pageOptionsSchema.safeParse(value);
    if (parsed.success) return parsed.data;
    // Une règle devenue invalide ne doit pas faire perdre les autres réglages : on la retire.
    const automations = Array.isArray(value.automations)
      ? value.automations.filter((r) => automationSchema.safeParse(r).success).slice(0, MAX_AUTOMATIONS)
      : [];
    const retry = pageOptionsSchema.safeParse({ ...value, automations, timezone: isValidTimeZone(String(value.timezone ?? "")) ? value.timezone : DEFAULT_TIMEZONE });
    return retry.success ? retry.data : DEFAULT_PAGE_OPTIONS;
  } catch {
    return DEFAULT_PAGE_OPTIONS;
  }
}

/** La redirection est-elle active à cet instant ? */
export function activeRedirect(options: PageOptions, now = Date.now()): string | null {
  if (!options.redirectUrl) return null;
  if (options.redirectUntil && Date.parse(options.redirectUntil) <= now) return null;
  return options.redirectUrl;
}

/** Corps accepté par PUT /api/me/page (sauvegarde complète depuis l'éditeur). */
export const pageSaveSchema = z.object({
  profile: profileSchema,
  theme: themeSchema,
  published: z.boolean(),
  customCss: z.string().max(MAX_CUSTOM_CSS, `${MAX_CUSTOM_CSS} caractères de CSS maximum.`).default(""),
  options: pageOptionsSchema.default(DEFAULT_PAGE_OPTIONS),
  blocks: z
    .array(blockSchema)
    .max(MAX_BLOCKS, `${MAX_BLOCKS} blocs maximum.`)
    .refine((blocks) => new Set(blocks.map((b) => b.id)).size === blocks.length, "Identifiants de blocs en double."),
});

export type PageSaveInput = z.infer<typeof pageSaveSchema>;

/** Page telle qu'affichée (publique ou aperçu). */
export type PageView = {
  slug: string;
  profile: Profile;
  theme: Theme;
  blocks: Block[];
  published: boolean;
  views: number;
  customCss: string;
  options: PageOptions;
};

/** Ce que le rendu doit savoir du propriétaire, au-delà de son profil Discord. */
export type PageContext = {
  /** Fonctionnalités dont le propriétaire dispose (offre et réglages d'administration). */
  features: FeatureFlags;
  verified: boolean;
  /** Partenaire officiel de Link by Unclaim (badge à côté du nom). */
  partner?: boolean;
  /** Domaines interdits dans les intégrations. */
  blockedDomains: string[];
  /** Badges officiels du propriétaire, calculés par le serveur (vide : aucun). */
  badges?: PublicBadge[];
  /** Cadres d'avatar débloqués par le propriétaire (boutique officielle). */
  frames?: string[];
};

/** Profil du propriétaire, tel que synchronisé par Unclaim Auth (tous fournisseurs). */
export type OwnerProfile = {
  /** Compte Discord rattaché (null sans identité Discord : blocs Discord indisponibles). */
  discordId: string | null;
  /** Pseudo Discord, seul identifiant de compte affiché publiquement avec Twitch et NationsGlory. */
  discordUsername: string | null;
  /** Identifiant du compte de connexion (jamais affiché sur la page publique). */
  username: string;
  /** Nom affiché. */
  globalName: string | null;
  avatarUrl: string;
  bannerUrl: string | null;
  accentColor: string | null;
  /** Fournisseur de la dernière connexion. */
  provider: string;
  /** Pseudos publics des comptes rattachés (Discord, Twitch, NationsGlory). */
  handles: { provider: string; username: string }[];
  /** Pseudo NationsGlory prouvé par une connexion NationsGlory. */
  ngAccount: string | null;
};
