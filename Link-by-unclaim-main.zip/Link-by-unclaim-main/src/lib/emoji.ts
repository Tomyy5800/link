// Émojis façon Discord (partagé serveur / navigateur) : codes « :nom: » les plus courants
// et catégories du sélecteur de l'éditeur. Les émojis Unicode collés tels quels restent valables.

export const EMOJI_CATEGORIES: { id: string; label: string; emojis: [string, string][] }[] = [
  {
    id: "smileys",
    label: "Visages",
    emojis: [
      ["smile", "😄"], ["grin", "😁"], ["joy", "😂"], ["rofl", "🤣"], ["smiley", "😃"], ["sweat_smile", "😅"],
      ["laughing", "😆"], ["wink", "😉"], ["blush", "😊"], ["innocent", "😇"], ["slight_smile", "🙂"], ["upside_down", "🙃"],
      ["heart_eyes", "😍"], ["star_struck", "🤩"], ["kissing_heart", "😘"], ["yum", "😋"], ["stuck_out_tongue", "😛"], ["zany_face", "🤪"],
      ["sunglasses", "😎"], ["nerd", "🤓"], ["smirk", "😏"], ["thinking", "🤔"], ["shushing_face", "🤫"], ["neutral_face", "😐"],
      ["expressionless", "😑"], ["no_mouth", "😶"], ["rolling_eyes", "🙄"], ["grimacing", "😬"], ["relieved", "😌"], ["pensive", "😔"],
      ["sleepy", "😪"], ["sleeping", "😴"], ["mask", "😷"], ["nauseated_face", "🤢"], ["hot_face", "🥵"], ["cold_face", "🥶"],
      ["dizzy_face", "😵"], ["exploding_head", "🤯"], ["cowboy", "🤠"], ["partying_face", "🥳"], ["disguised_face", "🥸"], ["confused", "😕"],
      ["worried", "😟"], ["open_mouth", "😮"], ["astonished", "😲"], ["flushed", "😳"], ["pleading_face", "🥺"], ["cry", "😢"],
      ["sob", "😭"], ["scream", "😱"], ["triumph", "😤"], ["rage", "😡"], ["angry", "😠"], ["skull", "💀"],
      ["clown", "🤡"], ["poop", "💩"], ["ghost", "👻"], ["alien", "👽"], ["robot", "🤖"], ["smiling_imp", "😈"],
      ["saluting_face", "🫡"], ["melting_face", "🫠"], ["face_holding_back_tears", "🥹"], ["eyes", "👀"],
    ],
  },
  {
    id: "gestes",
    label: "Gestes",
    emojis: [
      ["wave", "👋"], ["ok_hand", "👌"], ["pinched_fingers", "🤌"], ["v", "✌️"], ["crossed_fingers", "🤞"], ["metal", "🤘"],
      ["call_me", "🤙"], ["point_right", "👉"], ["point_left", "👈"], ["point_up", "☝️"], ["point_down", "👇"], ["thumbsup", "👍"],
      ["+1", "👍"], ["thumbsdown", "👎"], ["-1", "👎"], ["fist", "✊"], ["punch", "👊"], ["clap", "👏"],
      ["raised_hands", "🙌"], ["open_hands", "👐"], ["handshake", "🤝"], ["pray", "🙏"], ["muscle", "💪"], ["writing_hand", "✍️"],
      ["nail_care", "💅"], ["brain", "🧠"], ["crown", "👑"], ["gem", "💎"],
    ],
  },
  {
    id: "coeurs",
    label: "Cœurs",
    emojis: [
      ["heart", "❤️"], ["orange_heart", "🧡"], ["yellow_heart", "💛"], ["green_heart", "💚"], ["blue_heart", "💙"], ["purple_heart", "💜"],
      ["black_heart", "🖤"], ["white_heart", "🤍"], ["brown_heart", "🤎"], ["broken_heart", "💔"], ["two_hearts", "💕"], ["sparkling_heart", "💖"],
      ["heartpulse", "💗"], ["heartbeat", "💓"], ["revolving_hearts", "💞"], ["cupid", "💘"], ["gift_heart", "💝"], ["heart_on_fire", "❤️‍🔥"],
      ["100", "💯"], ["anger", "💢"], ["boom", "💥"], ["dizzy", "💫"], ["sweat_drops", "💦"], ["zzz", "💤"],
    ],
  },
  {
    id: "jeu",
    label: "Jeu",
    emojis: [
      ["video_game", "🎮"], ["joystick", "🕹️"], ["crossed_swords", "⚔️"], ["dagger", "🗡️"], ["shield", "🛡️"], ["bow_and_arrow", "🏹"],
      ["pick", "⛏️"], ["axe", "🪓"], ["hammer", "🔨"], ["tools", "🛠️"], ["bomb", "💣"], ["gun", "🔫"],
      ["castle", "🏰"], ["european_castle", "🏰"], ["japanese_castle", "🏯"], ["crown", "👑"], ["trophy", "🏆"], ["medal", "🏅"],
      ["first_place", "🥇"], ["second_place", "🥈"], ["third_place", "🥉"], ["dart", "🎯"], ["game_die", "🎲"], ["chess_pawn", "♟️"],
      ["map", "🗺️"], ["compass", "🧭"], ["world_map", "🗺️"], ["flag_white", "🏳️"], ["flag_black", "🏴"], ["checkered_flag", "🏁"],
      ["triangular_flag_on_post", "🚩"], ["moneybag", "💰"], ["coin", "🪙"], ["scroll", "📜"], ["key", "🔑"], ["lock", "🔒"],
    ],
  },
  {
    id: "objets",
    label: "Objets",
    emojis: [
      ["fire", "🔥"], ["sparkles", "✨"], ["star", "⭐"], ["star2", "🌟"], ["zap", "⚡"], ["rainbow", "🌈"],
      ["sunny", "☀️"], ["crescent_moon", "🌙"], ["snowflake", "❄️"], ["ocean", "🌊"], ["rocket", "🚀"], ["airplane", "✈️"],
      ["tada", "🎉"], ["confetti_ball", "🎊"], ["balloon", "🎈"], ["gift", "🎁"], ["birthday", "🎂"], ["cake", "🍰"],
      ["notes", "🎶"], ["musical_note", "🎵"], ["headphones", "🎧"], ["microphone", "🎤"], ["radio", "📻"], ["guitar", "🎸"],
      ["movie_camera", "🎥"], ["camera", "📷"], ["tv", "📺"], ["computer", "💻"], ["keyboard", "⌨️"], ["mouse_three_button", "🖱️"],
      ["iphone", "📱"], ["calendar", "📅"], ["date", "📅"], ["clock", "🕐"], ["hourglass", "⏳"], ["alarm_clock", "⏰"],
      ["link", "🔗"], ["pushpin", "📌"], ["paperclip", "📎"], ["memo", "📝"], ["books", "📚"], ["bulb", "💡"],
      ["mega", "📣"], ["loudspeaker", "📢"], ["bell", "🔔"], ["mailbox", "📫"], ["envelope", "✉️"], ["shopping_cart", "🛒"],
      ["coffee", "☕"], ["pizza", "🍕"], ["hamburger", "🍔"], ["fries", "🍟"], ["beer", "🍺"], ["popcorn", "🍿"],
      ["dog", "🐶"], ["cat", "🐱"], ["fox", "🦊"], ["wolf", "🐺"], ["dragon", "🐉"], ["unicorn", "🦄"],
      ["butterfly", "🦋"], ["bee", "🐝"], ["seedling", "🌱"], ["evergreen_tree", "🌲"], ["cherry_blossom", "🌸"], ["rose", "🌹"],
    ],
  },
  {
    id: "symboles",
    label: "Symboles",
    emojis: [
      ["white_check_mark", "✅"], ["heavy_check_mark", "✔️"], ["x", "❌"], ["warning", "⚠️"], ["no_entry", "⛔"], ["question", "❓"],
      ["exclamation", "❗"], ["bangbang", "‼️"], ["arrow_right", "➡️"], ["arrow_left", "⬅️"], ["arrow_up", "⬆️"], ["arrow_down", "⬇️"],
      ["arrows_counterclockwise", "🔄"], ["new", "🆕"], ["free", "🆓"], ["up", "🆙"], ["cool", "🆒"], ["sos", "🆘"],
      ["red_circle", "🔴"], ["orange_circle", "🟠"], ["yellow_circle", "🟡"], ["green_circle", "🟢"], ["blue_circle", "🔵"], ["purple_circle", "🟣"],
      ["black_circle", "⚫"], ["white_circle", "⚪"], ["red_square", "🟥"], ["green_square", "🟩"], ["blue_square", "🟦"], ["yellow_square", "🟨"],
      ["copyright", "©️"], ["registered", "®️"], ["tm", "™️"], ["infinity", "♾️"], ["recycle", "♻️"], ["peace", "☮️"],
      ["flag_fr", "🇫🇷"], ["fr", "🇫🇷"], ["flag_be", "🇧🇪"], ["flag_ch", "🇨🇭"], ["flag_ca", "🇨🇦"], ["flag_us", "🇺🇸"],
      ["flag_gb", "🇬🇧"], ["flag_de", "🇩🇪"], ["flag_es", "🇪🇸"], ["flag_it", "🇮🇹"], ["flag_jp", "🇯🇵"], ["pirate_flag", "🏴‍☠️"],
    ],
  },
];

/** :code: → émoji, pour les codes les plus utilisés sur Discord. */
export const EMOJI_SHORTCODES: Record<string, string> = Object.fromEntries(EMOJI_CATEGORIES.flatMap((c) => c.emojis));

/** Remplace les codes connus (« :fire: ») par leur émoji ; les codes inconnus restent tels quels. */
export function replaceShortcodes(text: string): string {
  return text.replace(/:([a-z0-9_+-]{1,32}):/g, (match, name: string) => EMOJI_SHORTCODES[name] ?? match);
}
