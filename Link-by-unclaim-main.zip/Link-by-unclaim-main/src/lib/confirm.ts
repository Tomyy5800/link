// Confirmation avant une action importante, dans le style du site (au lieu de window.confirm).
// <ConfirmHost> (layout racine) l'affiche ; sans lui, la boîte native du navigateur prend le relais.

export type ConfirmOptions = {
  title: string;
  message?: string;
  confirmLabel?: string;
  cancelLabel?: string;
  /** « danger » : bouton rouge, focus sur « Annuler ». */
  tone?: "danger" | "default";
};

export type ConfirmRequest = ConfirmOptions & { resolve: (ok: boolean) => void };

export const CONFIRM_EVENT = "lbu:confirm";

export function confirmDialog(options: ConfirmOptions): Promise<boolean> {
  if (typeof window === "undefined") return Promise.resolve(false);
  return new Promise((resolve) => {
    const event = new CustomEvent<ConfirmRequest>(CONFIRM_EVENT, { detail: { ...options, resolve }, cancelable: true });
    // L'hôte annule l'événement pour le prendre en charge.
    if (window.dispatchEvent(event)) resolve(window.confirm(options.message ? `${options.title}\n\n${options.message}` : options.title));
  });
}
