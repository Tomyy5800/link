// Webradios (partagé serveur / navigateur) : stations préréglées, radios AzuraCast et flux https.
// Le flux est lu directement par le navigateur du visiteur ; le titre en cours vient de l'API
// publique AzuraCast (CORS ouvert), interrogée côté navigateur toutes les 20 secondes.

export type RadioStation = {
  id: string;
  name: string;
  tagline: string;
  /** Flux audio (https). */
  stream: string;
  /** API « titre en cours » AzuraCast, si la radio en a une. */
  nowPlaying: string | null;
  site: string | null;
  discord: string | null;
};

/** Radios proposées en un clic dans l'éditeur. */
export const RADIO_PRESETS: Record<string, RadioStation> = {
  lyxia: {
    id: "lyxia",
    name: "LyxiaRadio",
    tagline: "Envole-toi vers toujours plus de hits !",
    stream: "https://radio.helyxia.fr/listen/lyxia/radio.mp3",
    nowPlaying: "https://radio.helyxia.fr/api/nowplaying/lyxia",
    site: "https://lyxia.fr",
    discord: "https://discord.gg/lyxia",
  },
};

export const RADIO_PRESET_IDS = Object.keys(RADIO_PRESETS);

/**
 * Résout une radio à partir d'un identifiant préréglé ou d'une adresse :
 *  - page publique AzuraCast (https://hôte/public/<station>) ou flux AzuraCast (https://hôte/listen/<station>/…)
 *    → flux + API du titre en cours ;
 *  - tout autre flux https (Icecast, Shoutcast…) → lecture seule, sans titre en cours.
 */
export function resolveRadio(source: string, name = ""): RadioStation | null {
  const value = source.trim();
  if (!value) return null;
  const preset = RADIO_PRESETS[value];
  if (preset) return preset;

  let url: URL;
  try {
    url = new URL(value);
  } catch {
    return null;
  }
  if (url.protocol !== "https:" || url.username || url.password) return null;
  const azura = url.pathname.match(/^\/(?:public|listen)\/([a-z0-9_-]{1,64})(?:\/|$)/i);
  if (azura) {
    const station = azura[1].toLowerCase();
    return {
      id: `${url.host}/${station}`,
      name: name || station,
      tagline: "",
      stream: url.pathname.startsWith("/listen/") ? url.toString() : `${url.origin}/listen/${station}/radio.mp3`,
      nowPlaying: `${url.origin}/api/nowplaying/${station}`,
      site: url.pathname.startsWith("/public/") ? url.toString() : null,
      discord: null,
    };
  }
  return { id: url.toString(), name: name || url.hostname, tagline: "", stream: url.toString(), nowPlaying: null, site: null, discord: null };
}

/** Adresse acceptée pour une radio : identifiant préréglé ou https. */
export function isValidRadioSource(value: string): boolean {
  return value === "" || resolveRadio(value) !== null;
}

export type NowPlaying = {
  online: boolean;
  title: string | null;
  artist: string | null;
  art: string | null;
  elapsed: number | null;
  duration: number | null;
  listeners: number | null;
  live: { isLive: boolean; streamer: string | null };
  /** Flux annoncé par la radio (peut différer de l'adresse saisie). */
  stream: string | null;
  history: { title: string; artist: string }[];
};

const text = (v: unknown, max = 200) => (typeof v === "string" && v.trim() ? v.trim().slice(0, max) : null);
const num = (v: unknown) => (typeof v === "number" && Number.isFinite(v) ? v : null);
const httpsUrl = (v: unknown) => (typeof v === "string" && /^https:\/\//.test(v) ? v.slice(0, 1024) : null);

/** Réponse de GET /api/nowplaying/<station> (AzuraCast) → informations affichables. */
export function normalizeNowPlaying(raw: unknown): NowPlaying | null {
  if (!raw || typeof raw !== "object") return null;
  const r = raw as Record<string, Record<string, unknown> | undefined>;
  const song = (r.now_playing?.song ?? {}) as Record<string, unknown>;
  const live = (r.live ?? {}) as Record<string, unknown>;
  const history = Array.isArray(r.song_history) ? (r.song_history as { song?: Record<string, unknown> }[]) : [];
  return {
    online: (raw as { is_online?: unknown }).is_online !== false,
    title: text(song.title),
    artist: text(song.artist),
    art: httpsUrl(song.art),
    elapsed: num(r.now_playing?.elapsed),
    duration: num(r.now_playing?.duration),
    listeners: num((r.listeners ?? {}).current),
    live: { isLive: live.is_live === true, streamer: text(live.streamer_name, 60) },
    stream: httpsUrl((r.station ?? {}).listen_url),
    history: history
      .map((h) => ({ title: text(h.song?.title) ?? "", artist: text(h.song?.artist) ?? "" }))
      .filter((h) => h.title)
      .slice(0, 5),
  };
}
