// Boutique d'une page (partagé serveur / navigateur) : prix, panier et demandes de commande.
//
// Link by Unclaim n'encaisse rien pour les vendeurs : un produit renvoie soit vers la boutique
// du vendeur (Ko-fi, Shopify, Etsy, Tipeee…), soit vers une demande de commande qui arrive dans
// « Mon espace › Commandes ». Le paiement se règle ensuite entre le vendeur et l'acheteur.
import type { BlockData } from "./blocks";

export const SHOP_CURRENCIES = ["EUR", "USD", "GBP", "CHF", "CAD"] as const;
export type ShopCurrency = (typeof SHOP_CURRENCIES)[number];

export const MAX_PRODUCTS = 24;
/** Lignes différentes dans un panier, et quantité maximale par ligne. */
export const MAX_CART_LINES = 20;
export const MAX_QUANTITY = 20;
/** Stock en dessous duquel la vignette affiche « Plus que N ». */
export const LOW_STOCK = 5;

export type ShopProduct = BlockData<"shop">["products"][number];

/** Montant en centimes → « 12 € » ou « 12,50 € ». */
export function formatMoney(cents: number, currency: string): string {
  try {
    return new Intl.NumberFormat("fr-FR", { style: "currency", currency, minimumFractionDigits: cents % 100 === 0 ? 0 : 2 }).format(cents / 100);
  } catch {
    return `${(cents / 100).toFixed(2).replace(".", ",")} ${currency}`;
  }
}

/** Saisie libre (« 12,5 », « 12.50 € ») → centimes ; null si vide ou invalide. */
export function parsePrice(input: string): number | null {
  const cleaned = input.replace(/\s/g, "").replace(/[^\d,.]/g, "").replace(",", ".");
  if (!cleaned) return null;
  const value = Number(cleaned);
  if (!Number.isFinite(value) || value < 0 || value > 100_000) return null;
  return Math.round(value * 100);
}

/** Centimes → valeur d'un champ de saisie (« 12,50 », « 12 »). */
export function priceInput(cents: number | null): string {
  if (cents === null) return "";
  return (cents / 100).toFixed(2).replace(".", ",").replace(/,00$/, "");
}

/** Remise affichée sur la vignette (« -20 % »), seulement si l'ancien prix est plus élevé. */
export function discountPercent(price: number | null, compareAt: number | null): number | null {
  if (price === null || compareAt === null || compareAt <= price || compareAt === 0) return null;
  const percent = Math.round((1 - price / compareAt) * 100);
  return percent > 0 ? percent : null;
}

/** Variantes réellement proposées (les cases laissées vides sont ignorées). */
export function productOptions(product: Pick<ShopProduct, "options">): string[] {
  return product.options.map((o) => o.trim()).filter(Boolean);
}

/** Le produit peut-il être commandé ou acheté en ce moment ? */
export function isAvailable(product: Pick<ShopProduct, "soldOut" | "stock">): boolean {
  return !product.soldOut && product.stock !== 0;
}

/** Ligne de panier, côté visiteur. */
export type CartLine = { productId: string; option: string; quantity: number };

/** Article d'une commande enregistrée : nom et prix figés au moment de la demande. */
export type OrderItem = { productId: string; name: string; option: string; quantity: number; price: number | null };

/** Total d'une commande en centimes ; null dès qu'un article est à prix libre. */
export function orderTotal(items: Pick<OrderItem, "price" | "quantity">[]): number | null {
  let total = 0;
  for (const item of items) {
    if (item.price === null) return null;
    total += item.price * item.quantity;
  }
  return total;
}

/**
 * Confronte un panier aux produits du bloc : seuls les produits « sur commande » disponibles,
 * avec une variante proposée et une quantité raisonnable, sont acceptés. Les lignes identiques
 * sont regroupées.
 */
export function resolveCart(products: ShopProduct[], lines: CartLine[]): { items: OrderItem[] } | { error: string } {
  if (!lines.length) return { error: "Ton panier est vide." };
  if (lines.length > MAX_CART_LINES) return { error: "Trop d'articles différents dans le panier." };
  const merged = new Map<string, OrderItem>();
  for (const line of lines) {
    const product = products.find((p) => p.id !== "" && p.id === line.productId);
    if (!product || product.mode !== "order" || !product.name.trim()) return { error: "Un article n'est plus proposé : vide ton panier et recommence." };
    if (!isAvailable(product)) return { error: `« ${product.name} » n'est plus disponible.` };
    const options = productOptions(product);
    const option = options.length ? line.option : "";
    if (options.length && !options.includes(option)) return { error: `Choisis une option pour « ${product.name} ».` };
    if (!Number.isInteger(line.quantity) || line.quantity < 1 || line.quantity > MAX_QUANTITY) return { error: "Quantité invalide." };
    const key = `${product.id}\u0000${option}`;
    const previous = merged.get(key);
    const quantity = Math.min(MAX_QUANTITY, (previous?.quantity ?? 0) + line.quantity);
    if (product.stock !== null && quantity > product.stock) return { error: `Il ne reste que ${product.stock} « ${product.name} ».` };
    merged.set(key, { productId: product.id, name: product.name.trim(), option, quantity, price: product.price });
  }
  return { items: [...merged.values()] };
}

export const ORDER_STATUSES = ["new", "accepted", "done", "cancelled"] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];
export const ORDER_STATUS_LABEL: Record<OrderStatus, string> = {
  new: "Nouvelle",
  accepted: "Acceptée",
  done: "Terminée",
  cancelled: "Annulée",
};

export function isOrderStatus(value: string): value is OrderStatus {
  return (ORDER_STATUSES as readonly string[]).includes(value);
}

/** Articles d'une commande stockée (JSON) ; une valeur abîmée donne une liste vide. */
export function parseOrderItems(raw: string): OrderItem[] {
  try {
    const value = JSON.parse(raw) as unknown;
    if (!Array.isArray(value)) return [];
    return value
      .filter((i): i is Record<string, unknown> => typeof i === "object" && i !== null)
      .map((i) => ({
        productId: String(i.productId ?? ""),
        name: String(i.name ?? ""),
        option: String(i.option ?? ""),
        quantity: Number.isInteger(i.quantity) ? (i.quantity as number) : 1,
        price: typeof i.price === "number" ? i.price : null,
      }));
  } catch {
    return [];
  }
}

/** Produit complet à partir de quelques champs (exemples, nouveaux produits). */
export function makeProduct(fields: Partial<ShopProduct>): ShopProduct {
  return {
    id: "",
    name: "",
    description: "",
    price: null,
    compareAt: null,
    images: [],
    emoji: "",
    optionLabel: "Taille",
    options: [],
    badge: "",
    mode: "link",
    url: "",
    buttonLabel: "",
    stock: null,
    soldOut: false,
    ...fields,
  };
}

/** Identifiant court pour un nouveau produit. */
export function newProductId(): string {
  const random = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}${Math.random()}`;
  return `p-${random.replace(/[^a-z0-9]/gi, "").slice(0, 10).toLowerCase()}`;
}
