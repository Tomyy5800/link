// Formules de Link by Unclaim (partagé serveur / navigateur).
//
// Quatre paliers, du plus simple au plus complet. Chaque palier comprend tout ce que
// contiennent les précédents. Les partenaires officiels ont les fonctions du palier Équipe
// et leurs propres limites. Le raisonnement tarifaire est détaillé dans docs/TARIFS.md.

export const TIERS = ["free", "plus", "pro", "team"] as const;
export type Tier = (typeof TIERS)[number];
export type PaidTier = Exclude<Tier, "free">;
export const PAID_TIERS: PaidTier[] = ["plus", "pro", "team"];

export const TIER_RANK: Record<Tier, number> = { free: 0, plus: 1, pro: 2, team: 3 };

/** Valeur stockée → palier (« premium » est l'ancien nom de Link+, avant les formules). */
export function normalizeTier(value: string | null | undefined): Tier {
  if (value === "premium") return "plus";
  return (TIERS as readonly string[]).includes(value ?? "") ? (value as Tier) : "free";
}

export function isPaidTier(value: string): value is PaidTier {
  return (PAID_TIERS as string[]).includes(value);
}

/** Formule payante d'une valeur stockée (repli : Link+). */
export function paidTier(value: string | null | undefined): PaidTier {
  const tier = normalizeTier(value);
  return tier === "free" ? "plus" : tier;
}

export function maxTier(a: Tier, b: Tier): Tier {
  return TIER_RANK[a] >= TIER_RANK[b] ? a : b;
}

/** Nom commercial d'un palier : « Gratuit », « Link+ », « Link+ Pro », « Link+ Équipe ». */
export function tierName(tier: Tier, premiumName: string): string {
  switch (tier) {
    case "free":
      return "Gratuit";
    case "plus":
      return premiumName;
    case "pro":
      return `${premiumName} Pro`;
    case "team":
      return `${premiumName} Équipe`;
  }
}

/** Positionnement de chaque formule : pour qui, et pourquoi la choisir. */
export const TIER_PITCH: Record<Tier, { tagline: string; audience: string; promise: string }> = {
  free: {
    tagline: "Pour commencer",
    audience: "Tout le monde",
    promise: "Une vraie page, tous les blocs de base, l'assistant de création et tes statistiques.",
  },
  plus: {
    tagline: "Pour te démarquer",
    audience: "Joueurs, membres de communauté, créateurs qui débutent",
    promise: "Effets, musique et vidéo de fond, polices, automatisations simples, statistiques sur 90 jours.",
  },
  pro: {
    tagline: "Pour les créateurs",
    audience: "Streamers, vidéastes, artistes, chefs de pays",
    promise: "CSS et widgets libres, redirection de live, notifications Discord, export des statistiques, 10 pages.",
  },
  team: {
    tagline: "Pour les collectifs",
    audience: "Serveurs, équipes e-sport, associations, marques",
    promise: "25 pages gérées à 20, kit de marque commun à toutes les pages, accompagnement prioritaire.",
  },
};

/**
 * Valeur d'une journée de chaque palier, en centimes, d'après le prix annuel de référence.
 * Sert à convertir le temps restant lors d'un changement de formule (rien n'est perdu).
 */
export const DEFAULT_DAY_VALUE: Record<PaidTier, number> = {
  plus: 1999 / 365,
  pro: 3999 / 365,
  team: 7999 / 365,
};
