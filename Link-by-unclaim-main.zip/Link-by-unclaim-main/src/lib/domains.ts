// Domaines personnels (partagé serveur / navigateur) : forme d'un nom d'hôte et enregistrements DNS.

/** Préfixe de l'enregistrement TXT qui prouve la propriété du domaine. */
export const TXT_PREFIX = "_link-unclaim";

export type DomainCheckStep = { ok: boolean; message: string };

/** Résultat d'un contrôle, enregistré en JSON et montré au propriétaire. */
export type DomainCheck = {
  ownership: DomainCheckStep;
  routing: DomainCheckStep;
  https: DomainCheckStep;
  checkedAt: string;
};

export type DomainStatus = "pending" | "active" | "error";

/**
 * Nom d'hôte saisi → forme canonique (minuscules, punycode, sans protocole, chemin, port ni
 * point final), ou null s'il n'est pas un nom de domaine public valable.
 */
export function normalizeHostname(input: string): string | null {
  let value = input.trim().toLowerCase();
  if (!value || value.length > 300) return null;
  value = value.replace(/^[a-z][a-z0-9+.-]*:\/\//, "").replace(/[/?#].*$/, "").replace(/:\d+$/, "").replace(/\.$/, "");
  let host: string;
  try {
    host = new URL(`http://${value}`).hostname;
  } catch {
    return null;
  }
  if (host.length > 253 || !host.includes(".")) return null;
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host) || host.startsWith("[")) return null;
  const labels = host.split(".");
  if (labels.some((l) => !/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(l))) return null;
  const tld = labels[labels.length - 1]!;
  if (!/^(?:[a-z]{2,63}|xn--[a-z0-9-]{1,59})$/.test(tld)) return null;
  if (["localhost", "local", "internal", "test", "example", "invalid", "onion"].includes(tld)) return null;
  return host;
}

/** Domaine racine (« mondomaine.fr ») plutôt que sous-domaine (« www.mondomaine.fr ») : pas de CNAME possible. */
export function isApexDomain(host: string): boolean {
  const labels = host.split(".");
  // Suffixes à deux niveaux les plus courants (co.uk, com.br…) : traités comme une racine.
  if (labels.length === 3 && /^(co|com|net|org|gouv|asso)$/.test(labels[1]!) && labels[2]!.length === 2) return true;
  return labels.length === 2;
}

export function parseDomainCheck(raw: string | null | undefined): DomainCheck | null {
  try {
    const value = JSON.parse(raw || "null") as DomainCheck | null;
    return value && typeof value === "object" && "ownership" in value ? value : null;
  } catch {
    return null;
  }
}
