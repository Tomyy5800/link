// Notifications d'une page (partagé serveur / navigateur) : un webhook Discord reçoit les
// nouveaux messages de contact et un bilan chaque semaine.
import { z } from "zod";

/** Adresse de webhook Discord : discord.com/api/webhooks/<id>/<jeton>. */
export const DISCORD_WEBHOOK = /^https:\/\/(?:(?:canary|ptb)\.)?discord(?:app)?\.com\/api\/webhooks\/\d{15,22}\/[\w-]{40,100}$/;

export const notificationsSchema = z.object({
  discordWebhook: z
    .string()
    .trim()
    .max(200)
    .refine((v) => v === "" || DISCORD_WEBHOOK.test(v), "Adresse de webhook Discord invalide (Paramètres du salon › Intégrations › Webhooks).")
    .default(""),
  onMessage: z.boolean().default(true),
  /** Nouvelle demande de commande reçue par le bloc « Boutique ». */
  onOrder: z.boolean().default(true),
  weekly: z.boolean().default(true),
});

export type NotificationSettings = z.infer<typeof notificationsSchema>;

/** Réglages stockés (avec l'état interne du bilan hebdomadaire). */
export type StoredNotifications = NotificationSettings & { lastDigestAt?: string };

export function parseNotifications(raw: string | null | undefined): StoredNotifications {
  try {
    const value = JSON.parse(raw || "{}") as Record<string, unknown>;
    const parsed = notificationsSchema.safeParse(value);
    const base = parsed.success ? parsed.data : notificationsSchema.parse({});
    return { ...base, ...(typeof value.lastDigestAt === "string" ? { lastDigestAt: value.lastDigestAt } : {}) };
  } catch {
    return notificationsSchema.parse({});
  }
}

/** Adresse masquée pour l'affichage : on montre seulement le début et la fin du jeton. */
export function maskWebhook(url: string): string {
  const m = url.match(/^(https:\/\/[^/]+\/api\/webhooks\/\d+\/)(.{4}).*(.{4})$/);
  return m ? `${m[1]}${m[2]}…${m[3]}` : url;
}
