// Résolution d'un bloc « Intégration » (partagé : rendu serveur, aperçu, éditeur).
import type { BlockData } from "./blocks";
import { isDomainBlocked } from "./features";
import { hostnameOf, toCustomFrame, toEmbed } from "./urls";

export type EmbedResolution =
  | { kind: "locked"; reason: string }
  | { kind: "empty"; reason: string }
  | { kind: "blocked"; reason: string }
  | { kind: "html" }
  | { kind: "frame"; src: string; label: string; aspect?: string; height?: number };

/** Ce que le bloc affichera, ou la raison pour laquelle il ne peut pas l'afficher. */
export function describeEmbed(data: BlockData<"embed">, allow: { iframe: boolean; html: boolean }, blocked: string[]): EmbedResolution {
  if (data.mode === "html") {
    if (!allow.html) return { kind: "locked", reason: "Les widgets HTML" };
    if (!data.html.trim()) return { kind: "empty", reason: "Colle le code HTML du widget." };
    return { kind: "html" };
  }
  if (data.mode === "iframe") {
    if (!allow.iframe) return { kind: "locked", reason: "Les intégrations libres" };
    const src = toCustomFrame(data.url);
    if (!src) return { kind: "empty", reason: data.url ? "Adresse https attendue." : "Colle l'adresse du site à intégrer." };
    if (isDomainBlocked(hostnameOf(src), blocked)) return { kind: "blocked", reason: "Ce site n'est pas autorisé sur Link by Unclaim." };
    return { kind: "frame", src, label: hostnameOf(src) };
  }
  const embed = toEmbed(data.url);
  if (!embed) {
    return {
      kind: "empty",
      reason: data.url
        ? "Ce lien n'est pas reconnu. Passe en mode « iframe libre » pour l'intégrer tel quel."
        : "Colle un lien YouTube, Twitch, Spotify, TikTok…",
    };
  }
  if (isDomainBlocked(hostnameOf(embed.src), blocked)) return { kind: "blocked", reason: "Ce site n'est pas autorisé sur Link by Unclaim." };
  return { kind: "frame", src: embed.src, label: embed.label, aspect: embed.aspect, height: embed.height };
}

/** Document d'un widget HTML, chargé dans une iframe sans même origine (isolée de la page). */
export function widgetDocument(html: string): string {
  return `<!doctype html><html><head><meta charset="utf-8"><base target="_blank"><meta name="viewport" content="width=device-width,initial-scale=1"><style>html,body{margin:0;background:transparent;color:#e5e7eb;font-family:system-ui,sans-serif}</style></head><body>${html}</body></html>`;
}
