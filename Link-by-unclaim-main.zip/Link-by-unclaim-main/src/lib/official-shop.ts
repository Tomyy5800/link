// Boutique officielle Unclaim (partagé serveur / navigateur) : catégories, récompenses, cadres.
//
// Les abonnements aux formules (Link+, Pro, Équipe) sont vendus sur /plus ; la boutique vend
// des personnalisations à l'unité (badges exclusifs, cadres d'avatar). Chaque article payé est
// attribué au compte par le serveur, après confirmation du paiement par Stripe.
import { z } from "zod";
import { BADGE_ICONS, BADGE_KEY_PATTERN, HEX_COLOR } from "./badges";

export const SHOP_CATEGORIES = {
  badges: { label: "Badges exclusifs", description: "À afficher à côté de ton nom, sur toutes tes pages." },
  profil: { label: "Cadres de profil", description: "Un cadre animé autour de ton avatar." },
} as const;
export const SHOP_CATEGORY_KEYS = ["badges", "profil"] as const;
export type ShopCategory = (typeof SHOP_CATEGORY_KEYS)[number];

/** Cadres d'avatar (dessinés en CSS : .lbu-frame[data-frame]). */
export const FRAME_KEYS = ["aurore", "or", "signal", "neon", "pixel"] as const;
export type FrameKey = (typeof FRAME_KEYS)[number];
export const AVATAR_FRAMES: Record<FrameKey, { label: string; description: string }> = {
  aurore: { label: "Aurore", description: "Un anneau aux couleurs d'aurore boréale qui tourne lentement." },
  or: { label: "Or", description: "Un liseré doré traversé d'un reflet." },
  signal: { label: "Signal", description: "Le cadre HUD d'Unclaim, avec ses repères d'angle." },
  neon: { label: "Néon", description: "Un halo rose et violet, comme une enseigne." },
  pixel: { label: "Pixel", description: "Une bordure en blocs, façon jeu vidéo." },
};

export const shopRewardSchema = z.discriminatedUnion("type", [
  /** Badge officiel attribué au compte (il doit exister dans /admin/badges). */
  z.object({ type: z.literal("badge"), badgeKey: z.string().regex(BADGE_KEY_PATTERN) }),
  /** Cadre d'avatar débloqué pour toutes les pages du compte. */
  z.object({ type: z.literal("frame"), frame: z.enum(FRAME_KEYS) }),
]);
export type ShopReward = z.infer<typeof shopRewardSchema>;

export function parseShopReward(raw: string | null | undefined): ShopReward | null {
  try {
    const parsed = shopRewardSchema.safeParse(JSON.parse(raw || "null"));
    return parsed.success ? parsed.data : null;
  } catch {
    return null;
  }
}

export function parsePerks(raw: string | null | undefined): string[] {
  try {
    const value: unknown = JSON.parse(raw || "[]");
    return Array.isArray(value) ? value.filter((v): v is string => typeof v === "string").slice(0, 6) : [];
  } catch {
    return [];
  }
}

export const shopItemInputSchema = z.object({
  slug: z.string().trim().toLowerCase().regex(BADGE_KEY_PATTERN, "Identifiant : minuscules, chiffres et tirets."),
  category: z.enum(SHOP_CATEGORY_KEYS),
  name: z.string().trim().min(2).max(48),
  description: z.string().trim().max(280),
  perks: z.array(z.string().trim().min(1).max(80)).max(6),
  priceCents: z.number().int().min(50, "Prix minimum : 0,50 €").max(100_000),
  icon: z.enum(BADGE_ICONS),
  imageUrl: z.union([z.literal(""), z.string().regex(/^\/api\/uploads\/[a-z0-9]{8,40}$/i, "Image invalide.")]),
  color: z.string().regex(HEX_COLOR, "Couleur invalide."),
  reward: shopRewardSchema,
  active: z.boolean(),
  position: z.number().int().min(0).max(999),
});
export type ShopItemInput = z.infer<typeof shopItemInputSchema>;

/** Article tel qu'affiché dans la boutique (sans rien de sensible). */
export type PublicShopItem = {
  id: string;
  slug: string;
  category: ShopCategory;
  name: string;
  description: string;
  perks: string[];
  priceCents: number;
  icon: string;
  imageUrl: string;
  color: string;
  reward: ShopReward;
  /** Déjà possédé par le compte connecté. */
  owned: boolean;
};
