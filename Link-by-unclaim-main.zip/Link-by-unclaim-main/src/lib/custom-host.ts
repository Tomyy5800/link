// Reconnaissance des domaines personnels dans le proxy (fonctions pures, sans base de données).

const LOCAL_HOST = /^(localhost|127\.0\.0\.1|0\.0\.0\.0|\[::1\])$/;
const IPV4 = /^\d{1,3}(\.\d{1,3}){3}$/;

/** Nom d'hôte du site d'après APP_URL. */
export function siteHost(appUrl: string | undefined): string {
  try {
    return new URL(appUrl || "http://localhost:3000").hostname.toLowerCase();
  } catch {
    return "localhost";
  }
}

/** Nom d'hôte d'une requête, en minuscules, sans port ni point final. */
export function hostFromHeaders(headers: Headers): string {
  const raw = headers.get("x-forwarded-host") ?? headers.get("host") ?? "";
  return raw.split(",")[0]!.trim().toLowerCase().replace(/:\d+$/, "").replace(/\.$/, "");
}

/** Hôte qui n'est ni le site, ni un de ses sous-domaines, ni une adresse locale ou IP. */
export function isCustomHost(host: string, site: string): boolean {
  if (!host || !host.includes(".") || LOCAL_HOST.test(host) || IPV4.test(host)) return false;
  const bare = site.replace(/^www\./, "");
  return host !== site && host !== bare && !host.endsWith(`.${bare}`);
}
