// Noms officiels protégés (partagé serveur / navigateur) : personne ne peut se faire passer pour
// l'équipe Unclaim avec une adresse, un rôle personnalisé ou le titre d'une boutique.

/** Forme comparable d'un texte : minuscules, sans accents, chiffres « leet » remplacés. */
export function foldName(input: string): string {
  return input
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[0@4]/g, (c) => (c === "0" ? "o" : "a"))
    .replace(/[1!|]/g, "i")
    .replace(/3/g, "e")
    .replace(/[5$]/g, "s")
    .replace(/7/g, "t");
}

/** Mots qui désignent l'équipe officielle. */
const OFFICIAL_WORDS = [
  "admin",
  "administrateur",
  "administratrice",
  "administrator",
  "staff",
  "moderateur",
  "moderatrice",
  "moderator",
  "modo",
  "fondateur",
  "fondatrice",
  "founder",
  "cofondateur",
  "officiel",
  "officielle",
  "official",
  "support",
];

/** Préfixes et suffixes qui suffisent à usurper (« admin-1 », « le-staff »…). */
const STRONG_AFFIXES = ["admin", "staff", "officiel", "official", "fondateur", "founder", "moderateur", "moderator"];

/**
 * Le texte reprend-il un nom officiel ? « Unclaim » est protégé partout ; les mots du staff le
 * sont seuls, en début ou en fin (« badminton » reste permis, « admin-unclaim » non).
 */
export function isOfficialName(input: string): boolean {
  const folded = foldName(input);
  const collapsed = folded.replace(/[^a-z]/g, "");
  if (!collapsed) return false;
  if (collapsed.includes("unclaim") || collapsed.includes("linkbyunclaim")) return true;
  const tokens = folded.split(/[^a-z]+/).filter(Boolean);
  if (tokens.some((t) => OFFICIAL_WORDS.includes(t))) return true;
  if (OFFICIAL_WORDS.includes(collapsed)) return true;
  if (/developpeurofficiel|devofficiel|equipeofficielle|boutiqueofficielle|officialshop|officialstore/.test(collapsed)) return true;
  return STRONG_AFFIXES.some((w) => collapsed.startsWith(w) || collapsed.endsWith(w));
}

export const OFFICIAL_NAME_ERROR = "Ce nom est réservé à l'équipe officielle d'Unclaim.";
