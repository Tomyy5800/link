// URLs du CDN Discord (partagé serveur / navigateur).
import { defaultAvatarUrl, parseIdentities, providerMeta } from "./identity";
import { intToHex } from "./theme";
import type { OwnerProfile } from "./page-schema";

const CDN = "https://cdn.discordapp.com";

export function discordAvatarUrl(discordId: string, hash: string | null | undefined, size = 256): string {
  if (hash) {
    const ext = hash.startsWith("a_") ? "gif" : "png";
    return `${CDN}/avatars/${discordId}/${hash}.${ext}?size=${size}`;
  }
  // Avatar par défaut (nouveau système de pseudos) : (id >> 22) % 6.
  let index = 0;
  try {
    index = Number((BigInt(discordId) >> 22n) % 6n);
  } catch {
    index = 0;
  }
  return `${CDN}/embed/avatars/${index}.png`;
}

/** Variante PNG statique (pour les images Open Graph, qui ne gèrent pas les GIF). */
export function discordAvatarPngUrl(discordId: string, hash: string | null | undefined, size = 256): string {
  if (!hash) return discordAvatarUrl(discordId, null);
  return `${CDN}/avatars/${discordId}/${hash}.png?size=${size}`;
}

export function discordBannerUrl(discordId: string, hash: string | null | undefined, size = 600): string | null {
  if (!hash) return null;
  const ext = hash.startsWith("a_") ? "gif" : "png";
  return `${CDN}/banners/${discordId}/${hash}.${ext}?size=${size}`;
}

export function discordGuildIconUrl(guildId: string, hash: string | null | undefined, size = 128): string | null {
  if (!hash) return null;
  const ext = hash.startsWith("a_") ? "gif" : "png";
  return `${CDN}/icons/${guildId}/${hash}.${ext}?size=${size}`;
}

type OwnerSource = {
  id?: string;
  discordId: string | null;
  provider?: string;
  username: string;
  globalName: string | null;
  avatarUrl?: string | null;
  avatarHash: string | null;
  bannerHash: string | null;
  accentColor: number | null;
  identities?: string;
  ngAccount?: string | null;
};

/** Avatar d'un compte : Discord, puis photo du fournisseur (https), puis avatar par défaut. */
export function accountAvatarUrl(user: OwnerSource): string {
  if (user.discordId && user.avatarHash) return discordAvatarUrl(user.discordId, user.avatarHash);
  if (user.avatarUrl && /^https:\/\//.test(user.avatarUrl)) return user.avatarUrl;
  if (user.discordId) return discordAvatarUrl(user.discordId, null);
  return defaultAvatarUrl(user.id ?? user.username, user.globalName ?? user.username);
}

export function toOwnerProfile(user: OwnerSource): OwnerProfile {
  const identities = parseIdentities(user.identities);
  const provider = user.provider ?? "discord";
  const discordUsername =
    identities.find((i) => i.provider === "discord")?.username ?? (provider === "discord" && user.discordId ? user.username : null);
  const handles = identities
    .filter((i): i is { provider: string; username: string } => Boolean(i.username) && providerMeta(i.provider).publicHandle)
    .map((i) => ({ provider: i.provider, username: i.username }));
  return {
    discordId: user.discordId,
    discordUsername,
    username: user.username,
    globalName: user.globalName,
    avatarUrl: accountAvatarUrl(user),
    bannerUrl: user.discordId ? discordBannerUrl(user.discordId, user.bannerHash) : null,
    accentColor: intToHex(user.accentColor),
    provider,
    handles,
    ngAccount: user.ngAccount ?? null,
  };
}

export type DiscordInvite = {
  code: string;
  status: "ok" | "invalid" | "unavailable";
  guild?: {
    id: string;
    name: string;
    iconUrl: string | null;
    description: string | null;
  };
  memberCount?: number;
  onlineCount?: number;
};
