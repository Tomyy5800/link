// Automatisations (partagé serveur / navigateur) : la page change toute seule selon des règles
// « quand… alors… ». Évaluées au moment de l'affichage, à l'heure de la page (fuseau réglable).
//
// Déclencheurs : créneau qui revient chaque semaine, période entre deux dates, live en cours
// (statut Discord « en stream »), jour de l'anniversaire (bloc compte à rebours).
// Actions : bandeau en haut de page, mise en avant d'un bloc, masquage d'un bloc, autre thème.
import { z } from "zod";
import type { PageView } from "./page-schema";
import { getPreset, type Theme } from "./theme";
import { normalizeUrl } from "./urls";

const hhmm = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, "Heure invalide (HH:MM)");
const isoDate = z.string().max(40).refine((v) => !Number.isNaN(Date.parse(v)), "Date invalide");
const httpsUrl = z
  .string()
  .max(500)
  .refine((v) => v === "" || /^https:\/\//.test(normalizeUrl(v) ?? ""), "Adresse https attendue")
  .transform((v) => (v ? (normalizeUrl(v) ?? "") : ""));

export const automationTriggerSchema = z.discriminatedUnion("type", [
  z.object({ type: z.literal("weekly"), days: z.array(z.number().int().min(0).max(6)).min(1).max(7), from: hhmm, to: hhmm }),
  z.object({ type: z.literal("dates"), start: isoDate, end: isoDate }),
  z.object({ type: z.literal("live") }),
  z.object({ type: z.literal("birthday") }),
]);

export const BANNER_STYLES = ["accent", "live", "celebration", "info"] as const;

export const automationActionSchema = z.discriminatedUnion("type", [
  z.object({
    type: z.literal("banner"),
    text: z.string().trim().min(1, "Texte du bandeau manquant").max(120),
    /** Lien du bandeau (vide pour un live : le lien du stream). */
    url: httpsUrl.default(""),
    style: z.enum(BANNER_STYLES).default("accent"),
  }),
  z.object({ type: z.literal("highlight"), blockId: z.string().max(40) }),
  z.object({ type: z.literal("hide"), blockId: z.string().max(40) }),
  z.object({ type: z.literal("theme"), preset: z.string().max(32) }),
]);

export const automationSchema = z.object({
  id: z.string().min(1).max(40),
  name: z.string().trim().max(60).default(""),
  enabled: z.boolean().default(true),
  trigger: automationTriggerSchema,
  actions: z.array(automationActionSchema).min(1).max(3),
});

export type AutomationTrigger = z.infer<typeof automationTriggerSchema>;
export type AutomationAction = z.infer<typeof automationActionSchema>;
export type Automation = z.infer<typeof automationSchema>;
export type BannerStyle = (typeof BANNER_STYLES)[number];

export const MAX_AUTOMATIONS = 12;
export const DEFAULT_TIMEZONE = "Europe/Paris";

export function isValidTimeZone(tz: string): boolean {
  try {
    new Intl.DateTimeFormat("fr-FR", { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

export type AutomationContext = {
  now: Date;
  timeZone: string;
  /** Live en cours (statut Discord « en stream ») et lien du stream s'il est connu. */
  live: { on: boolean; url: string | null };
  /** Forcer des règles actives (aperçu de l'éditeur). */
  force?: string[];
};

export type AutomationBanner = { id: string; text: string; url: string | null; style: BannerStyle };

const DAY_INDEX: Record<string, number> = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };

/** Jour de la semaine (0 = dimanche), minutes depuis minuit et date « MM-JJ » dans le fuseau donné. */
export function localClock(now: Date, timeZone: string): { day: number; minutes: number; monthDay: string } {
  const parts = Object.fromEntries(
    new Intl.DateTimeFormat("en-US", { timeZone, weekday: "short", hour: "2-digit", minute: "2-digit", month: "2-digit", day: "2-digit", hourCycle: "h23" })
      .formatToParts(now)
      .map((p) => [p.type, p.value]),
  );
  return {
    day: DAY_INDEX[parts.weekday] ?? 0,
    minutes: Number(parts.hour) * 60 + Number(parts.minute),
    monthDay: `${parts.month}-${parts.day}`,
  };
}

const toMinutes = (v: string) => Number(v.slice(0, 2)) * 60 + Number(v.slice(3, 5));

/** Anniversaire indiqué dans un bloc compte à rebours (mode anniversaire), s'il y en a un. */
export function pageBirthday(page: Pick<PageView, "blocks">): string | null {
  for (const b of page.blocks) {
    if (b.type === "countdown" && b.data.mode === "birthday" && b.data.birthday) return b.data.birthday;
  }
  return null;
}

/** Le déclencheur est-il vrai en ce moment ? */
export function triggerActive(trigger: AutomationTrigger, ctx: AutomationContext, birthday: string | null): boolean {
  switch (trigger.type) {
    case "weekly": {
      const { day, minutes } = localClock(ctx.now, ctx.timeZone);
      const from = toMinutes(trigger.from);
      const to = toMinutes(trigger.to);
      if (from === to) return trigger.days.includes(day);
      if (from < to) return trigger.days.includes(day) && minutes >= from && minutes < to;
      // Créneau qui passe minuit (22:00 → 02:00) : commence un jour choisi, se termine le lendemain.
      const previous = (day + 6) % 7;
      return (trigger.days.includes(day) && minutes >= from) || (trigger.days.includes(previous) && minutes < to);
    }
    case "dates": {
      const t = ctx.now.getTime();
      return t >= Date.parse(trigger.start) && t < Date.parse(trigger.end);
    }
    case "live":
      return ctx.live.on;
    case "birthday": {
      if (!birthday) return false;
      const { monthDay } = localClock(ctx.now, ctx.timeZone);
      // Né un 29 février : fêté le 28 les années non bissextiles.
      if (birthday === "02-29" && monthDay === "02-28") {
        const year = Number(new Intl.DateTimeFormat("en-US", { timeZone: ctx.timeZone, year: "numeric" }).format(ctx.now));
        const leap = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
        return !leap;
      }
      return monthDay === birthday;
    }
  }
}

/** Couleurs, fonds et cartes d'un thème prédéfini, appliqués sans toucher à la mise en page. */
function themeColors(base: Theme, presetKey: string): Theme {
  const preset = getPreset(presetKey)?.theme;
  if (!preset) return base;
  return {
    ...base,
    accent: preset.accent,
    accent2: preset.accent2,
    text: preset.text,
    bgType: preset.bgType,
    bgColor: preset.bgColor,
    bgColor2: preset.bgColor2,
    bgAngle: preset.bgAngle,
    bgImage: preset.bgImage,
    bgEffect: preset.bgEffect,
    cardStyle: preset.cardStyle,
    cardColor: preset.cardColor,
    cardOpacity: preset.cardOpacity,
  };
}

/**
 * Applique les automatisations actives à une page : renvoie la page modifiée, les bandeaux à
 * afficher et les règles déclenchées. Une règle désactivée ou mal formée est ignorée.
 */
export function applyAutomations(
  page: PageView,
  rules: Automation[],
  ctx: AutomationContext,
): { page: PageView; banners: AutomationBanner[]; active: string[] } {
  const birthday = pageBirthday(page);
  const active = rules.filter((r) => (ctx.force?.includes(r.id) ?? false) || (r.enabled && triggerActive(r.trigger, ctx, birthday)));
  if (!active.length) return { page, banners: [], active: [] };

  let blocks = [...page.blocks];
  let theme = page.theme;
  const banners: AutomationBanner[] = [];
  for (const rule of active) {
    for (const action of rule.actions) {
      switch (action.type) {
        case "banner":
          banners.push({
            id: `${rule.id}-${banners.length}`,
            text: action.text,
            url: action.url || (rule.trigger.type === "live" ? ctx.live.url : null) || null,
            style: action.style,
          });
          break;
        case "highlight": {
          const i = blocks.findIndex((b) => b.id === action.blockId);
          if (i > 0) blocks = [blocks[i], ...blocks.slice(0, i), ...blocks.slice(i + 1)];
          if (i >= 0) blocks = blocks.map((b) => (b.id === action.blockId ? { ...b, visible: true, width: "full", colSpan: null } : b));
          break;
        }
        case "hide":
          blocks = blocks.filter((b) => b.id !== action.blockId);
          break;
        case "theme":
          theme = themeColors(theme, action.preset);
          break;
      }
    }
  }
  return { page: { ...page, blocks, theme }, banners: banners.slice(0, 3), active: active.map((r) => r.id) };
}

/** Phrase lisible d'un déclencheur : « Le mercredi de 20:00 à 23:00 ». Dates écrites dans le fuseau donné (celui de la page), jamais celui de la machine. */
export function describeTrigger(trigger: AutomationTrigger, timeZone: string = DEFAULT_TIMEZONE): string {
  const DAYS = ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"];
  switch (trigger.type) {
    case "weekly": {
      const days = trigger.days.length === 7 ? "Tous les jours" : [...trigger.days].sort((a, b) => ((a + 6) % 7) - ((b + 6) % 7)).map((d) => DAYS[d]).join(", ");
      return `${trigger.days.length === 7 ? days : `Le ${days}`} de ${trigger.from} à ${trigger.to}`;
    }
    case "dates": {
      const f = (v: string) => new Date(v).toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short", timeZone });
      return `Du ${f(trigger.start)} au ${f(trigger.end)}`;
    }
    case "live":
      return "Pendant mes lives";
    case "birthday":
      return "Le jour de mon anniversaire";
  }
}

/** Règles prêtes à l'emploi proposées dans l'éditeur. */
export const AUTOMATION_PRESETS: { key: string; title: string; text: string; build: () => Omit<Automation, "id"> }[] = [
  {
    key: "live",
    title: "Bandeau pendant mes lives",
    text: "Quand ton statut Discord passe « en stream », un bandeau invite à te rejoindre.",
    build: () => ({
      name: "Je suis en live",
      enabled: true,
      trigger: { type: "live" },
      actions: [{ type: "banner", text: "🔴 Je suis en live en ce moment, viens me voir !", url: "", style: "live" }],
    }),
  },
  {
    key: "weekly",
    title: "Rendez-vous de la semaine",
    text: "Un bandeau qui s'affiche chaque semaine pendant ton créneau (stream, entraînement, réunion).",
    build: () => ({
      name: "Stream du mercredi",
      enabled: true,
      trigger: { type: "weekly", days: [3], from: "20:00", to: "23:00" },
      actions: [{ type: "banner", text: "📅 Stream ce soir à 20 h, ne le rate pas !", url: "", style: "accent" }],
    }),
  },
  {
    key: "birthday",
    title: "Fête d'anniversaire",
    text: "Le jour J : thème rose et bandeau festif (anniversaire pris dans ton bloc compte à rebours).",
    build: () => ({
      name: "Mon anniversaire",
      enabled: true,
      trigger: { type: "birthday" },
      actions: [
        { type: "banner", text: "🎂 C'est mon anniversaire aujourd'hui !", url: "", style: "celebration" },
        { type: "theme", preset: "sakura" },
      ],
    }),
  },
  {
    key: "night",
    title: "Mode nuit",
    text: "Un thème sombre et doux le soir, chaque jour de 22 h à 7 h.",
    build: () => ({
      name: "Mode nuit",
      enabled: true,
      trigger: { type: "weekly", days: [0, 1, 2, 3, 4, 5, 6], from: "22:00", to: "07:00" },
      actions: [{ type: "theme", preset: "midnight" }],
    }),
  },
  {
    key: "event",
    title: "Événement à venir",
    text: "Entre deux dates : un bandeau et un bloc remonté tout en haut (inscriptions, tournoi, sortie).",
    build: () => {
      const start = new Date();
      const end = new Date(Date.now() + 7 * 86_400_000);
      return {
        name: "Événement",
        enabled: true,
        trigger: { type: "dates", start: start.toISOString(), end: end.toISOString() },
        actions: [{ type: "banner", text: "🏆 Les inscriptions sont ouvertes !", url: "", style: "info" }],
      };
    },
  },
];
