// Statut Discord en direct, via Lanyard (https://github.com/Phineas/lanyard).
// La personne doit avoir rejoint le serveur Discord de Lanyard pour être suivie.
// Partagé serveur / navigateur : uniquement des types et de la normalisation.

export type PresenceStatus = "online" | "idle" | "dnd" | "offline";

export type DiscordPresence = {
  monitored: boolean;
  status: PresenceStatus;
  customStatus: { text: string; emoji: string | null } | null;
  activities: { kind: string; name: string; details: string | null; state: string | null }[];
  spotify: { song: string; artist: string; albumArt: string | null; trackUrl: string | null } | null;
  fetchedAt: string;
  /** Lanyard injoignable : statut inconnu (à ne pas confondre avec « hors ligne »). */
  unavailable?: boolean;
  /** En stream en ce moment (activité Discord « Streaming »), avec le lien du live s'il est connu. */
  streaming?: { url: string | null };
};

export const PRESENCE_LABELS: Record<PresenceStatus, { label: string; color: string }> = {
  online: { label: "En ligne", color: "#23a55a" },
  idle: { label: "Absent", color: "#f0b232" },
  dnd: { label: "Ne pas déranger", color: "#f23f43" },
  offline: { label: "Hors ligne", color: "#80848e" },
};

const ACTIVITY_KINDS: Record<number, string> = {
  0: "Joue à",
  1: "En stream",
  2: "Écoute",
  3: "Regarde",
  5: "En compétition sur",
};

type RawActivity = { type?: number; name?: string; details?: string | null; state?: string | null; url?: string | null; emoji?: { name?: string } | null };

/** Lien de live accepté : Twitch, YouTube ou Kick, en https. */
function streamUrl(value: unknown): string | null {
  if (typeof value !== "string") return null;
  try {
    const url = new URL(value);
    return url.protocol === "https:" && /(^|\.)(twitch\.tv|youtube\.com|youtu\.be|kick\.com)$/.test(url.hostname) ? url.toString() : null;
  } catch {
    return null;
  }
}

function str(value: unknown, max = 128): string | null {
  return typeof value === "string" && value.trim() ? value.trim().slice(0, max) : null;
}

export function offlinePresence(monitored: boolean): DiscordPresence {
  return { monitored, status: "offline", customStatus: null, activities: [], spotify: null, fetchedAt: new Date().toISOString() };
}

/** Normalise la réponse de GET api.lanyard.rest/v1/users/:id. */
export function normalizeLanyard(raw: unknown): DiscordPresence {
  if (!raw || typeof raw !== "object") return offlinePresence(false);
  const body = raw as { success?: boolean; data?: Record<string, unknown> };
  if (!body.success || !body.data) return offlinePresence(false);
  const data = body.data;
  const status = (["online", "idle", "dnd", "offline"] as const).find((s) => s === data.discord_status) ?? "offline";
  const rawActivities = Array.isArray(data.activities) ? (data.activities as RawActivity[]) : [];

  const custom = rawActivities.find((a) => a.type === 4);
  const customStatus = custom && (str(custom.state) || custom.emoji?.name)
    ? { text: str(custom.state) ?? "", emoji: str(custom.emoji?.name, 32) }
    : null;

  const activities = rawActivities
    .filter((a) => a.type !== 4 && !(a.type === 2 && a.name === "Spotify"))
    .slice(0, 2)
    .map((a) => ({
      kind: ACTIVITY_KINDS[a.type ?? 0] ?? "Joue à",
      name: str(a.name, 80) ?? "Activité",
      details: str(a.details),
      state: str(a.state),
    }));

  let spotify: DiscordPresence["spotify"] = null;
  if (data.listening_to_spotify && data.spotify && typeof data.spotify === "object") {
    const s = data.spotify as Record<string, unknown>;
    const trackId = str(s.track_id, 64);
    spotify = {
      song: str(s.song) ?? "Titre inconnu",
      artist: (str(s.artist) ?? "").replace(/;/g, ","),
      albumArt: str(s.album_art_url, 300),
      trackUrl: trackId && /^[A-Za-z0-9]+$/.test(trackId) ? `https://open.spotify.com/track/${trackId}` : null,
    };
  }

  const stream = rawActivities.find((a) => a.type === 1);
  return {
    monitored: true,
    status,
    customStatus,
    activities,
    spotify,
    fetchedAt: new Date().toISOString(),
    ...(stream ? { streaming: { url: streamUrl(stream.url) } } : {}),
  };
}
