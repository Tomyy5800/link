// Page de démonstration affichée sur la landing (aucune donnée réelle).
import { ngProfileKey, type PageExtras } from "@/components/page/types";
import { makeProduct } from "./shop";
import { createBlock } from "./blocks";
import { discordAvatarUrl } from "./discord-cdn";
import { mockNgProfile } from "./nationsglory-shared";
import { DEFAULT_PAGE_OPTIONS, type OwnerProfile, type PageView } from "./page-schema";
import { getPreset } from "./theme";

// Pseudo sans compte NationsGlory : le serveur de skins renvoie le skin par défaut.
const DEMO_NG = "Unclaim_Demo";

export function demoPage(): { page: PageView; owner: OwnerProfile; extras: PageExtras } {
  const theme = { ...getPreset("unclaim")!.theme, width: "narrow" as const };
  const page: PageView = {
    slug: "kaelis",
    published: true,
    views: 1284,
    theme,
    customCss: "",
    options: DEFAULT_PAGE_OPTIONS,
    profile: {
      displayName: "Kaelis",
      pronouns: "elle/iel",
      bio: "Diplomate sur **Blue** · bâtisseuse de capitales\n-# streams le mercredi soir",
      avatarSource: "discord",
      avatarUrl: "",
      bannerUrl: "",
      ngUsername: DEMO_NG,
      ngServer: "blue",
    },
    blocks: [
      createBlock("socials", {
        items: [
          { platform: "twitch", url: "https://twitch.tv" },
          { platform: "youtube", url: "https://youtube.com" },
          { platform: "x", url: "https://x.com" },
          { platform: "tiktok", url: "https://tiktok.com" },
        ],
      }),
      { ...createBlock("nationsglory", {}), width: "half" },
      { ...createBlock("skin", { animation: "wave", height: 300 }), width: "half" },
      createBlock("link", { label: "Rejoindre ma nation", url: "https://discord.gg", description: "Recrutement ouvert", highlight: true }),
      createBlock("link", { label: "Mes builds en timelapse", url: "https://youtube.com" }),
      createBlock("shop", {
        title: "La boutique de Kaelis",
        intro: "Merch de la nation et commandes de builds.",
        terms: "Paiement PayPal après confirmation, envoi sous 3 jours.",
        products: [
          makeProduct({
            id: "p-sweat",
            name: "Sweat « Blue Nation »",
            emoji: "🧥",
            price: 3900,
            compareAt: 4900,
            badge: "Nouveau",
            options: ["S", "M", "L", "XL"],
            mode: "order",
            description: "Coton bio, brodé du blason de la nation. Taille normalement.",
          }),
          makeProduct({ id: "p-poster", name: "Poster de la capitale", emoji: "🗺️", price: 1500, mode: "order", stock: 3, description: "Vue aérienne de la capitale, 40 × 60 cm." }),
          makeProduct({ id: "p-stickers", name: "Pack de stickers", emoji: "✨", price: 600, mode: "order" }),
          makeProduct({ id: "p-build", name: "Commission de build", emoji: "🏰", price: null, mode: "link", url: "https://ko-fi.com", buttonLabel: "Commander sur Ko-fi" }),
        ],
      }),
    ],
  };
  const owner: OwnerProfile = {
    discordId: "100000000000000002",
    username: "kaelis",
    globalName: "Kaelis",
    avatarUrl: discordAvatarUrl("100000000000000002", null),
    bannerUrl: null,
    accentColor: "#22c9e8",
    discordUsername: "kaelis",
    provider: "discord",
    handles: [{ provider: "discord", username: "kaelis" }],
    ngAccount: DEMO_NG,
  };
  const ng = mockNgProfile(DEMO_NG, ["blue"]);
  return { page, owner, extras: { ng: { [ngProfileKey(DEMO_NG, ["blue"])]: ng } } };
}
