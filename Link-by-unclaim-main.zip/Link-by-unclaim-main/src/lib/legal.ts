// Conditions générales d'utilisation : version en vigueur (partagé serveur / navigateur).
// Changer TERMS_VERSION après une modification importante des CGU : chaque compte devra les
// accepter de nouveau à sa prochaine visite de « Mon espace ».

export const TERMS_VERSION = "2026-10-16";
export const TERMS_UPDATED = "16 octobre 2026";

/** L'essentiel des CGU, affiché avant l'acceptation. */
export const TERMS_SUMMARY = [
  "Tu es responsable de ce que tu publies sur tes pages : pas de contenu illégal, haineux, trompeur ou qui usurpe l'identité de quelqu'un.",
  "La modération peut masquer une page ou suspendre un compte qui enfreint ces règles, après signalement ou de sa propre initiative.",
  "Ta connexion passe par Unclaim Auth : Link by Unclaim ne connaît jamais ton mot de passe.",
  "Tu peux exporter tes données ou supprimer ton compte à tout moment depuis « Mon espace ».",
  "Les achats de Link+ sont régis par les conditions générales de vente.",
];

/** Âge minimal pour créer un compte sans l'accord d'un parent (majorité numérique en France). */
export const MIN_AGE = 15;
