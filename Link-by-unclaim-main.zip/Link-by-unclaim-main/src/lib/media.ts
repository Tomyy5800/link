// Détection du format réel d'un fichier importé (partagé : testable sans serveur).
// Le type annoncé par le navigateur ne fait pas foi : on lit les premiers octets.

export type MediaKind = "image" | "audio" | "video";

export function sniffMedia(bytes: Uint8Array): { kind: MediaKind; mimeType: string } | null {
  const starts = (sig: number[], offset = 0) => sig.every((b, i) => bytes[offset + i] === b);
  const ascii = (offset: number, text: string) => starts([...text].map((c) => c.charCodeAt(0)), offset);
  if (starts([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) return { kind: "image", mimeType: "image/png" };
  if (starts([0xff, 0xd8, 0xff])) return { kind: "image", mimeType: "image/jpeg" };
  if (ascii(0, "GIF8")) return { kind: "image", mimeType: "image/gif" };
  if (ascii(0, "RIFF") && ascii(8, "WEBP")) return { kind: "image", mimeType: "image/webp" };
  if (ascii(0, "RIFF") && ascii(8, "WAVE")) return { kind: "audio", mimeType: "audio/wav" };
  if (ascii(0, "ID3") || (bytes[0] === 0xff && (bytes[1] & 0xe0) === 0xe0)) return { kind: "audio", mimeType: "audio/mpeg" };
  if (ascii(0, "OggS")) return { kind: "audio", mimeType: "audio/ogg" };
  if (ascii(4, "ftyp")) {
    const brand = String.fromCharCode(...bytes.slice(8, 12));
    return brand.startsWith("M4A") ? { kind: "audio", mimeType: "audio/mp4" } : { kind: "video", mimeType: "video/mp4" };
  }
  if (starts([0x1a, 0x45, 0xdf, 0xa3])) return { kind: "video", mimeType: "video/webm" };
  return null;
}
