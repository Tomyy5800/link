// Jeux du bloc « Profil de jeu » (partagé serveur / navigateur).
// « live » : données publiques récupérées côté serveur (API sans clé, vérifiées).
// Les autres jeux n'ont pas d'API publique utilisable : la carte est remplie à la main
// (pseudo, rang, statistiques) avec, quand il existe, un lien vers le profil officiel.

export type GameInfo = {
  name: string;
  /** Couleur de la pastille du jeu. */
  color: string;
  live: boolean;
  /** Le pseudo est un pseudo Minecraft (tête du skin affichée). */
  minecraft?: boolean;
  idLabel: string;
  idPlaceholder: string;
  /** Lien vers le profil public, quand l'adresse est stable. */
  profileUrl?: (id: string) => string;
};

const enc = encodeURIComponent;

export const GAMES = {
  minecraft: {
    name: "Minecraft",
    color: "#62b34a",
    live: true,
    minecraft: true,
    idLabel: "Pseudo Minecraft",
    idPlaceholder: "Notch",
    profileUrl: (id) => `https://namemc.com/profile/${enc(id)}`,
  },
  paladium: { name: "Paladium", color: "#e8413c", live: false, minecraft: true, idLabel: "Pseudo en jeu", idPlaceholder: "Ton pseudo Minecraft" },
  hypixel: {
    name: "Hypixel",
    color: "#f5b91f",
    live: false,
    minecraft: true,
    idLabel: "Pseudo Minecraft",
    idPlaceholder: "Ton pseudo",
    profileUrl: (id) => `https://plancke.io/hypixel/player/stats/${enc(id)}`,
  },
  wolfy: { name: "Wolfy", color: "#7c5cff", live: false, idLabel: "Pseudo Wolfy", idPlaceholder: "Ton pseudo" },
  chesscom: {
    name: "Chess.com",
    color: "#81b64c",
    live: true,
    idLabel: "Pseudo Chess.com",
    idPlaceholder: "hikaru",
    profileUrl: (id) => `https://www.chess.com/member/${enc(id)}`,
  },
  lichess: {
    name: "Lichess",
    color: "#d7d3cd",
    live: true,
    idLabel: "Pseudo Lichess",
    idPlaceholder: "thibault",
    profileUrl: (id) => `https://lichess.org/@/${enc(id)}`,
  },
  steam: { name: "Steam", color: "#66c0f4", live: true, idLabel: "Identifiant Steam", idPlaceholder: "Lien du profil, ID personnalisé ou SteamID64" },
  roblox: { name: "Roblox", color: "#e2231a", live: true, idLabel: "Pseudo Roblox", idPlaceholder: "builderman" },
  valorant: { name: "Valorant", color: "#ff4655", live: false, idLabel: "Riot ID", idPlaceholder: "Pseudo#TAG" },
  lol: { name: "League of Legends", color: "#c89b3c", live: false, idLabel: "Riot ID", idPlaceholder: "Pseudo#TAG" },
  fortnite: { name: "Fortnite", color: "#9d4dbb", live: false, idLabel: "Pseudo Epic", idPlaceholder: "Ton pseudo" },
  rocketleague: { name: "Rocket League", color: "#1f8ef1", live: false, idLabel: "Pseudo", idPlaceholder: "Ton pseudo" },
  brawlstars: { name: "Brawl Stars", color: "#ffcf27", live: false, idLabel: "Tag joueur", idPlaceholder: "#ABC123" },
  clashroyale: { name: "Clash Royale", color: "#3d8bfd", live: false, idLabel: "Tag joueur", idPlaceholder: "#ABC123" },
  osu: {
    name: "osu!",
    color: "#ff66aa",
    live: false,
    idLabel: "Pseudo osu!",
    idPlaceholder: "Ton pseudo",
    profileUrl: (id) => `https://osu.ppy.sh/users/${enc(id)}`,
  },
  genshin: { name: "Genshin Impact", color: "#d3bc8e", live: false, idLabel: "UID", idPlaceholder: "700000000" },
  other: { name: "Autre jeu", color: "#8b95a7", live: false, idLabel: "Pseudo", idPlaceholder: "Ton pseudo" },
} as const satisfies Record<string, GameInfo>;

export type GameId = keyof typeof GAMES;
export const GAME_IDS = Object.keys(GAMES) as GameId[];

export function gameInfo(id: string): GameInfo {
  return (GAMES as Record<string, GameInfo>)[id] ?? GAMES.other;
}

/** Données publiques d'un joueur, normalisées pour tous les jeux « live ». */
export type GameProfile = {
  name: string;
  avatar: string | null;
  url: string | null;
  /** Titre, statut ou date d'inscription. */
  subtitle: string | null;
  online: boolean | null;
  stats: { label: string; value: string }[];
};

/** Identifiant accepté pour une requête « live » (le serveur revalide selon le jeu). */
export function cleanGameId(game: GameId, raw: string): string | null {
  const value = raw.trim();
  if (!value || value.length > 120) return null;
  switch (game) {
    case "minecraft":
      return /^[A-Za-z0-9_]{2,16}$/.test(value) ? value : null;
    case "chesscom":
    case "lichess":
      return /^[A-Za-z0-9_-]{2,30}$/.test(value) ? value.toLowerCase() : null;
    case "roblox":
      return /^[A-Za-z0-9_]{3,20}$/.test(value) ? value : null;
    case "steam": {
      // Lien de profil, ID personnalisé ou SteamID64.
      const fromUrl = value.match(/steamcommunity\.com\/(id|profiles)\/([A-Za-z0-9_-]{2,64})/);
      if (fromUrl) return `${fromUrl[1] === "profiles" ? "p:" : "id:"}${fromUrl[2]}`;
      if (/^7656\d{13}$/.test(value)) return `p:${value}`;
      return /^[A-Za-z0-9_-]{2,32}$/.test(value) ? `id:${value}` : null;
    }
    default:
      return null;
  }
}
