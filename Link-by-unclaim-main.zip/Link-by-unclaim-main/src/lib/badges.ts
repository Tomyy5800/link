// Badges officiels (partagé serveur / navigateur) : icônes, règles d'attribution, badges intégrés.
//
// Un badge est attribué de deux façons :
// - enregistré : à la main (administration), par la règle « premiers comptes », par un rôle
//   Discord synchronisé ou par un achat dans la boutique officielle ;
// - calculé : la règle décrit une condition (formule active, ancienneté, compte vérifié,
//   partenaire, fondateur déclaré) vérifiée à chaque affichage, sans rien stocker.
// Le navigateur ne choisit jamais qui possède quoi : il reçoit des badges déjà calculés.
import { z } from "zod";

/** Icônes proposées pour un badge (noms des icônes Lucide, rendues par BadgeIcon). */
export const BADGE_ICONS = [
  "crown",
  "shield",
  "code",
  "gavel",
  "star",
  "handshake",
  "badge-check",
  "rocket",
  "hourglass",
  "gem",
  "sparkles",
  "heart",
  "flame",
  "trophy",
  "zap",
  "music",
  "gamepad",
  "palette",
  "castle",
  "swords",
  "flag",
  "leaf",
  "moon",
  "sun",
] as const;
export type BadgeIconKey = (typeof BADGE_ICONS)[number];

export const BADGE_KEY_PATTERN = /^[a-z0-9](?:[a-z0-9-]{0,30}[a-z0-9])?$/;
export const HEX_COLOR = /^#[0-9a-f]{6}$/i;

const earlyRule = z.object({
  type: z.literal("early"),
  /** Nombre de places. */
  limit: z.number().int().min(1).max(100_000),
  /** Compte Discord rattaché exigé : un compte Discord ne compte qu'une fois (anti multi-comptes). */
  requireDiscord: z.boolean().default(true),
  /** Au moins une page publiée. */
  requirePage: z.boolean().default(true),
});

export const badgeRuleSchema = z.discriminatedUnion("type", [
  z.object({ type: z.literal("manual") }),
  earlyRule,
  /** Membre depuis au moins `days` jours. */
  z.object({ type: z.literal("seniority"), days: z.number().int().min(1).max(36_500) }),
  /** Formule payante active, à partir de `tier`. */
  z.object({ type: z.literal("plan"), tier: z.enum(["plus", "pro", "team"]) }),
  /** Compte vérifié par l'administration. */
  z.object({ type: z.literal("verified") }),
  /** Partenaire officiel. */
  z.object({ type: z.literal("partner") }),
  /** Fondateur déclaré dans l'environnement du serveur (FOUNDER_*). */
  z.object({ type: z.literal("founder") }),
]);
export type BadgeRule = z.infer<typeof badgeRuleSchema>;
export type BadgeRuleType = BadgeRule["type"];

export const RULE_LABELS: Record<BadgeRuleType, { label: string; description: string }> = {
  manual: { label: "Manuelle", description: "Attribué par un administrateur (ou par un rôle Discord associé)." },
  early: { label: "Premiers comptes", description: "Donné automatiquement aux N premiers comptes éligibles." },
  seniority: { label: "Ancienneté", description: "Comptes inscrits depuis au moins N jours." },
  plan: { label: "Formule active", description: "Comptes avec un abonnement ou une formule payante en cours." },
  verified: { label: "Compte vérifié", description: "Comptes vérifiés par l'administration." },
  partner: { label: "Partenaire", description: "Partenaires officiels." },
  founder: { label: "Fondateur", description: "Fondateurs déclarés dans la configuration du serveur." },
};

/** Règles calculées à l'affichage : rien n'est enregistré, aucune attribution manuelle. */
export const COMPUTED_RULES: BadgeRuleType[] = ["seniority", "plan", "verified", "partner", "founder"];

export function isComputedRule(rule: BadgeRule): boolean {
  return COMPUTED_RULES.includes(rule.type);
}

/** Les attributions manuelles (et les rôles Discord) ne valent que pour les règles manuelles. */
export function acceptsManualGrant(rule: BadgeRule): boolean {
  return rule.type === "manual";
}

export function parseBadgeRule(raw: string | null | undefined): BadgeRule {
  try {
    const parsed = badgeRuleSchema.safeParse(JSON.parse(raw || "{}"));
    return parsed.success ? parsed.data : { type: "manual" };
  } catch {
    return { type: "manual" };
  }
}

/** Badge tel qu'affiché sur une page publique : uniquement ce qui doit être vu. */
export type PublicBadge = {
  key: string;
  name: string;
  description: string;
  icon: string;
  imageUrl: string;
  color: string;
  /** Sceau officiel, posé par un administrateur habilité. */
  validated: boolean;
  staff: boolean;
};

export type SystemBadge = {
  key: string;
  name: string;
  description: string;
  icon: BadgeIconKey;
  color: string;
  staffOnly: boolean;
  restricted: boolean;
  rule: BadgeRule;
};

/** Badges intégrés, créés au premier usage puis modifiables depuis l'administration. */
export const SYSTEM_BADGES: SystemBadge[] = [
  {
    key: "fondateur",
    name: "Fondateur",
    description: "A fondé Unclaim.",
    icon: "crown",
    color: "#ffc247",
    staffOnly: true,
    restricted: true,
    rule: { type: "founder" },
  },
  {
    key: "administrateur",
    name: "Administrateur",
    description: "Administre Link by Unclaim.",
    icon: "shield",
    color: "#22c9e8",
    staffOnly: true,
    restricted: false,
    rule: { type: "manual" },
  },
  {
    key: "developpeur",
    name: "Développeur",
    description: "Développe Link by Unclaim.",
    icon: "code",
    color: "#a78bfa",
    staffOnly: true,
    restricted: false,
    rule: { type: "manual" },
  },
  {
    key: "moderateur",
    name: "Modérateur",
    description: "Veille au respect des règles.",
    icon: "gavel",
    color: "#34d399",
    staffOnly: true,
    restricted: false,
    rule: { type: "manual" },
  },
  {
    key: "staff",
    name: "Staff officiel",
    description: "Membre de l'équipe Unclaim.",
    icon: "star",
    color: "#38bdf8",
    staffOnly: true,
    restricted: false,
    rule: { type: "manual" },
  },
  {
    key: "partenaire",
    name: "Partenaire",
    description: "Partenaire officiel de Link by Unclaim.",
    icon: "handshake",
    color: "#22c9e8",
    staffOnly: false,
    restricted: false,
    rule: { type: "partner" },
  },
  {
    key: "verifie",
    name: "Utilisateur vérifié",
    description: "Identité vérifiée par l'équipe de Link by Unclaim.",
    icon: "badge-check",
    color: "#22c9e8",
    staffOnly: false,
    restricted: false,
    rule: { type: "verified" },
  },
  {
    key: "early-supporter",
    name: "Early Supporter",
    description: "Parmi les tout premiers comptes de Link by Unclaim.",
    icon: "rocket",
    color: "#f472b6",
    staffOnly: false,
    restricted: false,
    rule: { type: "early", limit: 100, requireDiscord: true, requirePage: true },
  },
  {
    key: "membre-historique",
    name: "Membre historique",
    description: "Membre depuis plus d'un an.",
    icon: "hourglass",
    color: "#fb923c",
    staffOnly: false,
    restricted: false,
    rule: { type: "seniority", days: 365 },
  },
  {
    key: "premium",
    name: "Premium",
    description: "Soutient Link by Unclaim avec une formule payante.",
    icon: "gem",
    color: "#ffc247",
    staffOnly: false,
    restricted: false,
    rule: { type: "plan", tier: "plus" },
  },
];

/** Champs modifiables d'un badge, validés côté serveur. */
export const badgeInputSchema = z.object({
  key: z.string().trim().toLowerCase().regex(BADGE_KEY_PATTERN, "Identifiant : minuscules, chiffres et tirets (2 à 32 caractères)."),
  name: z.string().trim().min(2, "Nom trop court.").max(32, "32 caractères maximum."),
  description: z.string().trim().max(140, "140 caractères maximum."),
  icon: z.enum(BADGE_ICONS),
  imageUrl: z.union([z.literal(""), z.string().regex(/^\/api\/uploads\/[a-z0-9]{8,40}$/i, "Image invalide.")]),
  color: z.string().regex(HEX_COLOR, "Couleur invalide."),
  visibility: z.enum(["public", "hidden"]),
  staffOnly: z.boolean(),
  restricted: z.boolean(),
  rule: badgeRuleSchema,
  durationDays: z.number().int().min(1).max(3650).nullable(),
  active: z.boolean(),
  position: z.number().int().min(0).max(999),
});
export type BadgeInput = z.infer<typeof badgeInputSchema>;
