// Exemples remplis pour présenter les modèles sur la landing : les vrais modèles (templates.ts)
// partent de blocs vides à compléter, ceux-ci montrent à quoi ressemble une page aboutie.
// Données fictives, jamais enregistrées.
import { makeProduct } from "./shop";
import { createBlock, type Block } from "./blocks";
import { DEFAULT_PAGE_OPTIONS, type PageView } from "./page-schema";
import { getPreset } from "./theme";
import { PAGE_TEMPLATES } from "./templates";

export type Showcase = { id: string; name: string; description: string; preset: string; page: PageView };

/** Date à venir, à l'heure ronde (agendas d'exemple toujours dans le futur). */
function upcoming(days: number, hour: number): string {
  const date = new Date();
  date.setDate(date.getDate() + days);
  date.setHours(hour, 0, 0, 0);
  return date.toISOString();
}

const half = <T extends Block>(block: T): T => ({ ...block, width: "half" });

const SAMPLES: Record<string, { name: string; pronouns: string; bio: string; ngUsername: string; blocks: () => Block[] }> = {
  joueur: {
    name: "Kaelis",
    pronouns: "elle/iel",
    bio: "Diplomate sur **Blue** · bâtisseuse de capitales",
    ngUsername: "Unclaim_Demo",
    blocks: () => [
      half(createBlock("nationsglory", {})),
      half(createBlock("skin", { animation: "wave", height: 280 })),
      createBlock("link", { label: "Rejoindre ma nation", url: "https://discord.gg", description: "Recrutement ouvert", highlight: true }),
      createBlock("socials", {
        items: [
          { platform: "youtube", url: "https://youtube.com" },
          { platform: "twitch", url: "https://twitch.tv" },
          { platform: "tiktok", url: "https://tiktok.com" },
        ],
      }),
    ],
  },
  streamer: {
    name: "Nova Live",
    pronouns: "",
    bio: "Streams **chill & compétitifs** · 4 soirs par semaine",
    ngUsername: "",
    blocks: () => [
      createBlock("link", { label: "Regarder le live", url: "https://twitch.tv", description: "En direct sur Twitch", emoji: "🔴", highlight: true, animation: "pulse" }),
      createBlock("events", {
        title: "Planning des streams",
        items: [
          { title: "Ranked jusqu'au bout de la nuit", start: upcoming(1, 21), end: "", location: "Twitch", url: "" },
          { title: "Soirée viewers", start: upcoming(3, 20), end: "", location: "Discord", url: "" },
          { title: "Tournoi caritatif", start: upcoming(6, 18), end: "", location: "Twitch", url: "" },
        ],
      }),
      createBlock("socials", {
        items: [
          { platform: "twitch", url: "https://twitch.tv" },
          { platform: "youtube", url: "https://youtube.com" },
          { platform: "x", url: "https://x.com" },
          { platform: "discord", url: "https://discord.gg" },
        ],
      }),
      createBlock("contact", { title: "Partenariats et collaborations" }),
    ],
  },
  createur: {
    name: "Studio Lumen",
    pronouns: "",
    bio: "Vidéos, musique et illustrations · nouvelle sortie chaque vendredi",
    ngUsername: "",
    blocks: () => [
      createBlock("socials", {
        style: "pills",
        items: [
          { platform: "youtube", url: "https://youtube.com" },
          { platform: "instagram", url: "https://instagram.com" },
          { platform: "tiktok", url: "https://tiktok.com" },
        ],
      }),
      createBlock("link", { label: "Ma dernière vidéo", url: "https://youtube.com", description: "Making-of de l'album", emoji: "🎬", animation: "shine" }),
      createBlock("music", {
        title: "Lueurs",
        artist: "Studio Lumen",
        links: [
          { platform: "spotify", url: "https://open.spotify.com" },
          { platform: "deezer", url: "https://deezer.com" },
          { platform: "applemusic", url: "https://music.apple.com" },
        ],
      }),
      createBlock("shop", {
        title: "La boutique",
        layout: "carousel",
        products: [
          makeProduct({ id: "p-vinyle", name: "Vinyle « Lueurs »", emoji: "💿", price: 2400, badge: "Édition limitée", mode: "link", url: "https://example.com", stock: 4 }),
          makeProduct({ id: "p-print", name: "Illustration A3", emoji: "🎨", price: 1800, compareAt: 2200, mode: "link", url: "https://example.com" }),
          makeProduct({ id: "p-tote", name: "Tote bag", emoji: "👜", price: 1200, mode: "link", url: "https://example.com" }),
          makeProduct({ id: "p-commission", name: "Commission", emoji: "✏️", price: null, mode: "link", url: "https://example.com", soldOut: true }),
        ],
      }),
      createBlock("collection", {
        title: "Mes liens",
        links: [
          { label: "Boutique", url: "https://example.com", emoji: "🛍️" },
          { label: "Portfolio", url: "https://example.com", emoji: "🎨" },
          { label: "Newsletter", url: "https://example.com", emoji: "💌" },
        ],
      }),
    ],
  },
  communaute: {
    name: "Le Bastion",
    pronouns: "",
    bio: "Serveur **survie & factions** · communauté francophone depuis 2019",
    ngUsername: "",
    blocks: () => [
      createBlock("copy", { label: "IP du serveur", value: "play.lebastion.fr", hint: "Version 1.20 et plus" }),
      half(createBlock("game", { game: "minecraft", username: "Unclaim_Demo", rank: "Fondateur", showLive: false, stats: [{ label: "Joueurs", value: "1 240" }] })),
      half(createBlock("badges", { title: "Le serveur", items: ["Survie", "Factions", "Événements", "Francophone"] })),
      createBlock("events", {
        title: "Prochains événements",
        items: [
          { title: "Guerre de factions", start: upcoming(2, 20), end: "", location: "Monde PvP", url: "" },
          { title: "Concours de build", start: upcoming(5, 15), end: "", location: "Spawn", url: "" },
        ],
      }),
      createBlock("contact", { title: "Recrutement et partenariats" }),
    ],
  },
  minimal: {
    name: "Alex Martin",
    pronouns: "il/lui",
    bio: "Développeur et joueur du dimanche.",
    ngUsername: "",
    blocks: () => [
      createBlock("socials", {
        items: [
          { platform: "github", url: "https://github.com" },
          { platform: "x", url: "https://x.com" },
          { platform: "discord", url: "https://discord.gg" },
        ],
      }),
      createBlock("link", { label: "Mon site", url: "https://example.com", emoji: "🌐" }),
      createBlock("link", { label: "Me contacter", url: "mailto:contact@example.com", emoji: "✉️" }),
    ],
  },
};

/** Un exemple par modèle, prêt à passer au moteur de rendu (mode « demo »). */
export function templateShowcases(): Showcase[] {
  return PAGE_TEMPLATES.flatMap((template) => {
    const sample = SAMPLES[template.id];
    const preset = getPreset(template.preset);
    if (!sample || !preset) return [];
    const page: PageView = {
      slug: template.id,
      published: true,
      views: 0,
      customCss: "",
      options: DEFAULT_PAGE_OPTIONS,
      // Mise en page en colonne : l'aperçu s'affiche dans un téléphone.
      theme: { ...preset.theme, layout: "stack", width: "narrow" },
      profile: {
        displayName: sample.name,
        pronouns: sample.pronouns,
        bio: sample.bio,
        avatarSource: "discord",
        avatarUrl: "",
        bannerUrl: "",
        ngUsername: sample.ngUsername,
        ngServer: "blue",
      },
      blocks: sample.blocks(),
    };
    return [{ id: template.id, name: template.name, description: template.description, preset: template.preset, page }];
  });
}
