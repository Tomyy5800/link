// Fonctionnalités pilotables depuis l'administration (partagé serveur / navigateur).
// Chaque fonctionnalité a un mode : ouverte à tous, réservée à partir d'un palier (Link+, Pro,
// Équipe), ou désactivée. Un palier comprend tout ce que contiennent les précédents.
import { TIER_RANK, type PaidTier, type Tier } from "./plans";

export type FeatureMode = "all" | PaidTier | "off";

/** Palier minimal d'un mode (null : ouvert à tous ou coupé). */
export function modeTier(mode: FeatureMode): PaidTier | null {
  return mode === "all" || mode === "off" ? null : mode;
}

/** Ancien mode « premium » (avant les formules) → Link+. */
export function normalizeMode(value: unknown): FeatureMode | null {
  if (value === "premium") return "plus";
  return value === "all" || value === "plus" || value === "pro" || value === "team" || value === "off" ? value : null;
}

export const FEATURES = {
  advancedLayout: {
    label: "Mise en page sur ordinateur",
    description: "Grille modulable (bento) et profil latéral, avec largeur et hauteur réglables par bloc.",
    default: "all",
  },
  blockStyles: {
    label: "Style par bloc",
    description: "Fond, couleur, alignement et masquage d'un bloc sur mobile ou ordinateur.",
    default: "all",
  },
  scheduling: {
    label: "Blocs programmés",
    description: "Afficher un bloc entre deux dates.",
    default: "all",
  },
  presence: {
    label: "Statut Discord en direct",
    description: "Bloc relié à Lanyard : statut, jeu en cours, Spotify.",
    default: "all",
  },
  customEmbeds: {
    label: "Intégrations libres",
    description: "N'importe quel site en iframe (hors domaines bloqués), avec hauteur réglable.",
    default: "pro",
  },
  htmlWidgets: {
    label: "Widgets HTML",
    description: "Code HTML/JS isolé dans un cadre sécurisé (compteurs, chats, widgets tiers).",
    default: "pro",
  },
  effects: {
    label: "Effets animés",
    description: "Particules, curseur, animation du nom, bio en machine à écrire, cartes inclinables.",
    default: "plus",
  },
  backgroundMedia: {
    label: "Musique et vidéo de fond",
    description: "Lecteur audio, vidéo en fond de page et écran d'entrée.",
    default: "plus",
  },
  customFonts: {
    label: "Polices Google Fonts",
    description: "Choisir n'importe quelle police Google Fonts pour le texte et les titres.",
    default: "plus",
  },
  automations: {
    label: "Automatisations",
    description: "Bandeaux, mise en avant et thèmes qui changent seuls : horaires, live, anniversaire.",
    default: "plus",
  },
  removeBranding: {
    label: "Retirer « Link by Unclaim »",
    description: "Masque la mention en bas de la page publique.",
    default: "plus",
  },
  advancedStats: {
    label: "Statistiques avancées",
    description: "Historique long, sources de trafic et appareils.",
    default: "plus",
  },
  shortSlug: {
    label: "Adresse courte",
    description: "Adresse de 3 ou 4 caractères.",
    default: "plus",
  },
  customCss: {
    label: "CSS personnalisé",
    description: "Feuille de style propre à la page, cantonnée à celle-ci.",
    default: "pro",
  },
  redirect: {
    label: "Redirection temporaire",
    description: "Envoyer les visiteurs vers une autre adresse pendant un live ou une sortie.",
    default: "pro",
  },
  webhooks: {
    label: "Notifications Discord",
    description: "Nouveau message, début de live, bilan de la semaine : envoyés sur ton serveur Discord.",
    default: "pro",
  },
  statsExport: {
    label: "Export des statistiques",
    description: "Téléchargement des vues et des clics au format tableur (CSV).",
    default: "pro",
  },
  shop: {
    label: "Boutique personnelle",
    description:
      "Bloc boutique : fiches produits, prix et promos, panier et demandes de commande. Ne s'applique que si les boutiques personnelles sont ouvertes (réglages sensibles).",
    default: "all",
  },
  customRoles: {
    label: "Rôles personnalisés",
    description: "Créer des rôles (nom, couleur, permissions) pour les collaborateurs d'une page.",
    default: "plus",
  },
  customDomains: {
    label: "Domaine personnel",
    description: "Afficher une page sur son propre nom de domaine (mondomaine.fr).",
    default: "pro",
  },
  brandKit: {
    label: "Kit de marque",
    description: "Appliquer le même thème à toutes tes pages en un clic.",
    default: "team",
  },
} as const satisfies Record<string, { label: string; description: string; default: FeatureMode }>;

export type FeatureKey = keyof typeof FEATURES;
export const FEATURE_KEYS = Object.keys(FEATURES) as FeatureKey[];

export type FeatureFlags = Record<FeatureKey, boolean>;

export type PlanLimits = {
  /** Nombre maximal de pages dont le compte est propriétaire. */
  pages: number;
  /** Collaborateurs par page (en plus du propriétaire). */
  members: number;
  /** Nombre maximal de blocs sur la page. */
  blocks: number;
  /** Nombre maximal de fichiers importés. */
  uploads: number;
  /** Taille maximale d'une image, en Mo. */
  imageMb: number;
  /** Taille maximale d'un fichier audio ou vidéo, en Mo. */
  mediaMb: number;
  /** Profondeur des statistiques, en jours. */
  statsDays: number;
  /** Messages par jour à l'assistant de création. */
  aiMessages: number;
  /** Rôles personnalisés par page. */
  roles: number;
  /** Domaines personnels par compte. */
  domains: number;
};

/** Paliers qui ont leurs propres limites (les partenaires en plus des quatre formules). */
export const LIMIT_TIERS = ["free", "plus", "pro", "team", "partner"] as const;
export type LimitTier = (typeof LIMIT_TIERS)[number];

export type BillingInterval = "month" | "year";

/** Offre d'abonnement : une formule facturée chaque mois ou chaque année, résiliable à tout moment. */
export type Offer = {
  id: string;
  /** Formule vendue par cette offre. */
  tier: PaidTier;
  name: string;
  /** Période de facturation. */
  interval: BillingInterval;
  /** Prix TTC par période, en centimes d'euro. */
  priceCents: number;
  description: string;
  /** Mise en avant sur la page des tarifs. */
  highlight: boolean;
  active: boolean;
};

/** Jours couverts par une période de facturation. */
export const INTERVAL_DAYS: Record<BillingInterval, number> = { month: 30, year: 365 };

/** Délai de grâce après la fin d'une période d'abonnement, le temps que Stripe relance le paiement. */
export const SUBSCRIPTION_GRACE_DAYS = 3;

/** Informations du vendeur, reprises dans les mentions légales et les CGV. */
export type LegalInfo = {
  /** Nom de l'éditeur (personne ou société). */
  sellerName: string;
  /** Statut : « Entrepreneur individuel (micro-entreprise) », « SAS au capital de … »… */
  status: string;
  address: string;
  email: string;
  /** SIREN / SIRET. */
  siret: string;
  /** Mention TVA, par exemple « TVA non applicable, art. 293 B du CGI ». */
  vatMention: string;
  /** Directeur de la publication. */
  publisher: string;
  /** Hébergeur : nom, adresse, téléphone. */
  host: string;
  /** Médiateur de la consommation (obligatoire pour vendre à des particuliers). */
  mediator: string;
};

export type PlatformSettings = {
  features: Record<FeatureKey, FeatureMode>;
  /** Limites par formule ; « partner » s'applique aux partenaires officiels. */
  limits: Record<LimitTier, PlanLimits>;
  /** Domaines interdits dans les liens et les intégrations (sous-domaines compris). */
  blockedDomains: string[];
  /** Nouvelles pages autorisées. */
  registrationsOpen: boolean;
  /** Message affiché en haut de l'éditeur (vide : aucun). */
  announcement: string;
  /** Nom commercial de l'offre payante. */
  premiumName: string;
  /** Lien vers une boutique externe où obtenir un code (vide : aucun). */
  premiumUrl: string;
  /** Abonnements en vente sur /plus. */
  offers: Offer[];
  /**
   * Boutiques personnelles des profils (bloc « Boutique ») : fermées par défaut. Fermées, elles
   * restent enregistrées mais invisibles, et aucune commande n'est acceptée.
   */
  personalShops: boolean;
  /** Accès offert : toutes les formules pour tous les comptes (lancement). Désactivé par défaut. */
  launchFreeAccess: boolean;
  legal: LegalInfo;
};

export const DEFAULT_SETTINGS: PlatformSettings = {
  features: Object.fromEntries(FEATURE_KEYS.map((k) => [k, FEATURES[k].default])) as Record<FeatureKey, FeatureMode>,
  limits: {
    free: { pages: 1, members: 1, blocks: 40, uploads: 30, imageMb: 2, mediaMb: 0, statsDays: 14, aiMessages: 20, roles: 0, domains: 0 },
    plus: { pages: 3, members: 2, blocks: 80, uploads: 150, imageMb: 8, mediaMb: 12, statsDays: 90, aiMessages: 60, roles: 3, domains: 0 },
    pro: { pages: 10, members: 5, blocks: 120, uploads: 400, imageMb: 10, mediaMb: 25, statsDays: 120, aiMessages: 200, roles: 8, domains: 1 },
    team: { pages: 25, members: 20, blocks: 120, uploads: 1000, imageMb: 10, mediaMb: 25, statsDays: 120, aiMessages: 400, roles: 20, domains: 5 },
    partner: { pages: 30, members: 25, blocks: 120, uploads: 1000, imageMb: 10, mediaMb: 25, statsDays: 120, aiMessages: 400, roles: 20, domains: 5 },
  },
  blockedDomains: [],
  registrationsOpen: true,
  announcement: "",
  premiumName: "Link+",
  premiumUrl: "",
  // Abonnements résiliables à tout moment. L'année vaut 8 mois (un tiers de remise) ; chaque
  // palier coûte le double du précédent (raisonnement : docs/TARIFS.md).
  offers: [
    { id: "mois", tier: "plus", name: "Mensuel", interval: "month", priceCents: 249, description: "Sans engagement, résiliable à tout moment.", highlight: false, active: true },
    { id: "an", tier: "plus", name: "Annuel", interval: "year", priceCents: 1999, description: "Environ 1,67 € par mois.", highlight: true, active: true },
    { id: "pro-mois", tier: "pro", name: "Mensuel", interval: "month", priceCents: 499, description: "Sans engagement, résiliable à tout moment.", highlight: false, active: true },
    { id: "pro-an", tier: "pro", name: "Annuel", interval: "year", priceCents: 3999, description: "Environ 3,33 € par mois.", highlight: true, active: true },
    { id: "equipe-mois", tier: "team", name: "Mensuel", interval: "month", priceCents: 999, description: "Pour une saison, un tournoi, une campagne.", highlight: false, active: true },
    { id: "equipe-an", tier: "team", name: "Annuel", interval: "year", priceCents: 7999, description: "Environ 6,67 € par mois, partagés par toute l'équipe.", highlight: true, active: true },
  ],
  personalShops: false,
  launchFreeAccess: false,
  legal: {
    sellerName: "",
    status: "",
    address: "",
    email: "",
    siret: "",
    vatMention: "TVA non applicable, art. 293 B du CGI",
    publisher: "",
    host: "",
    mediator: "",
  },
};

/** Prix affiché : 2,49 €. */
export function formatPrice(cents: number): string {
  return new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(cents / 100);
}

/** « par mois », « par an ». */
export function intervalLabel(interval: BillingInterval): string {
  return interval === "year" ? "par an" : "par mois";
}

/** Prix d'une offre ramené au mois, en centimes. */
export function monthlyCents(offer: Pick<Offer, "interval" | "priceCents">): number {
  return offer.interval === "year" ? Math.round(offer.priceCents / 12) : offer.priceCents;
}

/** Durée affichée : « 1 an », « 30 jours », « à vie ». */
export function formatDuration(days: number): string {
  if (days === 0) return "à vie";
  if (days % 365 === 0) return days === 365 ? "1 an" : `${days / 365} ans`;
  if (days % 30 === 0) return days === 30 ? "1 mois" : `${days / 30} mois`;
  return `${days} jours`;
}

/** Champs légaux encore vides (la vente ne devrait pas ouvrir avant de les remplir). */
export function missingLegal(legal: LegalInfo): (keyof LegalInfo)[] {
  return (Object.keys(legal) as (keyof LegalInfo)[]).filter((k) => !legal[k].trim());
}

/** Ce que le compte peut utiliser, calculé côté serveur et transmis à l'éditeur. */
export type Entitlements = {
  /** Formule en vigueur (les administrateurs et l'accès offert ont Équipe). */
  tier: Tier;
  /** Au moins Link+. */
  premium: boolean;
  /** Accès offert à tous, décidé dans l'administration (réglages sensibles). */
  freeForAll: boolean;
  /** Fin d'une formule à durée limitée (code, don) ; null pour un abonnement ou sans limite. */
  premiumUntil: string | null;
  /** Abonnement en cours : fin de la période payée et renouvellement automatique. */
  subscription: { tier: Tier; until: string; renews: boolean } | null;
  /** Boutiques personnelles ouvertes par l'administration (sinon le bloc Boutique est en pause). */
  personalShops: boolean;
  admin: boolean;
  /** Partenaire officiel : fonctions de Link+ et limites « partenaires ». */
  partner: boolean;
  features: FeatureFlags;
  /** Mode de chaque fonctionnalité, pour afficher « Link+ » ou masquer ce qui est désactivé. */
  modes: Record<FeatureKey, FeatureMode>;
  limits: PlanLimits;
  premiumName: string;
  premiumUrl: string;
};

export function resolveFeatures(modes: Record<FeatureKey, FeatureMode>, tier: Tier): FeatureFlags {
  return Object.fromEntries(
    FEATURE_KEYS.map((k) => {
      const needed = modeTier(modes[k]);
      return [k, modes[k] === "all" || (needed !== null && TIER_RANK[tier] >= TIER_RANK[needed])];
    }),
  ) as FeatureFlags;
}

/** Tout est permis (aperçu d'administration, démonstration). */
export const ALL_FEATURES: FeatureFlags = Object.fromEntries(FEATURE_KEYS.map((k) => [k, true])) as FeatureFlags;

/** Un domaine (ou l'un de ses parents) est-il bloqué ? */
export function isDomainBlocked(host: string, blocked: string[]): boolean {
  const h = host.toLowerCase().replace(/^www\./, "");
  return blocked.some((d) => {
    const b = d.toLowerCase().trim().replace(/^\*\./, "").replace(/^www\./, "");
    return b && (h === b || h.endsWith(`.${b}`));
  });
}
