// Thèmes des pages publiques : schéma, préréglages et conversion en variables CSS.
import type { CSSProperties } from "react";
import { z } from "zod";
import { FRAME_KEYS } from "./official-shop";
import { isValidRadioSource } from "./radio";
import { normalizeImageUrl } from "./urls";

const hex = z.string().regex(/^#[0-9a-fA-F]{6}$/, "Couleur hexadécimale attendue (#rrggbb)");

const imageUrl = z
  .string()
  .max(2048)
  .refine((v) => normalizeImageUrl(v) !== null, "URL d'image invalide")
  .transform((v) => normalizeImageUrl(v) ?? "");

/** Fichier audio ou vidéo : uniquement importé sur la plateforme (pas de lien externe). */
const mediaUrl = z
  .string()
  .max(80)
  .refine((v) => v === "" || /^\/api\/uploads\/[a-z0-9]+$/i.test(v), "Fichier importé attendu")
  .default("");

export const PARTICLES = ["none", "snow", "sakura", "sparkles", "fireflies", "rain", "embers"] as const;
export const NAME_ANIMATIONS = ["none", "rainbow", "glitch", "typewriter", "wave", "shine"] as const;

export const FONT_KEYS = ["inter", "grotesk", "chakra", "display", "serif", "mono", "pixel", "arcade"] as const;
export type FontKey = (typeof FONT_KEYS)[number];

/** Polices réservées aux titres (illisibles en texte courant). */
export const HEADING_ONLY_FONTS: readonly FontKey[] = ["arcade"];

export const BG_EFFECTS = ["none", "grain", "grid", "chunks", "dots", "stars", "aurora"] as const;

export const themeSchema = z.object({
  preset: z.string().max(32).default("unclaim"),
  // Couleurs
  accent: hex.default("#22c9e8"),
  accent2: hex.default("#ffc247"),
  text: hex.default("#f8fafc"),
  // Fond
  bgType: z.enum(["solid", "gradient", "image"]).default("gradient"),
  bgColor: hex.default("#020618"),
  bgColor2: hex.default("#0f172b"),
  bgAngle: z.number().int().min(0).max(360).default(180),
  bgImage: imageUrl.default(""),
  bgDim: z.number().int().min(0).max(90).default(40),
  bgBlur: z.number().int().min(0).max(24).default(0),
  bgEffect: z.enum(BG_EFFECTS).default("none"),
  // Cartes
  cardStyle: z.enum(["glass", "solid", "outline", "flat"]).default("glass"),
  cardColor: hex.default("#ffffff"),
  /** Opacité du fond des cartes en % (null : valeur du style choisi). */
  cardOpacity: z.number().int().min(0).max(100).nullable().default(null),
  cardBlur: z.number().int().min(0).max(30).default(14),
  cardShadow: z.enum(["none", "soft", "strong", "glow"]).default("none"),
  // Boutons
  radius: z.enum(["none", "sm", "md", "lg", "full"]).default("md"),
  buttonFill: z.enum(["solid", "soft", "outline"]).default("solid"),
  buttonGradient: z.boolean().default(false),
  buttonHover: z.enum(["lift", "glow", "grow", "none"]).default("lift"),
  buttonAlign: z.enum(["left", "center"]).default("left"),
  // Typographie et mise en page
  font: z.enum(FONT_KEYS).default("inter"),
  /** Police des titres et du nom (null : même police que le texte). */
  headingFont: z.enum(FONT_KEYS).nullable().default(null),
  /** Police Google Fonts du texte (fonction « Polices Google Fonts ») ; vide : police de la liste. */
  googleFont: z.string().trim().max(40).regex(/^[A-Za-z0-9 ]*$/, "Nom de police invalide (lettres, chiffres, espaces)").default(""),
  /** Police Google Fonts des titres et du nom ; vide : celle du texte. */
  googleHeadingFont: z.string().trim().max(40).regex(/^[A-Za-z0-9 ]*$/, "Nom de police invalide (lettres, chiffres, espaces)").default(""),
  width: z.enum(["narrow", "wide", "full"]).default("narrow"),
  animation: z.enum(["none", "fade", "rise", "pop"]).default("rise"),
  // Mise en page sur ordinateur (le mobile reste une colonne à deux demi-largeurs)
  layout: z.enum(["stack", "grid", "sidebar"]).default("stack"),
  columns: z.union([z.literal(2), z.literal(3), z.literal(4)]).default(3),
  gap: z.enum(["sm", "md", "lg"]).default("md"),
  rowHeight: z.enum(["sm", "md", "lg"]).default("md"),
  // Effets (Link+ selon l'administration)
  particles: z.enum(PARTICLES).default("none"),
  cursor: z.enum(["default", "glow", "trail", "image"]).default("default"),
  cursorImage: imageUrl.default(""),
  nameAnimation: z.enum(NAME_ANIMATIONS).default("none"),
  bioTypewriter: z.boolean().default(false),
  tilt: z.boolean().default(false),
  // Médias de fond (Link+ selon l'administration)
  entryScreen: z.boolean().default(false),
  entryText: z.string().max(60).default("Clique pour entrer"),
  audioUrl: mediaUrl,
  /** Webradio en musique de fond : radio préréglée (« lyxia ») ou flux https. Prioritaire sur audioUrl. */
  audioRadio: z.string().trim().max(500).refine(isValidRadioSource, "Radio invalide").default(""),
  audioVolume: z.number().int().min(0).max(100).default(40),
  /** Lecteur de la musique de fond : en bas à gauche, à droite, ou réduit à un bouton. */
  audioPlayer: z.enum(["left", "right", "compact"]).default("left"),
  bgVideoUrl: mediaUrl,
  // En-tête
  headerLayout: z.enum(["classic", "left", "hero", "minimal"]).default("classic"),
  avatarShape: z.enum(["circle", "rounded", "square"]).default("circle"),
  avatarSize: z.enum(["sm", "md", "lg"]).default("md"),
  avatarRing: z.enum(["none", "accent", "gradient", "glow"]).default("none"),
  /** Cadre d'avatar de la boutique officielle : affiché seulement si le propriétaire l'a débloqué. */
  avatarFrame: z.enum(["none", ...FRAME_KEYS] as const).default("none"),
  nameEffect: z.enum(["none", "gradient", "glow", "shadow"]).default("none"),
  showBanner: z.boolean().default(true),
  showBadges: z.boolean().default(true),
  showViews: z.boolean().default(true),
});

export type Theme = z.infer<typeof themeSchema>;

export const DEFAULT_THEME: Theme = themeSchema.parse({});

/** Lit un thème stocké (JSON) en tolérant les anciennes versions ou les données corrompues. */
export function parseTheme(raw: unknown): Theme {
  let value = raw;
  if (typeof raw === "string") {
    try {
      value = JSON.parse(raw);
    } catch {
      value = {};
    }
  }
  const strict = themeSchema.safeParse(value);
  if (strict.success) return strict.data;
  // Récupère champ par champ ce qui est encore valide.
  const result: Record<string, unknown> = { ...DEFAULT_THEME };
  if (value && typeof value === "object") {
    for (const [key, field] of Object.entries(themeSchema.shape)) {
      const parsed = (field as z.ZodType).safeParse((value as Record<string, unknown>)[key]);
      if (parsed.success) result[key] = parsed.data;
    }
  }
  return themeSchema.parse(result);
}

// ─── Préréglages ─────────────────────────────────────────────────────────────

export type ThemePreset = { key: string; label: string; theme: Theme };

const preset = (key: string, label: string, values: Partial<Theme>): ThemePreset => ({
  key,
  label,
  theme: { ...DEFAULT_THEME, ...values, preset: key },
});

export const THEME_PRESETS: ThemePreset[] = [
  // La charte Link by Unclaim : nuit Unclaim, signal cyan, signature ambre, carte des chunks.
  preset("unclaim", "Unclaim", {
    cardStyle: "solid", cardColor: "#0f172b", radius: "sm", font: "inter", headingFont: "chakra",
    bgEffect: "chunks", avatarShape: "rounded", avatarRing: "gradient",
  }),
  preset("midnight", "Minuit", {
    accent: "#5865f2", accent2: "#eb459e", text: "#e6e8ee", bgType: "solid", bgColor: "#0b0d12", bgColor2: "#111521",
    cardStyle: "solid", cardColor: "#151a26", radius: "sm", buttonFill: "soft", font: "inter",
  }),
  preset("nations", "Nations", {
    accent: "#f2c94c", accent2: "#7bd389", text: "#f8f5e6", bgType: "gradient", bgColor: "#0b1a12", bgColor2: "#1f3d24",
    cardStyle: "outline", cardColor: "#10241a", radius: "sm", buttonFill: "solid", font: "pixel", headingFont: "arcade",
    avatarShape: "square", bgEffect: "chunks",
  }),
  preset("aurora", "Aurore", {
    accent: "#3ee6c1", accent2: "#7c5cf5", text: "#ecfffb", bgType: "gradient", bgColor: "#021118", bgColor2: "#0c3a4a",
    bgAngle: 200, cardStyle: "glass", radius: "full", buttonFill: "soft", font: "inter", bgEffect: "aurora",
  }),
  preset("sunset", "Couchant", {
    accent: "#2b1205", accent2: "#c2410c", text: "#2b1205", bgType: "gradient", bgColor: "#ff7e5f", bgColor2: "#feb47b",
    bgAngle: 135, cardStyle: "glass", radius: "full", buttonFill: "solid", font: "grotesk", bgEffect: "grain",
  }),
  preset("paper", "Papier", {
    accent: "#e4572e", accent2: "#2e86ab", text: "#1d1b19", bgType: "solid", bgColor: "#f6f3ee", bgColor2: "#ece6dc",
    cardStyle: "solid", cardColor: "#ffffff", radius: "md", buttonFill: "outline", font: "serif", avatarShape: "rounded",
    cardShadow: "soft", bgEffect: "grain",
  }),
  preset("neon", "Néon", {
    accent: "#c6f432", accent2: "#22d3ee", text: "#f0f0f0", bgType: "solid", bgColor: "#050505", bgColor2: "#101010",
    cardStyle: "outline", cardColor: "#0c0c0c", radius: "none", buttonFill: "outline", font: "mono", avatarShape: "square",
    buttonHover: "glow", bgEffect: "grid",
  }),
  preset("royaume", "Royaume", {
    accent: "#e9b949", accent2: "#b23a48", text: "#f7ecd9", bgType: "gradient", bgColor: "#1a0b10", bgColor2: "#3b1020",
    bgAngle: 170, cardStyle: "outline", cardColor: "#2a0f18", radius: "sm", buttonFill: "soft", font: "serif",
    headingFont: "serif", avatarRing: "accent", nameEffect: "gradient", bgEffect: "grain",
  }),
  preset("cyber", "Cyber", {
    accent: "#ff2bd6", accent2: "#22d3ee", text: "#f5f3ff", bgType: "gradient", bgColor: "#05010f", bgColor2: "#1a0638",
    bgAngle: 160, cardStyle: "glass", cardColor: "#ffffff", radius: "none", buttonFill: "outline", buttonGradient: true,
    buttonHover: "glow", font: "mono", headingFont: "display", nameEffect: "glow", avatarRing: "glow", bgEffect: "grid",
  }),
  preset("sakura", "Sakura", {
    accent: "#d6336c", accent2: "#f783ac", text: "#4a1d2f", bgType: "gradient", bgColor: "#fff1f5", bgColor2: "#ffe0eb",
    bgAngle: 160, cardStyle: "solid", cardColor: "#ffffff", radius: "full", buttonFill: "soft", font: "grotesk",
    headingFont: "serif", cardShadow: "soft", avatarRing: "accent", bgEffect: "dots",
  }),
  preset("ocean", "Océan", {
    accent: "#4fd1c5", accent2: "#63b3ed", text: "#e6fffb", bgType: "gradient", bgColor: "#021b2b", bgColor2: "#05445e",
    bgAngle: 190, cardStyle: "glass", radius: "lg", buttonFill: "soft", font: "inter", headingFont: "display",
    bgEffect: "aurora", headerLayout: "hero",
  }),
  preset("arcade", "Arcade", {
    accent: "#ffd319", accent2: "#ff2975", text: "#f5f5ff", bgType: "gradient", bgColor: "#120458", bgColor2: "#2b0a6e",
    bgAngle: 180, cardStyle: "solid", cardColor: "#1d0c63", radius: "none", buttonFill: "solid", buttonHover: "grow",
    font: "pixel", headingFont: "arcade", avatarShape: "square", bgEffect: "stars", animation: "pop",
  }),
];

export function getPreset(key: string): ThemePreset | undefined {
  return THEME_PRESETS.find((p) => p.key === key);
}

// ─── Couleurs ────────────────────────────────────────────────────────────────

function hexToRgb(value: string): [number, number, number] {
  const n = Number.parseInt(value.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export function relativeLuminance(value: string): number {
  const [r, g, b] = hexToRgb(value).map((c) => {
    const s = c / 255;
    return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

export function contrastRatio(a: string, b: string): number {
  const [l1, l2] = [relativeLuminance(a), relativeLuminance(b)].sort((x, y) => y - x);
  return (l1 + 0.05) / (l2 + 0.05);
}

/** Accent d'une page, lisible sur les fonds sombres du site (vitrine, « Mon espace ») ; repli : cyan Unclaim. */
export function accentOnDark(accent: string): string {
  return /^#[0-9a-fA-F]{6}$/.test(accent) && contrastRatio(accent, "#0a0f1a") >= 3 ? accent : "#5fd9ef";
}

/** Couleur de texte lisible sur un fond donné. */
export function readableOn(background: string): string {
  return contrastRatio(background, "#ffffff") >= contrastRatio(background, "#0b0b10") ? "#ffffff" : "#0b0b10";
}

export function rgba(value: string, alpha: number): string {
  const [r, g, b] = hexToRgb(value);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

export function intToHex(value: number | null | undefined): string | null {
  if (value === null || value === undefined) return null;
  return `#${value.toString(16).padStart(6, "0")}`;
}

// ─── Conversion en styles ────────────────────────────────────────────────────

const RADIUS: Record<Theme["radius"], string> = { none: "0px", sm: "8px", md: "14px", lg: "20px", full: "999px" };
const CARD_RADIUS: Record<Theme["radius"], string> = { none: "0px", sm: "10px", md: "18px", lg: "24px", full: "28px" };

export const FONT_STACKS: Record<FontKey, string> = {
  inter: "var(--font-inter), ui-sans-serif, system-ui, sans-serif",
  grotesk: "var(--font-grotesk), ui-sans-serif, system-ui, sans-serif",
  chakra: "var(--font-chakra), ui-sans-serif, system-ui, sans-serif",
  display: "var(--font-unbounded), ui-sans-serif, system-ui, sans-serif",
  serif: "var(--font-serif), ui-serif, Georgia, serif",
  mono: "var(--font-jetbrains), ui-monospace, SFMono-Regular, monospace",
  pixel: "var(--font-pixel), ui-monospace, monospace",
  arcade: "var(--font-arcade), ui-monospace, monospace",
};

export const FONT_LABELS: Record<FontKey, string> = {
  inter: "Inter",
  grotesk: "Space Grotesk",
  chakra: "Chakra Petch",
  display: "Unbounded",
  serif: "Fraunces",
  mono: "JetBrains Mono",
  pixel: "Pixel (VT323)",
  arcade: "Arcade (Press Start)",
};

/** Taille relative des polices à petit œil (VT323) ou très larges (Press Start). */
const FONT_SCALE: Partial<Record<FontKey, number>> = { pixel: 1.22, arcade: 0.72 };

function cardBackground(theme: Theme, isLightBg: boolean): string {
  const defaults: Record<Theme["cardStyle"], number> = {
    glass: isLightBg ? 55 : 8,
    solid: 100,
    outline: 0,
    flat: 6,
  };
  const opacity = (theme.cardOpacity ?? defaults[theme.cardStyle]) / 100;
  const base = theme.cardStyle === "flat" ? theme.text : theme.cardColor;
  return opacity >= 1 ? base : rgba(base, opacity);
}

const SHADOWS: Record<Theme["cardShadow"], (t: Theme) => string> = {
  none: () => "none",
  soft: () => "0 10px 30px -12px rgba(0, 0, 0, 0.35)",
  strong: () => "0 24px 50px -16px rgba(0, 0, 0, 0.6)",
  glow: (t) => `0 0 0 1px ${rgba(t.accent, 0.25)}, 0 10px 40px -10px ${rgba(t.accent, 0.55)}`,
};

/** Variables CSS consommées par les composants de la page (préfixe --lbu-). */
export function themeVars(theme: Theme): CSSProperties {
  const isLightBg = relativeLuminance(theme.bgColor) > 0.45;
  const translucent = theme.cardStyle === "glass" || (theme.cardOpacity !== null && theme.cardOpacity < 100);
  let cardBorder: string;
  switch (theme.cardStyle) {
    case "glass":
      cardBorder = rgba(theme.text, 0.12);
      break;
    case "solid":
      cardBorder = rgba(theme.text, 0.06);
      break;
    case "outline":
      cardBorder = rgba(theme.text, 0.28);
      break;
    case "flat":
    default:
      cardBorder = "transparent";
  }
  const headingFont = theme.headingFont ?? theme.font;
  // Polices Google Fonts en premier choix, la police de la liste en secours le temps du chargement.
  const bodyStack = theme.googleFont ? `"${theme.googleFont}", ${FONT_STACKS[theme.font]}` : FONT_STACKS[theme.font];
  const headingGoogle = theme.googleHeadingFont || (theme.headingFont === null ? theme.googleFont : "");
  const headingStack = headingGoogle ? `"${headingGoogle}", ${FONT_STACKS[headingFont]}` : FONT_STACKS[headingFont];
  const accentFill = theme.buttonGradient
    ? `linear-gradient(135deg, ${theme.accent}, ${theme.accent2})`
    : theme.accent;

  return {
    "--lbu-accent": theme.accent,
    // Accent utilisé comme couleur de texte : la couleur du texte si l'accent est illisible sur les cartes.
    "--lbu-accent-ink": contrastRatio(theme.accent, theme.cardStyle === "flat" || theme.cardStyle === "outline" ? theme.bgColor : theme.cardColor) >= 3 ? theme.accent : theme.text,
    "--lbu-accent-2": theme.accent2,
    "--lbu-accent-fill": accentFill,
    "--lbu-on-accent": readableOn(theme.accent),
    "--lbu-accent-soft": rgba(theme.accent, 0.16),
    "--lbu-accent-line": rgba(theme.accent, 0.45),
    "--lbu-accent-glow": rgba(theme.accent, 0.55),
    "--lbu-text": theme.text,
    "--lbu-muted": rgba(theme.text, 0.68),
    "--lbu-faint": rgba(theme.text, 0.12),
    "--lbu-card-bg": cardBackground(theme, isLightBg),
    "--lbu-card-border": cardBorder,
    "--lbu-card-blur": translucent && theme.cardBlur > 0 ? `blur(${theme.cardBlur}px) saturate(140%)` : "none",
    "--lbu-card-shadow": SHADOWS[theme.cardShadow](theme),
    "--lbu-radius": RADIUS[theme.radius],
    "--lbu-card-radius": CARD_RADIUS[theme.radius],
    "--lbu-font": bodyStack,
    "--lbu-heading-font": headingStack,
    "--lbu-heading-scale": String(FONT_SCALE[headingFont] ?? 1),
    "--lbu-font-scale": String(FONT_SCALE[theme.font] ?? 1),
    color: theme.text,
    fontFamily: bodyStack,
  } as CSSProperties;
}

/** Feuille de style Google Fonts des polices choisies (null : aucune). */
export function googleFontsHref(theme: Pick<Theme, "googleFont" | "googleHeadingFont">): string | null {
  const families = [...new Set([theme.googleFont, theme.googleHeadingFont].filter(Boolean))];
  if (!families.length) return null;
  return `https://fonts.googleapis.com/css2?${families.map((f) => `family=${encodeURIComponent(f).replace(/%20/g, "+")}`).join("&")}&display=swap`;
}

/** Polices Google Fonts proposées dans l'éditeur (toute autre police du catalogue reste possible). */
export const GOOGLE_FONT_SUGGESTIONS = [
  "Poppins",
  "Montserrat",
  "Outfit",
  "Lexend",
  "Rubik",
  "Space Grotesk",
  "Orbitron",
  "Audiowide",
  "Russo One",
  "Bebas Neue",
  "Righteous",
  "Press Start 2P",
  "Silkscreen",
  "VT323",
  "Pacifico",
  "Caveat",
] as const;

/** Fond de page (couleur, dégradé ou image). */
export function backgroundStyle(theme: Theme): CSSProperties {
  if (theme.bgType === "image" && theme.bgImage) {
    return {
      backgroundColor: theme.bgColor,
      backgroundImage: `url("${theme.bgImage.replace(/"/g, "%22")}")`,
      backgroundSize: "cover",
      backgroundPosition: "center",
    };
  }
  if (theme.bgType === "gradient") {
    return { backgroundImage: `linear-gradient(${theme.bgAngle}deg, ${theme.bgColor}, ${theme.bgColor2})` };
  }
  return { backgroundColor: theme.bgColor };
}

// ─── Import / export ─────────────────────────────────────────────────────────

/** Thème exportable (sans l'image de fond importée, propre à la page). */
export function exportTheme(theme: Theme): string {
  // Les fichiers importés appartiennent à la page : ils ne voyagent pas avec le thème.
  const local = (v: string) => (v.startsWith("/api/uploads/") ? "" : v);
  return JSON.stringify(
    {
      format: "link-by-unclaim/theme@3",
      ...theme,
      bgImage: local(theme.bgImage),
      cursorImage: local(theme.cursorImage),
      audioUrl: "",
      bgVideoUrl: "",
    },
    null,
    2,
  );
}

/** Lit un thème collé par l'utilisateur ; null si ce n'est pas un thème. */
export function importTheme(text: string): Theme | null {
  let value: unknown;
  try {
    value = JSON.parse(text);
  } catch {
    return null;
  }
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const known = Object.keys(themeSchema.shape);
  if (!Object.keys(value).some((k) => known.includes(k))) return null;
  return { ...parseTheme(value), preset: "custom" };
}
