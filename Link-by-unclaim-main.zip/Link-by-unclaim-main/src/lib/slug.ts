// Règles des adresses personnalisées (link.unclaim/<slug>, aussi joignables en /profil/<slug>).
import { isOfficialName } from "./reserved-names";

export const SLUG_MIN = 3;
/** Longueur minimale sans l'option « adresse courte » (Link+ selon l'administration). */
export const SLUG_MIN_STANDARD = 5;
export const SLUG_MAX = 30;

const SLUG_PATTERN = /^[a-z0-9](?:[a-z0-9._-]*[a-z0-9])?$/;

/** Adresses réservées aux routes de l'application ou à la marque. */
export const RESERVED_SLUGS = new Set([
  "about", "admin", "api", "app", "assets", "auth", "callback", "contact", "dashboard", "discord",
  "edit", "editor", "explore", "favicon.ico", "help", "home", "legal", "link", "links", "login",
  "logout", "me", "nationsglory", "new", "ng", "opengraph-image", "p", "page", "pages", "privacy",
  "profile", "public", "robots.txt", "settings", "signin", "signup", "sitemap.xml", "skin", "static",
  "status", "support", "terms", "u", "unclaim", "uploads", "user", "users", "www", "_next",
  // Vente de Link+ et pages légales.
  "plus", "tarifs", "pricing", "checkout", "merci", "cgv", "cgu", "mentions-legales", "confidentialite",
  "boutique", "shop", "premium", "abonnement", "manifest.webmanifest", "icon.svg", "favicon.svg",
  // Mon espace, équipes et partenaires.
  "bienvenue", "invitation", "invitations", "partenaires", "partenaire", "partners", "partner", "compte", "messages",
  "jeux", "games", "equipe", "team",
  // Profils, staff, badges, boutique officielle et domaines.
  "profil", "profils", "staff", "badges", "badge", "domaines", "domaine", "domains", "boutique-officielle", "store",
  "commandes", "officiel", "official", "moderation", "fondateur", "founder",
]);

export type SlugCheck = { ok: true; slug: string } | { ok: false; error: string };

type SlugOptions = {
  allowShort?: boolean;
  premiumName?: string;
  /** Staff : peut prendre une adresse qui reprend un nom officiel (« unclaim-support »…). */
  allowOfficial?: boolean;
};

export function normalizeSlug(input: string): string {
  return input.trim().toLowerCase();
}

export function validateSlug(input: string, opts: SlugOptions = {}): SlugCheck {
  const slug = normalizeSlug(input);
  if (slug.length < SLUG_MIN) return { ok: false, error: `Au moins ${SLUG_MIN} caractères.` };
  if (slug.length < SLUG_MIN_STANDARD && !opts.allowShort) {
    return {
      ok: false,
      error: opts.premiumName
        ? `Au moins ${SLUG_MIN_STANDARD} caractères (les adresses courtes sont réservées à ${opts.premiumName}).`
        : `Au moins ${SLUG_MIN_STANDARD} caractères.`,
    };
  }
  if (slug.length > SLUG_MAX) return { ok: false, error: `${SLUG_MAX} caractères maximum.` };
  if (!SLUG_PATTERN.test(slug)) {
    return { ok: false, error: "Lettres minuscules, chiffres, « . », « _ » et « - » uniquement (pas en début ni en fin)." };
  }
  if (/[._-]{2,}/.test(slug)) return { ok: false, error: "Pas deux séparateurs à la suite." };
  if (RESERVED_SLUGS.has(slug)) return { ok: false, error: "Cette adresse est réservée." };
  if (!opts.allowOfficial && isOfficialName(slug)) return { ok: false, error: "Cette adresse reprend un nom officiel d'Unclaim : elle est réservée à l'équipe." };
  return { ok: true, slug };
}

/** Propose une adresse à partir d'un pseudo Discord. */
export function suggestSlug(name: string): string {
  const base = name
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, "-")
    .replace(/[._-]{2,}/g, "-")
    .replace(/^[._-]+|[._-]+$/g, "")
    .slice(0, SLUG_MAX);
  if (base.length >= SLUG_MIN_STANDARD && !RESERVED_SLUGS.has(base)) return base;
  return `${base || "profil"}-${Math.floor(Math.random() * 900 + 100)}`.slice(0, SLUG_MAX);
}
