// Rôles des collaborateurs d'une page (partagé serveur / navigateur).
//
// Deux rôles de base (Éditeur, Lecteur) et, avec Link+ ou plus, des rôles personnalisés : un
// nom, une couleur, une icône et des permissions choisies dans la liste ci-dessous. Ces
// permissions ne concernent que la page : aucune ne donne accès à l'administration, aux badges
// officiels ou aux réglages réservés au propriétaire (adresse, équipe, domaines, suppression).
import { z } from "zod";
import { HEX_COLOR } from "./badges";
import { OFFICIAL_NAME_ERROR, isOfficialName } from "./reserved-names";

export const PAGE_PERMISSIONS = {
  content: { label: "Modifier la page", description: "Blocs, profil, apparence et notifications." },
  "messages.read": { label: "Lire les messages", description: "Voir les messages reçus et les marquer comme lus." },
  "messages.manage": { label: "Supprimer les messages", description: "Effacer des messages reçus." },
  orders: { label: "Gérer les commandes", description: "Accepter, terminer, annuler et supprimer les commandes de la boutique." },
  stats: { label: "Voir les statistiques", description: "Vues, clics, sources de trafic." },
} as const;

export type PagePermission = keyof typeof PAGE_PERMISSIONS;
export const PAGE_PERMISSION_KEYS = Object.keys(PAGE_PERMISSIONS) as PagePermission[];

/** Permissions des rôles de base. */
export const BASE_ROLE_PERMISSIONS: Record<"editor" | "viewer", PagePermission[]> = {
  editor: ["content", "messages.read", "messages.manage", "orders", "stats"],
  viewer: ["messages.read", "stats"],
};

export const ROLE_ICONS = ["user", "star", "shield", "pen", "megaphone", "camera", "music", "gamepad", "palette", "headphones", "store", "crown"] as const;
export type RoleIcon = (typeof ROLE_ICONS)[number];

export function parsePagePermissions(raw: string | null | undefined): PagePermission[] {
  try {
    const value: unknown = JSON.parse(raw || "[]");
    return Array.isArray(value) ? [...new Set(value.filter((v): v is PagePermission => typeof v === "string" && v in PAGE_PERMISSIONS))] : [];
  } catch {
    return [];
  }
}

export const memberRoleInputSchema = z.object({
  name: z
    .string()
    .trim()
    .min(2, "Nom trop court.")
    .max(24, "24 caractères maximum.")
    .refine((v) => !isOfficialName(v), OFFICIAL_NAME_ERROR),
  color: z.string().regex(HEX_COLOR, "Couleur invalide."),
  icon: z.enum(ROLE_ICONS),
  description: z.string().trim().max(120, "120 caractères maximum."),
  permissions: z.array(z.enum(PAGE_PERMISSION_KEYS as [PagePermission, ...PagePermission[]])).max(PAGE_PERMISSION_KEYS.length),
});
export type MemberRoleInput = z.infer<typeof memberRoleInputSchema>;

/** Rôle personnalisé tel qu'envoyé à l'éditeur. */
export type MemberRoleView = {
  id: string;
  name: string;
  color: string;
  icon: RoleIcon;
  description: string;
  permissions: PagePermission[];
  members: number;
};
