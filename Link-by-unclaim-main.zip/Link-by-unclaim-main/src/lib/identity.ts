// Identités Unclaim Auth (partagé serveur / navigateur).
// La connexion passe par n'importe quel fournisseur de la passerelle ; seuls les pseudos
// publics par nature (Discord, Twitch, NationsGlory) peuvent apparaître sur une page.
// Les comptes Google, Microsoft et Apple ne révèlent jamais leur identifiant (souvent un e-mail).

export type ProviderMeta = {
  name: string;
  /** Couleur de marque, pour les boutons de connexion. */
  color: string;
  /** Couleur du texte sur le bouton. */
  text: string;
  /** Le pseudo peut-il être affiché publiquement ? */
  publicHandle: boolean;
};

export const PROVIDERS: Record<string, ProviderMeta> = {
  discord: { name: "Discord", color: "#5865f2", text: "#ffffff", publicHandle: true },
  google: { name: "Google", color: "#ffffff", text: "#1f1f1f", publicHandle: false },
  microsoft: { name: "Microsoft", color: "#2f2f2f", text: "#ffffff", publicHandle: false },
  apple: { name: "Apple", color: "#000000", text: "#ffffff", publicHandle: false },
  twitch: { name: "Twitch", color: "#9146ff", text: "#ffffff", publicHandle: true },
  nationsglory: { name: "NationsGlory", color: "#ffc247", text: "#021018", publicHandle: true },
};

export function providerMeta(id: string): ProviderMeta {
  return PROVIDERS[id] ?? { name: id.charAt(0).toUpperCase() + id.slice(1), color: "#1d293d", text: "#f8fafc", publicHandle: false };
}

/** Identité rattachée, telle que conservée par Link (jamais d'e-mail ni d'identifiant privé). */
export type LinkedIdentity = { provider: string; username: string | null };

export function parseIdentities(raw: string | null | undefined): LinkedIdentity[] {
  try {
    const value = JSON.parse(raw ?? "[]") as unknown;
    if (!Array.isArray(value)) return [];
    return value
      .filter((v): v is { provider: string; username?: unknown } => typeof v === "object" && v !== null && typeof (v as { provider?: unknown }).provider === "string")
      .map((v) => ({ provider: v.provider, username: typeof v.username === "string" ? v.username.slice(0, 64) : null }))
      .slice(0, 12);
  } catch {
    return [];
  }
}

/** Avatar par défaut aux couleurs de la charte, à partir d'une graine stable (identifiant du compte). */
export function defaultAvatarUrl(seed: string, name: string): string {
  const letter = (name.trim().match(/[\p{L}\p{N}]/u)?.[0] ?? "?").toUpperCase();
  return `/api/avatar?seed=${encodeURIComponent(seed.slice(0, 40))}&l=${encodeURIComponent(letter)}`;
}
