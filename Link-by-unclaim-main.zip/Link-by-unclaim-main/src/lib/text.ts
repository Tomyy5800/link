import { discordMarkupToText } from "./discord-markup";
import { replaceShortcodes } from "./emoji";

/**
 * Version texte brut d'une bio en mise en forme Discord, pour les aperçus de lien
 * (description, image Open Graph). Les spoilers restent masqués.
 */
export function plainText(markdown: string): string {
  return replaceShortcodes(discordMarkupToText(markdown))
    .replace(/\[([^\]\n]+)\]\([^)\s]+\)/g, "$1")
    .replace(/\|\|[^|\n]+\|\|/g, "▒▒▒")
    .replace(/^(#{1,3}|-#|>)\s?/gm, "")
    .replace(/^\s*[-*•] /gm, "· ")
    .replace(/(\*\*|__|~~|`|\*|(?<![\w])_|_(?![\w]))/g, "")
    .replace(/\s+/g, " ")
    .trim();
}
