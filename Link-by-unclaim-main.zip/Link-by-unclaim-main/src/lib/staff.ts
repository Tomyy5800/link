// Permissions sensibles de l'administration (partagé serveur / navigateur).
//
// Trois niveaux :
// - fondateur : déclaré dans l'environnement du serveur (FOUNDER_*), toutes les permissions,
//   seul à pouvoir nommer des administrateurs et à gérer les badges réservés (« Fondateur ») ;
// - administrateur : accès à l'administration, plus les permissions ci-dessous qu'un fondateur
//   lui a accordées ;
// - tout le monde : aucune.
// Le navigateur ne fait qu'afficher ces droits : chaque route les vérifie côté serveur.

export const STAFF_PERMISSIONS = {
  "badges.validate": {
    label: "Valider les badges",
    description: "Apposer ou retirer le sceau officiel d'un badge.",
  },
  "badges.staff": {
    label: "Badges du staff",
    description: "Attribuer et retirer les badges réservés au staff (Administrateur, Développeur, Modérateur…).",
  },
  "discord.manage": {
    label: "Synchronisation Discord",
    description: "Configurer le serveur officiel et les rôles associés aux badges.",
  },
  "platform.critical": {
    label: "Réglages sensibles",
    description: "Boutiques personnelles, accès offert à tous, boutique officielle.",
  },
} as const;

export type StaffPermission = keyof typeof STAFF_PERMISSIONS;
export const STAFF_PERMISSION_KEYS = Object.keys(STAFF_PERMISSIONS) as StaffPermission[];

export type StaffLevel = "founder" | "admin";

export function isStaffPermission(value: unknown): value is StaffPermission {
  return typeof value === "string" && (STAFF_PERMISSION_KEYS as string[]).includes(value);
}

/** Permissions stockées (JSON) → liste propre, sans doublon ni valeur inconnue. */
export function parseStaffPermissions(raw: string | null | undefined): StaffPermission[] {
  try {
    const value: unknown = JSON.parse(raw || "[]");
    return Array.isArray(value) ? [...new Set(value.filter(isStaffPermission))] : [];
  } catch {
    return [];
  }
}

/** Droits d'un membre du staff, calculés côté serveur et transmis à l'interface d'administration. */
export type StaffRights = {
  level: StaffLevel;
  permissions: StaffPermission[];
};

export function can(rights: StaffRights | null | undefined, permission: StaffPermission): boolean {
  return Boolean(rights && (rights.level === "founder" || rights.permissions.includes(permission)));
}
