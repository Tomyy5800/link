// Définition des blocs de contenu : schémas de validation, valeurs par défaut et métadonnées.
// Ce module est partagé : il valide les données côté serveur et alimente l'éditeur côté navigateur.
import { z } from "zod";
import { GAME_IDS, gameInfo, type GameId } from "./games";
import { isValidRadioSource } from "./radio";
import { isOfficialName } from "./reserved-names";
import { MAX_PRODUCTS, SHOP_CURRENCIES } from "./shop";
import { MC_USERNAME, PLATFORM_KEYS, normalizeImageUrl, normalizeUrl, type Platform } from "./urls";

/** Plafond technique ; la limite réelle dépend de l'offre (réglages d'administration). */
export const MAX_BLOCKS = 120;

const url = z
  .string()
  .max(2048)
  .refine((v) => normalizeUrl(v) !== null, "URL invalide (http, https ou mailto uniquement)")
  .transform((v) => normalizeUrl(v) ?? "");

const imageUrl = z
  .string()
  .max(2048)
  .refine((v) => normalizeImageUrl(v) !== null, "URL d'image invalide")
  .transform((v) => normalizeImageUrl(v) ?? "");

const mcUsername = z
  .string()
  .max(16)
  .refine((v) => v === "" || MC_USERNAME.test(v), "Pseudo Minecraft invalide")
  .default("");

const align = z.enum(["left", "center", "right"]);

/** Date ISO (ou chaîne vide pendant l'édition). */
const isoDate = z
  .string()
  .max(40)
  .refine((v) => v === "" || !Number.isNaN(Date.parse(v)), "Date invalide");

const hex = z.string().regex(/^#[0-9a-fA-F]{6}$/, "Couleur hexadécimale attendue (#rrggbb)");

/** Un émoji (ou un court symbole) affiché devant un lien. */
const emoji = z.string().trim().max(16).default("");

/** Jour et mois d'anniversaire, au format MM-JJ. */
const monthDay = z
  .string()
  .regex(/^((0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01]))?$/, "Date d'anniversaire invalide (MM-JJ)")
  .default("");

/** Plateformes du bloc « Écouter partout ». */
export const MUSIC_PLATFORMS = ["spotify", "applemusic", "deezer", "youtubemusic", "youtube", "soundcloud", "tidal", "bandcamp", "other"] as const;
export type MusicPlatform = (typeof MUSIC_PLATFORMS)[number];

/** Style propre à un bloc (fond, couleurs, alignement, masquage par écran). */
export const blockStyleSchema = z.object({
  surface: z.enum(["auto", "none", "accent", "custom"]).default("auto"),
  color: hex.default("#0f172b"),
  text: hex.nullable().default(null),
  align: z.enum(["auto", "left", "center", "right"]).default("auto"),
  valign: z.enum(["stretch", "start", "center", "end"]).default("stretch"),
  hideOn: z.enum(["none", "mobile", "desktop"]).default("none"),
});

export type BlockStyle = z.infer<typeof blockStyleSchema>;
export const DEFAULT_BLOCK_STYLE: BlockStyle = blockStyleSchema.parse({});

const NG_SERVER = /^[a-z0-9-]{2,24}$/;

/** Montant en centimes (prix d'un produit de la boutique). */
const cents = z.number().int().min(0).max(10_000_000);

/** Produit du bloc « Boutique ». */
const shopProduct = z.object({
  /** Identifiant stable (panier, commandes), attribué par l'éditeur. */
  id: z.string().max(40).regex(/^[\w-]*$/, "Identifiant de produit invalide").default(""),
  name: z.string().max(80).default(""),
  description: z.string().max(600).default(""),
  /** Prix en centimes (null : prix libre ou sur demande). */
  price: cents.nullable().default(null),
  /** Ancien prix barré, pour une promotion. */
  compareAt: cents.nullable().default(null),
  images: z.array(imageUrl).max(4).default([]),
  /** Émoji affiché en grand quand le produit n'a pas de photo. */
  emoji,
  /** Variantes proposées (tailles, couleurs…) et leur intitulé. */
  optionLabel: z.string().max(24).default("Taille"),
  options: z.array(z.string().max(32)).max(12).default([]),
  /** Étiquette sur la vignette : « Nouveau », « Édition limitée »… */
  badge: z.string().max(24).default(""),
  /** link : bouton vers la boutique du vendeur · order : panier et demande de commande. */
  mode: z.enum(["link", "order"]).default("link"),
  url: url.default(""),
  buttonLabel: z.string().max(30).default(""),
  /** Stock restant (null : non suivi). */
  stock: z.number().int().min(0).max(99_999).nullable().default(null),
  soldOut: z.boolean().default(false),
});

const scheduleDate = z
  .string()
  .max(40)
  .refine((v) => !Number.isNaN(Date.parse(v)), "Date invalide")
  .transform((v) => new Date(v).toISOString())
  .nullable()
  .default(null);

export const blockDataSchemas = {
  heading: z.object({
    text: z.string().max(120).default(""),
    size: z.enum(["sm", "md", "lg"]).default("md"),
    align: align.default("center"),
  }),
  text: z.object({
    text: z.string().max(2000).default(""),
    align: align.default("center"),
  }),
  link: z.object({
    label: z.string().max(80).default(""),
    url: url.default(""),
    description: z.string().max(140).default(""),
    icon: z.enum(["auto", "none", ...PLATFORM_KEYS] as [string, ...string[]]).default("auto"),
    highlight: z.boolean().default(false),
    /** Émoji devant le texte (remplace l'icône). */
    emoji,
    /** Vignette : à gauche (classique) ou en grand au-dessus (mise en avant). */
    thumbnail: imageUrl.default(""),
    layout: z.enum(["classic", "featured"]).default("classic"),
    /** Animation qui attire l'œil sur le bouton. */
    animation: z.enum(["none", "pulse", "buzz", "wobble", "shine"]).default("none"),
    /** Contenu sensible : le visiteur confirme avant d'ouvrir le lien. */
    sensitive: z.boolean().default(false),
  }),
  socials: z.object({
    items: z
      .array(z.object({ platform: z.enum(PLATFORM_KEYS as [Platform, ...Platform[]]), url: url }))
      .max(16)
      .default([]),
    style: z.enum(["icons", "pills"]).default("icons"),
  }),
  image: z.object({
    url: imageUrl.default(""),
    alt: z.string().max(140).default(""),
    caption: z.string().max(140).default(""),
    href: url.default(""),
    aspect: z.enum(["auto", "square", "video", "portrait"]).default("auto"),
  }),
  discord: z.object({
    showBanner: z.boolean().default(true),
    showFriendButton: z.boolean().default(true),
    note: z.string().max(190).default(""),
  }),
  discordServer: z.object({
    invite: z.string().max(120).default(""),
    note: z.string().max(140).default(""),
  }),
  nationsglory: z.object({
    username: mcUsername,
    /** Serveurs affichés (1 à 3) ; vide : le serveur principal du profil. */
    servers: z.array(z.string().regex(NG_SERVER, "Serveur invalide")).max(3).default([]),
    showRole: z.boolean().default(true),
    showLastLogin: z.boolean().default(true),
  }),
  skin: z.object({
    username: mcUsername,
    animation: z.enum(["idle", "walk", "run", "fly", "wave", "crouch", "none"]).default("idle"),
    autoRotate: z.boolean().default(true),
    showName: z.boolean().default(false),
    height: z.number().int().min(220).max(520).default(340),
    label: z.string().max(60).default(""),
  }),
  embed: z.object({
    /** auto : fournisseur reconnu · iframe : n'importe quel site (Link+) · html : widget isolé (Link+) */
    mode: z.enum(["auto", "iframe", "html"]).default("auto"),
    url: url.default(""),
    html: z.string().max(20_000).default(""),
    title: z.string().max(80).default(""),
    /** Hauteur fixe en px (null : selon le fournisseur ou le format). */
    height: z.number().int().min(80).max(1200).nullable().default(null),
    aspect: z.enum(["auto", "16:9", "4:3", "1:1", "9:16"]).default("auto"),
  }),
  divider: z.object({
    style: z.enum(["line", "dots", "space"]).default("line"),
  }),
  countdown: z.object({
    /** date : une échéance unique · birthday : chaque année, au jour de l'anniversaire. */
    mode: z.enum(["date", "birthday"]).default("date"),
    title: z.string().max(80).default(""),
    target: isoDate.default(""),
    endedText: z.string().max(80).default("C'est parti !"),
    style: z.enum(["boxes", "inline"]).default("boxes"),
    birthday: monthDay,
    birthYear: z.number().int().min(1900).max(2100).nullable().default(null),
    showAge: z.boolean().default(true),
    birthdayText: z.string().max(80).default("C'est mon anniversaire aujourd'hui !"),
  }),
  radio: z.object({
    /** Radio préréglée (« lyxia ») ou adresse https (page AzuraCast ou flux). */
    station: z.string().trim().max(500).refine(isValidRadioSource, "Radio invalide : choisis une radio ou colle une adresse https").default("lyxia"),
    name: z.string().max(60).default(""),
    showNowPlaying: z.boolean().default(true),
    showListeners: z.boolean().default(true),
    showHistory: z.boolean().default(false),
  }),
  music: z.object({
    title: z.string().max(80).default(""),
    artist: z.string().max(80).default(""),
    cover: imageUrl.default(""),
    links: z
      .array(z.object({ platform: z.enum(MUSIC_PLATFORMS), url }))
      .max(10)
      .default([]),
  }),
  events: z.object({
    title: z.string().max(60).default("Agenda"),
    items: z
      .array(
        z.object({
          title: z.string().max(80),
          start: isoDate,
          end: isoDate.default(""),
          location: z.string().max(80).default(""),
          url: url.default(""),
        }),
      )
      .max(20)
      .default([]),
    hidePast: z.boolean().default(true),
    showAddToCalendar: z.boolean().default(true),
  }),
  collection: z.object({
    title: z.string().max(60).default(""),
    description: z.string().max(140).default(""),
    open: z.boolean().default(false),
    links: z
      .array(z.object({ label: z.string().max(80), url, emoji }))
      .max(12)
      .default([]),
  }),
  gallery: z.object({
    images: z
      .array(z.object({ url: imageUrl, alt: z.string().max(140).default("") }))
      .max(12)
      .default([]),
    layout: z.enum(["grid", "carousel"]).default("grid"),
    columns: z.union([z.literal(2), z.literal(3)]).default(2),
  }),
  faq: z.object({
    items: z
      .array(z.object({ question: z.string().max(140), answer: z.string().max(800) }))
      .max(12)
      .default([]),
  }),
  badges: z.object({
    title: z.string().max(60).default(""),
    items: z.array(z.string().max(32)).max(24).default([]),
    style: z.enum(["soft", "outline", "solid"]).default("soft"),
  }),
  copy: z.object({
    label: z.string().max(60).default("IP du serveur"),
    value: z.string().max(200).default(""),
    hint: z.string().max(120).default(""),
  }),
  ngCountry: z.object({
    server: z.string().regex(NG_SERVER, "Serveur invalide").default("blue"),
    /** Identifiant country_id de l'API v1 (vide : résolu par le nom). */
    countryId: z.string().max(64).default(""),
    /** Nom affiché (et repli pour les anciens blocs). */
    country: z.string().max(64).default(""),
    showMembers: z.boolean().default(true),
    showDescription: z.boolean().default(true),
  }),
  discordPresence: z.object({
    showActivity: z.boolean().default(true),
    showSpotify: z.boolean().default(true),
  }),
  game: z.object({
    game: z.enum(GAME_IDS as [GameId, ...GameId[]]).default("minecraft"),
    /** Pseudo, Riot ID, tag ou lien de profil selon le jeu. */
    username: z.string().trim().max(120).default(""),
    /** Nom du jeu pour « Autre jeu ». */
    customName: z.string().max(40).default(""),
    /** Rang, niveau ou titre mis en avant (saisie libre). */
    rank: z.string().max(40).default(""),
    /** Statistiques saisies à la main (jeux sans API, ou en complément). */
    stats: z
      .array(z.object({ label: z.string().max(24), value: z.string().max(24) }))
      .max(6)
      .default([]),
    /** Lien vers le profil (remplace le lien officiel quand il est renseigné). */
    url: url.default(""),
    /** Jeux avec API : afficher les données publiques en direct. */
    showLive: z.boolean().default(true),
  }),
  shop: z.object({
    // Une boutique personnelle ne se fait pas passer pour la boutique officielle (« Boutique officielle Unclaim »…).
    title: z
      .string()
      .max(60)
      .default("Ma boutique")
      .transform((v) => (isOfficialName(v) ? "Ma boutique" : v)),
    intro: z.string().max(240).default(""),
    currency: z.enum(SHOP_CURRENCIES).default("EUR"),
    layout: z.enum(["grid", "carousel", "list"]).default("grid"),
    products: z.array(shopProduct).max(MAX_PRODUCTS, `${MAX_PRODUCTS} produits au maximum`).default([]),
    /** Paiement et livraison, rappelés dans le panier (« PayPal après confirmation, envoi sous 3 jours »). */
    terms: z.string().max(300).default(""),
  }),
  contact: z.object({
    title: z.string().max(80).default("Me contacter"),
    intro: z.string().max(240).default(""),
    /** Champ « comment te répondre » : facultatif, obligatoire ou masqué. */
    contactField: z.enum(["optional", "required", "hidden"]).default("optional"),
    buttonLabel: z.string().max(40).default("Envoyer"),
    successText: z.string().max(160).default("Merci ! Ton message a bien été envoyé."),
  }),
} as const;

export type BlockType = keyof typeof blockDataSchemas;
export const BLOCK_TYPES = Object.keys(blockDataSchemas) as BlockType[];

const base = {
  id: z.uuid(),
  width: z.enum(["full", "half"]).default("full"),
  visible: z.boolean().default(true),
  /** Programmation : le bloc n'apparaît qu'à partir de / jusqu'à cette date. */
  startsAt: scheduleDate,
  endsAt: scheduleDate,
  /** Ordinateur : colonnes occupées (null : automatique selon la largeur mobile). */
  colSpan: z.number().int().min(1).max(4).nullable().default(null),
  /** Ordinateur : rangées occupées dans la grille. */
  rowSpan: z.number().int().min(1).max(4).default(1),
  style: blockStyleSchema.default(DEFAULT_BLOCK_STYLE),
};

export const blockSchema = z.discriminatedUnion("type", [
  z.object({ ...base, type: z.literal("heading"), data: blockDataSchemas.heading }),
  z.object({ ...base, type: z.literal("text"), data: blockDataSchemas.text }),
  z.object({ ...base, type: z.literal("link"), data: blockDataSchemas.link }),
  z.object({ ...base, type: z.literal("socials"), data: blockDataSchemas.socials }),
  z.object({ ...base, type: z.literal("image"), data: blockDataSchemas.image }),
  z.object({ ...base, type: z.literal("discord"), data: blockDataSchemas.discord }),
  z.object({ ...base, type: z.literal("discordServer"), data: blockDataSchemas.discordServer }),
  z.object({ ...base, type: z.literal("nationsglory"), data: blockDataSchemas.nationsglory }),
  z.object({ ...base, type: z.literal("skin"), data: blockDataSchemas.skin }),
  z.object({ ...base, type: z.literal("embed"), data: blockDataSchemas.embed }),
  z.object({ ...base, type: z.literal("divider"), data: blockDataSchemas.divider }),
  z.object({ ...base, type: z.literal("countdown"), data: blockDataSchemas.countdown }),
  z.object({ ...base, type: z.literal("gallery"), data: blockDataSchemas.gallery }),
  z.object({ ...base, type: z.literal("faq"), data: blockDataSchemas.faq }),
  z.object({ ...base, type: z.literal("badges"), data: blockDataSchemas.badges }),
  z.object({ ...base, type: z.literal("copy"), data: blockDataSchemas.copy }),
  z.object({ ...base, type: z.literal("ngCountry"), data: blockDataSchemas.ngCountry }),
  z.object({ ...base, type: z.literal("discordPresence"), data: blockDataSchemas.discordPresence }),
  z.object({ ...base, type: z.literal("radio"), data: blockDataSchemas.radio }),
  z.object({ ...base, type: z.literal("music"), data: blockDataSchemas.music }),
  z.object({ ...base, type: z.literal("events"), data: blockDataSchemas.events }),
  z.object({ ...base, type: z.literal("collection"), data: blockDataSchemas.collection }),
  z.object({ ...base, type: z.literal("game"), data: blockDataSchemas.game }),
  z.object({ ...base, type: z.literal("contact"), data: blockDataSchemas.contact }),
  z.object({ ...base, type: z.literal("shop"), data: blockDataSchemas.shop }),
]);

export type Block = z.infer<typeof blockSchema>;
export type BlockOf<T extends BlockType> = Extract<Block, { type: T }>;
export type BlockData<T extends BlockType> = BlockOf<T>["data"];

export function isBlockType(value: string): value is BlockType {
  return Object.prototype.hasOwnProperty.call(blockDataSchemas, value);
}

type StoredBlock = {
  id: string;
  type: string;
  width: string;
  visible: boolean;
  data: string;
  startsAt?: Date | null;
  endsAt?: Date | null;
  colSpan?: number | null;
  rowSpan?: number;
  style?: string;
};

function parseJson(text: string | undefined): unknown {
  if (!text) return {};
  try {
    return JSON.parse(text);
  } catch {
    return {};
  }
}

/** Lit un bloc stocké en base ; renvoie null s'il est inutilisable. */
export function parseStoredBlock(row: StoredBlock): Block | null {
  if (!isBlockType(row.type)) return null;
  let data: unknown = {};
  try {
    data = JSON.parse(row.data);
  } catch {
    data = {};
  }
  const common = {
    id: row.id,
    type: row.type,
    width: row.width,
    visible: row.visible,
    startsAt: row.startsAt ? row.startsAt.toISOString() : null,
    endsAt: row.endsAt ? row.endsAt.toISOString() : null,
    colSpan: row.colSpan ?? null,
    rowSpan: row.rowSpan ?? 1,
    style: (() => {
      const parsed = blockStyleSchema.safeParse(parseJson(row.style));
      return parsed.success ? parsed.data : DEFAULT_BLOCK_STYLE;
    })(),
  };
  const parsed = blockSchema.safeParse({ ...common, data });
  if (parsed.success) return parsed.data;
  // Données partiellement invalides : on repart des valeurs par défaut plutôt que de perdre le bloc.
  const fallback = blockSchema.safeParse({ ...common, data: {} });
  return fallback.success ? fallback.data : null;
}

/** Le bloc est-il dans sa fenêtre de programmation à cet instant ? */
export function isWithinSchedule(block: Pick<Block, "startsAt" | "endsAt">, now = Date.now()): boolean {
  if (block.startsAt && Date.parse(block.startsAt) > now) return false;
  if (block.endsAt && Date.parse(block.endsAt) <= now) return false;
  return true;
}

export function createBlock<T extends BlockType>(type: T, data: Partial<BlockData<T>> = {}): BlockOf<T> {
  const id = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : fallbackUuid();
  return blockSchema.parse({ id, type, width: "full", visible: true, data }) as BlockOf<T>;
}

function fallbackUuid(): string {
  const bytes = Array.from({ length: 16 }, () => Math.floor(Math.random() * 256));
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const hex = bytes.map((b) => b.toString(16).padStart(2, "0")).join("");
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

// ─── Métadonnées pour l'éditeur ──────────────────────────────────────────────

export type BlockCategory = "contenu" | "liens" | "boutique" | "discord" | "nationsglory" | "jeux" | "médias" | "interactif";

export const BLOCK_META: Record<BlockType, { label: string; description: string; category: BlockCategory }> = {
  heading: { label: "Titre", description: "Un titre pour séparer les sections.", category: "contenu" },
  text: { label: "Texte", description: "Un paragraphe avec la mise en forme Discord.", category: "contenu" },
  divider: { label: "Séparateur", description: "Une ligne, des points ou un espace.", category: "contenu" },
  link: { label: "Lien", description: "Un bouton vers n'importe quelle adresse.", category: "liens" },
  socials: { label: "Réseaux sociaux", description: "Une rangée d'icônes vers tes réseaux.", category: "liens" },
  discord: { label: "Profil Discord", description: "Ta carte de profil Discord, synchronisée.", category: "discord" },
  discordServer: { label: "Serveur Discord", description: "Une invitation avec le nombre de membres.", category: "discord" },
  nationsglory: { label: "Profil NationsGlory", description: "Tes informations de jeu via l'API.", category: "nationsglory" },
  skin: { label: "Skin 3D", description: "Ton skin animé, à faire tourner.", category: "nationsglory" },
  image: { label: "Image", description: "Une image, avec lien et légende.", category: "médias" },
  gallery: { label: "Galerie", description: "Jusqu'à 12 images en grille ou en carrousel.", category: "médias" },
  badges: { label: "Badges", description: "Tes rôles, compétences ou centres d'intérêt.", category: "contenu" },
  faq: { label: "Questions", description: "Des questions fréquentes qui se déplient.", category: "contenu" },
  countdown: { label: "Compte à rebours", description: "Jusqu'à une guerre, un stream ou un événement.", category: "interactif" },
  copy: { label: "À copier", description: "Une IP, un pseudo ou un code, copié en un clic.", category: "interactif" },
  discordPresence: { label: "Statut Discord", description: "Ton statut et ton activité en direct.", category: "discord" },
  ngCountry: { label: "Pays NationsGlory", description: "La carte de ton pays sur un serveur.", category: "nationsglory" },
  embed: { label: "Intégration", description: "Vidéo, musique, carte, widget ou n'importe quel site.", category: "médias" },
  radio: { label: "Radio", description: "Une webradio en direct (LyxiaRadio…) avec le titre en cours.", category: "médias" },
  music: { label: "Écouter partout", description: "Un morceau, avec un lien par plateforme de streaming.", category: "médias" },
  events: { label: "Agenda", description: "Tes prochains streams, guerres ou événements.", category: "interactif" },
  collection: { label: "Dossier de liens", description: "Plusieurs liens rangés sous un même titre.", category: "liens" },
  game: { label: "Profil de jeu", description: "Minecraft, Paladium, Steam, Roblox, échecs, Valorant, Wolfy…", category: "jeux" },
  contact: { label: "Formulaire de contact", description: "Tes visiteurs t'écrivent ; tu lis dans « Mon espace ».", category: "interactif" },
  shop: { label: "Boutique", description: "Vends tes produits : fiches, prix, promos, panier et commandes.", category: "boutique" },
};

/** Texte court résumant un bloc dans la liste de l'éditeur. */
export function blockSummary(block: Block): string {
  switch (block.type) {
    case "heading":
      return block.data.text || "Titre vide";
    case "text":
      return block.data.text.split("\n")[0]?.slice(0, 60) || "Texte vide";
    case "link":
      return block.data.label || block.data.url || "Lien sans titre";
    case "socials":
      return block.data.items.length ? `${block.data.items.length} réseau(x)` : "Aucun réseau";
    case "image":
      return block.data.alt || block.data.caption || (block.data.url ? "Image" : "Aucune image");
    case "discord":
      return "Carte de profil Discord";
    case "discordServer":
      return block.data.invite || "Invitation à définir";
    case "nationsglory":
      return `${block.data.username || "Pseudo de la page"}${block.data.servers.length ? ` · ${block.data.servers.join(", ")}` : ""}`;
    case "skin":
      return block.data.username || "Pseudo de la page";
    case "embed":
      if (block.data.mode === "html") return block.data.title || "Widget HTML";
      return block.data.title || block.data.url || "URL à définir";
    case "divider":
      return { line: "Ligne", dots: "Points", space: "Espace" }[block.data.style];
    case "countdown":
      if (block.data.title) return block.data.title;
      if (block.data.mode === "birthday") return block.data.birthday ? `Anniversaire · ${block.data.birthday.split("-").reverse().join("/")}` : "Anniversaire à définir";
      // Heure de Paris : ce résumé s'affiche dans l'éditeur, rendu côté serveur puis hydraté.
      return block.data.target
        ? new Date(block.data.target).toLocaleString("fr-FR", { dateStyle: "medium", timeStyle: "short", timeZone: "Europe/Paris" })
        : "Date à définir";
    case "gallery":
      return block.data.images.length ? `${block.data.images.length} image(s)` : "Aucune image";
    case "faq":
      return block.data.items.length ? `${block.data.items.length} question(s)` : "Aucune question";
    case "badges":
      return block.data.items.length ? block.data.items.slice(0, 4).join(" · ") : "Aucun badge";
    case "copy":
      return block.data.value || "Valeur à définir";
    case "ngCountry":
      return block.data.country ? `${block.data.country} · ${block.data.server}` : "Pays à définir";
    case "discordPresence":
      return "Statut en direct (Lanyard)";
    case "radio":
      return block.data.name || (block.data.station === "lyxia" ? "LyxiaRadio" : block.data.station || "Radio à choisir");
    case "music":
      return [block.data.title, block.data.artist].filter(Boolean).join(" · ") || "Morceau à définir";
    case "events":
      return block.data.items.length ? `${block.data.items.length} événement(s)` : "Aucun événement";
    case "collection":
      return block.data.title || (block.data.links.length ? `${block.data.links.length} lien(s)` : "Dossier vide");
    case "game": {
      const name = block.data.game === "other" ? block.data.customName || "Autre jeu" : gameInfo(block.data.game).name;
      return block.data.username ? `${name} · ${block.data.username}` : `${name} · pseudo à définir`;
    }
    case "contact":
      return block.data.title || "Formulaire de contact";
    case "shop": {
      const count = block.data.products.filter((p) => p.name.trim()).length;
      return count ? `${block.data.title || "Boutique"} · ${count} produit${count > 1 ? "s" : ""}` : "Boutique vide";
    }
  }
}
