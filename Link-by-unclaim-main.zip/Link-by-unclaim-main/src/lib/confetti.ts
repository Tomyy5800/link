// Pluie de confettis en forme de chunks, dessinée sur un canvas éphémère (aucune dépendance).
// Rien ne se passe si le visiteur a demandé moins d'animations.

const COLORS = ["#22c9e8", "#ffc247", "#8fe6f6", "#00bc7d", "#ff6467", "#5865f2", "#f8fafc"];

type Origin = { x: number; y: number } | Element | null | undefined;

export type ConfettiOptions = {
  /** Point de départ : élément (son centre) ou coordonnées relatives à l'écran (0 à 1). */
  origin?: Origin;
  count?: number;
  /** Ouverture du jet en degrés. */
  spread?: number;
  /** Direction du jet en degrés (−90 = vers le haut). */
  angle?: number;
  colors?: string[];
  /** Vitesse de départ (1 = normale). */
  power?: number;
};

type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  rotation: number;
  spin: number;
  wobble: number;
  life: number;
  shape: 0 | 1 | 2;
};

function reducedMotion(): boolean {
  return typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

function originPoint(origin: Origin): { x: number; y: number } {
  if (origin && "getBoundingClientRect" in origin) {
    const rect = origin.getBoundingClientRect();
    return { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
  }
  const o = origin ?? { x: 0.5, y: 0.55 };
  return { x: o.x * window.innerWidth, y: o.y * window.innerHeight };
}

export function confetti({ origin, count = 90, spread = 75, angle = -90, colors = COLORS, power = 1 }: ConfettiOptions = {}): void {
  if (typeof window === "undefined" || reducedMotion()) return;
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const canvas = document.createElement("canvas");
  canvas.setAttribute("aria-hidden", "true");
  Object.assign(canvas.style, { position: "fixed", inset: "0", width: "100vw", height: "100vh", pointerEvents: "none", zIndex: "300" });
  canvas.width = window.innerWidth * dpr;
  canvas.height = window.innerHeight * dpr;
  document.body.appendChild(canvas);
  const ctx = canvas.getContext("2d");
  if (!ctx) {
    canvas.remove();
    return;
  }
  ctx.scale(dpr, dpr);

  const start = originPoint(origin);
  const particles: Particle[] = Array.from({ length: count }, () => {
    const direction = ((angle + (Math.random() - 0.5) * spread) * Math.PI) / 180;
    const speed = (7 + Math.random() * 9) * power;
    return {
      x: start.x,
      y: start.y,
      vx: Math.cos(direction) * speed,
      vy: Math.sin(direction) * speed,
      size: 5 + Math.random() * 6,
      color: colors[Math.floor(Math.random() * colors.length)],
      rotation: Math.random() * Math.PI,
      spin: (Math.random() - 0.5) * 0.3,
      wobble: Math.random() * 10,
      life: 1,
      shape: Math.random() < 0.6 ? 0 : Math.random() < 0.5 ? 1 : 2,
    };
  });

  let last = performance.now();
  const frame = (now: number) => {
    const dt = Math.min(2, (now - last) / 16.7);
    last = now;
    ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
    let alive = 0;
    for (const p of particles) {
      if (p.life <= 0) continue;
      p.vx *= 0.985 ** dt;
      p.vy = p.vy * 0.985 ** dt + 0.32 * dt;
      p.wobble += 0.1 * dt;
      p.x += (p.vx + Math.cos(p.wobble) * 0.6) * dt;
      p.y += p.vy * dt;
      p.rotation += p.spin * dt;
      if (p.vy > 0) p.life -= 0.009 * dt;
      if (p.y > window.innerHeight + 20) p.life = 0;
      if (p.life <= 0) continue;
      alive++;
      ctx.save();
      ctx.globalAlpha = Math.max(0, Math.min(1, p.life * 1.4));
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rotation);
      ctx.fillStyle = p.color;
      if (p.shape === 0) {
        // Chunk : un carré, comme les territoires revendiqués
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
      } else if (p.shape === 1) {
        ctx.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2);
      } else {
        ctx.beginPath();
        ctx.arc(0, 0, p.size / 2.4, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }
    if (alive > 0) requestAnimationFrame(frame);
    else canvas.remove();
  };
  requestAnimationFrame(frame);
}

/** Double jet depuis les deux côtés de l'écran, pour les grandes occasions. */
export function celebrate(): void {
  confetti({ origin: { x: 0.08, y: 0.75 }, angle: -60, spread: 55, count: 70, power: 1.2 });
  confetti({ origin: { x: 0.92, y: 0.75 }, angle: -120, spread: 55, count: 70, power: 1.2 });
}
