// Notifications de l'interface : n'importe quel composant appelle toast(), le <Toaster> du
// layout racine les affiche (empilées en bas de l'écran, avec minuteur et action facultative).

export type ToastTone = "info" | "success" | "error" | "celebrate";

export type ToastOptions = {
  tone?: ToastTone;
  /** Ligne secondaire, plus discrète. */
  description?: string;
  /** Durée d'affichage en millisecondes (3,2 s par défaut, 5 s pour une erreur). */
  duration?: number;
  action?: { label: string; onClick: () => void };
};

export type ToastItem = ToastOptions & { id: number; message: string };

export const TOAST_EVENT = "lbu:toast";

let sequence = 0;

export function toast(message: string, options: ToastOptions = {}): void {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent<ToastItem>(TOAST_EVENT, { detail: { id: ++sequence, message, ...options } }));
}
