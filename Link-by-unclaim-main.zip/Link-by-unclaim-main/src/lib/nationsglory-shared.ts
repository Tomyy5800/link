// Types et normalisation des données NationsGlory (partagé : testable sans serveur).
//
// Contrat : API publique NationsGlory v1 (https://nationsglory.fr/developers).
// Toutes les réponses ont la forme { data, meta } ; les clés sont en snake_case ;
// null signifie « inconnu », jamais zéro.

export const NG_SERVERS: Record<string, { label: string; color: string }> = {
  black: { label: "Black", color: "#9ca3af" },
  blue: { label: "Blue", color: "#3b82f6" },
  coral: { label: "Coral", color: "#fb7185" },
  cyan: { label: "Cyan", color: "#06b6d4" },
  jade: { label: "Jade", color: "#10b981" },
  lime: { label: "Lime", color: "#84cc16" },
  mocha: { label: "Mocha", color: "#a47551" },
  ruby: { label: "Ruby", color: "#e11d48" },
  white: { label: "White", color: "#e5e7eb" },
};

export const NG_SERVER_KEYS = Object.keys(NG_SERVERS);

export function ngServerMeta(server: string): { label: string; color: string } {
  const key = server.toLowerCase();
  return NG_SERVERS[key] ?? { label: server.charAt(0).toUpperCase() + server.slice(1), color: "#94a3b8" };
}

export const NG_ROLES: Record<string, string> = {
  LEADER: "Chef",
  OFFICER: "Officier",
  MEMBER: "Membre",
  RECRUIT: "Recrue",
};

export function roleLabel(role: unknown): string | null {
  return typeof role === "string" ? (NG_ROLES[role] ?? null) : null;
}

/** Les drapeaux sont publiés sans clé sur nationsglory.fr, adressés par leur empreinte SHA-256. */
export function ngFlagUrl(sha256: unknown): string | null {
  return typeof sha256 === "string" && /^[0-9a-f]{64}$/.test(sha256) ? `https://nationsglory.fr/gamedata/img/${sha256}.png` : null;
}

export type NgStatus = "ok" | "not_found" | "unavailable" | "not_configured" | "invalid";

export type NgPlayerServer = {
  server: string;
  status: "ok" | "not_found" | "unavailable";
  countryId: string | null;
  countryName: string | null;
  flagUrl: string | null;
  role: string | null;
  lastLoginOn: string | null;
};

export type NgProfile = {
  username: string;
  status: NgStatus;
  message?: string;
  servers: NgPlayerServer[];
  fetchedAt: string;
  mock?: boolean;
};

export type NgCountry = {
  server: string;
  countryId: string;
  name: string;
  status: NgStatus | "gone";
  message?: string;
  description: string;
  leader: string | null;
  createdOn: string | null;
  membersCount: number | null;
  power: number | null;
  powerMax: number | null;
  claims: number | null;
  mmr: number | null;
  score: number | null;
  flagUrl: string | null;
  tags: string[];
  badges: string[];
  members: { username: string; role: string | null }[];
  fetchedAt: string;
  mock?: boolean;
};

export type NgCountrySummary = { countryId: string; name: string; membersCount: number; flagUrl: string | null };

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

const str = (v: unknown, max = 200) => (typeof v === "string" ? v.slice(0, max) : null);
const int = (v: unknown) => (typeof v === "number" && Number.isFinite(v) ? Math.trunc(v) : null);

const TAG_LABELS: Record<string, string> = {
  farm: "Ferme",
  build: "Construction",
  trade: "Commerce",
  pacifist: "Pacifiste",
  enterprises: "Entreprises",
  pvp: "PvP",
  conquest: "Conquête",
  aggresive: "Agressif",
};

/** Fiche pays (GET /servers/{server}/countries/{country_id}) → carte affichable. */
export function normalizeCountry(server: string, raw: unknown, members: unknown = []): NgCountry {
  const d = isRecord(raw) && isRecord(raw.data) ? raw.data : isRecord(raw) ? raw : {};
  const badges: string[] = [];
  if (d.is_empire === true) badges.push("Empire");
  if (d.has_unesco === true) badges.push("UNESCO");
  if (d.is_referent === true) badges.push("Référent");
  if (d.recruitment_open === true) badges.push("Recrute");
  if (d.is_top_warzone === true) badges.push("Top warzone");
  const tags = Array.isArray(d.tags) ? d.tags.filter((t): t is string => typeof t === "string").slice(0, 8) : [];
  const memberRows = isRecord(members) && Array.isArray(members.data) ? members.data : Array.isArray(members) ? members : [];
  return {
    server,
    countryId: str(d.country_id, 64) ?? "",
    name: str(d.name, 64) ?? "Pays inconnu",
    status: "ok",
    description: str(d.description, 1000) ?? "",
    leader: str(d.leader, 32),
    createdOn: str(d.created_on, 10),
    membersCount: int(d.members_count),
    power: int(d.power),
    powerMax: int(d.power_max),
    claims: int(d.claims),
    mmr: int(d.mmr),
    score: int(d.score),
    flagUrl: ngFlagUrl(d.flag_sha256),
    tags: tags.map((t) => TAG_LABELS[t] ?? t),
    badges,
    members: memberRows
      .filter(isRecord)
      .map((m) => ({ username: str(m.username, 32) ?? "?", role: roleLabel(m.role) }))
      .slice(0, 24),
    fetchedAt: new Date().toISOString(),
  };
}

/** Élément de GET /servers/{server}/countries → résumé pour le sélecteur de l'éditeur. */
export function normalizeCountrySummary(raw: unknown): NgCountrySummary | null {
  if (!isRecord(raw)) return null;
  const countryId = str(raw.country_id, 64);
  const name = str(raw.name, 64);
  if (!countryId || !name) return null;
  return { countryId, name, membersCount: int(raw.members_count) ?? 0, flagUrl: ngFlagUrl(raw.flag_sha256) };
}

export function formatNgDate(day: string | null): string | null {
  if (!day || !/^\d{4}-\d{2}-\d{2}$/.test(day)) return null;
  const [y, m, d] = day.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d, 12)).toLocaleDateString("fr-FR", { day: "numeric", month: "short", year: "numeric", timeZone: "Europe/Paris" });
}

// ─── Données de démonstration (NATIONSGLORY_MOCK=true) ──────────────────────

function seeded(text: string) {
  let seed = 7;
  for (const ch of text.toLowerCase()) seed = (seed * 33 + ch.charCodeAt(0)) >>> 0;
  return () => {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return seed / 2 ** 32;
  };
}

const MOCK_COUNTRIES = ["France", "Japon", "Brésil", "Canada", "Égypte", "Norvège", "Mexique", "Italie", "Corée du Sud", "Islande"];

/** Identifiant de démonstration stable d'un pays (sans accents ni espaces). */
const mockId = (server: string, name: string) =>
  `mock-${server}-${name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "")}`;
const MOCK_NAMES = ["Kaelis_", "Orvane", "Mistral_", "Talwyn", "Bracken", "Syl_", "Ewen", "Lyra_", "Haldor", "Nim"];

function mockDay(rand: () => number, maxDaysAgo: number): string {
  const d = new Date(Date.now() - Math.floor(rand() * maxDaysAgo) * 86_400_000);
  return d.toISOString().slice(0, 10);
}

export function mockNgProfile(username: string, servers: string[]): NgProfile {
  const rand = seeded(username);
  const roles = Object.keys(NG_ROLES);
  return {
    username,
    status: "ok",
    servers: servers.map((server) => {
      const r = seeded(`${username}:${server}`);
      const hasCountry = r() > 0.2;
      const name = MOCK_COUNTRIES[Math.floor(r() * MOCK_COUNTRIES.length)];
      return {
        server,
        status: "ok" as const,
        countryId: hasCountry ? mockId(server, name) : null,
        countryName: hasCountry ? name : null,
        flagUrl: null,
        role: hasCountry ? NG_ROLES[roles[Math.floor(r() * roles.length)]] : null,
        lastLoginOn: mockDay(rand, 20),
      };
    }),
    fetchedAt: new Date().toISOString(),
    mock: true,
  };
}

export function mockNgCountry(server: string, country: string): NgCountry {
  // Accepte un identifiant de démonstration ou un nom saisi à la main.
  const known = MOCK_COUNTRIES.find((n) => mockId(server, n) === country || n.toLowerCase() === country.trim().toLowerCase());
  const display = known ?? (country.trim().charAt(0).toUpperCase() + country.trim().slice(1));
  const rand = seeded(`${server}:${display.toLowerCase()}`);
  const members = MOCK_NAMES.slice(0, 3 + Math.floor(rand() * 7)).map((username, i) => ({
    username,
    role: i === 0 ? "Chef" : i < 3 ? "Officier" : i < 7 ? "Membre" : "Recrue",
  }));
  const power = Math.floor(rand() * 400) + 40;
  return {
    server,
    countryId: mockId(server, display),
    name: display,
    status: "ok",
    description: "Une nation de bâtisseurs et de diplomates. Recrutement ouvert aux joueurs actifs.",
    leader: members[0].username,
    createdOn: mockDay(rand, 1500),
    membersCount: members.length,
    power,
    powerMax: power + Math.floor(rand() * 60),
    claims: Math.floor(rand() * 900) + 60,
    mmr: Math.floor(rand() * 1200) + 600,
    score: Math.floor(rand() * 20000) + 1000,
    flagUrl: null,
    tags: ["Construction", "Commerce"],
    badges: rand() > 0.5 ? ["Recrute"] : ["Empire", "UNESCO"],
    members,
    fetchedAt: new Date().toISOString(),
    mock: true,
  };
}

export function mockCountryList(server: string): NgCountrySummary[] {
  return MOCK_COUNTRIES.map((name, i) => ({
    countryId: mockId(server, name),
    name,
    membersCount: 3 + ((i * 7) % 40),
    flagUrl: null,
  }));
}
