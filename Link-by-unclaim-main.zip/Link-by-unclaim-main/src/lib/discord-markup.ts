// Balises Discord dans les textes (partagé serveur / navigateur) :
//   <t:1767225600:R>  date affichée dans le fuseau du visiteur (styles t T d D f F R)
//   <:nom:id> <a:nom:id>  émoji personnalisé d'un serveur (image du CDN Discord, animée avec « a »)

export const TIMESTAMP_STYLES = ["t", "T", "d", "D", "f", "F", "R"] as const;
export type TimestampStyle = (typeof TIMESTAMP_STYLES)[number];

export const TIMESTAMP_STYLE_LABELS: Record<TimestampStyle, string> = {
  R: "Relatif (dans 3 jours)",
  F: "Date et heure complètes",
  f: "Date et heure",
  D: "Date longue",
  d: "Date courte",
  t: "Heure",
  T: "Heure avec secondes",
};

/** Texte d'une date Discord, en français, dans le fuseau donné (celui du visiteur par défaut). */
export function formatDiscordTimestamp(seconds: number, style: TimestampStyle = "f", now = Date.now(), timeZone?: string): string {
  const date = new Date(seconds * 1000);
  if (Number.isNaN(date.getTime())) return "date invalide";
  const tz = timeZone ? { timeZone } : {};
  switch (style) {
    case "t":
      return date.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit", ...tz });
    case "T":
      return date.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit", second: "2-digit", ...tz });
    case "d":
      return date.toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit", year: "numeric", ...tz });
    case "D":
      return date.toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric", ...tz });
    case "F":
      return date.toLocaleString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit", ...tz });
    case "R":
      return relativeTime(date.getTime() - now);
    default:
      return date.toLocaleString("fr-FR", { day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit", ...tz });
  }
}

const RELATIVE_UNITS: [Intl.RelativeTimeFormatUnit, number][] = [
  ["year", 365 * 86_400_000],
  ["month", 30 * 86_400_000],
  ["week", 7 * 86_400_000],
  ["day", 86_400_000],
  ["hour", 3_600_000],
  ["minute", 60_000],
  ["second", 1000],
];

/** « dans 3 jours », « il y a 2 heures »… */
export function relativeTime(diffMs: number): string {
  const rtf = new Intl.RelativeTimeFormat("fr", { numeric: "auto" });
  for (const [unit, size] of RELATIVE_UNITS) {
    if (Math.abs(diffMs) >= size || unit === "second") return rtf.format(Math.round(diffMs / size), unit);
  }
  return rtf.format(0, "second");
}

/** Balise Discord pour une date (ce que l'éditeur insère). */
export function discordTimestampTag(date: Date, style: TimestampStyle = "R"): string {
  return `<t:${Math.floor(date.getTime() / 1000)}:${style}>`;
}

/** Image d'un émoji personnalisé Discord. */
export function customEmojiUrl(id: string, animated: boolean, size = 48): string {
  return `https://cdn.discordapp.com/emojis/${id}.${animated ? "gif" : "webp"}?size=${size}&quality=lossless`;
}

/** Version texte (aperçus, métadonnées) : dates au format long en heure de Paris, émojis par leur nom. */
export function discordMarkupToText(text: string): string {
  return text
    .replace(/<t:(-?\d{1,13})(?::([tTdDfFR]))?>/g, (_, ts: string, style?: string) =>
      formatDiscordTimestamp(Number(ts), (style as TimestampStyle) || "f", Date.now(), "Europe/Paris"),
    )
    .replace(/<a?:([a-zA-Z0-9_]{2,32}):\d{15,22}>/g, ":$1:");
}
