// Modèles de page (partagé) : un thème de départ et des blocs déjà placés, pour ne jamais partir
// d'une page blanche. Les blocs restent entièrement modifiables ensuite.
import { createBlock, type Block } from "./blocks";

export type TemplateContext = {
  /** Pseudo NationsGlory saisi à la création (vide s'il n'y en a pas). */
  ngUsername: string;
  /** Compte Discord rattaché : les blocs Discord ont du sens. */
  hasDiscord: boolean;
};

export type PageTemplate = {
  id: string;
  name: string;
  description: string;
  /** Thème de départ (clé de THEME_PRESETS). */
  preset: string;
  /** Mise en page sur ordinateur. */
  layout: "stack" | "grid" | "sidebar";
  blocks: (ctx: TemplateContext) => Block[];
};

const half = <T extends Block>(block: T): T => ({ ...block, width: "half" });

export const PAGE_TEMPLATES: PageTemplate[] = [
  {
    id: "joueur",
    name: "Joueur NationsGlory",
    description: "Ton profil de jeu, ton pays, ton skin 3D et ton serveur.",
    preset: "nations",
    layout: "grid",
    blocks: ({ ngUsername, hasDiscord }) => [
      ...(hasDiscord ? [createBlock("discord", {})] : []),
      ...(ngUsername ? [half(createBlock("nationsglory", {})), half(createBlock("skin", { animation: "idle" }))] : []),
      createBlock("ngCountry", {}),
      createBlock("discordServer", { note: "Rejoins notre pays" }),
      createBlock("socials", { items: [] }),
    ],
  },
  {
    id: "streamer",
    name: "Streamer",
    description: "Ton live, ton planning de streams et tes dernières vidéos.",
    preset: "neon",
    layout: "grid",
    blocks: ({ hasDiscord }) => [
      createBlock("link", { label: "Regarder le live", url: "", description: "En direct sur Twitch", emoji: "🔴", highlight: true, animation: "pulse" }),
      createBlock("events", { title: "Planning des streams" }),
      createBlock("embed", { url: "" }),
      ...(hasDiscord ? [createBlock("discordPresence", {})] : []),
      createBlock("discordServer", { note: "La communauté" }),
      createBlock("socials", { items: [] }),
      createBlock("contact", { title: "Partenariats et collaborations" }),
    ],
  },
  {
    id: "createur",
    name: "Créateur",
    description: "Tes réseaux, une vidéo à la une, ta musique, ta boutique et une galerie.",
    preset: "aurora",
    layout: "stack",
    blocks: () => [
      createBlock("socials", { items: [], style: "pills" }),
      createBlock("link", { label: "Ma dernière vidéo", url: "", layout: "featured" }),
      createBlock("music", {}),
      createBlock("shop", {}),
      createBlock("gallery", {}),
      createBlock("collection", { title: "Mes liens" }),
      createBlock("contact", {}),
    ],
  },
  {
    id: "communaute",
    name: "Serveur ou équipe",
    description: "Ton serveur, l'IP à copier, l'agenda des événements et un contact.",
    preset: "unclaim",
    layout: "grid",
    blocks: () => [
      createBlock("discordServer", { note: "Rejoins-nous" }),
      createBlock("copy", { label: "IP du serveur", value: "" }),
      createBlock("game", { game: "minecraft" }),
      createBlock("events", { title: "Prochains événements" }),
      createBlock("socials", { items: [] }),
      createBlock("contact", { title: "Recrutement et partenariats" }),
    ],
  },
  {
    id: "minimal",
    name: "Minimal",
    description: "Une présentation et tes liens, rien de plus.",
    preset: "midnight",
    layout: "stack",
    blocks: () => [
      createBlock("socials", { items: [] }),
      createBlock("link", { label: "Mon site", url: "" }),
      createBlock("link", { label: "Me contacter", url: "" }),
    ],
  },
];

export function getTemplate(id: string): PageTemplate | undefined {
  return PAGE_TEMPLATES.find((t) => t.id === id);
}
