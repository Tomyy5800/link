// CSS personnalisé d'une page (Link+) : assaini puis cantonné à la page par imbrication CSS.
// Partagé : validé à l'enregistrement côté serveur et appliqué tel quel dans l'aperçu.

export const MAX_CUSTOM_CSS = 20_000;

const FORBIDDEN: { pattern: RegExp; message: string }[] = [
  { pattern: /</, message: "Le caractère « < » n'est pas autorisé." },
  { pattern: /@import/i, message: "@import n'est pas autorisé." },
  { pattern: /@(charset|namespace)/i, message: "@charset et @namespace ne sont pas autorisés." },
  { pattern: /expression\s*\(/i, message: "expression() n'est pas autorisé." },
  { pattern: /javascript\s*:/i, message: "javascript: n'est pas autorisé." },
  { pattern: /(behavior|-moz-binding)\s*:/i, message: "Propriété non autorisée." },
  { pattern: /\\[0-9a-f]{1,6}/i, message: "Les échappements unicode ne sont pas autorisés." },
];

export type CssCheck = { ok: true; css: string } | { ok: false; error: string };

/** Vérifie une feuille de style saisie par l'utilisateur. */
export function sanitizeCss(input: string): CssCheck {
  const css = input.replace(/\/\*[\s\S]*?\*\//g, "").trim();
  if (!css) return { ok: true, css: "" };
  if (css.length > MAX_CUSTOM_CSS) return { ok: false, error: `${MAX_CUSTOM_CSS} caractères maximum.` };
  for (const rule of FORBIDDEN) if (rule.pattern.test(css)) return { ok: false, error: rule.message };

  // url() : seulement https, les images importées et les images en data:.
  for (const m of css.matchAll(/url\(\s*(['"]?)(.*?)\1\s*\)/gi)) {
    const target = m[2].trim();
    const allowed = /^https:\/\//i.test(target) || /^\/api\/uploads\/[a-z0-9]+$/i.test(target) || /^data:image\/(png|jpe?g|gif|webp);/i.test(target);
    if (!allowed) return { ok: false, error: `Adresse non autorisée dans url() : ${target.slice(0, 60)}` };
  }

  // Accolades équilibrées : impossible de refermer le bloc qui cantonne la feuille à la page.
  let depth = 0;
  let quote: string | null = null;
  for (const ch of css) {
    if (quote) {
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'") quote = ch;
    else if (ch === "{") depth++;
    else if (ch === "}") {
      depth--;
      if (depth < 0) return { ok: false, error: "Accolade fermante en trop." };
    }
  }
  if (quote) return { ok: false, error: "Guillemet non refermé." };
  if (depth !== 0) return { ok: false, error: "Accolade ouvrante non refermée." };
  return { ok: true, css };
}

/**
 * Cantonne la feuille à `scope` grâce à l'imbrication CSS. Les @keyframes et @font-face,
 * interdits à l'intérieur d'une règle, sont sortis au niveau supérieur.
 */
export function scopeCss(css: string, scope: string): string {
  const hoisted: string[] = [];
  let rest = "";
  let i = 0;
  while (i < css.length) {
    const at = css.slice(i).match(/^@(?:-webkit-)?(keyframes|font-face)\b/i);
    if (at) {
      const open = css.indexOf("{", i);
      if (open === -1) break;
      let depth = 0;
      let j = open;
      for (; j < css.length; j++) {
        if (css[j] === "{") depth++;
        else if (css[j] === "}" && --depth === 0) break;
      }
      hoisted.push(css.slice(i, j + 1));
      i = j + 1;
      continue;
    }
    rest += css[i];
    i++;
  }
  return `${hoisted.join("\n")}\n${scope}{${rest}}`;
}
