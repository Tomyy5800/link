import "server-only";

// Lecture centralisée (et paresseuse) de la configuration serveur.
// Rien ici n'est jamais envoyé au navigateur.

function read(name: string): string {
  return (process.env[name] ?? "").trim();
}

export const env = {
  get appUrl(): string {
    return (read("APP_URL") || "http://localhost:3000").replace(/\/+$/, "");
  },
  get isProduction(): boolean {
    return process.env.NODE_ENV === "production";
  },
  get sessionSecret(): string {
    const secret = read("SESSION_SECRET");
    if (!secret && process.env.NODE_ENV === "production") {
      throw new Error("SESSION_SECRET doit être défini en production.");
    }
    return secret || "dev-only-insecure-secret";
  },
  /** Passerelle Unclaim Auth : Link by Unclaim y est déclaré comme site client. */
  unclaim: {
    /** PUBLIC_URL de la passerelle, sans slash final (sert aussi d'émetteur attendu des jetons). */
    get apiUrl(): string {
      return read("UNCLAIM_API_URL").replace(/\/+$/, "");
    },
    get clientId(): string {
      return read("UNCLAIM_CLIENT_ID");
    },
    get clientSecret(): string {
      return read("UNCLAIM_CLIENT_SECRET");
    },
    get configured(): boolean {
      return Boolean(read("UNCLAIM_API_URL") && read("UNCLAIM_CLIENT_ID") && read("UNCLAIM_CLIENT_SECRET"));
    },
    /** Fournisseurs à proposer si la passerelle ne peut pas être interrogée (séparés par des virgules). */
    get providers(): string[] {
      const list = read("UNCLAIM_PROVIDERS")
        .split(",")
        .map((v) => v.trim().toLowerCase())
        .filter((v) => /^[a-z][a-z0-9-]{1,23}$/.test(v));
      return list.length ? list : ["discord"];
    },
  },
  /** Comptes Discord administrateurs d'office (séparés par des virgules). */
  get adminDiscordIds(): string[] {
    return read("ADMIN_DISCORD_IDS")
      .split(",")
      .map((v) => v.trim())
      .filter((v) => /^\d{15,22}$/.test(v));
  },
  /** Comptes Unclaim (uncl_…) administrateurs d'office, quel que soit leur fournisseur. */
  get adminUnclaimIds(): string[] {
    return read("ADMIN_UNCLAIM_IDS")
      .split(",")
      .map((v) => v.trim())
      .filter((v) => /^uncl_[0-9A-Za-z]{10,40}$/.test(v));
  },
  /**
   * Fondateurs (comptes Unclaim uncl_… ou Discord) : toutes les permissions, badge « Fondateur ».
   * Sans fondateur déclaré, les administrateurs d'office (ADMIN_*) en tiennent lieu.
   */
  get founderUnclaimIds(): string[] {
    return read("FOUNDER_UNCLAIM_IDS")
      .split(",")
      .map((v) => v.trim())
      .filter((v) => /^uncl_[0-9A-Za-z]{10,40}$/.test(v));
  },
  get founderDiscordIds(): string[] {
    return read("FOUNDER_DISCORD_IDS")
      .split(",")
      .map((v) => v.trim())
      .filter((v) => /^\d{15,22}$/.test(v));
  },
  /** Bot du serveur Discord officiel (synchronisation des rôles du staff). Secret : jamais envoyé au navigateur. */
  discordBot: {
    get token(): string {
      return read("DISCORD_BOT_TOKEN");
    },
    get configured(): boolean {
      return read("DISCORD_BOT_TOKEN").length > 20;
    },
  },
  /** Domaines personnels : cible DNS que les clients doivent viser. */
  customDomains: {
    /** Nom d'hôte cible des CNAME (ex. « domaines.link.unclaim.fr »). */
    get cnameTarget(): string {
      return read("CUSTOM_DOMAIN_CNAME").toLowerCase().replace(/\.$/, "");
    },
    /** Adresses IPv4 du serveur (enregistrements A, pour les domaines racines). */
    get ipv4(): string[] {
      return read("CUSTOM_DOMAIN_IPV4")
        .split(",")
        .map((v) => v.trim())
        .filter((v) => /^\d{1,3}(\.\d{1,3}){3}$/.test(v));
    },
    get configured(): boolean {
      return Boolean(read("CUSTOM_DOMAIN_CNAME") || read("CUSTOM_DOMAIN_IPV4"));
    },
  },
  /** Stockage des fichiers importés : "db" (par défaut) ou "disk" (UPLOADS_DIR). */
  get uploadsDriver(): "db" | "disk" {
    return read("UPLOADS_DRIVER") === "disk" ? "disk" : "db";
  },
  get uploadsDir(): string {
    return read("UPLOADS_DIR") || "./data/uploads";
  },
  get devLoginEnabled(): boolean {
    return process.env.NODE_ENV !== "production" && read("UNCLAIM_AUTH_DEV_LOGIN") === "true";
  },
  /** Paiement en ligne : abonnements aux formules et boutique officielle (Stripe Checkout). */
  stripe: {
    get secretKey(): string {
      return read("STRIPE_SECRET_KEY");
    },
    get webhookSecret(): string {
      return read("STRIPE_WEBHOOK_SECRET");
    },
    /** Clé secrète présente : la vente en ligne est possible. */
    get configured(): boolean {
      return Boolean(read("STRIPE_SECRET_KEY"));
    },
    /** Webhook déclaré : confirmation des paiements même si l'acheteur ferme la page (recommandé en production). */
    get webhookConfigured(): boolean {
      return Boolean(read("STRIPE_WEBHOOK_SECRET"));
    },
    /** Clé de test (sk_test_…) : aucun vrai paiement. */
    get testMode(): boolean {
      return read("STRIPE_SECRET_KEY").startsWith("sk_test_") || read("STRIPE_SECRET_KEY").startsWith("rk_test_");
    },
  },
  ai: {
    /**
     * Clé de l'API Claude (Anthropic) : l'assistant de création comprend le langage naturel.
     * Sans clé, un assistant guidé local prend le relais (questions fixes, mêmes résultats).
     */
    get configured(): boolean {
      return Boolean(read("ANTHROPIC_API_KEY") || read("ANTHROPIC_AUTH_TOKEN"));
    },
    get model(): string {
      return read("ASSISTANT_MODEL") || "claude-opus-5-5";
    },
  },
  nationsglory: {
    get apiUrl(): string {
      // Base de l'API v1 ; une ancienne valeur sans /v1 est complétée.
      const url = (read("NATIONSGLORY_API_URL") || "https://publicapi.nationsglory.fr/v1").replace(/\/+$/, "");
      return /\/v\d+$/.test(url) ? url : `${url}/v1`;
    },
    get apiKey(): string {
      return read("NATIONSGLORY_API_KEY");
    },
    get skinsUrl(): string {
      return (read("NATIONSGLORY_SKINS_URL") || "https://skins.nationsglory.fr").replace(/\/+$/, "");
    },
    get mock(): boolean {
      return read("NATIONSGLORY_MOCK") === "true";
    },
    /** Requêtes par minute que l'application s'autorise (quota de la clé : 60 par défaut). */
    get rateLimit(): number {
      const n = Number(read("NATIONSGLORY_RATE_LIMIT"));
      return Number.isFinite(n) && n > 0 ? Math.floor(n) : 50;
    },
  },
};
