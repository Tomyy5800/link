import "server-only";
import type { Prisma, ShopItem, User } from "@prisma/client";
import { acceptsManualGrant, parseBadgeRule } from "../badges";
import { FRAME_KEYS, parsePerks, parseShopReward, type PublicShopItem, type ShopCategory, type ShopReward } from "../official-shop";
import { prisma } from "./db";
import { isAdmin } from "./entitlements";
import { grantBadge, logBadge, PREF_SOURCE } from "./badges";

// Boutique officielle : articles, possession et attribution des récompenses après paiement.

type Tx = Prisma.TransactionClient;

/**
 * Un badge vendu doit exister, être à règle manuelle et ne jamais être un badge du staff ou
 * réservé : on n'achète pas un titre officiel.
 */
export async function rewardError(input: { reward: ShopReward }): Promise<string | null> {
  if (input.reward.type !== "badge") return null;
  const badge = await prisma.badge.findUnique({ where: { key: input.reward.badgeKey } });
  if (!badge || badge.archivedAt) return "Ce badge n'existe pas (crée-le d'abord dans Badges).";
  if (badge.staffOnly || badge.restricted) return "Un badge du staff ou réservé ne peut pas être vendu.";
  if (!acceptsManualGrant(parseBadgeRule(badge.rule))) return "Seul un badge à règle manuelle peut être vendu.";
  return null;
}

/** Cadres d'avatar utilisables par un compte (les administrateurs les ont tous, pour les essayer). */
export async function framesOf(user: Pick<User, "id" | "role" | "discordId" | "unclaimId">): Promise<string[]> {
  if (isAdmin(user)) return [...FRAME_KEYS];
  const rows = await prisma.userUnlock.findMany({ where: { userId: user.id, kind: "frame" }, select: { key: true } }).catch(() => []);
  return rows.map((r) => r.key);
}

/** Le compte possède-t-il déjà la récompense ? (un article ne s'achète qu'une fois) */
export async function ownsReward(userId: string, reward: ShopReward, db: Tx | typeof prisma = prisma): Promise<boolean> {
  if (reward.type === "frame") {
    return Boolean(await db.userUnlock.findUnique({ where: { userId_kind_key: { userId, kind: "frame", key: reward.frame } }, select: { id: true } }));
  }
  const badge = await db.badge.findUnique({ where: { key: reward.badgeKey }, select: { id: true } });
  if (!badge) return false;
  const grant = await db.userBadge.findUnique({ where: { userId_badgeId: { userId, badgeId: badge.id } }, select: { source: true } });
  return Boolean(grant && grant.source !== PREF_SOURCE);
}

/** Donne la récompense d'un article payé (dans la transaction qui marque la commande payée). */
export async function deliverReward(tx: Tx, input: { userId: string; reward: ShopReward; orderId: string }): Promise<void> {
  if (input.reward.type === "frame") {
    await tx.userUnlock.upsert({
      where: { userId_kind_key: { userId: input.userId, kind: "frame", key: input.reward.frame } },
      create: { userId: input.userId, kind: "frame", key: input.reward.frame, orderId: input.orderId },
      update: { orderId: input.orderId },
    });
    return;
  }
  const badge = await tx.badge.findUnique({ where: { key: input.reward.badgeKey } });
  if (!badge) throw new Error(`Badge ${input.reward.badgeKey} introuvable : récompense impossible à livrer.`);
  await grantBadge(tx, { badge, userId: input.userId, actorId: `order:${input.orderId}`, source: "purchase", expiresAt: null });
}

/** Retire la récompense d'une commande remboursée. */
export async function takeBackReward(tx: Tx, input: { userId: string; reward: ShopReward; orderId: string }): Promise<void> {
  if (input.reward.type === "frame") {
    await tx.userUnlock.deleteMany({ where: { userId: input.userId, kind: "frame", key: input.reward.frame, orderId: input.orderId } });
    return;
  }
  const badge = await tx.badge.findUnique({ where: { key: input.reward.badgeKey } });
  if (!badge) return;
  const removed = await tx.userBadge.deleteMany({ where: { userId: input.userId, badgeId: badge.id, source: "purchase" } });
  if (removed.count) await logBadge(tx, `order:${input.orderId}`, "badge.revoke", badge.id, { userId: input.userId, reason: "Achat remboursé" });
}

export function toPublicItem(item: ShopItem, owned: boolean): PublicShopItem | null {
  const reward = parseShopReward(item.reward);
  if (!reward) return null;
  return {
    id: item.id,
    slug: item.slug,
    category: item.category as ShopCategory,
    name: item.name,
    description: item.description,
    perks: parsePerks(item.perks),
    priceCents: item.priceCents,
    icon: item.icon,
    imageUrl: item.imageUrl,
    color: item.color,
    reward,
    owned,
  };
}

/** Articles en vente, avec ce que le compte connecté possède déjà. */
export async function listShopItems(userId: string | null): Promise<PublicShopItem[]> {
  const items = await prisma.shopItem.findMany({ where: { active: true }, orderBy: [{ position: "asc" }, { createdAt: "asc" }] });
  const [frames, grants] = userId
    ? await Promise.all([
        prisma.userUnlock.findMany({ where: { userId, kind: "frame" }, select: { key: true } }),
        prisma.userBadge.findMany({ where: { userId, source: { not: PREF_SOURCE } }, select: { badge: { select: { key: true } } } }),
      ])
    : [[], []];
  const ownedFrames = new Set(frames.map((f) => f.key));
  const ownedBadges = new Set(grants.map((g) => g.badge.key));
  return items
    .map((item) => {
      const reward = parseShopReward(item.reward);
      const owned = reward ? (reward.type === "frame" ? ownedFrames.has(reward.frame) : ownedBadges.has(reward.badgeKey)) : false;
      return toPublicItem(item, owned);
    })
    .filter((i): i is PublicShopItem => i !== null);
}
