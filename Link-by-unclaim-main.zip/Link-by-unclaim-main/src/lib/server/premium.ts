import "server-only";
import { randomInt } from "node:crypto";
import type { Prisma } from "@prisma/client";
import type { Offer } from "../features";
import { DEFAULT_DAY_VALUE, TIER_RANK, normalizeTier, type PaidTier, type Tier } from "../plans";
import { prisma } from "./db";
import { sha256 } from "./security";

// Codes Link+ : générés depuis l'administration, échangés par les utilisateurs dans leurs réglages.
// Seule l'empreinte SHA-256 est stockée ; le code en clair n'est montré qu'une fois, à sa création.

// Sans 0/O ni 1/I/L : pas de confusion à la lecture.
const ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";

export function generateCode(): string {
  const group = () => Array.from({ length: 4 }, () => ALPHABET[randomInt(ALPHABET.length)]).join("");
  return `LBU-${group()}-${group()}-${group()}`;
}

/** Forme canonique d'un code saisi (espaces, tirets et casse ignorés). */
export function normalizeCode(input: string): string {
  return input.toUpperCase().replace(/[^A-Z0-9]/g, "");
}

export function hashCode(code: string): string {
  return sha256(`lbu-code:${normalizeCode(code)}`);
}

type Tx = Prisma.TransactionClient;
const DAY = 86_400_000;

/** Valeur d'une journée de chaque formule, d'après son abonnement annuel (repli : mensuel, puis tarifs de référence). */
export function dayValues(offers: Offer[]): Record<PaidTier, number> {
  const value = (tier: PaidTier) => {
    const offer = offers.find((o) => o.tier === tier && o.interval === "year") ?? offers.find((o) => o.tier === tier);
    if (!offer) return DEFAULT_DAY_VALUE[tier];
    return offer.interval === "year" ? offer.priceCents / 365 : (offer.priceCents * 12) / 365;
  };
  return { plus: value("plus"), pro: value("pro"), team: value("team") };
}

/** Jours d'une formule convertis en jours d'une autre, à valeur égale. */
export function convertDays(days: number, from: PaidTier, to: PaidTier, values: Record<PaidTier, number> = DEFAULT_DAY_VALUE): number {
  if (from === to) return days;
  return Math.max(0, Math.round((days * values[from]) / values[to]));
}

/**
 * Ajoute une formule au compte pour `days` jours (0 = sans limite). Aucun temps payé n'est perdu :
 * - même formule : la période est prolongée ;
 * - formule supérieure : le temps restant de l'ancienne est converti à valeur égale, et une
 *   formule « à vie » inférieure est gardée pour la suite (basePlan) ;
 * - formule inférieure pendant une formule supérieure : les jours sont convertis et ajoutés à
 *   la formule en cours (une formule « à vie » inférieure devient la formule de repli).
 * Renvoie la formule et la date de fin résultantes (null = sans limite).
 */
export async function grantPremium(
  tx: Tx,
  userId: string,
  days: number,
  tier: PaidTier = "plus",
  values: Record<PaidTier, number> = DEFAULT_DAY_VALUE,
  now = Date.now(),
): Promise<{ plan: PaidTier; planExpiresAt: Date | null }> {
  const user = await tx.user.findUniqueOrThrow({ where: { id: userId }, select: { plan: true, planExpiresAt: true, basePlan: true } });
  const next = applyGrant({ plan: user.plan, planExpiresAt: user.planExpiresAt, basePlan: user.basePlan }, days, tier, values, now);
  await tx.user.update({ where: { id: userId }, data: next });
  return { plan: next.plan, planExpiresAt: next.planExpiresAt };
}

type PlanState = { plan: string; planExpiresAt: Date | null; basePlan: string };

/** Calcul pur de grantPremium (testable). */
export function applyGrant(
  user: PlanState,
  days: number,
  tier: PaidTier,
  values: Record<PaidTier, number> = DEFAULT_DAY_VALUE,
  now = Date.now(),
): { plan: PaidTier; planExpiresAt: Date | null; basePlan: Tier } {
  const current = normalizeTier(user.plan);
  const base = normalizeTier(user.basePlan);
  const active = current !== "free" && (!user.planExpiresAt || user.planExpiresAt.getTime() > now);
  const lifetime = active && user.planExpiresAt === null;
  const remaining = active && user.planExpiresAt ? Math.max(0, Math.floor((user.planExpiresAt.getTime() - now) / DAY)) : 0;
  const keepBase = (t: Tier): Tier => (TIER_RANK[t] > TIER_RANK[base] ? t : base);

  // Pas de formule active : on part de zéro (en gardant une éventuelle formule « à vie » de repli).
  if (!active) {
    return { plan: tier, planExpiresAt: days === 0 ? null : new Date(now + days * DAY), basePlan: days === 0 ? "free" : base };
  }
  const currentPaid = current as PaidTier;

  // Même formule : prolongation (ou passage « à vie »).
  if (currentPaid === tier) {
    if (lifetime || days === 0) return { plan: tier, planExpiresAt: null, basePlan: base };
    return { plan: tier, planExpiresAt: new Date(user.planExpiresAt!.getTime() + days * DAY), basePlan: base };
  }

  // Formule supérieure : le temps restant est converti, une formule « à vie » est gardée en repli.
  if (TIER_RANK[tier] > TIER_RANK[currentPaid]) {
    if (days === 0) return { plan: tier, planExpiresAt: null, basePlan: "free" };
    if (lifetime) return { plan: tier, planExpiresAt: new Date(now + days * DAY), basePlan: keepBase(currentPaid) };
    const bonus = convertDays(remaining, currentPaid, tier, values);
    return { plan: tier, planExpiresAt: new Date(now + (days + bonus) * DAY), basePlan: base };
  }

  // Formule inférieure pendant une formule supérieure.
  if (days === 0) {
    // À vie : elle prendra le relais quand la formule supérieure se terminera.
    return { plan: currentPaid, planExpiresAt: user.planExpiresAt, basePlan: keepBase(tier) };
  }
  if (lifetime) return { plan: currentPaid, planExpiresAt: null, basePlan: base };
  const extra = convertDays(days, tier, currentPaid, values);
  return { plan: currentPaid, planExpiresAt: new Date(user.planExpiresAt!.getTime() + extra * DAY), basePlan: base };
}

/**
 * Retire `days` jours d'une formule (remboursement). Sans limite ou plus de jours restants : le
 * compte retrouve sa formule de repli, ou l'offre gratuite.
 */
export async function revokePremium(tx: Tx, userId: string, days: number, tier: PaidTier = "plus"): Promise<void> {
  const user = await tx.user.findUniqueOrThrow({ where: { id: userId }, select: { plan: true, planExpiresAt: true, basePlan: true } });
  const plan = normalizeTier(user.plan);
  const base = normalizeTier(user.basePlan);
  if (plan !== tier) {
    // La formule remboursée était la formule de repli « à vie ».
    if (days === 0 && base === tier) await tx.user.update({ where: { id: userId }, data: { basePlan: "free" } });
    return;
  }
  const fallback = { plan: base, planExpiresAt: null, basePlan: "free" };
  if (days === 0 || !user.planExpiresAt) {
    await tx.user.update({ where: { id: userId }, data: fallback });
    return;
  }
  const end = user.planExpiresAt.getTime() - days * DAY;
  await tx.user.update({ where: { id: userId }, data: end > Date.now() ? { planExpiresAt: new Date(end) } : fallback });
}

export type RedeemResult = { ok: true; plan: PaidTier; planExpiresAt: Date | null; days: number } | { ok: false; error: string };

/** Échange un code : ajoute sa formule pour le nombre de jours du code (0 = sans limite de durée). */
export async function redeemCode(userId: string, input: string): Promise<RedeemResult> {
  const normalized = normalizeCode(input);
  if (normalized.length < 8 || normalized.length > 40) return { ok: false, error: "Code invalide." };
  const code = await prisma.premiumCode.findUnique({ where: { codeHash: hashCode(normalized) } });
  if (!code || code.disabled) return { ok: false, error: "Code invalide ou désactivé." };
  if (code.expiresAt && code.expiresAt < new Date()) return { ok: false, error: "Ce code a expiré." };
  if (code.uses >= code.maxUses) return { ok: false, error: "Ce code a déjà été utilisé." };
  if (await prisma.codeRedemption.findUnique({ where: { codeId_userId: { codeId: code.id, userId } } })) {
    return { ok: false, error: "Tu as déjà utilisé ce code." };
  }

  return prisma.$transaction(async (tx) => {
    // Incrément conditionnel : deux échanges simultanés ne peuvent pas dépasser maxUses.
    const claimed = await tx.premiumCode.updateMany({ where: { id: code.id, uses: { lt: code.maxUses } }, data: { uses: { increment: 1 } } });
    if (claimed.count === 0) return { ok: false as const, error: "Ce code a déjà été utilisé." };
    await tx.codeRedemption.create({ data: { codeId: code.id, userId } });

    const tier = (normalizeTier(code.tier) === "free" ? "plus" : normalizeTier(code.tier)) as PaidTier;
    const { plan, planExpiresAt } = await grantPremium(tx, userId, code.days, tier);
    await tx.auditLog.create({
      data: { actorId: userId, action: "code.redeem", targetType: "code", targetId: code.id, details: JSON.stringify({ days: code.days, tier, hint: code.hint }) },
    });
    return { ok: true as const, plan, planExpiresAt, days: code.days };
  });
}
