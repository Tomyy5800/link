import "server-only";
import type { Page, Prisma, User } from "@prisma/client";
import { redirect } from "next/navigation";
import { cache } from "react";
import type { NextResponse } from "next/server";
import { toOwnerProfile } from "../discord-cdn";
import { TERMS_VERSION } from "../legal";
import { BASE_ROLE_PERMISSIONS, PAGE_PERMISSION_KEYS, parsePagePermissions, type PagePermission } from "../member-roles";
import { accentOnDark, parseTheme, type Theme } from "../theme";
import { prisma } from "./db";
import { entitlementsFrom } from "./entitlements";
import { getSettings } from "./settings";
import { guardMutation, guardRate, jsonError } from "./http";
import { getCurrentUser } from "./unclaim-auth";
import { syncFromUnclaim } from "./unclaim-auth/sync";

// Accès à « Mon espace » et aux pages : compte connecté, CGU acceptées, rôle sur chaque page.

/** owner : propriétaire · editor : modifie la page · viewer : statistiques et messages seulement. */
export type PageRole = "owner" | "editor" | "viewer";

export const ROLE_LABELS: Record<PageRole, string> = { owner: "Propriétaire", editor: "Éditeur", viewer: "Lecteur" };

export function needsTerms(user: Pick<User, "termsVersion">): boolean {
  return user.termsVersion !== TERMS_VERSION;
}

export function canEdit(role: PageRole): boolean {
  return role === "owner" || role === "editor";
}

/** Compte connecté, resynchronisé avec Unclaim Auth si besoin (une fois par requête). */
export const getSyncedUser = cache(async (): Promise<User | null> => {
  const current = await getCurrentUser();
  return current ? syncFromUnclaim(current) : null;
});

/** Pages de « Mon espace » : connexion, compte actif et CGU acceptées, sinon redirection. */
export async function requireAccountPage(next: string): Promise<User> {
  const user = await getSyncedUser();
  if (!user) redirect(`/login?next=${encodeURIComponent(next)}`);
  if (user.banned) redirect("/login?error=banned");
  if (needsTerms(user)) redirect(`/bienvenue?next=${encodeURIComponent(next)}`);
  return user;
}

/** Routes /api/me : renvoie le compte, ou la réponse d'erreur à retourner telle quelle. */
export async function requireAccountApi(
  request: Request,
  opts: { mutation?: boolean; rate?: [scope: string, limit: number]; terms?: boolean } = {},
): Promise<User | NextResponse> {
  if (opts.mutation) {
    const blocked = guardMutation(request) ?? (opts.rate ? guardRate(request, opts.rate[0], opts.rate[1]) : null);
    if (blocked) return blocked;
  }
  const user = await getCurrentUser();
  if (!user) return jsonError(401, "Connexion requise.");
  if (opts.terms !== false && needsTerms(user)) {
    return jsonError(403, "Accepte les conditions d'utilisation pour continuer.", { code: "terms_required" });
  }
  return user;
}

export type PageAccess = {
  page: Page & { user: User };
  role: PageRole;
  /** Permissions effectives : rôle personnalisé s'il y en a un (et si la formule du propriétaire les permet), sinon rôle de base. */
  permissions: PagePermission[];
  /** Rôle personnalisé appliqué (nom et couleur, pour l'affichage). */
  customRole: { id: string; name: string; color: string } | null;
};

/** Rôle et permissions d'un compte sur une page (null : aucun accès). */
export async function pageAccess(userId: string, pageId: string): Promise<PageAccess | null> {
  if (!/^[a-z0-9]{8,40}$/i.test(pageId)) return null;
  const row = await prisma.page.findUnique({
    where: { id: pageId },
    include: {
      user: true,
      members: { where: { userId }, select: { role: true, customRole: { select: { id: true, name: true, color: true, permissions: true } } } },
    },
  });
  if (!row) return null;
  const { members, ...page } = row;
  if (page.userId === userId) return { page, role: "owner", permissions: [...PAGE_PERMISSION_KEYS], customRole: null };
  const member = members[0];
  if (!member) return null;
  const role: PageRole = member.role === "viewer" ? "viewer" : "editor";
  // Rôle personnalisé : seulement si la formule du propriétaire comprend encore cette fonction.
  if (member.customRole && entitlementsFrom(page.user, await getSettings()).features.customRoles) {
    const { permissions, ...customRole } = member.customRole;
    return { page, role, permissions: parsePagePermissions(permissions), customRole };
  }
  return { page, role, permissions: BASE_ROLE_PERMISSIONS[role], customRole: null };
}

export function hasPagePermission(access: Pick<PageAccess, "role" | "permissions">, permission: PagePermission): boolean {
  return access.role === "owner" || access.permissions.includes(permission);
}

const PERMISSION_ERRORS: Record<PagePermission, string> = {
  content: "Ton rôle sur cette page ne permet pas de la modifier.",
  "messages.read": "Ton rôle sur cette page ne permet pas de lire ses messages.",
  "messages.manage": "Ton rôle sur cette page ne permet pas de supprimer des messages.",
  orders: "Ton rôle sur cette page ne permet pas de gérer ses commandes.",
  stats: "Ton rôle sur cette page ne permet pas de voir ses statistiques.",
};

/**
 * Accès d'une route d'API à une page : « view » (membre), « own » (propriétaire), « edit »
 * (= permission « content »), ou une permission précise.
 */
export async function requirePageApi(user: User, pageId: string, need: "view" | "edit" | "own" | PagePermission): Promise<PageAccess | NextResponse> {
  const access = await pageAccess(user.id, pageId);
  if (!access) return jsonError(404, "Page introuvable.");
  if (need === "own") return access.role === "owner" ? access : jsonError(403, "Réservé au propriétaire de la page.");
  if (need === "view") return access;
  const permission: PagePermission = need === "edit" ? "content" : need;
  return hasPagePermission(access, permission) ? access : jsonError(403, PERMISSION_ERRORS[permission]);
}

const summarySelect = {
  id: true,
  slug: true,
  label: true,
  displayName: true,
  bio: true,
  avatarSource: true,
  avatarUrl: true,
  theme: true,
  published: true,
  status: true,
  views: true,
  createdAt: true,
  updatedAt: true,
  user: true,
  _count: { select: { messages: { where: { read: false } }, members: true } },
} as const satisfies Prisma.PageSelect;

export type AccountPage = {
  id: string;
  slug: string;
  name: string;
  label: string;
  displayName: string;
  avatar: string;
  accent: string;
  /** Couleurs du thème, pour la vignette de la page dans « Mon espace ». */
  palette: { bg: string; bg2: string; accent: string; accent2: string };
  /** Thème complet et présence d'une bio : miniature fidèle de la page. */
  theme: Theme;
  hasBio: boolean;
  published: boolean;
  suspended: boolean;
  views: number;
  updatedAt: string;
  role: PageRole;
  /** Permissions du compte sur la page (rôle personnalisé compris). */
  permissions: PagePermission[];
  /** Rôle personnalisé du compte sur la page, pour l'affichage. */
  customRole: { name: string; color: string } | null;
  unread: number;
  members: number;
  /** Propriétaire, pour les pages partagées avec ce compte. */
  ownerName: string;
};

type SummaryRow = Prisma.PageGetPayload<{ select: typeof summarySelect }>;

function toAccountPage(
  p: SummaryRow,
  role: PageRole,
  access: { permissions: PagePermission[]; customRole: { name: string; color: string } | null } = { permissions: [...PAGE_PERMISSION_KEYS], customRole: null },
): AccountPage {
  const owner = toOwnerProfile(p.user);
  const theme = parseTheme(p.theme);
  return {
    id: p.id,
    slug: p.slug,
    name: p.label || p.displayName,
    label: p.label,
    displayName: p.displayName,
    avatar: p.avatarSource === "custom" && p.avatarUrl ? p.avatarUrl : owner.avatarUrl,
    accent: accentOnDark(theme.accent),
    theme,
    hasBio: p.bio.trim().length > 0,
    palette: { bg: theme.bgColor, bg2: theme.bgType === "solid" ? theme.bgColor : theme.bgColor2, accent: theme.accent, accent2: theme.accent2 },
    published: p.published,
    suspended: p.status === "suspended",
    views: p.views,
    updatedAt: p.updatedAt.toISOString(),
    role,
    permissions: access.permissions,
    customRole: access.customRole,
    unread: p._count.messages,
    members: p._count.members,
    ownerName: p.user.globalName ?? p.user.username,
  };
}

/** Pages d'un compte : les siennes (ordre de création), puis celles où il collabore. */
export async function listAccountPages(userId: string): Promise<AccountPage[]> {
  const [own, shared, settings] = await Promise.all([
    prisma.page.findMany({ where: { userId }, orderBy: { createdAt: "asc" }, select: summarySelect }),
    prisma.pageMember.findMany({
      where: { userId },
      orderBy: { createdAt: "asc" },
      select: { role: true, customRole: { select: { name: true, color: true, permissions: true } }, page: { select: summarySelect } },
    }),
    getSettings(),
  ]);
  return [
    ...own.map((p) => toAccountPage(p, "owner")),
    ...shared.map((m) => {
      const role: PageRole = m.role === "viewer" ? "viewer" : "editor";
      const custom = m.customRole && entitlementsFrom(m.page.user, settings).features.customRoles ? m.customRole : null;
      return toAccountPage(m.page, role, {
        permissions: custom ? parsePagePermissions(custom.permissions) : BASE_ROLE_PERMISSIONS[role],
        customRole: custom ? { name: custom.name, color: custom.color } : null,
      });
    }),
  ];
}

export function ownedPageCount(userId: string): Promise<number> {
  return prisma.page.count({ where: { userId } });
}
