import "server-only";
import { parseBadgeRule } from "../badges";
import { backfillEarly, ensureSystemBadges, purgeExpiredBadges } from "./badges";
import { prisma } from "./db";
import { maybeRunDiscordSync } from "./discord-sync";
import { recheckStaleDomains } from "./domains";

// Tâches périodiques, sans planificateur externe : lancées après une réponse (next/server
// `after`) au plus toutes les 5 minutes. Un verrou en base empêche deux serveurs (ou deux
// requêtes) de les lancer en même temps.

const EVERY_MS = 5 * 60_000;
const LOCK_KEY = "jobs-lock";
const memory = globalThis as unknown as { __lbuJobsAt?: number };

async function claimLock(now: number): Promise<boolean> {
  const value = String(now);
  const row = await prisma.appSetting.findUnique({ where: { key: LOCK_KEY } });
  if (!row) {
    return prisma.appSetting
      .create({ data: { key: LOCK_KEY, value } })
      .then(() => true)
      .catch(() => false);
  }
  if (now - Number(row.value) < EVERY_MS) return false;
  // Mise à jour conditionnelle : un seul gagnant si plusieurs tentent en même temps.
  const claimed = await prisma.appSetting.updateMany({ where: { key: LOCK_KEY, value: row.value }, data: { value } });
  return claimed.count === 1;
}

export async function maybeRunJobs(now = Date.now()): Promise<void> {
  if (memory.__lbuJobsAt && now - memory.__lbuJobsAt < EVERY_MS) return;
  memory.__lbuJobsAt = now;
  if (!(await claimLock(now).catch(() => false))) return;
  await runJobs();
}

/** Toutes les tâches, chacune isolée : l'échec de l'une n'empêche pas les autres. */
export async function runJobs(): Promise<void> {
  const step = async (name: string, task: () => Promise<unknown>) => {
    try {
      await task();
    } catch (error) {
      console.error(`[tâches] ${name} :`, error instanceof Error ? error.message : error);
    }
  };
  await step("badges intégrés", ensureSystemBadges);
  await step("badges expirés", () => purgeExpiredBadges());
  await step("premiers comptes", async () => {
    const badges = await prisma.badge.findMany({ where: { active: true, archivedAt: null } });
    for (const badge of badges) if (parseBadgeRule(badge.rule).type === "early") await backfillEarly(badge, 200);
  });
  await step("synchronisation Discord", () => maybeRunDiscordSync());
  await step("domaines personnels", () => recheckStaleDomains(10));
}
