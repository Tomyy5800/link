import "server-only";
import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import { env } from "./env";

export function randomToken(bytes = 32): string {
  return randomBytes(bytes).toString("base64url");
}

export function sha256(value: string): string {
  return createHash("sha256").update(value).digest("hex");
}

export function safeEqual(a: string, b: string): boolean {
  const ab = Buffer.from(a);
  const bb = Buffer.from(b);
  return ab.length === bb.length && timingSafeEqual(ab, bb);
}

export function clientIp(headers: Headers): string {
  const forwarded = headers.get("x-forwarded-for");
  if (forwarded) return forwarded.split(",")[0]!.trim();
  return headers.get("x-real-ip")?.trim() || "unknown";
}

/**
 * Protection CSRF des routes qui modifient des données : la requête doit venir
 * de l'application elle-même (en-tête Origin, ou Sec-Fetch-Site à défaut).
 */
export function isSameOrigin(request: Request): boolean {
  const origin = request.headers.get("origin");
  if (!origin) return request.headers.get("sec-fetch-site") === "same-origin";
  const allowed = new Set<string>([new URL(env.appUrl).origin]);
  try {
    allowed.add(new URL(request.url).origin);
  } catch {
    // ignore
  }
  const host = request.headers.get("x-forwarded-host") ?? request.headers.get("host");
  if (host) {
    const proto = request.headers.get("x-forwarded-proto") ?? (env.isProduction ? "https" : "http");
    allowed.add(`${proto}://${host}`);
  }
  return allowed.has(origin);
}

/** Empreinte anonyme d'un visiteur, valable un seul jour (aucune IP stockée). */
export function visitorHash(ip: string, userAgent: string, day: string): string {
  return sha256(`${env.sessionSecret}|${day}|${ip}|${userAgent}`).slice(0, 40);
}

/** Chemin de redirection interne sûr (évite les redirections ouvertes). */
export function safeNextPath(value: string | null | undefined, fallback = "/dashboard"): string {
  if (!value || !value.startsWith("/") || value.startsWith("//") || value.startsWith("/\\")) return fallback;
  return value.slice(0, 200);
}
