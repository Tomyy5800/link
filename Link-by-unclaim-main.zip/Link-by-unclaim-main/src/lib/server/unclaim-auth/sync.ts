import "server-only";
import type { User } from "@prisma/client";
import { prisma } from "../db";
import { env } from "../env";
import { UnclaimError, fetchUser } from "./client";
import { profileFields, revokeSessions } from "./index";

const STALE_AFTER_MS = 6 * 60 * 60 * 1000;

/** Préfixe des comptes créés par la connexion de démonstration (/api/auth/dev). */
export const DEMO_UNCLAIM_PREFIX = "uncl_DEMO";

/**
 * Remet à jour le profil Discord d'un compte depuis Unclaim Auth (avatar, bannière, pseudo)
 * et applique un éventuel bannissement décidé dans la passerelle.
 * Sans `force`, ne fait rien si la dernière synchronisation date de moins de 6 h.
 */
export async function syncFromUnclaim(user: User, { force = false } = {}): Promise<User> {
  if (!env.unclaim.configured || !user.unclaimId) return user;
  // Le compte de démonstration (connexion de dev) n'existe pas dans la passerelle : on ne le
  // resynchronise jamais, sinon la passerelle répond 404 et ses sessions seraient fermées.
  if (user.unclaimId.startsWith(DEMO_UNCLAIM_PREFIX)) return user;
  if (!force && Date.now() - user.discordSyncedAt.getTime() < STALE_AFTER_MS) return user;

  try {
    const remote = await fetchUser(user.unclaimId, force ? 8000 : 2500);
    const updated = await prisma.user.update({ where: { id: user.id }, data: profileFields(remote) });
    if (updated.banned) await revokeSessions(updated.id);
    return updated;
  } catch (error) {
    if (error instanceof UnclaimError && error.status === 404) {
      // Compte effacé dans la passerelle : on ferme ses sessions, sa page reste en l'état.
      await revokeSessions(user.id);
    }
    // On note la tentative pour ne pas réessayer à chaque visite.
    return prisma.user.update({ where: { id: user.id }, data: { discordSyncedAt: new Date() } }).catch(() => user);
  }
}
