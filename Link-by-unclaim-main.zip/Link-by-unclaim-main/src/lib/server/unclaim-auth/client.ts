import "server-only";
import { createHash, createPublicKey, randomBytes, verify, type JsonWebKey } from "node:crypto";
import { env } from "../env";

// ─── Client de la passerelle Unclaim Auth ────────────────────────────────────
// Portage TypeScript de sdk/unclaim-node.js (projet unclaim-api).
// Link by Unclaim est un « site client » de la passerelle :
//   1. /auth/<fournisseur>?client_id&redirect_uri&state&code_challenge  (navigateur)
//   2. retour sur notre redirect_uri avec ?unclaim_code&unclaim_id&provider&state
//   3. POST /api/v1/token (Basic client_id:client_secret) → identité + jeton EdDSA
// Le secret client ne quitte jamais le serveur. La passerelle gère plusieurs fournisseurs
// (Discord, Google, Microsoft, Apple, Twitch, NationsGlory) : Discord n'est plus obligatoire.

/** Identité rattachée au compte Unclaim (sans jetons). */
export type UnclaimIdentity = {
  provider: string;
  provider_id: string | null;
  username: string | null;
  display_name: string | null;
  avatar_url: string | null;
  email?: string | null;
};

/**
 * Profil renvoyé par la passerelle (objet `user` de /api/v1/token et /api/v1/users/:id).
 * Le profil du fournisseur utilisé pour se connecter est à la racine ; `discord_id` reste
 * renseigné tant qu'une identité Discord est rattachée, même après une connexion Google.
 */
export type UnclaimUser = {
  unclaim_id: string;
  provider?: string | null;
  provider_id?: string | null;
  discord_id: string | null;
  username: string | null;
  display_name?: string | null;
  global_name?: string | null;
  avatar?: string | null;
  avatar_url?: string | null;
  banner?: string | null;
  banner_url?: string | null;
  accent_color?: number | null;
  identities?: UnclaimIdentity[];
  banned?: boolean;
};

export type UnclaimTokenResponse = {
  unclaim_id: string;
  unclaim_token: string;
  refresh_token?: string;
  token_type?: string;
  expires_in?: number;
  is_new_user?: boolean;
  scopes?: string[];
  user: UnclaimUser;
};

export class UnclaimError extends Error {
  constructor(
    message: string,
    readonly status: number,
    readonly code?: string,
  ) {
    super(message);
    this.name = "UnclaimError";
  }
}

export function callbackUrl(): string {
  return `${env.appUrl}/api/auth/callback`;
}

export function pkceChallenge(verifier: string): string {
  return createHash("sha256").update(verifier).digest("base64url");
}

export const PROVIDER_ID = /^[a-z][a-z0-9-]{1,23}$/;

/**
 * Prépare une connexion : URL de la passerelle pour le fournisseur choisi, `state` et
 * vérificateur PKCE à garder côté serveur. Pas d'écran intermédiaire : le visiteur part
 * directement chez le fournisseur. Les autorisations sont celles déclarées pour le site.
 */
export function startLogin(provider = "discord"): { url: string; state: string; codeVerifier: string } {
  if (!PROVIDER_ID.test(provider)) throw new Error("fournisseur_invalide");
  const state = randomBytes(16).toString("base64url");
  const codeVerifier = randomBytes(48).toString("base64url");
  const params = new URLSearchParams({
    client_id: env.unclaim.clientId,
    redirect_uri: callbackUrl(),
    state,
    code_challenge: pkceChallenge(codeVerifier),
    code_challenge_method: "S256",
  });
  return { url: `${env.unclaim.apiUrl}/auth/${provider}?${params.toString()}`, state, codeVerifier };
}

async function call<T>(
  method: "GET" | "POST",
  pathname: string,
  body?: unknown,
  { anonymous = false, timeoutMs = 10_000 }: { anonymous?: boolean; timeoutMs?: number } = {},
): Promise<T> {
  const headers: Record<string, string> = { Accept: "application/json" };
  if (!anonymous) {
    // Le secret voyage dans l'en-tête Authorization, jamais dans l'URL ou le corps.
    const basic = Buffer.from(`${env.unclaim.clientId}:${env.unclaim.clientSecret}`).toString("base64");
    headers.Authorization = `Basic ${basic}`;
  }
  if (body !== undefined) headers["Content-Type"] = "application/json";

  let res: Response;
  try {
    res = await fetch(`${env.unclaim.apiUrl}${pathname}`, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
      cache: "no-store",
      signal: AbortSignal.timeout(timeoutMs),
    });
  } catch (error) {
    const timeout = error instanceof DOMException && error.name === "TimeoutError";
    throw new UnclaimError(timeout ? "Unclaim Auth ne répond pas." : "Unclaim Auth est injoignable.", timeout ? 504 : 503);
  }

  const text = await res.text();
  let data: Record<string, unknown> = {};
  try {
    data = text ? (JSON.parse(text) as Record<string, unknown>) : {};
  } catch {
    data = {};
  }
  if (!res.ok) {
    const code = typeof data.error === "string" ? data.error : undefined;
    const description = typeof data.error_description === "string" ? data.error_description : `HTTP ${res.status}`;
    throw new UnclaimError(description, res.status, code);
  }
  return data as T;
}

/** Échange le code reçu sur notre redirect_uri contre l'identité Unclaim. */
export function exchangeCode(code: string, codeVerifier: string): Promise<UnclaimTokenResponse> {
  return call("POST", "/api/v1/token", { code, code_verifier: codeVerifier, redirect_uri: callbackUrl() });
}

/** Profil à jour d'un compte déjà connu du site (synchronisation, bannissement). */
export async function fetchUser(unclaimId: string, timeoutMs = 10_000): Promise<UnclaimUser> {
  const data = await call<{ user: UnclaimUser }>("GET", `/api/v1/users/${encodeURIComponent(unclaimId)}`, undefined, { timeoutMs });
  return data.user;
}

// ─── Fournisseurs proposés ─────────────────────────────────────────────────

/**
 * Fournisseurs à proposer : ceux que la passerelle a en service (/auth/config), limités à
 * ceux qu'elle autorise pour notre site (/api/v1/site). En cache 5 minutes ; si la passerelle
 * ne répond pas, la dernière liste connue (ou UNCLAIM_PROVIDERS) est utilisée.
 */
const providersCache: { ids: string[]; until: number } = { ids: [], until: 0 };

export async function availableProviders(): Promise<string[]> {
  if (providersCache.ids.length && Date.now() < providersCache.until) return providersCache.ids;
  const remember = (ids: string[], ttlMs: number) => {
    providersCache.ids = ids;
    providersCache.until = Date.now() + ttlMs;
    return ids;
  };
  // Passerelle injoignable : dernière liste connue (ou UNCLAIM_PROVIDERS), réessayée dans une minute.
  const fallback = () => remember(providersCache.ids.length ? providersCache.ids : env.unclaim.providers, 60_000);
  if (!env.unclaim.configured) return env.unclaim.providers;
  try {
    const [config, site] = await Promise.all([
      call<{ providers_supported?: { id?: string }[] }>("GET", "/auth/config", undefined, { anonymous: true, timeoutMs: 4000 }),
      call<{ site?: { providers?: string[] | null } }>("GET", "/api/v1/site", undefined, { timeoutMs: 4000 }).catch(() => null),
    ]);
    let ids = (config.providers_supported ?? []).map((p) => p.id).filter((id): id is string => typeof id === "string" && PROVIDER_ID.test(id));
    const allowed = site?.site?.providers;
    if (Array.isArray(allowed) && allowed.length) ids = ids.filter((id) => allowed.includes(id));
    return ids.length ? remember(ids, 5 * 60_000) : fallback();
  } catch {
    return fallback();
  }
}

// ─── Vérification locale des jetons (EdDSA / JWKS) ─────────────────────────

type Jwk = JsonWebKey & { kid?: string };
type JwksFetcher = () => Promise<Jwk[]>;

const jwksCache: { keys: Jwk[]; fetchedAt: number } = { keys: [], fetchedAt: 0 };
const JWKS_TTL_MS = 60 * 60 * 1000;

async function defaultJwks(force: boolean): Promise<Jwk[]> {
  if (!force && jwksCache.keys.length && Date.now() - jwksCache.fetchedAt < JWKS_TTL_MS) return jwksCache.keys;
  const data = await call<{ keys?: Jwk[] }>("GET", "/.well-known/jwks.json", undefined, { anonymous: true });
  jwksCache.keys = data.keys ?? [];
  jwksCache.fetchedAt = Date.now();
  return jwksCache.keys;
}

export type AccessTokenPayload = {
  sub: string;
  aud: string;
  iss: string;
  typ: string;
  exp: number;
  nbf?: number;
  user?: UnclaimUser;
};

/**
 * Vérifie un jeton d'accès Unclaim : signature Ed25519 (algorithme imposé),
 * émetteur, audience = notre client_id, type « access », dates. Renvoie le payload ou null.
 */
export async function verifyAccessToken(
  token: string,
  options: { issuer?: string; audience?: string; getKeys?: (force: boolean) => Promise<Jwk[]>; now?: number } = {},
): Promise<AccessTokenPayload | null> {
  const issuer = options.issuer ?? env.unclaim.apiUrl;
  const audience = options.audience ?? env.unclaim.clientId;
  const getKeys = options.getKeys ?? defaultJwks;
  const parts = token.split(".");
  if (parts.length !== 3) return null;

  let header: { alg?: string; kid?: string };
  try {
    header = JSON.parse(Buffer.from(parts[0], "base64url").toString("utf8"));
  } catch {
    return null;
  }
  // « alg: none » ou HS256 forgés ne sont jamais examinés plus loin.
  if (header.alg !== "EdDSA" || !header.kid) return null;

  let jwk = (await getKeys(false)).find((k) => k.kid === header.kid);
  if (!jwk) jwk = (await getKeys(true)).find((k) => k.kid === header.kid); // rotation de clé côté passerelle
  if (!jwk) return null;

  try {
    const key = createPublicKey({ key: jwk, format: "jwk" });
    const ok = verify(null, Buffer.from(`${parts[0]}.${parts[1]}`), key, Buffer.from(parts[2], "base64url"));
    if (!ok) return null;
  } catch {
    return null;
  }

  let payload: AccessTokenPayload;
  try {
    payload = JSON.parse(Buffer.from(parts[1], "base64url").toString("utf8"));
  } catch {
    return null;
  }
  const now = Math.floor((options.now ?? Date.now()) / 1000);
  const tolerance = 30;
  if (payload.iss !== issuer || payload.aud !== audience || payload.typ !== "access") return null;
  if (typeof payload.exp !== "number" || payload.exp + tolerance < now) return null;
  if (typeof payload.nbf === "number" && payload.nbf - tolerance > now) return null;
  return payload;
}

export type { JwksFetcher };
