import "server-only";
import { cookies } from "next/headers";
import type { NextResponse } from "next/server";
import { cache } from "react";
import type { User } from "@prisma/client";
import { prisma } from "../db";
import { env } from "../env";
import { randomToken, sha256 } from "../security";
import { providerMeta, type LinkedIdentity } from "../../identity";
import type { UnclaimUser } from "./client";

// ─── Sessions Link by Unclaim ────────────────────────────────────────────────
// L'identité vient de la passerelle Unclaim Auth (voir client.ts) : chaque compte
// est rattaché à un ID Unclaim stable (uncl_…) et à son compte Discord.
// Les sessions locales sont stockées en base ; le cookie ne contient qu'un jeton
// aléatoire dont seule l'empreinte SHA-256 est conservée côté serveur.

export const SESSION_COOKIE = "lbu_session";
export const OAUTH_COOKIE = "lbu_oauth";
const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000;

const cookieBase = () => ({
  httpOnly: true,
  sameSite: "lax" as const,
  secure: env.isProduction,
  path: "/",
});

/**
 * Champs du compte tels que la passerelle les transmet, quel que soit le fournisseur.
 * Les champs propres à Discord (avatar, bannière, couleur) ne sont mis à jour que lorsque
 * le profil reçu est celui de Discord ; ils restent sinon inchangés. Aucune adresse e-mail
 * n'est conservée.
 */
export function profileFields(user: UnclaimUser) {
  const provider = user.provider || (user.discord_id ? "discord" : "unclaim");
  const isDiscord = provider === "discord";
  const identities: LinkedIdentity[] = (user.identities ?? [])
    .filter((i) => typeof i?.provider === "string")
    .map((i) => ({ provider: i.provider, username: providerMeta(i.provider).publicHandle ? (i.username ?? null) : null }));
  if (!identities.some((i) => i.provider === provider)) {
    identities.unshift({ provider, username: providerMeta(provider).publicHandle ? (user.username ?? null) : null });
  }
  const ng = (user.identities ?? []).find((i) => i.provider === "nationsglory")?.username ?? (provider === "nationsglory" ? user.username : null);
  const avatar = (user.identities ?? []).find((i) => i.provider === "discord")?.avatar_url ?? user.avatar_url ?? null;

  return {
    discordId: user.discord_id ?? null,
    provider,
    username: (user.username || user.display_name || "membre").slice(0, 64),
    globalName: (user.display_name ?? user.global_name ?? null)?.slice(0, 64) ?? null,
    avatarUrl: avatar && /^https:\/\//.test(avatar) ? avatar.slice(0, 500) : null,
    ...(isDiscord
      ? { avatarHash: user.avatar ?? null, bannerHash: user.banner ?? null, accentColor: user.accent_color ?? null }
      : user.discord_id
        ? {}
        : { avatarHash: null, bannerHash: null, accentColor: null }),
    identities: JSON.stringify(identities.slice(0, 12)),
    ngAccount: ng && /^[A-Za-z0-9_]{2,16}$/.test(ng) ? ng : null,
    banned: Boolean(user.banned),
    discordSyncedAt: new Date(),
  };
}

/** Crée ou met à jour le compte local à partir de l'identité Unclaim. */
export async function upsertUnclaimUser(user: UnclaimUser): Promise<User> {
  const fields = profileFields(user);
  // Un compte créé avant le passage à Unclaim Auth est retrouvé par son ID Discord.
  const existing =
    (await prisma.user.findUnique({ where: { unclaimId: user.unclaim_id } })) ??
    (user.discord_id ? await prisma.user.findUnique({ where: { discordId: user.discord_id } }) : null);
  if (existing) {
    return prisma.user.update({
      where: { id: existing.id },
      data: { ...fields, unclaimId: user.unclaim_id, lastLoginAt: new Date() },
    });
  }
  return prisma.user.create({ data: { ...fields, unclaimId: user.unclaim_id } });
}

/** Ouvre une session et pose le cookie sur la réponse fournie. */
export async function startSession(response: NextResponse, userId: string, userAgent: string | null) {
  const token = randomToken(32);
  const expiresAt = new Date(Date.now() + SESSION_TTL_MS);
  await prisma.session.create({
    data: { id: sha256(token), userId, userAgent: userAgent?.slice(0, 255) ?? null, expiresAt },
  });
  response.cookies.set(SESSION_COOKIE, token, { ...cookieBase(), expires: expiresAt });
  // Nettoyage opportuniste des sessions expirées.
  if (Math.random() < 0.05) {
    await prisma.session.deleteMany({ where: { expiresAt: { lt: new Date() } } }).catch(() => undefined);
  }
}

export async function endSession(response: NextResponse) {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) await prisma.session.deleteMany({ where: { id: sha256(token) } });
  response.cookies.set(SESSION_COOKIE, "", { ...cookieBase(), maxAge: 0 });
}

/** Ferme toutes les sessions d'un compte (bannissement côté Unclaim Auth). */
export async function revokeSessions(userId: string) {
  await prisma.session.deleteMany({ where: { userId } });
}

/** Utilisateur connecté pour la requête en cours (mémoïsé par requête). Un compte bloqué n'est jamais connecté. */
export const getCurrentUser = cache(async (): Promise<User | null> => {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token || token.length > 100) return null;
  const session = await prisma.session.findUnique({ where: { id: sha256(token) }, include: { user: true } });
  if (!session) return null;
  if (session.expiresAt < new Date() || session.user.banned) {
    await prisma.session.delete({ where: { id: session.id } }).catch(() => undefined);
    return null;
  }
  return session.user;
});

// ─── État de connexion (anti-CSRF + PKCE) ───────────────────────────────────

type OAuthState = { state: string; verifier: string; next: string };

export function setOAuthState(response: NextResponse, value: OAuthState) {
  response.cookies.set(OAUTH_COOKIE, JSON.stringify({ s: value.state, v: value.verifier, n: value.next }), {
    ...cookieBase(),
    path: "/api/auth",
    maxAge: 600,
  });
}

export async function readOAuthState(): Promise<OAuthState | null> {
  const raw = (await cookies()).get(OAUTH_COOKIE)?.value;
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw) as { s?: unknown; v?: unknown; n?: unknown };
    if (typeof parsed.s !== "string" || typeof parsed.v !== "string" || typeof parsed.n !== "string") return null;
    return { state: parsed.s, verifier: parsed.v, next: parsed.n };
  } catch {
    return null;
  }
}

export function clearOAuthState(response: NextResponse) {
  response.cookies.set(OAUTH_COOKIE, "", { ...cookieBase(), path: "/api/auth", maxAge: 0 });
}
