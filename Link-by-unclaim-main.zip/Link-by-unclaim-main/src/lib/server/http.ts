import "server-only";
import { NextResponse } from "next/server";
import type { ZodError } from "zod";
import { rateLimit } from "./rate-limit";
import { clientIp, isSameOrigin } from "./security";

// Petits utilitaires communs aux route handlers.

export function jsonError(status: number, error: string, details?: unknown) {
  return NextResponse.json({ error, ...(details ? { details } : {}) }, { status });
}

export function zodDetails(error: ZodError) {
  return error.issues.slice(0, 10).map((issue) => ({ path: issue.path.join("."), message: issue.message }));
}

/** Refuse les requêtes inter-sites sur les routes qui modifient des données. */
export function guardMutation(request: Request): NextResponse | null {
  if (!isSameOrigin(request)) return jsonError(403, "Requête refusée (origine inconnue).");
  return null;
}

export function guardRate(request: Request, scope: string, limit: number, windowMs = 60_000): NextResponse | null {
  const { ok, retryAfter } = rateLimit(`${scope}:${clientIp(request.headers)}`, limit, windowMs);
  if (ok) return null;
  return NextResponse.json(
    { error: "Trop de requêtes, réessaie dans un instant." },
    { status: 429, headers: { "Retry-After": String(retryAfter) } },
  );
}

export async function readJson(request: Request, maxBytes = 256_000): Promise<unknown> {
  const text = await request.text();
  if (text.length > maxBytes) throw new Error("payload_too_large");
  return JSON.parse(text);
}
