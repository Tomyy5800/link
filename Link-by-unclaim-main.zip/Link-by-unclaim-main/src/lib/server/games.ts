import "server-only";
import { GAMES, type GameId, type GameProfile } from "../games";
import { cachedStale } from "./cache";
import { env } from "./env";

// Profils publics des jeux « live » (API sans clé). Résultats mis en cache 15 min, avec repli
// sur la dernière valeur connue (24 h) si le service du jeu ne répond pas.

const FRESH_SECONDS = 15 * 60;
const STALE_SECONDS = 24 * 60 * 60;
const nf = new Intl.NumberFormat("fr-FR");

export class GameNotFound extends Error {}

async function getJson<T>(url: string, init: RequestInit = {}): Promise<T | null> {
  const res = await fetch(url, {
    ...init,
    headers: { Accept: "application/json", "User-Agent": `LinkByUnclaim/1.0 (+${env.appUrl})`, ...init.headers },
    signal: AbortSignal.timeout(5000),
    cache: "no-store",
  });
  if (res.status === 404 || res.status === 204) return null;
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return (await res.json()) as T;
}

const year = (date: string | number) => new Date(date).getFullYear();

async function minecraft(id: string): Promise<GameProfile | null> {
  const data = await getJson<{ id: string; name: string }>(`https://api.mojang.com/users/profiles/minecraft/${encodeURIComponent(id)}`);
  if (!data?.name) return null;
  return {
    name: data.name,
    avatar: `/api/skin/${encodeURIComponent(data.name)}?type=face&size=128`,
    url: GAMES.minecraft.profileUrl(data.name),
    subtitle: "Compte Minecraft Java",
    online: null,
    stats: [],
  };
}

type ChessStat = { last?: { rating?: number }; record?: { win?: number; loss?: number; draw?: number } };

async function chesscom(id: string): Promise<GameProfile | null> {
  const [player, stats] = await Promise.all([
    getJson<{ username: string; name?: string; title?: string; avatar?: string; url?: string; followers?: number; joined?: number }>(
      `https://api.chess.com/pub/player/${encodeURIComponent(id)}`,
    ),
    getJson<Record<string, ChessStat>>(`https://api.chess.com/pub/player/${encodeURIComponent(id)}/stats`).catch(() => null),
  ]);
  if (!player) return null;
  const rating = (key: string) => stats?.[key]?.last?.rating;
  const games = stats
    ? Object.values(stats).reduce((n, s) => n + (s?.record ? (s.record.win ?? 0) + (s.record.loss ?? 0) + (s.record.draw ?? 0) : 0), 0)
    : 0;
  return {
    name: player.name ? `${player.name} (${player.username})` : player.username,
    avatar: player.avatar ?? null,
    url: player.url ?? GAMES.chesscom.profileUrl(player.username),
    subtitle: [player.title, player.joined ? `membre depuis ${year(player.joined * 1000)}` : null].filter(Boolean).join(" · ") || null,
    online: null,
    stats: [
      ...(rating("chess_rapid") ? [{ label: "Rapide", value: String(rating("chess_rapid")) }] : []),
      ...(rating("chess_blitz") ? [{ label: "Blitz", value: String(rating("chess_blitz")) }] : []),
      ...(rating("chess_bullet") ? [{ label: "Bullet", value: String(rating("chess_bullet")) }] : []),
      ...(games ? [{ label: "Parties", value: nf.format(games) }] : []),
    ].slice(0, 4),
  };
}

async function lichess(id: string): Promise<GameProfile | null> {
  const data = await getJson<{
    username: string;
    title?: string;
    url?: string;
    createdAt?: number;
    disabled?: boolean;
    count?: { all?: number };
    perfs?: Record<string, { rating?: number; games?: number; prov?: boolean }>;
  }>(`https://lichess.org/api/user/${encodeURIComponent(id)}`);
  if (!data || data.disabled) return null;
  const perf = (key: string) => (data.perfs?.[key]?.games ? data.perfs[key].rating : undefined);
  return {
    name: data.username,
    avatar: null,
    url: data.url ?? GAMES.lichess.profileUrl(data.username),
    subtitle: [data.title, data.createdAt ? `membre depuis ${year(data.createdAt)}` : null].filter(Boolean).join(" · ") || null,
    online: null,
    stats: [
      ...(perf("rapid") ? [{ label: "Rapide", value: String(perf("rapid")) }] : []),
      ...(perf("blitz") ? [{ label: "Blitz", value: String(perf("blitz")) }] : []),
      ...(perf("bullet") ? [{ label: "Bullet", value: String(perf("bullet")) }] : []),
      ...(data.count?.all ? [{ label: "Parties", value: nf.format(data.count.all) }] : []),
    ].slice(0, 4),
  };
}

/** Valeur d'une balise du profil XML public de Steam (avec ou sans CDATA). */
function xmlTag(xml: string, tag: string): string | null {
  const match = xml.match(new RegExp(`<${tag}>(?:<!\\[CDATA\\[)?([\\s\\S]*?)(?:\\]\\]>)?</${tag}>`));
  return match ? match[1].trim() : null;
}

async function steam(id: string): Promise<GameProfile | null> {
  const [kind, value] = id.split(":") as ["id" | "p", string];
  const base = kind === "p" ? `https://steamcommunity.com/profiles/${value}` : `https://steamcommunity.com/id/${encodeURIComponent(value)}`;
  const res = await fetch(`${base}/?xml=1`, { signal: AbortSignal.timeout(5000), cache: "no-store", headers: { "User-Agent": `LinkByUnclaim/1.0 (+${env.appUrl})` } });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const xml = await res.text();
  if (/<error>/.test(xml)) return null;
  const name = xmlTag(xml, "steamID");
  const steamId64 = xmlTag(xml, "steamID64");
  if (!name || !steamId64) return null;
  const state = xmlTag(xml, "onlineState");
  const message = xmlTag(xml, "stateMessage")?.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
  const memberSince = xmlTag(xml, "memberSince");
  const privacy = xmlTag(xml, "privacyState");
  const visibility = privacy === "public" ? "Profil public" : privacy === "friendsonly" ? "Profil réservé aux amis" : "Profil privé";
  return {
    name,
    avatar: xmlTag(xml, "avatarMedium"),
    url: `https://steamcommunity.com/profiles/${steamId64}`,
    subtitle: state === "in-game" && message ? message : memberSince ? `Membre depuis ${memberSince}` : visibility,
    online: state === "online" || state === "in-game",
    stats: [],
  };
}

async function roblox(id: string): Promise<GameProfile | null> {
  const lookup = await getJson<{ data?: { id: number; name: string; displayName: string; hasVerifiedBadge?: boolean }[] }>(
    "https://users.roblox.com/v1/usernames/users",
    { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ usernames: [id], excludeBannedUsers: true }) },
  );
  const user = lookup?.data?.[0];
  if (!user) return null;
  const [details, thumb, friends] = await Promise.all([
    getJson<{ created?: string }>(`https://users.roblox.com/v1/users/${user.id}`).catch(() => null),
    getJson<{ data?: { imageUrl?: string; state?: string }[] }>(
      `https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${user.id}&size=150x150&format=Png`,
    ).catch(() => null),
    getJson<{ count?: number }>(`https://friends.roblox.com/v1/users/${user.id}/friends/count`).catch(() => null),
  ]);
  const image = thumb?.data?.[0];
  return {
    name: user.displayName && user.displayName !== user.name ? `${user.displayName} (@${user.name})` : user.name,
    avatar: image?.state === "Completed" && image.imageUrl ? image.imageUrl : null,
    url: `https://www.roblox.com/users/${user.id}/profile`,
    subtitle: [user.hasVerifiedBadge ? "Compte vérifié" : null, details?.created ? `membre depuis ${year(details.created)}` : null].filter(Boolean).join(" · ") || null,
    online: null,
    stats: typeof friends?.count === "number" ? [{ label: "Amis", value: nf.format(friends.count) }] : [],
  };
}

const LOADERS: Partial<Record<GameId, (id: string) => Promise<GameProfile | null>>> = { minecraft, chesscom, lichess, steam, roblox };

/** Profil public d'un joueur (null : joueur introuvable). Lève une erreur si le service est indisponible. */
export async function getGameProfile(game: GameId, id: string): Promise<GameProfile | null> {
  const load = LOADERS[game];
  if (!load) return null;
  const result = await cachedStale<{ found: boolean; profile: GameProfile | null }>(`game:${game}:${id.toLowerCase()}`, FRESH_SECONDS, STALE_SECONDS, async () => {
    const profile = await load(id);
    return { ok: true, value: { found: profile !== null, profile } };
  });
  if (!result) throw new Error("Service du jeu indisponible");
  return result.profile;
}
