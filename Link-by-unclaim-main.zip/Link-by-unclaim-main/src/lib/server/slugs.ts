import "server-only";
import { parsePageOptions } from "../page-schema";
import { prisma } from "./db";

// Adresses des pages : disponibilité, changement d'adresse et redirection des anciennes.
//
// Quand une page change d'adresse, l'ancienne est gardée 30 jours pour son propriétaire :
// personne d'autre ne peut la prendre pendant ce délai (pas d'usurpation d'un lien déjà partagé)
// et elle redirige vers la nouvelle tant que personne ne l'a reprise.

export const SLUG_HOLD_DAYS = 30;
/** Anciennes adresses gardées par page (les plus anciennes sont libérées). */
const MAX_REDIRECTS = 5;

export type SlugAvailability = { available: true } | { available: false; reason: "own" | "taken" | "held"; until?: Date };

/** L'adresse est-elle libre pour ce compte ? */
export async function slugAvailability(slug: string, userId: string | null, now = new Date()): Promise<SlugAvailability> {
  const [page, held] = await Promise.all([
    prisma.page.findUnique({ where: { slug }, select: { userId: true } }),
    prisma.slugRedirect.findUnique({ where: { slug }, select: { heldUntil: true, page: { select: { userId: true } } } }),
  ]);
  if (page) return { available: false, reason: page.userId === userId ? "own" : "taken" };
  if (held && held.heldUntil > now && held.page.userId !== userId) return { available: false, reason: "held", until: held.heldUntil };
  return { available: true };
}

export function availabilityError(result: SlugAvailability): string | null {
  if (result.available) return null;
  if (result.reason === "own") return "C'est déjà l'adresse d'une de tes pages.";
  if (result.reason === "held") {
    const date = result.until?.toLocaleDateString("fr-FR", { dateStyle: "long", timeZone: "Europe/Paris" });
    return `Cette adresse vient de changer de propriétaire ; elle se libère le ${date}.`;
  }
  return "Cette adresse est déjà prise.";
}

/**
 * Change l'adresse d'une page : l'ancienne devient une redirection réservée 30 jours. Renvoie
 * une erreur lisible, ou null si tout s'est bien passé.
 */
export async function changePageSlug(page: { id: string; slug: string; userId: string }, next: string, now = new Date()): Promise<string | null> {
  if (page.slug === next) return null;
  const check = await slugAvailability(next, page.userId, now);
  if (!check.available) return availabilityError(check);
  try {
    await prisma.$transaction(async (tx) => {
      // La nouvelle adresse était une redirection (de cette page, ou libérée) : elle n'en est plus une.
      await tx.slugRedirect.deleteMany({ where: { slug: next } });
      await tx.page.update({ where: { id: page.id }, data: { slug: next } });
      await tx.slugRedirect.upsert({
        where: { slug: page.slug },
        create: { slug: page.slug, pageId: page.id, heldUntil: new Date(now.getTime() + SLUG_HOLD_DAYS * 86_400_000) },
        update: { pageId: page.id, heldUntil: new Date(now.getTime() + SLUG_HOLD_DAYS * 86_400_000) },
      });
      const extra = await tx.slugRedirect.findMany({ where: { pageId: page.id }, orderBy: { createdAt: "desc" }, skip: MAX_REDIRECTS, select: { slug: true } });
      if (extra.length) await tx.slugRedirect.deleteMany({ where: { slug: { in: extra.map((r) => r.slug) } } });
    });
  } catch {
    return "Cette adresse est déjà prise.";
  }
  return null;
}

/** Une page est créée sur une adresse libérée : l'ancienne redirection disparaît. */
export async function releaseRedirect(slug: string): Promise<void> {
  await prisma.slugRedirect.deleteMany({ where: { slug } }).catch(() => undefined);
}

/** Nouvelle adresse d'une ancienne adresse, si la page l'autorise (null : pas de redirection). */
export async function resolveOldSlug(slug: string): Promise<string | null> {
  const row = await prisma.slugRedirect.findUnique({ where: { slug }, select: { page: { select: { slug: true, published: true, options: true } } } });
  if (!row || !row.page.published) return null;
  if (!parsePageOptions(row.page.options).redirectOldSlugs) return null;
  return row.page.slug;
}
