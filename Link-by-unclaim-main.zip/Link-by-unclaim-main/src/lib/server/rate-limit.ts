import "server-only";

// Limiteur de débit en mémoire (fenêtre glissante simple), suffisant pour une instance.
// Pour plusieurs instances, remplacer par un stockage partagé (Redis…).

type Bucket = { count: number; resetAt: number };

const globalStore = globalThis as unknown as { __lbuRateLimit?: Map<string, Bucket> };
const buckets = (globalStore.__lbuRateLimit ??= new Map<string, Bucket>());

export function rateLimit(key: string, limit: number, windowMs: number): { ok: boolean; retryAfter: number } {
  const now = Date.now();
  const bucket = buckets.get(key);
  if (!bucket || bucket.resetAt <= now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    if (buckets.size > 10_000) {
      for (const [k, b] of buckets) if (b.resetAt <= now) buckets.delete(k);
    }
    return { ok: true, retryAfter: 0 };
  }
  bucket.count += 1;
  if (bucket.count > limit) return { ok: false, retryAfter: Math.ceil((bucket.resetAt - now) / 1000) };
  return { ok: true, retryAfter: 0 };
}
