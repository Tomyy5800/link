import "server-only";
import { normalizeLanyard, offlinePresence, type DiscordPresence } from "../presence";
import { cached } from "./cache";

// Statut Discord en direct via Lanyard, mis en cache 20 secondes (bloc « Statut Discord » et
// automatisations « pendant mes lives »).
export async function getPresence(discordId: string): Promise<DiscordPresence> {
  return cached<DiscordPresence>(`presence:${discordId}`, async () => {
    try {
      const res = await fetch(`https://api.lanyard.rest/v1/users/${discordId}`, {
        headers: { Accept: "application/json" },
        cache: "no-store",
        signal: AbortSignal.timeout(4000),
      });
      return { value: normalizeLanyard(await res.json()), ttlSeconds: 20 };
    } catch {
      return { value: { ...offlinePresence(true), unavailable: true }, ttlSeconds: 10 };
    }
  });
}
