import "server-only";
import { promises as dnsPromises } from "node:dns";
import type { CustomDomain } from "@prisma/client";
import { TXT_PREFIX, isApexDomain, normalizeHostname, parseDomainCheck, type DomainCheck, type DomainStatus } from "../domains";
import { prisma } from "./db";
import { env } from "./env";
import { randomToken, sha256 } from "./security";

// Domaines personnels (Pro, Équipe) : vérification de propriété et de configuration.
//
// Un domaine n'affiche la page qu'après trois contrôles faits par le serveur :
//   1. propriété : l'enregistrement TXT _link-unclaim.<domaine> contient le jeton du domaine ;
//   2. routage : le domaine pointe vers Link by Unclaim (CNAME vers CUSTOM_DOMAIN_CNAME, ou A
//      vers CUSTOM_DOMAIN_IPV4) ;
//   3. HTTPS : une requête https://<domaine>/api/domains/probe arrive bien sur cette application.
// Le certificat TLS est émis par le proxy inverse (Caddy en émission à la demande), qui demande
// /api/domains/tls-check avant chaque émission : seuls les domaines dont la propriété est prouvée
// sont acceptés. Étapes externes : docs/CONFIGURATION.md.

export type Resolver = Pick<typeof dnsPromises, "resolveTxt" | "resolveCname" | "resolve4">;

/** Domaine réservé à l'application elle-même (et ses sous-domaines). */
export function isOwnHost(host: string): boolean {
  let app = "";
  try {
    app = new URL(env.appUrl).hostname.toLowerCase();
  } catch {
    return false;
  }
  const bare = app.replace(/^www\./, "");
  return host === app || host === bare || host.endsWith(`.${bare}`) || (env.customDomains.cnameTarget !== "" && host === env.customDomains.cnameTarget);
}

export type HostnameCheck = { ok: true; hostname: string } | { ok: false; error: string };

export function validateHostname(input: string): HostnameCheck {
  const hostname = normalizeHostname(input);
  if (!hostname) return { ok: false, error: "Nom de domaine invalide (exemple : mondomaine.fr ou www.mondomaine.fr)." };
  if (isOwnHost(hostname)) return { ok: false, error: "Ce domaine appartient à Link by Unclaim." };
  return { ok: true, hostname };
}

export function newDomainToken(): string {
  return `lbu-${randomToken(18)}`;
}

/** Valeur que /api/domains/probe renvoie pour un hôte : prouve que la requête est arrivée ici. */
export function probeSignature(host: string): string {
  return sha256(`lbu-domain-probe|${env.sessionSecret}|${host}`).slice(0, 24);
}

export type DnsInstructions = {
  txt: { type: "TXT"; name: string; value: string };
  routing: { type: "CNAME" | "A"; name: string; values: string[] }[];
  apex: boolean;
  /** La cible DNS n'est pas encore configurée par l'administration. */
  targetMissing: boolean;
};

/** Enregistrements à créer chez le fournisseur DNS du domaine. */
export function dnsInstructions(domain: Pick<CustomDomain, "hostname" | "token">): DnsInstructions {
  const apex = isApexDomain(domain.hostname);
  const routing: DnsInstructions["routing"] = [];
  if (!apex && env.customDomains.cnameTarget) routing.push({ type: "CNAME", name: domain.hostname, values: [env.customDomains.cnameTarget] });
  if (env.customDomains.ipv4.length) routing.push({ type: "A", name: domain.hostname, values: env.customDomains.ipv4 });
  return {
    txt: { type: "TXT", name: `${TXT_PREFIX}.${domain.hostname}`, value: domain.token },
    routing,
    apex,
    targetMissing: !env.customDomains.configured,
  };
}

async function safe<T>(promise: Promise<T>): Promise<T | null> {
  return promise.catch(() => null);
}

/** Contrôle complet d'un domaine (DNS puis HTTPS). N'écrit rien : voir recheckDomain. */
export async function checkDomain(domain: Pick<CustomDomain, "hostname" | "token">, deps: { resolver?: Resolver; fetcher?: typeof fetch } = {}): Promise<DomainCheck> {
  const resolver = deps.resolver ?? dnsPromises;
  const fetcher = deps.fetcher ?? fetch;
  const host = domain.hostname;

  const txt = await safe(resolver.resolveTxt(`${TXT_PREFIX}.${host}`));
  const found = (txt ?? []).map((parts) => parts.join("")).some((v) => v.trim() === domain.token);
  const ownership = found
    ? { ok: true, message: "Propriété confirmée (enregistrement TXT trouvé)." }
    : { ok: false, message: txt ? "L'enregistrement TXT existe mais ne contient pas le bon jeton." : `Aucun enregistrement TXT ${TXT_PREFIX}.${host} trouvé (la propagation DNS peut prendre jusqu'à quelques heures).` };

  let routing: DomainCheck["routing"];
  if (!env.customDomains.configured) {
    routing = { ok: false, message: "La cible DNS de Link by Unclaim n'est pas encore configurée par l'administration." };
  } else {
    const [cname, a] = await Promise.all([safe(resolver.resolveCname(host)), safe(resolver.resolve4(host))]);
    const target = env.customDomains.cnameTarget;
    const cnameOk = Boolean(target && (cname ?? []).some((c) => c.toLowerCase().replace(/\.$/, "") === target));
    const aOk = Boolean(a && a.length && env.customDomains.ipv4.length && a.every((ip) => env.customDomains.ipv4.includes(ip)));
    routing = cnameOk || aOk
      ? { ok: true, message: cnameOk ? `Le domaine pointe vers ${target} (CNAME).` : "Le domaine pointe vers le serveur (enregistrement A)." }
      : { ok: false, message: a?.length ? `Le domaine pointe ailleurs (${a.slice(0, 3).join(", ")}).` : "Le domaine ne pointe pas encore vers Link by Unclaim." };
  }

  let https: DomainCheck["https"] = { ok: false, message: "Contrôle HTTPS en attente des étapes précédentes." };
  if (ownership.ok && routing.ok) {
    const res = await safe(fetcher(`https://${host}/api/domains/probe`, { cache: "no-store", redirect: "manual", signal: AbortSignal.timeout(8000) }));
    const body = res?.ok ? ((await res.json().catch(() => null)) as { signature?: string } | null) : null;
    https =
      body?.signature === probeSignature(host)
        ? { ok: true, message: "HTTPS actif : la page répond avec un certificat valide." }
        : res
          ? { ok: false, message: `Le domaine répond (code ${res.status}) mais pas encore par Link by Unclaim : vérifie le proxy.` }
          : { ok: false, message: "HTTPS pas encore disponible : le certificat est en cours d'émission, réessaie dans quelques minutes." };
  }

  return { ownership, routing, https, checkedAt: new Date().toISOString() };
}

export function statusFrom(check: DomainCheck): DomainStatus {
  if (check.ownership.ok && check.routing.ok && check.https.ok) return "active";
  return check.ownership.ok || check.routing.ok ? "pending" : "error";
}

/** Contrôle et enregistre le résultat. La propriété prouvée une fois reste acquise tant que le TXT existe. */
export async function recheckDomain(domain: CustomDomain, deps?: Parameters<typeof checkDomain>[1]): Promise<CustomDomain> {
  const check = await checkDomain(domain, deps);
  const status = statusFrom(check);
  return prisma.customDomain.update({
    where: { id: domain.id },
    data: {
      status,
      lastCheck: JSON.stringify(check),
      lastCheckAt: new Date(),
      verifiedAt: check.ownership.ok ? (domain.verifiedAt ?? new Date()) : null,
    },
  });
}

/** Domaine tel que montré à son propriétaire (jeton et enregistrements DNS compris). */
export function domainView(domain: CustomDomain) {
  return {
    id: domain.id,
    hostname: domain.hostname,
    status: domain.status as DomainStatus,
    verifiedAt: domain.verifiedAt?.toISOString() ?? null,
    lastCheckAt: domain.lastCheckAt?.toISOString() ?? null,
    check: parseDomainCheck(domain.lastCheck),
    dns: dnsInstructions(domain),
  };
}
export type DomainView = ReturnType<typeof domainView>;

/** Domaine actif servi pour un nom d'hôte (null : inconnu ou pas encore validé). */
export async function activeDomain(host: string) {
  const hostname = normalizeHostname(host);
  if (!hostname) return null;
  return prisma.customDomain.findFirst({
    where: { hostname, status: "active" },
    include: { page: { select: { slug: true, published: true, status: true } } },
  });
}

/** Le proxy peut-il demander un certificat pour cet hôte ? (propriété prouvée) */
export async function tlsAllowed(host: string): Promise<boolean> {
  const hostname = normalizeHostname(host);
  if (!hostname) return false;
  return Boolean(await prisma.customDomain.findFirst({ where: { hostname, verifiedAt: { not: null } }, select: { id: true } }));
}

/** Contrôle quotidien des domaines actifs (un TXT ou un CNAME supprimé désactive le domaine). */
export async function recheckStaleDomains(limit = 10): Promise<number> {
  const stale = await prisma.customDomain.findMany({
    where: { OR: [{ lastCheckAt: null }, { lastCheckAt: { lt: new Date(Date.now() - 24 * 3_600_000) } }], status: { in: ["active", "pending"] } },
    orderBy: { lastCheckAt: "asc" },
    take: limit,
  });
  for (const domain of stale) await recheckDomain(domain).catch(() => undefined);
  return stale.length;
}
