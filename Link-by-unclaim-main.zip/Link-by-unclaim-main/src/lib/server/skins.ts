import "server-only";
import { isValidMcUsername } from "../urls";
import { env } from "./env";

// Proxy des images du serveur de skins NationsGlory.
// Le visualiseur 3D (WebGL) a besoin d'une texture servie proprement : on la relaie
// depuis notre domaine, avec validation et un petit cache mémoire.
//
// Routes connues de skins.nationsglory.fr :
//   /skin?username=<pseudo>     texture brute 64×64 (skin par défaut si inconnu)
//   /face/<pseudo>/<taille>     rendu 2D de la tête
//   /body/<pseudo>/<taille>     rendu 2D du corps
// Aucune route de cape n'existe : le serveur renvoie le skin pour toute requête ?username=.

export type SkinAsset = "skin" | "face" | "body";

type Entry = { body: Uint8Array; expiresAt: number };
const store = globalThis as unknown as { __lbuSkins?: Map<string, Entry> };
const memory = (store.__lbuSkins ??= new Map<string, Entry>());
const TTL_MS = 30 * 60 * 1000;
const MAX_ENTRIES = 300;
const MAX_BYTES = 1_000_000;

const PNG_MAGIC = [0x89, 0x50, 0x4e, 0x47];

function sourceUrl(asset: SkinAsset, username: string, size: number): string {
  const root = env.nationsglory.skinsUrl;
  const u = encodeURIComponent(username);
  switch (asset) {
    case "skin":
      return `${root}/skin?username=${u}`;
    case "face":
      return `${root}/face/${u}/${size}`;
    case "body":
      return `${root}/body/${u}/${size}`;
  }
}

export async function getSkinAsset(asset: SkinAsset, username: string, size = 128): Promise<Uint8Array | null> {
  if (!isValidMcUsername(username)) return null;
  const key = `${asset}:${username.toLowerCase()}:${size}`;
  const hit = memory.get(key);
  if (hit && hit.expiresAt > Date.now()) return hit.body;

  try {
    const res = await fetch(sourceUrl(asset, username, size), {
      headers: { Accept: "image/png" },
      cache: "no-store",
      signal: AbortSignal.timeout(6000),
    });
    if (!res.ok) return null;
    const buffer = new Uint8Array(await res.arrayBuffer());
    if (buffer.byteLength > MAX_BYTES || !PNG_MAGIC.every((b, i) => buffer[i] === b)) return null;

    if (memory.size >= MAX_ENTRIES) {
      const oldest = memory.keys().next().value;
      if (oldest) memory.delete(oldest);
    }
    memory.set(key, { body: buffer, expiresAt: Date.now() + TTL_MS });
    return buffer;
  } catch {
    return null;
  }
}
