import "server-only";
import { blockSummary, parseStoredBlock } from "../blocks";
import { parseNotifications, type StoredNotifications } from "../notifications";
import { formatMoney, type OrderItem } from "../shop";
import { prisma } from "./db";
import { entitlementsFrom } from "./entitlements";
import { env } from "./env";
import { clicksByBlock, viewsByDay } from "./pages";
import { getSettings } from "./settings";

// Envoi des notifications Discord d'une page (fonction « Notifications Discord » de l'offre du
// propriétaire). Les mentions sont toujours désactivées : un message de visiteur contenant
// « @everyone » ne notifie personne.

const nf = new Intl.NumberFormat("fr-FR");
const BRAND_COLOR = 0x22c9e8;

type Embed = {
  title: string;
  description?: string;
  url?: string;
  color?: number;
  fields?: { name: string; value: string; inline?: boolean }[];
  footer?: { text: string };
  timestamp?: string;
};

/** Poste un message sur un webhook Discord. Renvoie false en cas d'échec (sans lever d'erreur). */
export async function postDiscordWebhook(url: string, embed: Embed): Promise<boolean> {
  try {
    const res = await fetch(`${url}?wait=false`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: "Link by Unclaim",
        allowed_mentions: { parse: [] },
        embeds: [{ color: BRAND_COLOR, ...embed, footer: embed.footer ?? { text: "Link by Unclaim" } }],
      }),
      signal: AbortSignal.timeout(5000),
      cache: "no-store",
    });
    return res.ok;
  } catch {
    return false;
  }
}

const clip = (text: string, max: number) => (text.length > max ? `${text.slice(0, max - 1)}…` : text);

/** Réglages et droits d'une page : null si les notifications ne sont pas actives. */
async function activeNotifications(pageId: string) {
  const page = await prisma.page.findUnique({
    where: { id: pageId },
    select: { id: true, slug: true, displayName: true, notifications: true, user: true },
  });
  if (!page) return null;
  const notifications = parseNotifications(page.notifications);
  if (!notifications.discordWebhook) return null;
  if (!entitlementsFrom(page.user, await getSettings()).features.webhooks) return null;
  return { page, notifications };
}

/** Nouveau message reçu par le formulaire de contact. */
export async function notifyNewMessage(pageId: string, message: { name: string; contact: string; message: string }): Promise<void> {
  const active = await activeNotifications(pageId);
  if (!active || !active.notifications.onMessage) return;
  const { page, notifications } = active;
  await postDiscordWebhook(notifications.discordWebhook, {
    title: `✉️ Nouveau message sur ${clip(page.displayName, 60)}`,
    description: clip(message.message, 1500),
    url: `${env.appUrl}/dashboard/messages?page=${page.id}`,
    fields: [
      { name: "De", value: clip(message.name, 60), inline: true },
      ...(message.contact ? [{ name: "Pour répondre", value: clip(message.contact, 120), inline: true }] : []),
    ],
    timestamp: new Date().toISOString(),
  });
}

/** Nouvelle demande de commande reçue par le bloc « Boutique ». */
export async function notifyNewOrder(
  pageId: string,
  order: { name: string; contact: string; note: string; items: OrderItem[]; total: number | null; currency: string },
): Promise<void> {
  const active = await activeNotifications(pageId);
  if (!active || !active.notifications.onOrder) return;
  const { page, notifications } = active;
  const lines = order.items.map(
    (i) => `• ${i.quantity} × ${clip(i.name, 60)}${i.option ? ` (${clip(i.option, 32)})` : ""}${i.price !== null ? ` — ${formatMoney(i.price * i.quantity, order.currency)}` : ""}`,
  );
  await postDiscordWebhook(notifications.discordWebhook, {
    title: `🛍️ Nouvelle commande sur ${clip(page.displayName, 60)}`,
    description: clip([...lines, ...(order.note ? ["", `> ${order.note}`] : [])].join("\n"), 1500),
    url: `${env.appUrl}/dashboard/commandes?page=${page.id}`,
    fields: [
      { name: "De", value: clip(order.name, 60), inline: true },
      { name: "Pour répondre", value: clip(order.contact, 120), inline: true },
      { name: "Total", value: order.total !== null ? formatMoney(order.total, order.currency) : "Prix à convenir", inline: true },
    ],
    timestamp: new Date().toISOString(),
  });
}

async function weeklyEmbed(page: { id: string; slug: string; displayName: string }): Promise<Embed> {
  const [days, clicks, messages, blocks] = await Promise.all([
    viewsByDay(page.id, 7),
    clicksByBlock(page.id, 7),
    prisma.contactMessage.count({ where: { pageId: page.id, createdAt: { gte: new Date(Date.now() - 7 * 86_400_000) } } }),
    prisma.block.findMany({ where: { pageId: page.id } }),
  ]);
  const views = days.reduce((n, d) => n + d.count, 0);
  const totalClicks = clicks.reduce((n, c) => n + c.count, 0);
  const best = days.reduce((a, b) => (b.count > a.count ? b : a), days[0]);
  const top = clicks[0] ? blocks.find((b) => b.id === clicks[0].blockId) : null;
  const topBlock = top ? parseStoredBlock(top) : null;
  return {
    title: `📊 Ta semaine sur /${page.slug}`,
    url: `${env.appUrl}/${page.slug}`,
    fields: [
      { name: "Vues uniques", value: nf.format(views), inline: true },
      { name: "Clics", value: nf.format(totalClicks), inline: true },
      { name: "Messages", value: nf.format(messages), inline: true },
      ...(best && best.count > 0
        ? [{ name: "Meilleur jour", value: `${new Date(`${best.day}T12:00:00Z`).toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })} (${nf.format(best.count)})` }]
        : []),
      ...(topBlock ? [{ name: "Lien le plus cliqué", value: `${clip(blockSummary(topBlock), 80)} (${nf.format(clicks[0].count)})` }] : []),
    ],
    timestamp: new Date().toISOString(),
  };
}

/**
 * Bilan de la semaine, envoyé au plus une fois tous les 7 jours. Déclenché à l'occasion d'une
 * visite (pas de tâche planifiée nécessaire) ; la date d'envoi est réservée avant l'envoi pour
 * éviter les doublons quand plusieurs visites arrivent en même temps.
 */
export async function maybeWeeklyDigest(pageId: string): Promise<void> {
  const active = await activeNotifications(pageId);
  if (!active || !active.notifications.weekly) return;
  const { page, notifications } = active;
  const last = notifications.lastDigestAt ? Date.parse(notifications.lastDigestAt) : 0;
  if (Date.now() - last < 7 * 86_400_000) return;

  const stored: StoredNotifications = { ...notifications, lastDigestAt: new Date().toISOString() };
  const claimed = await prisma.page.updateMany({ where: { id: page.id, notifications: page.notifications }, data: { notifications: JSON.stringify(stored) } });
  if (claimed.count === 0) return; // une autre visite s'en occupe
  // Première activation : on attend une semaine complète avant le premier bilan.
  if (!last) return;
  await postDiscordWebhook(notifications.discordWebhook, await weeklyEmbed(page));
}

/** Message de test, envoyé depuis l'éditeur. */
export async function sendTestNotification(webhook: string, page: { slug: string; displayName: string }): Promise<boolean> {
  return postDiscordWebhook(webhook, {
    title: "✅ Notifications reliées",
    description: `Ce salon recevra les nouveaux messages de contact et le bilan de la semaine de **${clip(page.displayName, 60)}** (${env.appUrl}/${page.slug}).`,
    timestamp: new Date().toISOString(),
  });
}
