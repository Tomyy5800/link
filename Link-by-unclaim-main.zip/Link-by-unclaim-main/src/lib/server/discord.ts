import "server-only";
import { discordGuildIconUrl, type DiscordInvite } from "../discord-cdn";
import { parseDiscordInvite } from "../urls";
import { cached } from "./cache";

const DISCORD_API = "https://discord.com/api/v10";

type RawInvite = {
  code: string;
  guild?: { id: string; name: string; icon: string | null; description?: string | null };
  approximate_member_count?: number;
  approximate_presence_count?: number;
};

/** Informations publiques d'une invitation Discord (nom, icône, membres), mises en cache 10 min. */
export async function getDiscordInvite(input: string): Promise<DiscordInvite> {
  const code = parseDiscordInvite(input);
  if (!code) return { code: input.slice(0, 32), status: "invalid" };

  return cached<DiscordInvite>(`discord:invite:${code}`, async () => {
    try {
      const res = await fetch(`${DISCORD_API}/invites/${encodeURIComponent(code)}?with_counts=true`, {
        headers: { Accept: "application/json" },
        cache: "no-store",
        signal: AbortSignal.timeout(5000),
      });
      if (res.status === 404) return { value: { code, status: "invalid" }, ttlSeconds: 600 };
      if (!res.ok) return { value: { code, status: "unavailable" }, ttlSeconds: 60 };
      const raw = (await res.json()) as RawInvite;
      if (!raw.guild) return { value: { code, status: "invalid" }, ttlSeconds: 600 };
      return {
        value: {
          code,
          status: "ok",
          guild: {
            id: raw.guild.id,
            name: raw.guild.name,
            iconUrl: discordGuildIconUrl(raw.guild.id, raw.guild.icon),
            description: raw.guild.description ?? null,
          },
          memberCount: raw.approximate_member_count,
          onlineCount: raw.approximate_presence_count,
        },
        ttlSeconds: 600,
      };
    } catch {
      return { value: { code, status: "unavailable" }, ttlSeconds: 30 };
    }
  });
}
