import "server-only";
import path from "node:path";
import { PrismaClient } from "@prisma/client";

/**
 * Prisma résout un chemin SQLite relatif (« file:./dev.db ») depuis l'emplacement du client
 * généré, qui varie selon l'environnement d'exécution. On l'ancre sur le dossier prisma/,
 * comme le fait la CLI, pour que l'application et les migrations utilisent le même fichier.
 */
export function resolveDatabaseUrl(url = process.env.DATABASE_URL): string | undefined {
  if (url && /^file:\.\.?\//.test(url)) return `file:${path.resolve(process.cwd(), "prisma", url.slice(5))}`;
  return url;
}

// Une seule instance de Prisma, conservée entre les rechargements à chaud en développement.
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    datasourceUrl: resolveDatabaseUrl(),
    log: process.env.NODE_ENV === "development" ? ["warn", "error"] : ["error"],
  });

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
