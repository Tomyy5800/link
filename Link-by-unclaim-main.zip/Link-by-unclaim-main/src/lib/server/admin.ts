import "server-only";
import type { User } from "@prisma/client";
import { redirect } from "next/navigation";
import type { NextResponse } from "next/server";
import { prisma } from "./db";
import { isAdmin } from "./entitlements";
import { guardMutation, guardRate, jsonError } from "./http";
import { getCurrentUser } from "./unclaim-auth";

// Accès à l'administration : rôle « admin » en base, ou ID Discord listé dans ADMIN_DISCORD_IDS.

/** Pages /admin : redirige les visiteurs non autorisés. */
export async function requireAdminPage(): Promise<User> {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/admin");
  if (!isAdmin(user)) redirect("/dashboard");
  return user;
}

/** Routes /api/admin : renvoie l'administrateur, ou la réponse d'erreur à retourner telle quelle. */
export async function requireAdminApi(request: Request, opts: { mutation?: boolean } = { mutation: true }): Promise<User | NextResponse> {
  if (opts.mutation !== false) {
    const blocked = guardMutation(request) ?? guardRate(request, "admin", 120);
    if (blocked) return blocked;
  }
  const user = await getCurrentUser();
  if (!user) return jsonError(401, "Connexion requise.");
  if (!isAdmin(user)) return jsonError(403, "Réservé aux administrateurs.");
  return user;
}

export function isResponse(value: unknown): value is NextResponse {
  return value instanceof Response;
}

/** Trace une action d'administration (qui, quoi, sur quoi). */
export async function audit(actorId: string, action: string, targetType: string, targetId: string, details: Record<string, unknown> = {}) {
  await prisma.auditLog
    .create({ data: { actorId, action, targetType, targetId, details: JSON.stringify(details).slice(0, 4000) } })
    .catch((error) => console.error("[admin] journal indisponible", error));
}

export const ACTION_LABELS: Record<string, string> = {
  "user.plan": "Offre modifiée",
  "user.verify": "Badge vérifié",
  "user.partner": "Statut partenaire",
  "partner.accept": "Candidature partenaire acceptée",
  "partner.refuse": "Candidature partenaire refusée",
  "user.role": "Rôle modifié",
  "user.suspend": "Compte suspendu",
  "user.unsuspend": "Suspension levée",
  "page.suspend": "Page suspendue",
  "page.restore": "Page rétablie",
  "page.feature": "Mise en avant",
  "page.delete": "Page supprimée",
  "report.resolve": "Signalement traité",
  "report.dismiss": "Signalement classé",
  "settings.update": "Réglages modifiés",
  "codes.create": "Codes créés",
  "code.disable": "Code désactivé",
  "code.enable": "Code réactivé",
  "code.redeem": "Code échangé",
  "cache.clear": "Cache vidé",
  "order.paid": "Paiement reçu",
  "order.refund": "Paiement remboursé",
  "settings.critical": "Réglage sensible modifié",
  "staff.permissions": "Permissions du staff modifiées",
  "badge.create": "Badge créé",
  "badge.update": "Badge modifié",
  "badge.validate": "Badge validé officiellement",
  "badge.unvalidate": "Sceau officiel retiré",
  "badge.archive": "Badge archivé",
  "badge.restore": "Badge restauré",
  "badge.delete": "Badge supprimé",
  "badge.grant": "Badge attribué",
  "badge.revoke": "Badge retiré",
  "badge.auto": "Badge attribué automatiquement",
  "badge.expire": "Badge arrivé à échéance",
  "badge.backfill": "Places « premiers comptes » distribuées",
  "discord.config": "Synchronisation Discord configurée",
  "discord.sync": "Synchronisation Discord lancée",
  "discord.link": "Rôle Discord associé",
  "discord.link.update": "Association Discord modifiée",
  "discord.unlink": "Rôle Discord dissocié",
  "shop.create": "Article de la boutique créé",
  "shop.update": "Article de la boutique modifié",
  "shop.disable": "Article retiré de la vente",
  "shop.delete": "Article supprimé",
  "subscription.cancel": "Abonnement résilié",
  "subscription.resume": "Abonnement repris",
  "domain.add": "Domaine ajouté",
  "domain.replace": "Domaine remplacé",
  "domain.remove": "Domaine supprimé",
  "role.create": "Rôle personnalisé créé",
  "role.update": "Rôle personnalisé modifié",
  "role.delete": "Rôle personnalisé supprimé",
  "role.assign": "Rôle personnalisé attribué",
};
