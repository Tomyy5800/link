import "server-only";
import type { User } from "@prisma/client";
import { toOwnerProfile } from "../discord-cdn";
import { prisma } from "./db";
import { sha256 } from "./security";

// Invitations à collaborer sur une page : lien à usage unique, valable 7 jours.

export type InviteInfo = {
  pageId: string;
  slug: string;
  pageName: string;
  ownerName: string;
  ownerAvatar: string;
  role: "editor" | "viewer";
  expiresAt: Date;
};

async function findInvite(token: string) {
  if (!/^[A-Za-z0-9_-]{20,64}$/.test(token)) return null;
  const invite = await prisma.pageInvite.findUnique({
    where: { tokenHash: sha256(token) },
    include: { page: { select: { id: true, slug: true, label: true, displayName: true, userId: true, user: true } } },
  });
  if (!invite || invite.usedAt || invite.expiresAt < new Date()) return null;
  return invite;
}

/** Invitation encore valable, décrite pour la page d'acceptation. */
export async function describeInvite(token: string): Promise<InviteInfo | null> {
  const invite = await findInvite(token);
  if (!invite) return null;
  const owner = toOwnerProfile(invite.page.user);
  return {
    pageId: invite.page.id,
    slug: invite.page.slug,
    pageName: invite.page.label || invite.page.displayName,
    ownerName: owner.globalName ?? owner.username,
    ownerAvatar: owner.avatarUrl,
    role: invite.role === "viewer" ? "viewer" : "editor",
    expiresAt: invite.expiresAt,
  };
}

export class InviteError extends Error {}

/** Rejoint la page de l'invitation ; renvoie l'identifiant de la page. */
export async function acceptInvite(user: User, token: string): Promise<string> {
  const invite = await findInvite(token);
  if (!invite) throw new InviteError("Cette invitation n'est plus valable : demande un nouveau lien.");
  if (invite.page.userId === user.id) throw new InviteError("C'est ta propre page : tu en es déjà propriétaire.");
  const already = await prisma.pageMember.findUnique({ where: { pageId_userId: { pageId: invite.pageId, userId: user.id } } });
  await prisma.$transaction([
    ...(already ? [] : [prisma.pageMember.create({ data: { pageId: invite.pageId, userId: user.id, role: invite.role } })]),
    prisma.pageInvite.update({ where: { id: invite.id }, data: { usedAt: new Date(), usedById: user.id } }),
  ]);
  return invite.pageId;
}
