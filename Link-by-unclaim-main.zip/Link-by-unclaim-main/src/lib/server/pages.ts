import "server-only";
import type { Block as BlockRow, Page, User } from "@prisma/client";
import { createBlock, parseStoredBlock, type Block } from "../blocks";
import { sanitizeCss } from "../css";
import { toOwnerProfile } from "../discord-cdn";
import { parsePageOptions, type OwnerProfile, type PageSaveInput, type PageView } from "../page-schema";
import { normalizeSlug } from "../slug";
import { getTemplate } from "../templates";
import { getPreset, parseTheme, type Theme } from "../theme";
import { prisma } from "./db";
import { deleteUploads } from "./storage";

// Accès aux pages : lecture (publique / éditeur), création, sauvegarde et statistiques.

/** Durée de conservation des visites détaillées (statistiques avancées comprises). */
export const VIEW_RETENTION_DAYS = 120;

type PageWithBlocks = Page & { blocks: BlockRow[] };

export function toPageView(page: PageWithBlocks): PageView {
  const blocks = [...page.blocks]
    .sort((a, b) => a.position - b.position)
    .map(parseStoredBlock)
    .filter((b): b is Block => b !== null);
  return {
    slug: page.slug,
    published: page.published,
    views: page.views,
    theme: parseTheme(page.theme),
    customCss: page.customCss,
    options: parsePageOptions(page.options),
    blocks,
    profile: {
      displayName: page.displayName,
      pronouns: page.pronouns,
      bio: page.bio,
      avatarSource: page.avatarSource === "custom" || page.avatarSource === "nationsglory" ? page.avatarSource : "discord",
      avatarUrl: page.avatarUrl,
      bannerUrl: page.bannerUrl,
      ngUsername: page.ngUsername,
      ngServer: /^[a-z0-9-]{2,24}$/.test(page.ngServer) ? page.ngServer : "blue",
    },
  };
}

export async function getPageBySlug(slug: string): Promise<{
  page: PageView;
  pageId: string;
  status: string;
  statusReason: string;
  owner: OwnerProfile;
  user: User;
} | null> {
  const row = await prisma.page.findUnique({
    where: { slug: normalizeSlug(slug) },
    include: { blocks: true, user: true },
  });
  if (!row) return null;
  return {
    page: toPageView(row),
    pageId: row.id,
    status: row.status,
    statusReason: row.statusReason,
    owner: toOwnerProfile(row.user),
    user: row.user,
  };
}

/** Page complète pour l'éditeur (l'accès est vérifié par l'appelant). */
export async function getEditorPage(pageId: string): Promise<PageView | null> {
  const row = await prisma.page.findUnique({ where: { id: pageId }, include: { blocks: true } });
  return row ? toPageView(row) : null;
}

/** Contenu de départ d'une nouvelle page, pour ne pas commencer devant une page blanche. */
export function starterBlocks(ngUsername: string, hasDiscord = true): Block[] {
  const blocks: Block[] = [...(hasDiscord ? [createBlock("discord", {})] : []), createBlock("socials", { items: [] })];
  if (ngUsername) {
    blocks.push(createBlock("nationsglory", {}), createBlock("skin", { animation: "idle" }));
  }
  blocks.push(createBlock("link", { label: "Mon serveur Discord", url: "", description: "Rejoins la communauté" }));
  return blocks;
}

function blockRow(block: Block, position: number) {
  return {
    id: block.id,
    type: block.type,
    position,
    width: block.width,
    colSpan: block.colSpan,
    rowSpan: block.rowSpan,
    style: JSON.stringify(block.style),
    visible: block.visible,
    startsAt: block.startsAt ? new Date(block.startsAt) : null,
    endsAt: block.endsAt ? new Date(block.endsAt) : null,
    data: JSON.stringify(block.data),
  };
}

export async function createPage(input: {
  user: User;
  slug: string;
  displayName: string;
  /** Nom interne dans « Mon espace ». */
  label?: string;
  ngUsername: string;
  ngServer: string;
  preset: string;
  /** Modèle de page (blocs de départ et mise en page) ; vide : blocs de départ simples. */
  template?: string;
  /** Contenu déjà composé (assistant de création) : remplace modèle et blocs de départ. */
  content?: { bio: string; pronouns: string; theme: Theme; blocks: Block[] };
}): Promise<{ id: string; page: PageView }> {
  const template = input.template ? getTemplate(input.template) : undefined;
  const base: Theme = getPreset(input.preset)?.theme ?? parseTheme({});
  const theme: Theme = input.content?.theme ?? (template && template.layout !== "stack" ? { ...base, layout: template.layout, width: "wide" } : base);
  const ctx = { ngUsername: input.ngUsername, hasDiscord: Boolean(input.user.discordId) };
  const blocks = input.content?.blocks ?? (template ? template.blocks(ctx) : starterBlocks(input.ngUsername, ctx.hasDiscord));
  const row = await prisma.page.create({
    data: {
      slug: input.slug,
      userId: input.user.id,
      displayName: input.displayName,
      bio: input.content?.bio ?? "",
      pronouns: input.content?.pronouns ?? "",
      label: input.label ?? "",
      ngUsername: input.ngUsername,
      ngServer: input.ngServer,
      avatarSource: "discord",
      theme: JSON.stringify(theme),
      blocks: { create: blocks.map(blockRow) },
    },
    include: { blocks: true },
  });
  return { id: row.id, page: toPageView(row) };
}

export class SaveError extends Error {
  constructor(
    message: string,
    readonly status = 400,
  ) {
    super(message);
  }
}

/** Sauvegarde complète depuis l'éditeur : profil, thème, CSS et liste ordonnée des blocs. */
export async function savePage(
  pageId: string,
  input: PageSaveInput,
  limits: { blocks: number },
  editorId: string,
): Promise<{ updatedAt: Date }> {
  const page = await prisma.page.findUnique({ where: { id: pageId }, select: { id: true, userId: true } });
  if (!page) throw new SaveError("Page introuvable.", 404);
  if (input.blocks.length > limits.blocks) {
    throw new SaveError(`Ton offre permet ${limits.blocks} blocs au maximum.`, 403);
  }
  const css = sanitizeCss(input.customCss);
  if (!css.ok) throw new SaveError(`CSS personnalisé : ${css.error}`);

  const [, , updated] = await prisma.$transaction([
    prisma.block.deleteMany({ where: { pageId: page.id } }),
    prisma.block.createMany({ data: input.blocks.map((block, position) => ({ ...blockRow(block, position), pageId: page.id })) }),
    prisma.page.update({
      where: { id: page.id },
      data: {
        displayName: input.profile.displayName,
        pronouns: input.profile.pronouns,
        bio: input.profile.bio,
        avatarSource: input.profile.avatarSource,
        avatarUrl: input.profile.avatarUrl,
        bannerUrl: input.profile.bannerUrl,
        ngUsername: input.profile.ngUsername,
        ngServer: input.profile.ngServer,
        theme: JSON.stringify(input.theme),
        customCss: css.css,
        options: JSON.stringify(input.options),
        published: input.published,
      },
      select: { updatedAt: true },
    }),
  ]);

  await collectUnusedUploads(editorId).catch(() => undefined);
  return updated;
}

/** Contenu des pages où un compte peut avoir placé ses fichiers (les siennes et celles où il collabore). */
async function contentOfPagesFor(userId: string): Promise<string> {
  const pages = await prisma.page.findMany({
    where: { OR: [{ userId }, { members: { some: { userId } } }] },
    select: { avatarUrl: true, bannerUrl: true, theme: true, customCss: true, blocks: { select: { data: true } } },
  });
  return pages.map((p) => [p.avatarUrl, p.bannerUrl, p.theme, p.customCss, ...p.blocks.map((b) => b.data)].join("\n")).join("\n");
}

/**
 * Supprime les fichiers importés par un compte qui ne sont plus utilisés sur aucune de ses pages
 * (ni sur celles où il collabore), après un délai de grâce (1 h par défaut, pour l'import en cours).
 */
export async function collectUnusedUploads(userId: string, graceMs = 60 * 60 * 1000) {
  const uploads = await prisma.upload.findMany({
    where: { userId, createdAt: { lt: new Date(Date.now() - graceMs) } },
    select: { id: true },
  });
  if (!uploads.length) return;
  const content = await contentOfPagesFor(userId);
  const unused = uploads.filter((u) => !content.includes(`/api/uploads/${u.id}`)).map((u) => u.id);
  if (unused.length) await deleteUploads(unused, userId);
}

/** Supprime une page (blocs, statistiques, messages) et les fichiers qui ne servaient qu'à elle. */
export async function deletePage(pageId: string) {
  const page = await prisma.page.findUnique({ where: { id: pageId }, select: { userId: true, members: { select: { userId: true } } } });
  if (!page) return;
  await prisma.page.delete({ where: { id: pageId } });
  for (const userId of new Set([page.userId, ...page.members.map((m) => m.userId)])) {
    await collectUnusedUploads(userId, 0).catch(() => undefined);
  }
}

export function todayKey(date = new Date()): string {
  return date.toISOString().slice(0, 10);
}

/** Enregistre une visite unique par visiteur et par jour ; renvoie true si elle est nouvelle. */
export async function recordView(
  pageId: string,
  visitorHash: string,
  extra: { referrer: string | null; device: string | null } = { referrer: null, device: null },
): Promise<boolean> {
  const day = todayKey();
  try {
    await prisma.$transaction([
      prisma.pageView.create({ data: { pageId, day, visitorHash, referrer: extra.referrer, device: extra.device } }),
      prisma.page.update({ where: { id: pageId }, data: { views: { increment: 1 } } }),
    ]);
  } catch {
    return false; // déjà comptée aujourd'hui (contrainte d'unicité)
  }
  if (Math.random() < 0.01) {
    const cutoff = todayKey(new Date(Date.now() - VIEW_RETENTION_DAYS * 86_400_000));
    await prisma.pageView.deleteMany({ where: { day: { lt: cutoff } } }).catch(() => undefined);
    await prisma.linkClick.deleteMany({ where: { day: { lt: cutoff } } }).catch(() => undefined);
  }
  return true;
}

function dayKeys(days: number): string[] {
  return Array.from({ length: days }, (_, i) => todayKey(new Date(Date.now() - (days - 1 - i) * 86_400_000)));
}

/** Vues uniques des N derniers jours, du plus ancien au plus récent. */
export async function viewsByDay(pageId: string, days = 14): Promise<{ day: string; count: number }[]> {
  const keys = dayKeys(days);
  const rows = await prisma.pageView.groupBy({
    by: ["day"],
    where: { pageId, day: { gte: keys[0] } },
    _count: { _all: true },
  });
  const map = new Map(rows.map((r) => [r.day, r._count._all]));
  return keys.map((day) => ({ day, count: map.get(day) ?? 0 }));
}

/** Clics des N derniers jours, par bloc (du plus cliqué au moins cliqué). */
export async function clicksByBlock(pageId: string, days = 14): Promise<{ blockId: string; count: number }[]> {
  const rows = await prisma.linkClick.groupBy({
    by: ["blockId"],
    where: { pageId, day: { gte: dayKeys(days)[0] } },
    _sum: { count: true },
  });
  return rows
    .map((r) => ({ blockId: r.blockId, count: r._sum.count ?? 0 }))
    .filter((r) => r.count > 0)
    .sort((a, b) => b.count - a.count);
}

/** Sources de trafic et appareils des N derniers jours (statistiques avancées). */
export async function audience(pageId: string, days: number) {
  const since = dayKeys(days)[0];
  const [referrers, devices] = await Promise.all([
    prisma.pageView.groupBy({ by: ["referrer"], where: { pageId, day: { gte: since } }, _count: { _all: true } }),
    prisma.pageView.groupBy({ by: ["device"], where: { pageId, day: { gte: since } }, _count: { _all: true } }),
  ]);
  return {
    referrers: referrers
      .map((r) => ({ source: r.referrer ?? "direct", count: r._count._all }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 8),
    devices: devices.map((d) => ({ device: d.device ?? "inconnu", count: d._count._all })).sort((a, b) => b.count - a.count),
  };
}
