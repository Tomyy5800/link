import "server-only";
import { z } from "zod";
import { DEFAULT_SETTINGS, FEATURE_KEYS, normalizeMode, type Offer, type PlanLimits, type PlatformSettings } from "../features";
import { prisma } from "./db";

// Réglages de la plateforme, modifiés depuis /admin et gardés en mémoire 30 secondes.

const SETTINGS_KEY = "platform";
const mode = z.enum(["all", "plus", "pro", "team", "off"]);
const limits = z.object({
  pages: z.number().int().min(1).max(100),
  members: z.number().int().min(0).max(100),
  blocks: z.number().int().min(1).max(120),
  uploads: z.number().int().min(0).max(5000),
  imageMb: z.number().int().min(1).max(20),
  mediaMb: z.number().int().min(0).max(50),
  statsDays: z.number().int().min(7).max(120),
  aiMessages: z.number().int().min(0).max(2000),
  roles: z.number().int().min(0).max(50),
  domains: z.number().int().min(0).max(20),
});

const offerSchema = z.object({
  id: z.string().regex(/^[a-z0-9-]{2,24}$/, "Identifiant d'offre invalide (minuscules, chiffres, tirets)"),
  tier: z.enum(["plus", "pro", "team"]),
  name: z.string().trim().min(1).max(32),
  interval: z.enum(["month", "year"]),
  priceCents: z.number().int().min(50, "Prix minimum : 0,50 €").max(100_000),
  description: z.string().trim().max(80),
  highlight: z.boolean(),
  active: z.boolean(),
});

/**
 * Anciennes offres à paiement unique (avant les abonnements) : 30 jours → mensuel,
 * 365 jours → annuel ; les offres « à vie » et les autres durées ne sont plus vendues.
 */
export function migrateOffer(raw: unknown): Offer | null {
  if (!raw || typeof raw !== "object") return null;
  const o = raw as Partial<Offer> & { days?: number; tier?: string };
  if (o.interval === "month" || o.interval === "year") return { ...(o as Offer), tier: (o.tier as Offer["tier"]) ?? "plus" };
  const interval = o.days === 30 ? "month" : o.days === 365 ? "year" : null;
  if (!interval) return null;
  const { days: _days, ...rest } = o;
  void _days;
  return {
    ...(rest as Omit<Offer, "interval">),
    tier: (o.tier as Offer["tier"]) ?? "plus",
    interval,
    name: interval === "month" ? "Mensuel" : "Annuel",
  };
}

const legalField = z.string().trim().max(300);
const legalSchema = z.object({
  sellerName: legalField,
  status: legalField,
  address: legalField,
  email: z.union([z.literal(""), z.email("Adresse e-mail invalide")]),
  siret: z.string().trim().max(20),
  vatMention: legalField,
  publisher: legalField,
  host: legalField,
  mediator: legalField,
});

export const settingsSchema = z.object({
  features: z.object(Object.fromEntries(FEATURE_KEYS.map((k) => [k, mode])) as Record<(typeof FEATURE_KEYS)[number], typeof mode>),
  limits: z.object({ free: limits, plus: limits, pro: limits, team: limits, partner: limits }),
  blockedDomains: z
    .array(z.string().trim().toLowerCase().regex(/^(\*\.)?[a-z0-9.-]+\.[a-z]{2,}$/, "Domaine invalide"))
    .max(500),
  registrationsOpen: z.boolean(),
  announcement: z.string().max(280),
  premiumName: z.string().trim().min(1).max(24),
  premiumUrl: z.union([z.literal(""), z.url({ protocol: /^https$/ })]),
  offers: z
    .array(offerSchema)
    .max(12)
    .refine((offers) => new Set(offers.map((o) => o.id)).size === offers.length, "Deux offres ont le même identifiant"),
  personalShops: z.boolean(),
  launchFreeAccess: z.boolean(),
  legal: legalSchema,
});

/** Réglages sensibles : modifiables seulement avec la permission « platform.critical », avec confirmation. */
export const CRITICAL_SETTINGS = ["personalShops", "launchFreeAccess"] as const;

const memory = globalThis as unknown as { __lbuSettings?: { value: PlatformSettings; at: number } };

/** Fusionne une valeur stockée (éventuellement ancienne ou partielle) avec les valeurs par défaut. */
function merge(raw: unknown): PlatformSettings {
  const value = (raw && typeof raw === "object" ? raw : {}) as Omit<Partial<PlatformSettings>, "limits"> & { limits?: unknown };
  const features = { ...DEFAULT_SETTINGS.features };
  for (const k of FEATURE_KEYS) {
    // Ancien réglage « premium » (avant les formules, « payant ») : la formule prévue pour cette
    // fonction (Link+, Pro ou Équipe) plutôt que Link+ pour tout.
    const raw = value.features?.[k] as unknown;
    if (raw === "premium") {
      const planned = DEFAULT_SETTINGS.features[k];
      features[k] = planned === "all" || planned === "off" ? "plus" : planned;
      continue;
    }
    const m = normalizeMode(raw);
    if (m) features[k] = m;
  }
  const storedLimits = (value.limits && typeof value.limits === "object" ? value.limits : {}) as Record<string, Partial<PlanLimits> | undefined>;
  const limits = Object.fromEntries(
    (["free", "plus", "pro", "team", "partner"] as const).map((tier) => [
      tier,
      { ...DEFAULT_SETTINGS.limits[tier], ...(tier === "plus" ? storedLimits.premium : undefined), ...storedLimits[tier] },
    ]),
  );
  // Offres enregistrées avant les abonnements : converties (mensuel, annuel). Une formule qui
  // n'a plus aucune offre reçoit celles par défaut, pour que chaque formule reste en vente.
  let offers: Offer[] = Array.isArray(value.offers)
    ? (value.offers as unknown[]).map(migrateOffer).filter((o): o is Offer => o !== null)
    : DEFAULT_SETTINGS.offers;
  if (Array.isArray(value.offers)) {
    for (const tier of ["plus", "pro", "team"] as const) {
      if (!offers.some((o) => o.tier === tier)) offers = [...offers, ...DEFAULT_SETTINGS.offers.filter((o) => o.tier === tier && !offers.some((x) => x.id === o.id))];
    }
  }
  const candidate = {
    ...DEFAULT_SETTINGS,
    ...value,
    features,
    limits,
    offers,
    // Jamais ouverts par une ancienne valeur : seulement par un réglage explicite et vérifié.
    personalShops: value.personalShops === true,
    launchFreeAccess: value.launchFreeAccess === true,
    legal: { ...DEFAULT_SETTINGS.legal, ...value.legal },
  };
  const parsed = settingsSchema.safeParse(candidate);
  return parsed.success ? parsed.data : DEFAULT_SETTINGS;
}

export async function getSettings(): Promise<PlatformSettings> {
  const cached = memory.__lbuSettings;
  if (cached && Date.now() - cached.at < 30_000) return cached.value;
  let value = DEFAULT_SETTINGS;
  try {
    const row = await prisma.appSetting.findUnique({ where: { key: SETTINGS_KEY } });
    value = merge(row ? JSON.parse(row.value) : {});
  } catch {
    value = DEFAULT_SETTINGS;
  }
  memory.__lbuSettings = { value, at: Date.now() };
  return value;
}

export async function saveSettings(next: PlatformSettings): Promise<PlatformSettings> {
  const value = settingsSchema.parse(next);
  const serialized = JSON.stringify(value);
  await prisma.appSetting.upsert({
    where: { key: SETTINGS_KEY },
    create: { key: SETTINGS_KEY, value: serialized },
    update: { value: serialized },
  });
  memory.__lbuSettings = { value, at: Date.now() };
  return value;
}
