import "server-only";
import type { User } from "@prisma/client";
import type { NextResponse } from "next/server";
import { can, parseStaffPermissions, type StaffPermission, type StaffRights } from "../staff";
import { env } from "./env";
import { isAdmin } from "./entitlements";
import { jsonError } from "./http";

// Niveau et permissions du staff. Le niveau « fondateur » ne vient que de l'environnement du
// serveur : aucune requête, aucun administrateur ne peut se l'attribuer.

type StaffAccount = Pick<User, "role" | "discordId" | "unclaimId" | "staffPermissions">;

/** Fondateur déclaré explicitement (FOUNDER_UNCLAIM_IDS / FOUNDER_DISCORD_IDS) : badge « Fondateur ». */
export function isDeclaredFounder(user: Pick<User, "discordId" | "unclaimId"> | null | undefined): boolean {
  if (!user) return false;
  if (user.unclaimId && env.founderUnclaimIds.includes(user.unclaimId)) return true;
  return Boolean(user.discordId && env.founderDiscordIds.includes(user.discordId));
}

/** Aucun fondateur déclaré : les administrateurs d'office (ADMIN_*) ont le niveau fondateur. */
export function foundersDeclared(): boolean {
  return env.founderUnclaimIds.length > 0 || env.founderDiscordIds.length > 0;
}

function isEnvAdmin(user: Pick<User, "discordId" | "unclaimId">): boolean {
  return Boolean((user.discordId && env.adminDiscordIds.includes(user.discordId)) || (user.unclaimId && env.adminUnclaimIds.includes(user.unclaimId)));
}

/**
 * Niveau fondateur : fondateur déclaré ; sinon administrateur d'office ; et seulement si rien
 * n'est déclaré dans l'environnement, tout administrateur (installation neuve).
 */
export function isFounderLevel(user: StaffAccount | null | undefined): boolean {
  // Un fondateur déclaré est toujours administrateur (voir isAdmin).
  if (!user || !isAdmin(user)) return false;
  if (foundersDeclared()) return isDeclaredFounder(user);
  if (env.adminDiscordIds.length || env.adminUnclaimIds.length) return isEnvAdmin(user);
  return true;
}

export function staffRights(user: StaffAccount | null | undefined): StaffRights | null {
  if (!user) return null;
  if (isFounderLevel(user)) return { level: "founder", permissions: [] };
  if (!isAdmin(user)) return null;
  return { level: "admin", permissions: parseStaffPermissions(user.staffPermissions) };
}

export function hasStaffPermission(user: StaffAccount | null | undefined, permission: StaffPermission): boolean {
  return can(staffRights(user), permission);
}

/** Route d'administration : refuse si la permission manque (à appeler après requireAdminApi). */
export function requireStaffPermission(user: StaffAccount, permission: StaffPermission): NextResponse | null {
  return hasStaffPermission(user, permission) ? null : jsonError(403, "Ton compte n'a pas la permission nécessaire. Demande-la à un fondateur.");
}

export function requireFounder(user: StaffAccount): NextResponse | null {
  return isFounderLevel(user) ? null : jsonError(403, "Réservé aux fondateurs.");
}
