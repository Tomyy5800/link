import "server-only";
import { ngCountryKey, ngProfileKey, type PageExtras } from "@/components/page/types";
import type { PageView } from "../page-schema";
import { parseDiscordInvite } from "../urls";
import { getDiscordInvite } from "./discord";
import { getNationsGloryProfile, getNgCountry } from "./nationsglory";

/** Précharge les données externes des blocs visibles, pour un premier affichage complet côté serveur. */
export async function loadPageExtras(page: PageView): Promise<PageExtras> {
  const profiles = new Map<string, { username: string; servers: string[] }>();
  const countries = new Map<string, { server: string; country: string }>();
  const inviteCodes = new Set<string>();

  for (const block of page.blocks) {
    if (!block.visible) continue;
    if (block.type === "nationsglory") {
      const username = block.data.username || page.profile.ngUsername;
      const servers = block.data.servers.length ? block.data.servers : [page.profile.ngServer];
      if (username) profiles.set(ngProfileKey(username, servers), { username, servers });
    }
    if (block.type === "ngCountry") {
      const country = (block.data.countryId || block.data.country).trim();
      if (country) countries.set(ngCountryKey(block.data.server, country), { server: block.data.server, country });
    }
    if (block.type === "discordServer") {
      const code = parseDiscordInvite(block.data.invite);
      if (code) inviteCodes.add(code);
    }
  }

  const [ngProfiles, countryCards, invites] = await Promise.all([
    Promise.all([...profiles.values()].map((p) => getNationsGloryProfile(p.username, p.servers))),
    Promise.all([...countries.values()].map((c) => getNgCountry(c.server, c.country))),
    Promise.all([...inviteCodes].map(getDiscordInvite)),
  ]);

  // Les clés reprennent la demande (et non la réponse) : l'API peut renvoyer une autre casse.
  return {
    ng: Object.fromEntries([...profiles.keys()].map((key, i) => [key, ngProfiles[i]])),
    countries: Object.fromEntries([...countries.keys()].map((key, i) => [key, countryCards[i]])),
    invites: Object.fromEntries(invites.map((invite) => [invite.code, invite])),
  };
}
