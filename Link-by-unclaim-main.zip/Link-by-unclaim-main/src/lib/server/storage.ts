import "server-only";
import { mkdir, readFile, unlink, writeFile } from "node:fs/promises";
import path from "node:path";
import { prisma } from "./db";
import { env } from "./env";

// Stockage des fichiers importés.
// « db »   : octets dans la base (simple, adapté à un petit déploiement).
// « disk » : fichiers sous UPLOADS_DIR (volume Docker), la base ne garde que le chemin.

export type UploadKind = "image" | "audio" | "video";

// Dossier choisi à l'exécution (UPLOADS_DIR) : exclu du traçage des fichiers du build.
function baseDir(): string {
  return path.resolve(/*turbopackIgnore: true*/ process.cwd(), env.uploadsDir);
}

/** Chemin d'un fichier : jamais en dehors du dossier des fichiers importés. */
function resolveSafe(relative: string): string {
  const root = baseDir();
  const full = path.resolve(/*turbopackIgnore: true*/ root, relative);
  if (!full.startsWith(root + path.sep)) throw new Error("chemin_invalide");
  return full;
}

export async function saveUpload(input: { userId: string; kind: UploadKind; mimeType: string; bytes: Uint8Array }): Promise<string> {
  if (env.uploadsDriver === "disk") {
    const row = await prisma.upload.create({
      data: { userId: input.userId, kind: input.kind, mimeType: input.mimeType, size: input.bytes.byteLength, storage: "disk" },
      select: { id: true },
    });
    const relative = path.join(row.id.slice(0, 2), row.id);
    const full = resolveSafe(relative);
    await mkdir(path.dirname(full), { recursive: true });
    await writeFile(full, input.bytes);
    await prisma.upload.update({ where: { id: row.id }, data: { path: relative } });
    return row.id;
  }
  const row = await prisma.upload.create({
    data: {
      userId: input.userId,
      kind: input.kind,
      mimeType: input.mimeType,
      size: input.bytes.byteLength,
      storage: "db",
      data: Buffer.from(input.bytes),
    },
    select: { id: true },
  });
  return row.id;
}

export async function readUpload(id: string): Promise<{ mimeType: string; bytes: Uint8Array<ArrayBuffer> } | null> {
  const row = await prisma.upload.findUnique({ where: { id }, select: { mimeType: true, storage: true, path: true, data: true } });
  if (!row) return null;
  if (row.storage === "disk") {
    if (!row.path) return null;
    try {
      return { mimeType: row.mimeType, bytes: new Uint8Array(await readFile(resolveSafe(row.path))) };
    } catch {
      return null;
    }
  }
  return row.data ? { mimeType: row.mimeType, bytes: new Uint8Array(row.data) } : null;
}

export async function deleteUploads(ids: string[], userId?: string): Promise<void> {
  if (!ids.length) return;
  const rows = await prisma.upload.findMany({
    where: { id: { in: ids }, ...(userId ? { userId } : {}) },
    select: { id: true, storage: true, path: true },
  });
  for (const row of rows) {
    if (row.storage === "disk" && row.path) await unlink(resolveSafe(row.path)).catch(() => undefined);
  }
  await prisma.upload.deleteMany({ where: { id: { in: rows.map((r) => r.id) } } });
}

/** Volume total stocké (octets), pour l'administration. */
export async function storageUsage(): Promise<{ files: number; bytes: number }> {
  const agg = await prisma.upload.aggregate({ _count: { _all: true }, _sum: { size: true } });
  return { files: agg._count._all, bytes: agg._sum.size ?? 0 };
}
