import "server-only";
import { createHmac, timingSafeEqual } from "node:crypto";
import type { Order, ShopItem, Subscription, User } from "@prisma/client";
import { INTERVAL_DAYS, SUBSCRIPTION_GRACE_DAYS, type BillingInterval, type Offer } from "../features";
import { parseShopReward } from "../official-shop";
import { TIER_RANK, normalizeTier, paidTier, tierName, type PaidTier, type Tier } from "../plans";
import { prisma } from "./db";
import { env } from "./env";
import { deliverReward, ownsReward, takeBackReward } from "./official-shop";
import { dayValues, generateCode, grantPremium, hashCode, normalizeCode, revokePremium } from "./premium";
import { getSettings } from "./settings";

// Paiements Stripe, sans SDK (appels REST), version d'API figée pour des réponses stables.
//
// Abonnements aux formules (Link+, Pro, Équipe) :
//   1. POST /api/checkout → session Stripe Checkout en mode « subscription » → paiement.
//   2. Stripe prévient POST /api/webhooks/stripe (signature vérifiée). Pour chaque événement, on
//      relit l'abonnement dans l'API Stripe (jamais le contenu de l'événement seul), puis on
//      met à jour Subscription et les droits du compte (User.subTier / subUntil).
//   3. Chaque facture payée devient une ligne d'historique (Order, kind « subscription »).
//   Résiliation, reprise et changement de formule passent par l'API, depuis Mon espace › Offre.
// Boutique officielle (paiement unique) : commande « pending », session Checkout « payment »,
//   puis le webhook marque la commande payée et livre la récompense dans la même transaction.
// Aucune donnée de carte ne transite par Link by Unclaim.

const STRIPE_API = "https://api.stripe.com/v1";
/** Version d'API figée : les champs lus ci-dessous (current_period_end, invoice.payment_intent…) en dépendent. */
export const STRIPE_API_VERSION = "2024-06-20";
/** Délai de grâce après la fin d'une période, le temps que Stripe relance un paiement. */
export const GRACE_DAYS = SUBSCRIPTION_GRACE_DAYS;
const DAY = 86_400_000;

/** Statuts Stripe qui donnent accès à la formule. */
export const ACCESS_STATUSES = new Set(["active", "trialing", "past_due"]);

export class PaymentError extends Error {
  constructor(
    message: string,
    readonly status = 400,
  ) {
    super(message);
  }
}

/** Encode des paramètres imbriqués au format attendu par l'API Stripe (a[b][0][c]=…). */
export function stripeForm(params: Record<string, unknown>, prefix = ""): URLSearchParams {
  const out = new URLSearchParams();
  const walk = (value: unknown, key: string) => {
    if (value === undefined || value === null) return;
    if (Array.isArray(value)) value.forEach((v, i) => walk(v, `${key}[${i}]`));
    else if (typeof value === "object") for (const [k, v] of Object.entries(value)) walk(v, key ? `${key}[${k}]` : k);
    else out.append(key, String(value));
  };
  walk(params, prefix);
  return out;
}

async function stripe<T>(method: "GET" | "POST" | "DELETE", path: string, params?: Record<string, unknown>, idempotencyKey?: string): Promise<T> {
  const res = await fetch(`${STRIPE_API}${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${env.stripe.secretKey}`,
      "Content-Type": "application/x-www-form-urlencoded",
      "Stripe-Version": STRIPE_API_VERSION,
      ...(idempotencyKey ? { "Idempotency-Key": idempotencyKey } : {}),
    },
    body: params ? stripeForm(params).toString() : undefined,
    cache: "no-store",
    signal: AbortSignal.timeout(15_000),
  }).catch(() => null);
  if (!res) throw new PaymentError("Le service de paiement est injoignable. Réessaie dans un instant.", 503);
  const json = (await res.json().catch(() => ({}))) as T & { error?: { message?: string; code?: string } };
  if (!res.ok) {
    console.error(`[paiement] Stripe ${res.status} : ${json.error?.message ?? "erreur"}`);
    throw new PaymentError(json.error?.code === "card_declined" ? "Le paiement a été refusé par la banque." : "Le paiement n'a pas pu être traité. Réessaie dans un instant.", 502);
  }
  return json;
}

function requireStripe() {
  if (!env.stripe.configured) throw new PaymentError("Le paiement en ligne n'est pas encore ouvert.", 503);
}

// --- Clients Stripe ---------------------------------------------------------------------------

/** Client Stripe du compte (créé au premier paiement, sans donnée personnelle : Stripe demande l'e-mail lui-même). */
export async function ensureCustomer(user: Pick<User, "id" | "stripeCustomerId">): Promise<string> {
  if (user.stripeCustomerId) return user.stripeCustomerId;
  const customer = await stripe<{ id: string }>("POST", "/customers", { metadata: { userId: user.id } }, `customer-${user.id}`);
  // Deux demandes simultanées reçoivent le même client grâce à la clé d'idempotence.
  await prisma.user.updateMany({ where: { id: user.id, stripeCustomerId: null }, data: { stripeCustomerId: customer.id } });
  return customer.id;
}

// --- Abonnements ------------------------------------------------------------------------------

type StripePrice = { unit_amount: number | null; currency: string; recurring?: { interval: string } | null; product?: string };
export type StripeSubscription = {
  id: string;
  customer: string;
  status: string;
  cancel_at_period_end: boolean;
  canceled_at: number | null;
  current_period_end?: number;
  metadata?: Record<string, string>;
  items: { data: { id: string; price: StripePrice; current_period_end?: number }[] };
};

/** Abonnement qui donne accès à la formule (statut et période). */
export function subscriptionGivesAccess(sub: Pick<Subscription, "status" | "currentPeriodEnd">, now = Date.now()): boolean {
  return ACCESS_STATUSES.has(sub.status) && Boolean(sub.currentPeriodEnd) && sub.currentPeriodEnd!.getTime() + GRACE_DAYS * DAY > now;
}

/** Abonnement en cours d'un compte (le plus haut s'il y en a plusieurs). */
export async function currentSubscription(userId: string): Promise<Subscription | null> {
  const subs = await prisma.subscription.findMany({ where: { userId }, orderBy: { updatedAt: "desc" } });
  const live = subs.filter((s) => subscriptionGivesAccess(s));
  live.sort((a, b) => TIER_RANK[normalizeTier(b.tier)] - TIER_RANK[normalizeTier(a.tier)]);
  return live[0] ?? subs.find((s) => ["incomplete", "unpaid"].includes(s.status)) ?? null;
}

/** Recalcule les droits d'abonnement du compte à partir de ses abonnements enregistrés. */
export async function recomputeSubscriptionAccess(userId: string, now = Date.now()): Promise<void> {
  const subs = await prisma.subscription.findMany({ where: { userId } });
  let best: Subscription | null = null;
  for (const sub of subs) {
    if (!subscriptionGivesAccess(sub, now)) continue;
    if (!best || TIER_RANK[normalizeTier(sub.tier)] > TIER_RANK[normalizeTier(best.tier)]) best = sub;
  }
  await prisma.user.update({
    where: { id: userId },
    data: best
      ? {
          subTier: normalizeTier(best.tier),
          subUntil: new Date(best.currentPeriodEnd!.getTime() + GRACE_DAYS * DAY),
          subRenews: !best.cancelAtPeriodEnd && best.status !== "past_due",
        }
      : { subTier: "free", subUntil: null, subRenews: false },
  });
}

function periodEnd(sub: StripeSubscription): Date | null {
  const end = sub.current_period_end ?? sub.items.data[0]?.current_period_end;
  return end ? new Date(end * 1000) : null;
}

/**
 * Relit un abonnement chez Stripe et l'enregistre. Le compte est retrouvé par le client Stripe
 * qu'on lui a créé (et, à défaut, par la référence posée à la souscription, recoupée avec le client).
 */
export async function syncSubscription(subscriptionId: string): Promise<Subscription | null> {
  if (!/^sub_[A-Za-z0-9]{6,80}$/.test(subscriptionId)) return null;
  const sub = await stripe<StripeSubscription>("GET", `/subscriptions/${encodeURIComponent(subscriptionId)}`);
  return storeSubscription(sub);
}

export async function storeSubscription(sub: StripeSubscription): Promise<Subscription | null> {
  const byCustomer = await prisma.user.findUnique({ where: { stripeCustomerId: sub.customer }, select: { id: true } });
  let userId = byCustomer?.id ?? null;
  if (!userId && sub.metadata?.userId) {
    const candidate = await prisma.user.findUnique({ where: { id: sub.metadata.userId }, select: { id: true, stripeCustomerId: true } });
    // Seulement si le compte n'a pas déjà un autre client Stripe : on ne rattache pas l'abonnement d'un tiers.
    if (candidate && (!candidate.stripeCustomerId || candidate.stripeCustomerId === sub.customer)) {
      userId = candidate.id;
      if (!candidate.stripeCustomerId) await prisma.user.updateMany({ where: { id: candidate.id, stripeCustomerId: null }, data: { stripeCustomerId: sub.customer } });
    }
  }
  if (!userId) {
    console.error(`[paiement] abonnement ${sub.id} sans compte correspondant`);
    return null;
  }
  const item = sub.items.data[0];
  const interval: BillingInterval = item?.price.recurring?.interval === "year" ? "year" : "month";
  const tier = paidTier(sub.metadata?.tier);
  const data = {
    userId,
    customerRef: sub.customer,
    tier,
    offerId: sub.metadata?.offerId ?? "",
    interval,
    amountCents: item?.price.unit_amount ?? 0,
    currency: item?.price.currency ?? "eur",
    status: sub.status,
    currentPeriodEnd: periodEnd(sub),
    cancelAtPeriodEnd: sub.cancel_at_period_end,
    canceledAt: sub.canceled_at ? new Date(sub.canceled_at * 1000) : null,
  };
  const termsAcceptedAt = sub.metadata?.termsAcceptedAt && !Number.isNaN(Date.parse(sub.metadata.termsAcceptedAt)) ? new Date(sub.metadata.termsAcceptedAt) : null;
  const stored = await prisma.subscription.upsert({
    where: { providerRef: sub.id },
    create: { ...data, providerRef: sub.id, termsAcceptedAt },
    update: data,
  });
  await recomputeSubscriptionAccess(userId);
  return stored;
}

function productLabel(tier: PaidTier, premiumName: string) {
  return tierName(tier, premiumName);
}

/** Démarre une souscription : renvoie l'adresse de la page de paiement Stripe. */
export async function createSubscriptionCheckout(input: { user: Pick<User, "id" | "stripeCustomerId">; offer: Offer; premiumName: string }): Promise<{ url: string }> {
  requireStripe();
  const { offer, user } = input;
  const current = await currentSubscription(user.id);
  if (current && subscriptionGivesAccess(current)) {
    throw new PaymentError("Tu as déjà un abonnement en cours : change de formule depuis Mon espace › Offre.", 409);
  }
  const customer = await ensureCustomer(user);
  const name = productLabel(offer.tier, input.premiumName);
  const accepted = new Date().toISOString();
  const metadata = { userId: user.id, tier: offer.tier, offerId: offer.id, termsAcceptedAt: accepted, kind: "subscription" };
  const session = await stripe<{ id: string; url: string }>("POST", "/checkout/sessions", {
    mode: "subscription",
    locale: "fr",
    customer,
    client_reference_id: user.id,
    success_url: `${env.appUrl}/plus/merci?session={CHECKOUT_SESSION_ID}`,
    cancel_url: `${env.appUrl}/plus?annule=1`,
    metadata,
    subscription_data: { metadata, description: `${name} · ${offer.interval === "year" ? "annuel" : "mensuel"}` },
    line_items: [
      {
        quantity: 1,
        price_data: {
          currency: "eur",
          unit_amount: offer.priceCents,
          recurring: { interval: offer.interval },
          product_data: { name, description: `Abonnement ${offer.interval === "year" ? "annuel" : "mensuel"} aux fonctions ${name} de Link by Unclaim, résiliable à tout moment.` },
        },
      },
    ],
  });
  return { url: session.url };
}

const PRODUCTS_KEY = "stripe-products";

/** Produit Stripe d'une formule (créé une fois, nécessaire pour changer le prix d'un abonnement). */
async function tierProduct(tier: PaidTier, premiumName: string): Promise<string> {
  const row = await prisma.appSetting.findUnique({ where: { key: PRODUCTS_KEY } });
  const products = (row ? JSON.parse(row.value) : {}) as Record<string, string>;
  if (products[tier]) return products[tier];
  const product = await stripe<{ id: string }>("POST", "/products", { name: productLabel(tier, premiumName), metadata: { tier } }, `product-${tier}-v1`);
  const next = JSON.stringify({ ...products, [tier]: product.id });
  await prisma.appSetting.upsert({ where: { key: PRODUCTS_KEY }, create: { key: PRODUCTS_KEY, value: next }, update: { value: next } });
  return product.id;
}

/**
 * Change la formule ou la période d'un abonnement en cours. La différence est facturée (ou
 * créditée) immédiatement au prorata ; si le paiement échoue, rien ne change.
 */
export async function changeSubscription(input: { userId: string; offer: Offer; premiumName: string }): Promise<Subscription | null> {
  requireStripe();
  const current = await currentSubscription(input.userId);
  if (!current || !subscriptionGivesAccess(current)) throw new PaymentError("Aucun abonnement en cours à modifier.", 404);
  const sub = await stripe<StripeSubscription>("GET", `/subscriptions/${encodeURIComponent(current.providerRef)}`);
  const item = sub.items.data[0];
  if (!item) throw new PaymentError("Abonnement illisible chez Stripe.", 502);
  if (current.offerId === input.offer.id && sub.metadata?.tier === input.offer.tier) throw new PaymentError("C'est déjà ta formule actuelle.", 400);
  const product = await tierProduct(input.offer.tier, input.premiumName);
  const updated = await stripe<StripeSubscription>("POST", `/subscriptions/${encodeURIComponent(sub.id)}`, {
    items: [{ id: item.id, price_data: { currency: "eur", product, unit_amount: input.offer.priceCents, recurring: { interval: input.offer.interval } } }],
    proration_behavior: "always_invoice",
    payment_behavior: "error_if_incomplete",
    cancel_at_period_end: false,
    metadata: { ...(sub.metadata ?? {}), tier: input.offer.tier, offerId: input.offer.id },
  });
  return storeSubscription(updated);
}

/** Résilie à la fin de la période payée (ou reprend un abonnement résilié). */
export async function setCancelAtPeriodEnd(userId: string, cancel: boolean): Promise<Subscription | null> {
  requireStripe();
  const current = await currentSubscription(userId);
  if (!current || !subscriptionGivesAccess(current)) throw new PaymentError("Aucun abonnement en cours.", 404);
  const updated = await stripe<StripeSubscription>("POST", `/subscriptions/${encodeURIComponent(current.providerRef)}`, { cancel_at_period_end: cancel });
  return storeSubscription(updated);
}

/** Arrête immédiatement un abonnement (remboursement décidé par l'administration). */
export async function cancelSubscriptionNow(subscriptionRef: string): Promise<void> {
  requireStripe();
  const sub = await stripe<StripeSubscription>("DELETE", `/subscriptions/${encodeURIComponent(subscriptionRef)}`);
  await storeSubscription(sub);
}

/** Portail de facturation Stripe (moyen de paiement, factures). À configurer dans le tableau de bord Stripe. */
export async function billingPortalUrl(user: Pick<User, "id" | "stripeCustomerId">): Promise<string> {
  requireStripe();
  if (!user.stripeCustomerId) throw new PaymentError("Aucun abonnement associé à ce compte.", 404);
  const session = await stripe<{ url: string }>("POST", "/billing_portal/sessions", {
    customer: user.stripeCustomerId,
    return_url: `${env.appUrl}/dashboard/abonnement`,
  }).catch(() => {
    throw new PaymentError("Le portail de facturation n'est pas encore disponible. Écris-nous pour toute question de facture.", 503);
  });
  return session.url;
}

type StripeInvoice = {
  id: string;
  subscription: string | null;
  customer: string;
  status: string;
  amount_paid: number;
  currency: string;
  payment_intent: string | null;
  billing_reason?: string;
  lines?: { data: { period?: { start: number; end: number } }[] };
};

/** Facture payée → ligne d'historique (une seule par facture, même si Stripe renvoie l'événement). */
export async function recordInvoice(invoiceId: string): Promise<Order | null> {
  if (!/^in_[A-Za-z0-9]{6,80}$/.test(invoiceId)) return null;
  const invoice = await stripe<StripeInvoice>("GET", `/invoices/${encodeURIComponent(invoiceId)}`);
  if (invoice.status !== "paid" || !invoice.subscription || invoice.amount_paid <= 0) return null;
  const sub = (await prisma.subscription.findUnique({ where: { providerRef: invoice.subscription } })) ?? (await syncSubscription(invoice.subscription));
  if (!sub) return null;
  const settings = await getSettings();
  const tier = paidTier(sub.tier);
  const line = invoice.lines?.data[0]?.period;
  const days = line ? Math.max(1, Math.round((line.end - line.start) / 86_400)) : INTERVAL_DAYS[sub.interval === "year" ? "year" : "month"];
  const label = `${tierName(tier, settings.premiumName)} · ${sub.interval === "year" ? "annuel" : "mensuel"}`;
  const existing = await prisma.order.findUnique({ where: { providerRef: invoice.id } });
  if (existing) return existing;
  const order = await prisma.order
    .create({
      data: {
        userId: sub.userId,
        kind: "subscription",
        subscriptionRef: sub.providerRef,
        offerId: sub.offerId,
        tier,
        offerName: label,
        days,
        amountCents: invoice.amount_paid,
        currency: invoice.currency,
        status: "paid",
        provider: "stripe",
        providerRef: invoice.id,
        paymentRef: invoice.payment_intent,
        termsAcceptedAt: sub.termsAcceptedAt,
        paidAt: new Date(),
        note: invoice.billing_reason === "subscription_create" ? "Première échéance" : invoice.billing_reason === "subscription_update" ? "Changement de formule" : "",
      },
    })
    .catch(() => prisma.order.findUnique({ where: { providerRef: invoice.id } }));
  if (order) {
    await prisma.auditLog
      .create({ data: { actorId: sub.userId, action: "order.paid", targetType: "order", targetId: order.id, details: JSON.stringify({ offer: label, amount: invoice.amount_paid, subscription: sub.providerRef }) } })
      .catch(() => undefined);
  }
  return order;
}

// --- Boutique officielle ----------------------------------------------------------------------

/** Démarre l'achat d'un article de la boutique officielle. */
export async function createItemCheckout(input: { user: Pick<User, "id" | "stripeCustomerId">; item: ShopItem }): Promise<{ url: string; orderId: string }> {
  requireStripe();
  const reward = parseShopReward(input.item.reward);
  if (!reward) throw new PaymentError("Cet article n'est pas disponible.", 404);
  if (await ownsReward(input.user.id, reward)) throw new PaymentError("Tu possèdes déjà cet article.", 409);
  const customer = await ensureCustomer(input.user);
  const order = await prisma.order.create({
    data: {
      userId: input.user.id,
      kind: "item",
      itemId: input.item.id,
      offerId: input.item.slug,
      offerName: input.item.name,
      days: 0,
      amountCents: input.item.priceCents,
      termsAcceptedAt: new Date(),
    },
  });
  const session = await stripe<{ id: string; url: string }>(
    "POST",
    "/checkout/sessions",
    {
      mode: "payment",
      locale: "fr",
      customer,
      client_reference_id: order.id,
      success_url: `${env.appUrl}/boutique/merci?commande=${order.id}`,
      cancel_url: `${env.appUrl}/boutique?annule=1`,
      metadata: { orderId: order.id, kind: "item" },
      payment_intent_data: { metadata: { orderId: order.id }, description: `Boutique Unclaim · ${input.item.name}` },
      line_items: [{ quantity: 1, price_data: { currency: "eur", unit_amount: input.item.priceCents, product_data: { name: input.item.name, description: input.item.description || undefined } } }],
    },
    `checkout-${order.id}`,
  ).catch(async (error: unknown) => {
    await prisma.order.update({ where: { id: order.id }, data: { status: "failed" } });
    throw error;
  });
  await prisma.order.update({ where: { id: order.id }, data: { providerRef: session.id } });
  return { url: session.url, orderId: order.id };
}

/**
 * Vérifie l'en-tête Stripe-Signature (t=…, v1=…) : HMAC-SHA256 de « t.corps » avec le secret
 * du webhook, et horodatage de moins de 5 minutes (anti-rejeu).
 */
export function verifyStripeSignature(payload: string, header: string | null, secret: string, now = Date.now(), toleranceSec = 300): boolean {
  if (!header || !secret) return false;
  const parts = header.split(",").map((p) => p.trim().split("="));
  const t = Number(parts.find(([k]) => k === "t")?.[1]);
  const signatures = parts.filter(([k]) => k === "v1").map(([, v]) => v ?? "");
  if (!Number.isFinite(t) || !signatures.length) return false;
  if (Math.abs(now / 1000 - t) > toleranceSec) return false;
  const expected = Buffer.from(createHmac("sha256", secret).update(`${t}.${payload}`).digest("hex"));
  return signatures.some((sig) => {
    const given = Buffer.from(sig);
    return given.length === expected.length && timingSafeEqual(given, expected);
  });
}

/**
 * Marque une commande à paiement unique payée et livre ce qu'elle contient : article de la
 * boutique officielle, ou (anciennes commandes) durée de formule ou code cadeau. Idempotent :
 * Stripe peut envoyer le même événement plusieurs fois.
 */
export async function fulfillOrder(orderId: string, paymentRef: string | null): Promise<Order | null> {
  return prisma.$transaction(async (tx) => {
    const order = await tx.order.findUnique({ where: { id: orderId } });
    if (!order) return null;
    if (order.status === "paid" || order.status === "refunded") return order;

    const claimed = await tx.order.updateMany({
      where: { id: orderId, status: { in: ["pending", "failed", "canceled"] } },
      data: { status: "paid", paidAt: new Date(), paymentRef },
    });
    if (claimed.count === 0) return tx.order.findUnique({ where: { id: orderId } });

    let giftCode: string | null = null;
    if (order.kind === "item") {
      const item = order.itemId ? await tx.shopItem.findUnique({ where: { id: order.itemId } }) : null;
      const reward = item ? parseShopReward(item.reward) : null;
      if (!reward) throw new Error(`Article introuvable pour la commande ${order.id}.`);
      await deliverReward(tx, { userId: order.userId, reward, orderId: order.id });
    } else if (order.gift) {
      giftCode = generateCode();
      await tx.premiumCode.create({
        data: {
          codeHash: hashCode(giftCode),
          hint: normalizeCode(giftCode).slice(-4),
          days: order.days,
          tier: order.tier,
          maxUses: 1,
          note: `Cadeau · commande ${order.id}`,
          createdById: order.userId,
        },
      });
    } else {
      const settings = await getSettings();
      await grantPremium(tx, order.userId, order.days, paidTier(order.tier), dayValues(settings.offers));
    }
    await tx.auditLog.create({
      data: {
        actorId: order.userId,
        action: "order.paid",
        targetType: "order",
        targetId: order.id,
        details: JSON.stringify({ offer: order.offerName, amount: order.amountCents, kind: order.kind, gift: order.gift }),
      },
    });
    return tx.order.update({ where: { id: orderId }, data: { giftCode } });
  });
}

/**
 * Commande remboursée (depuis Stripe ou l'administration). Selon son type : article repris,
 * abonnement arrêté (si `revoke`), ou durée de formule retirée.
 */
export async function markRefunded(orderId: string, actorId: string, revoke = true): Promise<Order | null> {
  const before = await prisma.order.findUnique({ where: { id: orderId } });
  const result = await prisma.$transaction(async (tx) => {
    const order = await tx.order.findUnique({ where: { id: orderId } });
    if (!order || order.status === "refunded") return order;
    await tx.order.update({ where: { id: orderId }, data: { status: "refunded", refundedAt: new Date() } });
    if (order.status === "paid" && revoke) {
      if (order.kind === "item") {
        const item = order.itemId ? await tx.shopItem.findUnique({ where: { id: order.itemId } }) : null;
        const reward = item ? parseShopReward(item.reward) : null;
        if (reward) await takeBackReward(tx, { userId: order.userId, reward, orderId: order.id });
      } else if (order.kind === "plan") {
        if (order.gift && order.giftCode) {
          const code = await tx.premiumCode.findUnique({ where: { codeHash: hashCode(order.giftCode) } });
          if (code) {
            await tx.premiumCode.update({ where: { id: code.id }, data: { disabled: true } });
            // Le code a déjà été échangé : on retire les jours au compte qui l'a utilisé.
            const redemption = await tx.codeRedemption.findFirst({ where: { codeId: code.id } });
            if (redemption) await revokePremium(tx, redemption.userId, order.days, paidTier(order.tier));
          }
        } else {
          await revokePremium(tx, order.userId, order.days, paidTier(order.tier));
        }
      }
    }
    await tx.auditLog.create({
      data: { actorId, action: "order.refund", targetType: "order", targetId: order.id, details: JSON.stringify({ amount: order.amountCents, revoke, kind: order.kind }) },
    });
    return tx.order.findUnique({ where: { id: orderId } });
  });
  // Facture d'abonnement remboursée avec retrait : l'abonnement s'arrête tout de suite chez Stripe.
  if (before?.status === "paid" && before.kind === "subscription" && revoke && before.subscriptionRef && env.stripe.configured) {
    await cancelSubscriptionNow(before.subscriptionRef).catch((error) => console.error("[paiement] arrêt de l'abonnement impossible", error));
  }
  return result;
}

const lastSync = new Map<string, number>();

function throttled(key: string): boolean {
  const last = lastSync.get(key) ?? 0;
  if (Date.now() - last < 3000) return true;
  lastSync.set(key, Date.now());
  if (lastSync.size > 5000) lastSync.clear();
  return false;
}

/**
 * Interroge Stripe sur une commande en attente (page de retour) : le paiement est confirmé même
 * sans webhook, par exemple en local où Stripe ne peut pas joindre l'application. Au plus un appel
 * toutes les 3 secondes par commande.
 */
export async function syncCheckout(order: Pick<Order, "id" | "status" | "providerRef">): Promise<Order | null> {
  if (!env.stripe.configured || order.status !== "pending" || !order.providerRef) return null;
  if (throttled(order.id)) return null;
  const session = await stripe<{ status?: string; payment_status?: string; payment_intent?: string | null }>(
    "GET",
    `/checkout/sessions/${encodeURIComponent(order.providerRef)}`,
  ).catch(() => null);
  if (!session) return null;
  if (session.payment_status === "paid") return fulfillOrder(order.id, typeof session.payment_intent === "string" ? session.payment_intent : null);
  if (session.status === "expired") {
    await prisma.order.updateMany({ where: { id: order.id, status: "pending" }, data: { status: "canceled" } });
  }
  return null;
}

export type SubscriptionCheckoutState = { state: "pending" | "active" | "failed"; tier: Tier | null; until: string | null };

/**
 * Page de retour d'une souscription : lit la session Stripe (qui doit appartenir au compte
 * connecté) et enregistre l'abonnement sans attendre le webhook.
 */
export async function syncSubscriptionCheckout(sessionId: string, userId: string): Promise<SubscriptionCheckoutState> {
  if (!env.stripe.configured || !/^cs_[A-Za-z0-9_]{10,200}$/.test(sessionId)) return { state: "failed", tier: null, until: null };
  if (!throttled(sessionId)) {
    const session = await stripe<{ client_reference_id?: string | null; status?: string; subscription?: string | null; mode?: string }>(
      "GET",
      `/checkout/sessions/${encodeURIComponent(sessionId)}`,
    ).catch(() => null);
    if (!session || session.client_reference_id !== userId || session.mode !== "subscription") return { state: "failed", tier: null, until: null };
    if (session.status === "expired") return { state: "failed", tier: null, until: null };
    if (session.status === "complete" && session.subscription) await syncSubscription(session.subscription).catch(() => null);
  }
  const user = await prisma.user.findUnique({ where: { id: userId }, select: { subTier: true, subUntil: true } });
  if (user?.subUntil && user.subUntil.getTime() > Date.now() && user.subTier !== "free") {
    return { state: "active", tier: normalizeTier(user.subTier), until: user.subUntil.toISOString() };
  }
  return { state: "pending", tier: null, until: null };
}

/** Rembourse le paiement chez Stripe (le webhook charge.refunded confirmera ensuite). */
export async function refundPayment(order: Pick<Order, "id" | "paymentRef">): Promise<void> {
  if (!env.stripe.configured || !order.paymentRef) throw new PaymentError("Remboursement en ligne indisponible pour cette commande.", 400);
  await stripe("POST", "/refunds", { payment_intent: order.paymentRef, metadata: { orderId: order.id } }, `refund-${order.id}`);
}

type StripeEvent = {
  id: string;
  type: string;
  data: { object: Record<string, unknown> };
};

const str = (v: unknown) => (typeof v === "string" ? v : null);

/** Traite un événement Stripe déjà authentifié. */
export async function handleStripeEvent(event: StripeEvent): Promise<void> {
  const object = event.data.object;
  const metadata = (object.metadata ?? {}) as Record<string, string>;

  switch (event.type) {
    case "checkout.session.completed":
    case "checkout.session.async_payment_succeeded": {
      if (object.mode === "subscription") {
        const subscription = str(object.subscription);
        if (subscription) await syncSubscription(subscription);
        return;
      }
      const orderId = metadata.orderId ?? str(object.client_reference_id);
      if (orderId && object.payment_status === "paid") await fulfillOrder(orderId, str(object.payment_intent));
      return;
    }
    case "checkout.session.expired":
    case "checkout.session.async_payment_failed": {
      if (object.mode === "subscription") return;
      const orderId = metadata.orderId ?? str(object.client_reference_id);
      if (orderId) {
        await prisma.order.updateMany({
          where: { id: orderId, status: "pending" },
          data: { status: event.type.endsWith("expired") ? "canceled" : "failed" },
        });
      }
      return;
    }
    case "customer.subscription.created":
    case "customer.subscription.updated":
    case "customer.subscription.deleted":
    case "customer.subscription.paused":
    case "customer.subscription.resumed": {
      const id = str(object.id);
      if (id) await syncSubscription(id);
      return;
    }
    case "invoice.paid": {
      const id = str(object.id);
      if (id) await recordInvoice(id);
      const subscription = str(object.subscription);
      if (subscription) await syncSubscription(subscription);
      return;
    }
    case "invoice.payment_failed": {
      const subscription = str(object.subscription);
      if (subscription) await syncSubscription(subscription);
      return;
    }
    case "charge.refunded": {
      const intent = str(object.payment_intent);
      const order = intent ? await prisma.order.findFirst({ where: { paymentRef: intent } }) : null;
      if (order && object.refunded === true) await markRefunded(order.id, order.userId, true);
      return;
    }
    default:
      return;
  }
}
