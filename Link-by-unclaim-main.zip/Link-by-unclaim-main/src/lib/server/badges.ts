import "server-only";
import type { Badge, Prisma, User, UserBadge } from "@prisma/client";
import {
  SYSTEM_BADGES,
  acceptsManualGrant,
  isComputedRule,
  parseBadgeRule,
  type BadgeRule,
  type PublicBadge,
} from "../badges";
import { PAID_TIERS, TIER_RANK, type PaidTier } from "../plans";
import { prisma } from "./db";
import { env } from "./env";
import { activeTier } from "./entitlements";
import { hasStaffPermission, isDeclaredFounder, isFounderLevel } from "./staff";

// Badges officiels : création des badges intégrés, calcul des badges d'un compte, attribution,
// retrait et règle « premiers comptes ». Toute décision est prise ici, côté serveur.

const DAY = 86_400_000;
/** Préférence d'affichage d'un badge calculé (masqué par son titulaire) : n'attribue rien. */
export const PREF_SOURCE = "pref";

type Tx = Prisma.TransactionClient;
type Db = typeof prisma | Tx;

/** Champs du compte nécessaires au calcul des badges. */
export type BadgeHolder = Pick<
  User,
  "id" | "createdAt" | "plan" | "planExpiresAt" | "basePlan" | "subTier" | "subUntil" | "verified" | "partner" | "discordId" | "unclaimId" | "deletedAt" | "banned"
>;

const memory = globalThis as unknown as { __lbuBadgesReady?: Promise<void> };

/** Crée les badges intégrés qui manquent (une fois par processus). Les existants ne sont jamais modifiés. */
export function ensureSystemBadges(): Promise<void> {
  memory.__lbuBadgesReady ??= (async () => {
    const existing = new Set((await prisma.badge.findMany({ select: { key: true } })).map((b) => b.key));
    for (const [position, def] of SYSTEM_BADGES.entries()) {
      if (existing.has(def.key)) continue;
      await prisma.badge
        .create({
          data: {
            key: def.key,
            name: def.name,
            description: def.description,
            icon: def.icon,
            color: def.color,
            staffOnly: def.staffOnly,
            restricted: def.restricted,
            rule: JSON.stringify(def.rule),
            system: true,
            position,
          },
        })
        .catch(() => undefined); // créé au même moment par une autre requête
    }
  })().catch((error) => {
    memory.__lbuBadgesReady = undefined;
    console.error("[badges] création des badges intégrés impossible", error);
  });
  return memory.__lbuBadgesReady;
}

/** Le compte remplit-il la condition d'un badge calculé ? */
export function computedHolds(rule: BadgeRule, user: BadgeHolder, now = Date.now()): boolean {
  switch (rule.type) {
    case "verified":
      return user.verified;
    case "partner":
      return user.partner;
    case "founder":
      return isDeclaredFounder(user);
    case "seniority":
      return now - user.createdAt.getTime() >= rule.days * DAY;
    case "plan": {
      const tier = activeTier(user, now);
      return tier !== "free" && TIER_RANK[tier] >= TIER_RANK[rule.tier];
    }
    default:
      return false;
  }
}

/** Badge visible (actif, non archivé). */
function usable(badge: Badge): boolean {
  return badge.active && !badge.archivedAt;
}

export function grantActive(grant: Pick<UserBadge, "source" | "expiresAt">, now = Date.now()): boolean {
  return grant.source !== PREF_SOURCE && (!grant.expiresAt || grant.expiresAt.getTime() > now);
}

export type OwnedBadge = {
  badge: Badge;
  /** Attribution enregistrée (null : badge calculé). */
  grant: UserBadge | null;
  hidden: boolean;
};

/** Badges d'un compte (enregistrés et calculés), dans l'ordre de l'administration. */
export async function badgesOf(user: BadgeHolder, opts: { db?: Db; now?: number } = {}): Promise<OwnedBadge[]> {
  if (user.deletedAt || user.banned) return [];
  await ensureSystemBadges();
  const db = opts.db ?? prisma;
  const now = opts.now ?? Date.now();
  const [badges, grants] = await Promise.all([
    db.badge.findMany({ where: { active: true, archivedAt: null }, orderBy: [{ position: "asc" }, { createdAt: "asc" }] }),
    db.userBadge.findMany({ where: { userId: user.id } }),
  ]);
  const byBadge = new Map(grants.map((g) => [g.badgeId, g]));
  const owned: OwnedBadge[] = [];
  for (const badge of badges) {
    const rule = parseBadgeRule(badge.rule);
    const row = byBadge.get(badge.id) ?? null;
    if (isComputedRule(rule)) {
      if (computedHolds(rule, user, now)) owned.push({ badge, grant: null, hidden: Boolean(row?.hidden) });
    } else if (row && grantActive(row, now)) {
      owned.push({ badge, grant: row, hidden: row.hidden });
    }
  }
  return owned;
}

export function toPublicBadge(badge: Badge): PublicBadge {
  return {
    key: badge.key,
    name: badge.name,
    description: badge.description,
    icon: badge.icon,
    imageUrl: badge.imageUrl,
    color: badge.color,
    validated: badge.validated,
    staff: badge.staffOnly,
  };
}

/** Badges affichés sur les pages publiques d'un compte (visibles, non masqués par lui). */
export async function publicBadgesOf(user: BadgeHolder): Promise<PublicBadge[]> {
  const owned = await badgesOf(user).catch(() => []);
  return owned.filter((o) => o.badge.visibility === "public" && !o.hidden).map((o) => toPublicBadge(o.badge));
}

type StaffActor = Pick<User, "id" | "role" | "discordId" | "unclaimId" | "staffPermissions">;

/**
 * Qui peut modifier, attribuer ou retirer ce badge : les badges réservés aux fondateurs ne
 * dépendent que d'eux, les badges du staff demandent la permission « badges.staff ».
 */
export function badgeManageError(actor: StaffActor, badge: Pick<Badge, "restricted" | "staffOnly">): string | null {
  if (badge.restricted && !isFounderLevel(actor)) return "Ce badge est réservé aux fondateurs.";
  if (badge.staffOnly && !hasStaffPermission(actor, "badges.staff")) return "Attribuer un badge du staff demande la permission « Badges du staff ».";
  return null;
}

export async function logBadge(db: Db, actorId: string, action: string, badgeId: string, details: Record<string, unknown> = {}) {
  await db.auditLog
    .create({ data: { actorId, action, targetType: "badge", targetId: badgeId, details: JSON.stringify(details).slice(0, 4000) } })
    .catch((error) => console.error("[badges] journal indisponible", error));
}

/**
 * Attribue un badge enregistré. `source` : "manual" (administration), "discord", "purchase".
 * Les badges calculés n'acceptent pas d'attribution (leur condition fait foi).
 */
export async function grantBadge(
  db: Db,
  input: { badge: Badge; userId: string; actorId: string; source: "manual" | "discord" | "purchase" | "auto"; expiresAt?: Date | null; note?: string },
): Promise<UserBadge> {
  const rule = parseBadgeRule(input.badge.rule);
  if (input.source !== "auto" && input.source !== "purchase" && !acceptsManualGrant(rule)) {
    throw new Error("Ce badge est attribué automatiquement selon sa règle.");
  }
  const expiresAt =
    input.expiresAt !== undefined ? input.expiresAt : input.source === "manual" && input.badge.durationDays ? new Date(Date.now() + input.badge.durationDays * DAY) : null;
  const grant = await db.userBadge.upsert({
    where: { userId_badgeId: { userId: input.userId, badgeId: input.badge.id } },
    create: { userId: input.userId, badgeId: input.badge.id, source: input.source, grantedById: input.actorId, expiresAt, note: input.note ?? "" },
    update: { source: input.source, grantedById: input.actorId, expiresAt, ...(input.note !== undefined ? { note: input.note } : {}) },
  });
  await logBadge(db, input.actorId, "badge.grant", input.badge.id, { userId: input.userId, source: input.source, expiresAt: expiresAt?.toISOString() ?? null });
  return grant;
}

/** Retire un badge enregistré (la préférence d'affichage d'un badge calculé n'est pas un badge). */
export async function revokeBadge(db: Db, input: { badge: Badge; userId: string; actorId: string; reason?: string; onlySource?: string }): Promise<boolean> {
  const where = { userId: input.userId, badgeId: input.badge.id, source: input.onlySource ? input.onlySource : { not: PREF_SOURCE } };
  const removed = await db.userBadge.deleteMany({ where });
  if (removed.count) await logBadge(db, input.actorId, "badge.revoke", input.badge.id, { userId: input.userId, reason: input.reason ?? "" });
  return removed.count > 0;
}

// --- Règle « premiers comptes » -------------------------------------------------------------

type EarlyRule = Extract<BadgeRule, { type: "early" }>;

/** Compte éligible : actif, conditions acceptées, Discord rattaché et page publiée si demandés. */
export async function earlyEligible(db: Db, user: Pick<User, "id" | "discordId" | "deletedAt" | "banned" | "suspendedAt" | "termsAcceptedAt">, rule: EarlyRule): Promise<boolean> {
  if (user.deletedAt || user.banned || user.suspendedAt || !user.termsAcceptedAt) return false;
  if (rule.requireDiscord && !user.discordId) return false;
  if (rule.requirePage) {
    const page = await db.page.findFirst({ where: { userId: user.id, published: true, status: "active" }, select: { id: true } });
    if (!page) return false;
  }
  return true;
}

/**
 * Donne une place « premiers comptes », sans transaction longue (SQLite bloquerait des
 * transactions simultanées) :
 *   1. la place est réservée par un incrément conditionnel, atomique (autoGranted < limite) :
 *      deux inscriptions simultanées ne peuvent pas dépasser la limite ;
 *   2. l'attribution est créée ; si le compte l'avait déjà (contrainte d'unicité), la place
 *      est rendue. Au pire (arrêt brutal entre les deux), une place est perdue, jamais en trop.
 */
export async function claimEarlySlot(badge: Badge, userId: string): Promise<boolean> {
  const rule = parseBadgeRule(badge.rule);
  if (rule.type !== "early" || !usable(badge)) return false;
  const existing = await prisma.userBadge.findUnique({ where: { userId_badgeId: { userId, badgeId: badge.id } } });
  if (existing && existing.source !== PREF_SOURCE) return false;
  const claimed = await prisma.badge.updateMany({ where: { id: badge.id, autoGranted: { lt: rule.limit } }, data: { autoGranted: { increment: 1 } } });
  if (claimed.count === 0) return false;
  try {
    if (existing) {
      // Préférence d'affichage déjà enregistrée : elle devient une vraie attribution, une seule fois.
      const promoted = await prisma.userBadge.updateMany({ where: { id: existing.id, source: PREF_SOURCE }, data: { source: "auto", grantedById: "system", expiresAt: null } });
      if (promoted.count === 0) throw new Error("déjà attribué");
    } else {
      await prisma.userBadge.create({ data: { userId, badgeId: badge.id, source: "auto", grantedById: "system" } });
    }
  } catch {
    // Attribution simultanée pour le même compte : la place réservée est rendue.
    await prisma.badge.updateMany({ where: { id: badge.id, autoGranted: { gt: 0 } }, data: { autoGranted: { decrement: 1 } } });
    return false;
  }
  await logBadge(prisma, "system", "badge.auto", badge.id, { userId });
  return true;
}

/** À la connexion ou à la publication d'une page : attribue les badges « premiers comptes » mérités. */
export async function evaluateEarlyBadges(userId: string): Promise<string[]> {
  await ensureSystemBadges();
  const badges = (await prisma.badge.findMany({ where: { active: true, archivedAt: null } })).filter((b) => parseBadgeRule(b.rule).type === "early");
  if (!badges.length) return [];
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) return [];
  const granted: string[] = [];
  for (const badge of badges) {
    const rule = parseBadgeRule(badge.rule) as EarlyRule;
    if (badge.autoGranted >= rule.limit) continue;
    if (!(await earlyEligible(prisma, user, rule))) continue;
    if (await claimEarlySlot(badge, user.id)) granted.push(badge.key);
  }
  return granted;
}

/** Distribue les places restantes aux comptes éligibles, du plus ancien au plus récent. */
export async function backfillEarly(badge: Badge, max = 500): Promise<number> {
  const rule = parseBadgeRule(badge.rule);
  if (rule.type !== "early" || !usable(badge)) return 0;
  let given = 0;
  let cursor: { createdAt: Date; id: string } | null = null;
  while (given < max) {
    const fresh = await prisma.badge.findUnique({ where: { id: badge.id } });
    if (!fresh || fresh.autoGranted >= rule.limit) break;
    const batch: User[] = await prisma.user.findMany({
      where: {
        deletedAt: null,
        banned: false,
        suspendedAt: null,
        termsAcceptedAt: { not: null },
        ...(rule.requireDiscord ? { discordId: { not: null } } : {}),
        ...(rule.requirePage ? { pages: { some: { published: true, status: "active" } } } : {}),
        badges: { none: { badgeId: badge.id, source: { not: PREF_SOURCE } } },
        ...(cursor ? { OR: [{ createdAt: { gt: cursor.createdAt } }, { createdAt: cursor.createdAt, id: { gt: cursor.id } }] } : {}),
      },
      orderBy: [{ createdAt: "asc" }, { id: "asc" }],
      take: 100,
    });
    if (!batch.length) break;
    for (const user of batch) {
      if (given >= max) break;
      if (await claimEarlySlot(fresh, user.id)) given++;
    }
    const last = batch[batch.length - 1]!;
    cursor = { createdAt: last.createdAt, id: last.id };
  }
  return given;
}

// --- Titulaires ------------------------------------------------------------------------------

/** Filtre Prisma des comptes qui remplissent la condition d'un badge calculé. */
export function computedWhere(rule: BadgeRule, now = new Date()): Prisma.UserWhereInput | null {
  switch (rule.type) {
    case "verified":
      return { verified: true };
    case "partner":
      return { partner: true };
    case "founder": {
      const or: Prisma.UserWhereInput[] = [];
      if (env.founderUnclaimIds.length) or.push({ unclaimId: { in: env.founderUnclaimIds } });
      if (env.founderDiscordIds.length) or.push({ discordId: { in: env.founderDiscordIds } });
      return or.length ? { OR: or } : { id: "__aucun__" };
    }
    case "seniority":
      return { createdAt: { lte: new Date(now.getTime() - rule.days * DAY) } };
    case "plan": {
      const tiers = PAID_TIERS.filter((t: PaidTier) => TIER_RANK[t] >= TIER_RANK[rule.tier]);
      const stored = rule.tier === "plus" ? [...tiers, "premium"] : tiers;
      return {
        OR: [
          { plan: { in: stored }, planExpiresAt: null },
          { plan: { in: stored }, planExpiresAt: { gt: now } },
          { basePlan: { in: stored } },
          { subTier: { in: tiers }, subUntil: { gt: now } },
        ],
      };
    }
    default:
      return null;
  }
}

export type BadgeHolderRow = {
  user: Pick<User, "id" | "username" | "globalName" | "avatarUrl" | "avatarHash" | "discordId" | "unclaimId">;
  grant: Pick<UserBadge, "source" | "expiresAt" | "createdAt" | "hidden" | "note"> | null;
};

/** Titulaires d'un badge (paginés). */
export async function holdersOf(badge: Badge, opts: { skip?: number; take?: number; q?: string } = {}): Promise<{ total: number; rows: BadgeHolderRow[] }> {
  const rule = parseBadgeRule(badge.rule);
  const take = opts.take ?? 25;
  const select = { id: true, username: true, globalName: true, avatarUrl: true, avatarHash: true, discordId: true, unclaimId: true } as const;
  const search: Prisma.UserWhereInput = opts.q ? { OR: [{ username: { contains: opts.q } }, { globalName: { contains: opts.q } }, { id: opts.q }, { unclaimId: opts.q }] } : {};
  const base: Prisma.UserWhereInput = { deletedAt: null, banned: false, ...search };
  if (isComputedRule(rule)) {
    const where = { ...base, AND: [computedWhere(rule) ?? { id: "__aucun__" }] };
    const [total, users] = await Promise.all([
      prisma.user.count({ where }),
      prisma.user.findMany({ where, select, orderBy: { createdAt: "asc" }, skip: opts.skip, take }),
    ]);
    return { total, rows: users.map((user) => ({ user, grant: null })) };
  }
  const where: Prisma.UserBadgeWhereInput = {
    badgeId: badge.id,
    source: { not: PREF_SOURCE },
    OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }],
    user: base,
  };
  const [total, grants] = await Promise.all([
    prisma.userBadge.count({ where }),
    prisma.userBadge.findMany({ where, include: { user: { select } }, orderBy: { createdAt: "asc" }, skip: opts.skip, take }),
  ]);
  return { total, rows: grants.map(({ user, ...grant }) => ({ user, grant })) };
}

/** Supprime les attributions temporaires arrivées à échéance (l'historique les garde). */
export async function purgeExpiredBadges(now = new Date()): Promise<number> {
  const expired = await prisma.userBadge.findMany({ where: { expiresAt: { lte: now }, source: { not: PREF_SOURCE } }, select: { id: true, userId: true, badgeId: true } });
  for (const grant of expired) {
    await prisma.userBadge.delete({ where: { id: grant.id } }).catch(() => undefined);
    await logBadge(prisma, "system", "badge.expire", grant.badgeId, { userId: grant.userId });
  }
  return expired.length;
}
