import "server-only";
import Anthropic from "@anthropic-ai/sdk";
import { betaZodOutputFormat } from "@anthropic-ai/sdk/helpers/beta/zod";
import { z } from "zod";
import {
  ASSISTANT_TEMPLATES,
  localAssistantTurn,
  sanitizeDraft,
  type AssistantDraft,
  type AssistantTurn,
  type ChatMessage,
} from "../assistant";
import { GAME_IDS, GAMES } from "../games";
import { THEME_PRESETS } from "../theme";
import { prisma } from "./db";
import { env } from "./env";

// Moteur de l'assistant de création : Claude quand une clé API est configurée, assistant guidé
// local sinon (ou si l'API ne répond pas). Les messages envoyés à Claude sont comptés par jour.

export type AssistantEngine = "claude" | "local";

let client: Anthropic | null = null;
function anthropic(): Anthropic {
  // Identifiants lus dans l'environnement (ANTHROPIC_API_KEY ou ANTHROPIC_AUTH_TOKEN).
  client ??= new Anthropic();
  return client;
}

const PRESET_KEYS = THEME_PRESETS.map((p) => p.key) as [string, ...string[]];

/** Ce que Claude renvoie à chaque tour (nettoyé ensuite par sanitizeDraft). */
const turnSchema = z.object({
  reply: z.string(),
  quickReplies: z.array(z.string()),
  ready: z.boolean(),
  draft: z.object({
    displayName: z.string(),
    pronouns: z.string(),
    bio: z.string(),
    slug: z.string(),
    template: z.enum(ASSISTANT_TEMPLATES),
    preset: z.enum(PRESET_KEYS),
    links: z.array(z.object({ label: z.string(), url: z.string(), emoji: z.string() })),
    socials: z.array(z.string()),
    games: z.array(z.object({ game: z.enum(GAME_IDS as [string, ...string[]]), username: z.string(), rank: z.string() })),
    ngUsername: z.string(),
    discordInvite: z.string(),
    serverIp: z.string(),
    radio: z.boolean(),
    birthday: z.string(),
    contact: z.boolean(),
    events: z.boolean(),
  }),
});

// Prompt fixe (mis en cache) : le contexte variable (brouillon, compte) arrive en message système
// placé après le dernier message de la personne.
const SYSTEM_PROMPT = `Tu es l'assistant de création de Link by Unclaim, un site de pages de profil (« link in bio ») pour joueurs, streamers, créateurs et communautés, en français. La personne vient de se connecter : tu l'aides à créer sa page en moins de cinq minutes, en discutant.

Ta façon de parler : tutoiement, chaleureux et direct, deux phrases courtes au plus, puis une seule question à la fois. Pas de liste, pas de jargon. Si la personne écrit beaucoup d'un coup, prends tout ce qu'elle donne et passe à ce qui manque.

Ce que tu dois obtenir, dans cet ordre, en sautant ce qui est déjà connu :
1. le nom à afficher ;
2. ce qu'elle fait (stream, jeu, serveur, création, musique…) : tu en tires une présentation à la première personne, 200 caractères au plus, avec éventuellement un mot en **gras** ;
3. ses liens (réseaux, Discord, site) : uniquement ceux qu'elle écrit, jamais inventés ; « twitch kaelis » devient https://twitch.tv/kaelis ;
4. ses jeux et pseudos (facultatif) ;
5. l'ambiance visuelle.
Quand le nom, la présentation et au moins des liens ou des jeux sont connus, ou si elle dit que c'est bon, mets ready à true et invite-la à vérifier l'aperçu puis à créer sa page. Ensuite, applique les changements qu'elle demande.

Le brouillon (champ draft) décrit toute la page à chaque tour : reprends le brouillon actuel fourni et modifie seulement ce qui change.
- template : joueur (NationsGlory, Paladium, factions, pays), streamer (live, Twitch, Kick), createur (vidéo, musique, art), communaute (serveur Discord, équipe, association, clan), minimal (le reste).
- preset (ambiance) : unclaim (cyan et or, par défaut), midnight (sombre et sobre), nations (militaire, carte), aurora (doux, aurore boréale), sunset (couchant chaud), paper (clair, minimaliste), neon (néon flashy), royaume (médiéval, or), cyber (futuriste), sakura (rose, pastel, japonais), ocean (bleu, mer), arcade (rétro, pixel).
- socials : adresses complètes des profils sur les réseaux ; links : autres boutons (site, boutique, dernière vidéo) avec un texte court et un émoji.
- games : jeu parmi ${GAME_IDS.map((id) => `${id} (${GAMES[id].name})`).join(", ")}, pseudo tel qu'écrit, rang si donné. NationsGlory va dans ngUsername (pseudo Minecraft), pas dans games.
- discordInvite : lien d'invitation discord.gg s'il est donné. serverIp : IP d'un serveur de jeu à copier.
- radio : true si elle veut une radio en direct (LyxiaRadio) ; birthday : « MM-JJ » si elle donne sa date d'anniversaire ; contact : true pour un formulaire de contact (partenariats, recrutement) ; events : true pour un agenda (planning de streams, tournois).
- slug : adresse courte proposée (minuscules, chiffres, tirets), tirée du nom.
quickReplies : jusqu'à quatre réponses rapides de moins de 30 caractères qui aident à répondre à ta question (vide si aucune n'a de sens).

Ne demande jamais de mot de passe, d'adresse e-mail, d'adresse postale ni de numéro de téléphone. Si la demande sort du sujet, réponds en une phrase et reviens à la page.`;

/** Le brouillon suffit-il pour créer une page ? */
function draftReady(draft: AssistantDraft): boolean {
  return Boolean(draft.displayName && (draft.bio || draft.socials.length || draft.links.length || draft.games.length || draft.ngUsername));
}

function dayKey(userId: string): string {
  return `assistant:${userId}:${new Date().toISOString().slice(0, 10)}`;
}

/** Messages à Claude déjà envoyés aujourd'hui par ce compte. */
export async function assistantUsage(userId: string): Promise<number> {
  const row = await prisma.cacheEntry.findUnique({ where: { key: dayKey(userId) } }).catch(() => null);
  return row ? Number(row.value) || 0 : 0;
}

async function countUsage(userId: string, used: number) {
  const key = dayKey(userId);
  const expiresAt = new Date(Date.now() + 2 * 86_400_000);
  await prisma.cacheEntry
    .upsert({ where: { key }, create: { key, value: String(used + 1), expiresAt }, update: { value: String(used + 1), expiresAt } })
    .catch(() => undefined);
}

/** Un tour de conversation. Claude si possible (et dans le quota du jour), sinon l'assistant guidé. */
export async function assistantTurn(
  messages: ChatMessage[],
  draft: AssistantDraft,
  ctx: { userId: string; name: string; dailyLimit: number },
): Promise<AssistantTurn & { engine: AssistantEngine; remaining: number | null }> {
  if (!env.ai.configured) return { ...localAssistantTurn(messages, ctx), engine: "local", remaining: null };

  const used = await assistantUsage(ctx.userId);
  if (used >= ctx.dailyLimit) {
    // Conversation déjà commencée : on garde le brouillon construit jusqu'ici.
    if (messages.some((m) => m.role === "assistant") && draftReady(draft)) {
      return {
        reply: `Tu as utilisé tes ${ctx.dailyLimit} messages d'assistant IA du jour. Ta page peut déjà être créée avec tout ce qu'on a vu : tu la compléteras dans l'éditeur.`,
        quickReplies: [],
        draft,
        ready: true,
        engine: "claude",
        remaining: 0,
      };
    }
    const turn = localAssistantTurn(messages, ctx);
    return { ...turn, reply: `Tu as utilisé tes messages d'assistant IA du jour : je passe en mode guidé. ${turn.reply}`, engine: "local", remaining: 0 };
  }

  // Premier tour : on lance la conversation sans appel à l'API.
  if (!messages.some((m) => m.role === "user")) {
    return {
      reply: `Salut ${ctx.name} ! Je crée ta page avec toi, ça prend deux minutes. Dis-moi qui tu es et ce que tu fais, et colle tes liens si tu les as sous la main.`,
      quickReplies: ["Je stream sur Twitch", "Je joue à NationsGlory", "Je gère un serveur", "Je crée des vidéos"],
      draft: sanitizeDraft({ ...draft, displayName: draft.displayName || ctx.name }),
      ready: false,
      engine: "claude",
      remaining: ctx.dailyLimit - used,
    };
  }

  try {
    const response = await anthropic().beta.messages.parse({
      model: env.ai.model,
      max_tokens: 16000,
      // Repli côté serveur sur un autre modèle si celui-ci décline une demande.
      betas: ["server-side-fallback-2026-07-01"],
      fallbacks: "default",
      system: [{ type: "text", text: SYSTEM_PROMPT, cache_control: { type: "ephemeral" } }],
      output_config: { effort: "medium", format: betaZodOutputFormat(turnSchema) },
      messages: [
        ...messages.map((m) => ({ role: m.role, content: m.content })),
        {
          role: "system" as const,
          content: `Compte connecté : ${ctx.name}. Brouillon actuel (JSON) : ${JSON.stringify(draft)}`,
        },
      ],
    });
    await countUsage(ctx.userId, used);

    if (response.stop_reason === "refusal" || !response.parsed_output) {
      return {
        reply:
          response.stop_reason === "refusal"
            ? "Je ne peux pas t'aider sur ce point. Revenons à ta page : qu'est-ce que tu veux y mettre ?"
            : "Je n'ai pas bien saisi. Tu peux reformuler ?",
        quickReplies: [],
        draft,
        ready: draftReady(draft),
        engine: "claude",
        remaining: ctx.dailyLimit - used - 1,
      };
    }
    const out = response.parsed_output;
    return {
      reply: out.reply.trim().slice(0, 1200) || "C'est noté.",
      quickReplies: out.quickReplies.map((q) => q.trim().slice(0, 40)).filter(Boolean).slice(0, 4),
      draft: sanitizeDraft(out.draft),
      ready: out.ready,
      engine: "claude",
      remaining: ctx.dailyLimit - used - 1,
    };
  } catch (error) {
    if (error instanceof Anthropic.RateLimitError) console.warn("[assistant] limite de débit de l'API atteinte");
    else if (error instanceof Anthropic.AuthenticationError) console.error("[assistant] clé API refusée");
    else if (error instanceof Anthropic.APIError) console.error(`[assistant] erreur API ${error.status}`, error.message);
    else console.error("[assistant] échec", error);
    // Conversation en cours : on garde le brouillon et on invite à renvoyer le message ; au premier
    // échange, l'assistant guidé prend le relais. La personne n'est jamais bloquée.
    if (messages.some((m) => m.role === "assistant") && draftReady(draft)) {
      return {
        reply: "Petit souci de connexion avec l'assistant IA. Renvoie ton message dans un instant, ou crée ta page dès maintenant avec l'aperçu.",
        quickReplies: [],
        draft,
        ready: true,
        engine: "claude",
        remaining: ctx.dailyLimit - used,
      };
    }
    return { ...localAssistantTurn(messages, ctx), engine: "local", remaining: ctx.dailyLimit - used };
  }
}
