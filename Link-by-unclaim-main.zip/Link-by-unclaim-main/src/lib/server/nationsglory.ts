import "server-only";
import {
  NG_SERVER_KEYS,
  mockCountryList,
  mockNgCountry,
  mockNgProfile,
  ngFlagUrl,
  normalizeCountry,
  normalizeCountrySummary,
  roleLabel,
  type NgCountry,
  type NgCountrySummary,
  type NgPlayerServer,
  type NgProfile,
} from "../nationsglory-shared";
import { isValidMcUsername } from "../urls";
import { cachedStale } from "./cache";
import { env } from "./env";
import { rateLimit } from "./rate-limit";

// ─── Client de l'API publique NationsGlory v1 ────────────────────────────────
// https://publicapi.nationsglory.fr/v1 · clé dans l'en-tête X-API-Key (jamais dans l'URL).
// Quota par défaut : 60 requêtes / minute par clé. Chaque réponse est mise en cache
// selon la cadence de son domaine, et l'ancienne valeur est resservie en cas d'erreur.
// La clé reste sur le serveur : le navigateur passe toujours par /api/nationsglory/….

type NgMeta = { page?: { next_cursor?: string | null; has_more?: boolean; total?: number } };
type NgResult<T> = { ok: true; data: T; meta: NgMeta } | { ok: false; status: number; code: string };

const SERVER_SLUG = /^[a-z0-9-]{2,24}$/;

async function ngGet<T = unknown>(path: string): Promise<NgResult<T>> {
  // Garde-fou global : on reste sous le quota de la clé, toutes routes confondues.
  if (!rateLimit("ng-api-key", env.nationsglory.rateLimit, 60_000).ok) return { ok: false, status: 429, code: "rate_limited" };
  try {
    const res = await fetch(`${env.nationsglory.apiUrl}${path}`, {
      headers: { "X-API-Key": env.nationsglory.apiKey, Accept: "application/json" },
      cache: "no-store",
      signal: AbortSignal.timeout(6000),
    });
    const body = (await res.json().catch(() => null)) as { data?: T; meta?: NgMeta; code?: string } | null;
    if (!res.ok) {
      const code = body?.code ?? `http_${res.status}`;
      if (res.status === 401 || res.status === 403) console.error(`[nationsglory] clé refusée (${code}) — vérifie NATIONSGLORY_API_KEY et l'adresse IP déclarée`);
      return { ok: false, status: res.status, code };
    }
    return { ok: true, data: body?.data as T, meta: body?.meta ?? {} };
  } catch {
    return { ok: false, status: 503, code: "network_error" };
  }
}

function unavailableMessage(code: string): string {
  if (code === "rate_limited") return "Trop de demandes vers NationsGlory, réessaie dans une minute.";
  if (code === "domain_unavailable" || code === "upstream_unavailable") return "Le serveur NationsGlory ne publie pas ces données pour le moment.";
  return "Les données NationsGlory sont momentanément indisponibles.";
}

export function nationsGloryReady(): "mock" | "live" | "off" {
  if (env.nationsglory.mock) return "mock";
  return env.nationsglory.apiKey ? "live" : "off";
}

// ─── Serveurs ───────────────────────────────────────────────────────────────

export async function getNgServers(): Promise<{ slug: string; name: string }[]> {
  const fallback = NG_SERVER_KEYS.map((slug) => ({ slug, name: slug.charAt(0).toUpperCase() + slug.slice(1) }));
  if (nationsGloryReady() !== "live") return fallback;
  return cachedStale("ng:v1:servers", 6 * 3600, 7 * 86400, async () => {
    const r = await ngGet<{ slug: string; name: string }[]>("/servers");
    if (!r.ok || !Array.isArray(r.data)) return { ok: false, value: fallback };
    return { ok: true, value: r.data.filter((s) => SERVER_SLUG.test(s.slug)).map((s) => ({ slug: s.slug, name: String(s.name).slice(0, 32) })) };
  });
}

// ─── Pays ───────────────────────────────────────────────────────────────────

/** Tous les pays (avec au moins un membre) d'un serveur, pour le sélecteur et la recherche par nom. */
export async function listNgCountries(server: string): Promise<NgCountrySummary[]> {
  if (!SERVER_SLUG.test(server)) return [];
  const mode = nationsGloryReady();
  if (mode === "mock") return mockCountryList(server);
  if (mode === "off") return [];
  return cachedStale(`ng:v1:countries:${server}`, 30 * 60, 2 * 86400, async () => {
    const all: NgCountrySummary[] = [];
    let cursor: string | null = null;
    for (let page = 0; page < 12; page++) {
      const qs = new URLSearchParams({ limit: "100", sort: "-members_count" });
      if (cursor) qs.set("cursor", cursor);
      const r = await ngGet<unknown[]>(`/servers/${server}/countries?${qs}`);
      if (!r.ok) return { ok: false, value: [] };
      for (const row of Array.isArray(r.data) ? r.data : []) {
        const summary = normalizeCountrySummary(row);
        if (summary && summary.membersCount > 0) all.push(summary);
      }
      cursor = r.meta.page?.has_more ? (r.meta.page.next_cursor ?? null) : null;
      if (!cursor) break;
    }
    return { ok: true, value: all };
  });
}

export async function getNgCountry(server: string, countryIdOrName: string): Promise<NgCountry> {
  const input = countryIdOrName.trim();
  const base = (status: NgCountry["status"], message: string): NgCountry => ({
    ...mockNgCountry(server, input || "inconnu"),
    countryId: "",
    name: input,
    status,
    message,
    mock: false,
    members: [],
    badges: [],
    tags: [],
    description: "",
    leader: null,
    createdOn: null,
    membersCount: null,
    power: null,
    powerMax: null,
    claims: null,
    mmr: null,
    score: null,
  });
  if (!SERVER_SLUG.test(server) || input.length < 1 || input.length > 64) return base("invalid", "Pays ou serveur invalide.");
  const mode = nationsGloryReady();
  if (mode === "mock") return mockNgCountry(server, input);
  if (mode === "off") return base("not_configured", "La connexion à l'API NationsGlory n'est pas encore configurée.");

  // Les anciens blocs stockent un nom : on le résout via la liste du serveur.
  let countryId = input;
  if (!/^[0-9a-f-]{8,64}$/i.test(input)) {
    const match = (await listNgCountries(server)).find((c) => c.name.toLowerCase() === input.toLowerCase());
    if (!match) return base("not_found", "Aucun pays de ce nom sur ce serveur.");
    countryId = match.countryId;
  }

  return cachedStale(`ng:v1:country:${server}:${countryId}`, 5 * 60, 2 * 86400, async () => {
    const sheet = await ngGet(`/servers/${server}/countries/${encodeURIComponent(countryId)}`);
    if (!sheet.ok) {
      if (sheet.code === "entity_gone") return { ok: true, value: base("gone", "Ce pays a été dissous.") };
      if (sheet.status === 404) return { ok: true, value: base("not_found", "Pays introuvable sur ce serveur.") };
      return { ok: false, value: base("unavailable", unavailableMessage(sheet.code)) };
    }
    const members = await ngGet(`/servers/${server}/countries/${encodeURIComponent(countryId)}/members?limit=24&sort=role`);
    return { ok: true, value: normalizeCountry(server, sheet.data, members.ok ? members.data : []) };
  });
}

// ─── Joueurs ────────────────────────────────────────────────────────────────

async function playerOnServer(server: string, username: string): Promise<NgPlayerServer> {
  const empty: NgPlayerServer = { server, status: "unavailable", countryId: null, countryName: null, flagUrl: null, role: null, lastLoginOn: null };
  return cachedStale(`ng:v1:player:${server}:${username.toLowerCase()}`, 5 * 60, 2 * 86400, async () => {
    const player = await ngGet<{ username: string; country_id: string | null; role: string | null }>(
      `/servers/${server}/players/${encodeURIComponent(username)}`,
    );
    if (!player.ok) {
      if (player.code === "player_not_found" || player.status === 404) return { ok: true, value: { ...empty, status: "not_found" } };
      return { ok: false, value: empty };
    }
    const login = await ngGet<{ last_login_on: string }>(`/servers/${server}/players/${encodeURIComponent(username)}/last-login`);
    let countryName: string | null = null;
    let flagUrl: string | null = null;
    if (player.data.country_id) {
      const country = await getNgCountry(server, player.data.country_id);
      if (country.status === "ok") {
        countryName = country.name;
        flagUrl = country.flagUrl;
      }
    }
    return {
      ok: true,
      value: {
        server,
        status: "ok",
        countryId: player.data.country_id,
        countryName,
        flagUrl,
        role: roleLabel(player.data.role),
        lastLoginOn: login.ok ? (login.data.last_login_on ?? null) : null,
      },
    };
  });
}

/** Profil d'un joueur sur un à trois serveurs : pays, rang, drapeau, dernière connexion. */
export async function getNationsGloryProfile(username: string, servers: string[]): Promise<NgProfile> {
  const list = [...new Set(servers.filter((s) => SERVER_SLUG.test(s)))].slice(0, 3);
  const base = (status: NgProfile["status"], message?: string): NgProfile => ({
    username,
    status,
    message,
    servers: [],
    fetchedAt: new Date().toISOString(),
  });
  if (!isValidMcUsername(username)) return base("invalid", "Pseudo invalide.");
  if (!list.length) return base("invalid", "Choisis au moins un serveur.");
  const mode = nationsGloryReady();
  if (mode === "mock") return mockNgProfile(username, list);
  if (mode === "off") return base("not_configured", "La connexion à l'API NationsGlory n'est pas encore configurée.");

  const results = await Promise.all(list.map((s) => playerOnServer(s, username)));
  if (results.every((r) => r.status === "not_found")) return { ...base("not_found", "Ce pseudo n'a pas été vu sur ces serveurs depuis 90 jours."), servers: results };
  if (results.every((r) => r.status === "unavailable")) return { ...base("unavailable", unavailableMessage("upstream")), servers: results };
  return { ...base("ok"), servers: results };
}

export { ngFlagUrl };
