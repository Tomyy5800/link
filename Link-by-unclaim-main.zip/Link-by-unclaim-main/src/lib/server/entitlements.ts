import "server-only";
import type { User } from "@prisma/client";
import { SUBSCRIPTION_GRACE_DAYS, resolveFeatures, type Entitlements, type PlatformSettings } from "../features";
import type { PageContext } from "../page-schema";
import { maxTier, normalizeTier, type Tier } from "../plans";
import { env } from "./env";
import { getSettings } from "./settings";

// Droits d'un compte : formule (Gratuit, Link+, Pro, Équipe), rôle administrateur,
// partenariat, fonctionnalités et limites.

type Account = Pick<User, "role" | "plan" | "planExpiresAt" | "discordId" | "unclaimId"> &
  Partial<Pick<User, "partner" | "basePlan" | "subTier" | "subUntil" | "subRenews">>;

type PlanFields = Pick<User, "plan" | "planExpiresAt"> & Partial<Pick<User, "basePlan" | "subTier" | "subUntil">>;

export function isAdmin(user: Pick<User, "role" | "discordId" | "unclaimId"> | null | undefined): boolean {
  if (!user) return false;
  if (user.role === "admin") return true;
  // Administrateurs et fondateurs d'office, déclarés dans l'environnement du serveur.
  if (user.discordId && (env.adminDiscordIds.includes(user.discordId) || env.founderDiscordIds.includes(user.discordId))) return true;
  return Boolean(user.unclaimId && (env.adminUnclaimIds.includes(user.unclaimId) || env.founderUnclaimIds.includes(user.unclaimId)));
}

/** Formule d'un code, d'un don ou d'un ancien achat unique, encore active (repli : basePlan). */
export function planTier(user: PlanFields, now = Date.now()): Tier {
  const plan = normalizeTier(user.plan);
  if (plan !== "free" && (!user.planExpiresAt || user.planExpiresAt.getTime() > now)) return plan;
  return normalizeTier(user.basePlan ?? "free");
}

/** Formule de l'abonnement Stripe, tant que la période payée (délai de grâce compris) court. */
export function subscriptionTier(user: Partial<Pick<User, "subTier" | "subUntil">>, now = Date.now()): Tier {
  return user.subUntil && user.subUntil.getTime() > now ? normalizeTier(user.subTier) : "free";
}

/**
 * Formule en vigueur : la plus haute entre l'abonnement et les formules à durée (codes, dons,
 * anciens achats). Quand une formule temporaire se termine, le compte retrouve sa formule de
 * repli (basePlan) s'il en a une, sinon l'offre gratuite.
 */
export function activeTier(user: PlanFields, now = Date.now()): Tier {
  return maxTier(planTier(user, now), subscriptionTier(user, now));
}

export function isPremium(user: PlanFields | null | undefined, now = Date.now()): boolean {
  return Boolean(user) && activeTier(user!, now) !== "free";
}

/** Accès offert à tous : uniquement si l'administration l'a explicitement activé. */
export function freeForAll(settings: Pick<PlatformSettings, "launchFreeAccess">): boolean {
  return settings.launchFreeAccess;
}

export function entitlementsFrom(user: Account, settings: PlatformSettings, opts: { freeForAll?: boolean } = {}): Entitlements {
  const admin = isAdmin(user);
  const free = opts.freeForAll ?? freeForAll(settings);
  const partner = Boolean(user.partner);
  const bought = activeTier(user);
  const fromPlan = planTier(user);
  const fromSub = subscriptionTier(user);
  // Administrateurs (pour tester ce qu'ils ouvrent aux autres), accès offert et partenaires :
  // toutes les fonctions. Les fonctions « coupées » par l'administration restent coupées.
  const tier: Tier = admin || free || partner ? "team" : bought;
  const limitsTier = partner ? "partner" : admin || free ? maxTier(bought, "pro") : bought;
  const features = resolveFeatures(settings.features, tier);
  // Boutiques personnelles fermées : personne n'y a accès, quelle que soit la formule.
  if (!settings.personalShops) features.shop = false;
  return {
    tier,
    premium: tier !== "free",
    freeForAll: free,
    premiumUntil: fromPlan !== "free" && fromPlan === bought && normalizeTier(user.plan) === fromPlan && user.planExpiresAt ? user.planExpiresAt.toISOString() : null,
    // Fin de la période payée (sans le délai de grâce compté dans subUntil).
    subscription:
      fromSub !== "free" && user.subUntil
        ? { tier: fromSub, until: new Date(user.subUntil.getTime() - SUBSCRIPTION_GRACE_DAYS * 86_400_000).toISOString(), renews: Boolean(user.subRenews) }
        : null,
    personalShops: settings.personalShops,
    admin,
    partner,
    features,
    modes: settings.features,
    limits: settings.limits[limitsTier],
    premiumName: settings.premiumName,
    premiumUrl: settings.premiumUrl,
  };
}

export async function getEntitlements(user: Account): Promise<Entitlements> {
  return entitlementsFrom(user, await getSettings());
}

/** Ce que le rendu d'une page doit savoir de son propriétaire. */
export function pageContextFrom(user: Account & Pick<User, "verified">, settings: PlatformSettings): PageContext {
  return {
    features: entitlementsFrom(user, settings).features,
    verified: user.verified,
    partner: Boolean(user.partner),
    blockedDomains: settings.blockedDomains,
  };
}

/** Compte ou page suspendus par la modération de Link by Unclaim. */
export function suspension(user: Pick<User, "suspendedAt" | "suspendReason">, page?: { status: string; statusReason: string } | null) {
  if (user.suspendedAt) return { scope: "account" as const, reason: user.suspendReason };
  if (page?.status === "suspended") return { scope: "page" as const, reason: page.statusReason };
  return null;
}
