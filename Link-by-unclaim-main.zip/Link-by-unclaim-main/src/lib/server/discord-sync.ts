import "server-only";
import type { Badge, DiscordRoleLink } from "@prisma/client";
import { z } from "zod";
import { acceptsManualGrant, parseBadgeRule } from "../badges";
import { prisma } from "./db";
import { env } from "./env";
import { grantBadge, revokeBadge } from "./badges";

// Synchronisation des rôles du serveur Discord officiel avec les badges du staff.
//
// - Le bot (DISCORD_BOT_TOKEN, secret du serveur) lit les rôles des membres par l'API Discord.
// - Un compte Link n'est relié qu'au compte Discord prouvé par Unclaim Auth (connexion OAuth
//   Discord dans la passerelle) : personne ne peut déclarer le Discord de quelqu'un d'autre.
// - Seuls les badges à règle manuelle peuvent être associés à un rôle. Un badge donné à la main
//   n'est jamais retiré par la synchronisation : elle ne gère que ses propres attributions.

const DISCORD_API = "https://discord.com/api/v10";
const CONFIG_KEY = "discord-sync";
const STATUS_KEY = "discord-sync-status";
const ACTOR = "discord-sync";

export const discordConfigSchema = z.object({
  guildId: z.union([z.literal(""), z.string().regex(/^\d{15,22}$/, "Identifiant de serveur invalide (nombre de 15 à 22 chiffres).")]),
  enabled: z.boolean(),
  intervalMinutes: z.number().int().min(15).max(1440),
});
export type DiscordConfig = z.infer<typeof discordConfigSchema>;

export type DiscordSyncStatus = {
  lastRunAt: string | null;
  ok: boolean;
  message: string;
  mode: "list" | "members" | null;
  checked: number;
  granted: number;
  revoked: number;
  errors: string[];
};

const DEFAULT_CONFIG: DiscordConfig = { guildId: "", enabled: false, intervalMinutes: 60 };
const EMPTY_STATUS: DiscordSyncStatus = { lastRunAt: null, ok: false, message: "Jamais lancée.", mode: null, checked: 0, granted: 0, revoked: 0, errors: [] };

async function readSetting<T>(key: string, fallback: T): Promise<T> {
  const row = await prisma.appSetting.findUnique({ where: { key } }).catch(() => null);
  if (!row) return fallback;
  try {
    return { ...fallback, ...(JSON.parse(row.value) as T) };
  } catch {
    return fallback;
  }
}

async function writeSetting(key: string, value: unknown) {
  const serialized = JSON.stringify(value);
  await prisma.appSetting.upsert({ where: { key }, create: { key, value: serialized }, update: { value: serialized } });
}

export async function getDiscordConfig(): Promise<DiscordConfig> {
  const raw = await readSetting<DiscordConfig>(CONFIG_KEY, DEFAULT_CONFIG);
  const parsed = discordConfigSchema.safeParse(raw);
  return parsed.success ? parsed.data : DEFAULT_CONFIG;
}

export async function saveDiscordConfig(config: DiscordConfig): Promise<DiscordConfig> {
  const value = discordConfigSchema.parse(config);
  await writeSetting(CONFIG_KEY, value);
  return value;
}

export function getDiscordStatus(): Promise<DiscordSyncStatus> {
  return readSetting(STATUS_KEY, EMPTY_STATUS);
}

export class DiscordApiError extends Error {
  constructor(
    message: string,
    readonly status: number,
    readonly code?: number,
  ) {
    super(message);
  }
}

/** Appel authentifié par le bot. Respecte les limites de débit (429 : attente courte puis nouvel essai). */
export async function discordBotFetch<T>(path: string, attempt = 0): Promise<T> {
  if (!env.discordBot.configured) throw new DiscordApiError("Bot non configuré (DISCORD_BOT_TOKEN manquant).", 0);
  const res = await fetch(`${DISCORD_API}${path}`, {
    headers: { Authorization: `Bot ${env.discordBot.token}`, Accept: "application/json" },
    cache: "no-store",
    signal: AbortSignal.timeout(10_000),
  }).catch(() => null);
  if (!res) throw new DiscordApiError("API Discord injoignable.", 503);
  if (res.status === 429 && attempt < 3) {
    const body = (await res.json().catch(() => ({}))) as { retry_after?: number };
    const wait = Math.min(10, Math.max(0.5, Number(body.retry_after) || 1));
    await new Promise((r) => setTimeout(r, wait * 1000));
    return discordBotFetch<T>(path, attempt + 1);
  }
  const json = (await res.json().catch(() => ({}))) as T & { message?: string; code?: number };
  if (!res.ok) {
    const hint =
      res.status === 401
        ? "Jeton du bot refusé : vérifie DISCORD_BOT_TOKEN."
        : res.status === 403
          ? "Accès refusé : le bot doit être sur le serveur (et l'intention « Server Members » activée pour la lecture complète)."
          : res.status === 404
            ? "Introuvable (serveur, rôle ou membre)."
            : `Erreur Discord ${res.status}.`;
    throw new DiscordApiError(hint, res.status, json.code);
  }
  return json;
}

export type DiscordRole = { id: string; name: string; color: number; position: number; managed: boolean };

/** Vérifie le serveur et renvoie ses rôles (hors @everyone et rôles gérés par des intégrations). */
export async function fetchGuild(guildId: string): Promise<{ name: string; roles: DiscordRole[] }> {
  const [guild, roles] = await Promise.all([
    discordBotFetch<{ name: string }>(`/guilds/${guildId}`),
    discordBotFetch<DiscordRole[]>(`/guilds/${guildId}/roles`),
  ]);
  return {
    name: guild.name,
    roles: roles.filter((r) => r.id !== guildId && !r.managed).sort((a, b) => b.position - a.position),
  };
}

type Member = { user?: { id: string }; roles: string[] };

/** Rôles d'un membre (tableau vide s'il n'est pas sur le serveur). */
export async function memberRoles(guildId: string, discordId: string): Promise<string[]> {
  try {
    return (await discordBotFetch<Member>(`/guilds/${guildId}/members/${discordId}`)).roles ?? [];
  } catch (error) {
    if (error instanceof DiscordApiError && error.status === 404) return [];
    throw error;
  }
}

/** Liste complète des membres (intention « Server Members » requise), 10 000 au plus. */
async function listMembers(guildId: string): Promise<Map<string, string[]>> {
  const map = new Map<string, string[]>();
  let after = "0";
  for (let page = 0; page < 10; page++) {
    const batch = await discordBotFetch<Member[]>(`/guilds/${guildId}/members?limit=1000&after=${after}`);
    for (const m of batch) if (m.user) map.set(m.user.id, m.roles ?? []);
    if (batch.length < 1000) break;
    after = batch[batch.length - 1]!.user?.id ?? after;
  }
  return map;
}

type ActiveLink = DiscordRoleLink & { badge: Badge };

async function activeLinks(): Promise<ActiveLink[]> {
  const links = await prisma.discordRoleLink.findMany({ where: { enabled: true }, include: { badge: true } });
  return links.filter((l) => l.badge.active && !l.badge.archivedAt && acceptsManualGrant(parseBadgeRule(l.badge.rule)));
}

/**
 * Applique les rôles d'un compte : ajoute les badges des rôles détenus, retire (si la règle le
 * prévoit) ceux que la synchronisation avait donnés pour des rôles perdus.
 */
export async function applyRoles(userId: string, roles: string[], links: ActiveLink[]): Promise<{ granted: number; revoked: number }> {
  const held = new Set(roles);
  const wanted = new Map<string, Badge>();
  const keepOnLoss = new Set<string>();
  for (const link of links) {
    if (held.has(link.roleId)) wanted.set(link.badgeId, link.badge);
    if (!link.removeOnLoss) keepOnLoss.add(link.badgeId);
  }
  const grants = await prisma.userBadge.findMany({ where: { userId, badgeId: { in: [...new Set(links.map((l) => l.badgeId))] } } });
  let granted = 0;
  let revoked = 0;
  for (const [badgeId, badge] of wanted) {
    const existing = grants.find((g) => g.badgeId === badgeId);
    // Déjà détenu (à la main, par achat ou par une synchronisation précédente) : rien à faire.
    if (existing && existing.source !== "pref") continue;
    await grantBadge(prisma, { badge, userId, actorId: ACTOR, source: "discord", expiresAt: null });
    granted++;
  }
  for (const grant of grants) {
    if (grant.source !== "discord" || wanted.has(grant.badgeId) || keepOnLoss.has(grant.badgeId)) continue;
    const link = links.find((l) => l.badgeId === grant.badgeId);
    if (!link) continue;
    if (await revokeBadge(prisma, { badge: link.badge, userId, actorId: ACTOR, reason: "Rôle Discord perdu", onlySource: "discord" })) revoked++;
  }
  return { granted, revoked };
}

/** Synchronise un seul compte (à la connexion). Silencieux si rien n'est configuré. */
export async function syncDiscordUser(user: { id: string; discordId: string | null }): Promise<void> {
  if (!user.discordId || !env.discordBot.configured) return;
  const config = await getDiscordConfig();
  if (!config.enabled || !config.guildId) return;
  const links = await activeLinks();
  if (!links.length) return;
  try {
    await applyRoles(user.id, await memberRoles(config.guildId, user.discordId), links);
  } catch (error) {
    console.error("[discord] synchronisation du compte impossible", error instanceof Error ? error.message : error);
  }
}

const memory = globalThis as unknown as { __lbuDiscordSync?: Promise<DiscordSyncStatus> };

/** Synchronisation complète. Une seule à la fois par processus ; l'état est enregistré. */
export function runDiscordSync(): Promise<DiscordSyncStatus> {
  memory.__lbuDiscordSync ??= doSync().finally(() => {
    memory.__lbuDiscordSync = undefined;
  });
  return memory.__lbuDiscordSync;
}

async function doSync(): Promise<DiscordSyncStatus> {
  const status: DiscordSyncStatus = { ...EMPTY_STATUS, lastRunAt: new Date().toISOString(), errors: [] };
  const finish = async (ok: boolean, message: string) => {
    status.ok = ok;
    status.message = message;
    await writeSetting(STATUS_KEY, status).catch(() => undefined);
    return status;
  };
  if (!env.discordBot.configured) return finish(false, "Bot non configuré : ajoute DISCORD_BOT_TOKEN dans l'environnement du serveur.");
  const config = await getDiscordConfig();
  if (!config.guildId) return finish(false, "Aucun serveur Discord renseigné.");
  const links = await activeLinks();
  if (!links.length) return finish(true, "Aucune association active : rien à synchroniser.");

  const users = await prisma.user.findMany({ where: { discordId: { not: null }, deletedAt: null }, select: { id: true, discordId: true } });
  let members: Map<string, string[]> | null = null;
  try {
    members = await listMembers(config.guildId);
    status.mode = "list";
  } catch (error) {
    if (!(error instanceof DiscordApiError) || error.status !== 403) {
      return finish(false, error instanceof Error ? error.message : "Erreur inconnue.");
    }
    // Pas d'intention « Server Members » : lecture membre par membre (comptes les plus récents d'abord).
    status.mode = "members";
  }

  const pool = members ? users : users.slice(0, 300);
  for (const user of pool) {
    try {
      const roles = members ? (members.get(user.discordId!) ?? []) : await memberRoles(config.guildId, user.discordId!);
      const result = await applyRoles(user.id, roles, links);
      status.checked++;
      status.granted += result.granted;
      status.revoked += result.revoked;
    } catch (error) {
      if (status.errors.length < 5) status.errors.push(error instanceof Error ? error.message : "Erreur inconnue.");
      if (error instanceof DiscordApiError && (error.status === 401 || error.status === 403)) break;
    }
  }
  const partial = status.mode === "members" && users.length > pool.length ? ` (${pool.length} comptes sur ${users.length} : active l'intention « Server Members » du bot pour tout lire)` : "";
  return finish(status.errors.length === 0, `${status.checked} compte${status.checked > 1 ? "s" : ""} vérifié${status.checked > 1 ? "s" : ""}${partial}.`);
}

/** Lancée par les tâches périodiques quand l'intervalle est écoulé. */
export async function maybeRunDiscordSync(now = Date.now()): Promise<void> {
  if (!env.discordBot.configured) return;
  const config = await getDiscordConfig();
  if (!config.enabled || !config.guildId) return;
  const status = await getDiscordStatus();
  const last = status.lastRunAt ? Date.parse(status.lastRunAt) : 0;
  if (now - last < config.intervalMinutes * 60_000) return;
  await runDiscordSync();
}
