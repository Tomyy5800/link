import "server-only";
import type { MemberRole } from "@prisma/client";
import { ROLE_ICONS, parsePagePermissions, type MemberRoleView, type RoleIcon } from "../member-roles";
import { prisma } from "./db";

// Rôles personnalisés d'une page : lecture pour l'éditeur.

export function toRoleView(role: MemberRole & { _count?: { members: number } }): MemberRoleView {
  return {
    id: role.id,
    name: role.name,
    color: role.color,
    icon: (ROLE_ICONS as readonly string[]).includes(role.icon) ? (role.icon as RoleIcon) : "user",
    description: role.description,
    permissions: parsePagePermissions(role.permissions),
    members: role._count?.members ?? 0,
  };
}

export async function listPageRoles(pageId: string): Promise<MemberRoleView[]> {
  const roles = await prisma.memberRole.findMany({ where: { pageId }, orderBy: [{ position: "asc" }, { createdAt: "asc" }], include: { _count: { select: { members: true } } } });
  return roles.map(toRoleView);
}
