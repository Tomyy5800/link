import "server-only";
import { prisma } from "./db";

// Cache persistant (table CacheEntry) pour les appels aux API externes.
// Les requêtes simultanées sur une même clé sont fusionnées en une seule.

const inflight = new Map<string, Promise<unknown>>();

export type CacheResult<T> = { value: T; ttlSeconds: number };

export async function cached<T>(key: string, load: () => Promise<CacheResult<T>>): Promise<T> {
  const now = new Date();
  try {
    const hit = await prisma.cacheEntry.findUnique({ where: { key } });
    if (hit && hit.expiresAt > now) return JSON.parse(hit.value) as T;
  } catch {
    // Cache indisponible : on interroge directement la source.
  }

  const pending = inflight.get(key) as Promise<T> | undefined;
  if (pending) return pending;

  const task = (async () => {
    const { value, ttlSeconds } = await load();
    if (ttlSeconds > 0) {
      const expiresAt = new Date(Date.now() + ttlSeconds * 1000);
      const serialized = JSON.stringify(value);
      await prisma.cacheEntry
        .upsert({ where: { key }, create: { key, value: serialized, expiresAt }, update: { value: serialized, expiresAt } })
        .catch(() => undefined);
    }
    // Nettoyage opportuniste des entrées expirées.
    if (Math.random() < 0.02) {
      await prisma.cacheEntry.deleteMany({ where: { expiresAt: { lt: new Date() } } }).catch(() => undefined);
    }
    return value;
  })().finally(() => inflight.delete(key));

  inflight.set(key, task);
  return task;
}

type StaleEnvelope<T> = { savedAt: number; value: T };

/**
 * Cache avec repli : une valeur est « fraîche » pendant freshSeconds, puis rechargée.
 * Si le rechargement échoue (load renvoie ok: false), l'ancienne valeur est servie
 * tant qu'elle a moins de staleSeconds. Sans ancienne valeur, l'échec est renvoyé.
 */
export async function cachedStale<T>(
  key: string,
  freshSeconds: number,
  staleSeconds: number,
  load: () => Promise<{ ok: boolean; value: T }>,
): Promise<T> {
  const now = Date.now();
  let previous: StaleEnvelope<T> | null = null;
  try {
    const hit = await prisma.cacheEntry.findUnique({ where: { key } });
    if (hit && hit.expiresAt.getTime() > now) {
      previous = JSON.parse(hit.value) as StaleEnvelope<T>;
      if (now - previous.savedAt < freshSeconds * 1000) return previous.value;
    }
  } catch {
    previous = null;
  }

  const pendingKey = `stale:${key}`;
  const pending = inflight.get(pendingKey) as Promise<T> | undefined;
  if (pending) return pending;

  const task = (async () => {
    const result = await load().catch(() => ({ ok: false, value: undefined as unknown as T }));
    if (result.ok) {
      const envelope: StaleEnvelope<T> = { savedAt: Date.now(), value: result.value };
      const expiresAt = new Date(Date.now() + staleSeconds * 1000);
      const serialized = JSON.stringify(envelope);
      await prisma.cacheEntry
        .upsert({ where: { key }, create: { key, value: serialized, expiresAt }, update: { value: serialized, expiresAt } })
        .catch(() => undefined);
      return result.value;
    }
    return previous ? previous.value : result.value;
  })().finally(() => inflight.delete(pendingKey));

  inflight.set(pendingKey, task);
  return task;
}
