// Anniversaire (partagé, testable) : prochaine date à minuit, dans le fuseau du visiteur.
// Un anniversaire le 29 février est fêté le 28 les années non bissextiles.

const isLeap = (year: number) => (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;

/** Date de l'anniversaire une année donnée, à minuit heure locale. */
export function birthdayInYear(monthDay: string, year: number): Date | null {
  const match = monthDay.match(/^(\d{2})-(\d{2})$/);
  if (!match) return null;
  const month = Number(match[1]);
  const day = Number(match[2]);
  if (month < 1 || month > 12 || day < 1 || day > 31) return null;
  const actualDay = month === 2 && day === 29 && !isLeap(year) ? 28 : day;
  const date = new Date(year, month - 1, actualDay);
  return date.getMonth() === month - 1 ? date : null;
}

/** « MM-JJ » désigne un jour qui existe (le 29 février compris). */
export function isValidBirthday(monthDay: string): boolean {
  return birthdayInYear(monthDay, 2024) !== null;
}

/** Nombre de jours proposés pour un mois (février : 29, pour les anniversaires bissextiles). */
export function daysInMonth(month: number): number {
  return month === 2 ? 29 : new Date(2023, month, 0).getDate();
}

export type BirthdayInfo = {
  /** Minuit du prochain anniversaire (celui du jour s'il tombe aujourd'hui). */
  target: Date;
  isToday: boolean;
  /** Âge atteint à ce prochain anniversaire (null sans année de naissance). */
  turning: number | null;
};

export function nextBirthday(monthDay: string, now: Date, birthYear: number | null = null): BirthdayInfo | null {
  const thisYear = birthdayInYear(monthDay, now.getFullYear());
  if (!thisYear) return null;
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  let target = thisYear;
  const isToday = thisYear.getTime() === today.getTime();
  if (!isToday && thisYear < today) target = birthdayInYear(monthDay, now.getFullYear() + 1)!;
  const turning = birthYear ? target.getFullYear() - birthYear : null;
  return { target, isToday, turning: turning !== null && turning > 0 && turning < 150 ? turning : null };
}
