-- AlterTable
ALTER TABLE "Block" ADD COLUMN "endsAt" DATETIME;
ALTER TABLE "Block" ADD COLUMN "startsAt" DATETIME;

-- CreateTable
CREATE TABLE "LinkClick" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "pageId" TEXT NOT NULL,
    "blockId" TEXT NOT NULL,
    "day" TEXT NOT NULL,
    "count" INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT "LinkClick_pageId_fkey" FOREIGN KEY ("pageId") REFERENCES "Page" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_User" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "unclaimId" TEXT,
    "discordId" TEXT NOT NULL,
    "username" TEXT NOT NULL,
    "globalName" TEXT,
    "avatarHash" TEXT,
    "bannerHash" TEXT,
    "accentColor" INTEGER,
    "banned" BOOLEAN NOT NULL DEFAULT false,
    "discordSyncedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lastLoginAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);
INSERT INTO "new_User" ("accentColor", "avatarHash", "bannerHash", "createdAt", "discordId", "discordSyncedAt", "globalName", "id", "lastLoginAt", "updatedAt", "username") SELECT "accentColor", "avatarHash", "bannerHash", "createdAt", "discordId", "discordSyncedAt", "globalName", "id", "lastLoginAt", "updatedAt", "username" FROM "User";
DROP TABLE "User";
ALTER TABLE "new_User" RENAME TO "User";
CREATE UNIQUE INDEX "User_unclaimId_key" ON "User"("unclaimId");
CREATE UNIQUE INDEX "User_discordId_key" ON "User"("discordId");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;

-- CreateIndex
CREATE INDEX "LinkClick_pageId_day_idx" ON "LinkClick"("pageId", "day");

-- CreateIndex
CREATE UNIQUE INDEX "LinkClick_pageId_blockId_day_key" ON "LinkClick"("pageId", "blockId", "day");
