-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Order" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "userId" TEXT NOT NULL,
    "offerId" TEXT NOT NULL,
    "tier" TEXT NOT NULL DEFAULT 'plus',
    "offerName" TEXT NOT NULL,
    "days" INTEGER NOT NULL,
    "amountCents" INTEGER NOT NULL,
    "currency" TEXT NOT NULL DEFAULT 'eur',
    "status" TEXT NOT NULL DEFAULT 'pending',
    "provider" TEXT NOT NULL DEFAULT 'stripe',
    "providerRef" TEXT,
    "paymentRef" TEXT,
    "gift" BOOLEAN NOT NULL DEFAULT false,
    "giftCode" TEXT,
    "termsAcceptedAt" DATETIME,
    "paidAt" DATETIME,
    "refundedAt" DATETIME,
    "note" TEXT NOT NULL DEFAULT '',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "Order_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_Order" ("amountCents", "createdAt", "currency", "days", "gift", "giftCode", "id", "note", "offerId", "offerName", "paidAt", "paymentRef", "provider", "providerRef", "refundedAt", "status", "termsAcceptedAt", "updatedAt", "userId") SELECT "amountCents", "createdAt", "currency", "days", "gift", "giftCode", "id", "note", "offerId", "offerName", "paidAt", "paymentRef", "provider", "providerRef", "refundedAt", "status", "termsAcceptedAt", "updatedAt", "userId" FROM "Order";
DROP TABLE "Order";
ALTER TABLE "new_Order" RENAME TO "Order";
CREATE UNIQUE INDEX "Order_providerRef_key" ON "Order"("providerRef");
CREATE INDEX "Order_userId_createdAt_idx" ON "Order"("userId", "createdAt");
CREATE INDEX "Order_status_createdAt_idx" ON "Order"("status", "createdAt");
CREATE TABLE "new_PremiumCode" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "codeHash" TEXT NOT NULL,
    "hint" TEXT NOT NULL,
    "tier" TEXT NOT NULL DEFAULT 'plus',
    "days" INTEGER NOT NULL,
    "maxUses" INTEGER NOT NULL DEFAULT 1,
    "uses" INTEGER NOT NULL DEFAULT 0,
    "expiresAt" DATETIME,
    "disabled" BOOLEAN NOT NULL DEFAULT false,
    "note" TEXT NOT NULL DEFAULT '',
    "createdById" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO "new_PremiumCode" ("codeHash", "createdAt", "createdById", "days", "disabled", "expiresAt", "hint", "id", "maxUses", "note", "uses") SELECT "codeHash", "createdAt", "createdById", "days", "disabled", "expiresAt", "hint", "id", "maxUses", "note", "uses" FROM "PremiumCode";
DROP TABLE "PremiumCode";
ALTER TABLE "new_PremiumCode" RENAME TO "PremiumCode";
CREATE UNIQUE INDEX "PremiumCode_codeHash_key" ON "PremiumCode"("codeHash");
CREATE TABLE "new_User" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "unclaimId" TEXT,
    "discordId" TEXT,
    "provider" TEXT NOT NULL DEFAULT 'discord',
    "username" TEXT NOT NULL,
    "globalName" TEXT,
    "avatarUrl" TEXT,
    "avatarHash" TEXT,
    "bannerHash" TEXT,
    "accentColor" INTEGER,
    "identities" TEXT NOT NULL DEFAULT '[]',
    "ngAccount" TEXT,
    "banned" BOOLEAN NOT NULL DEFAULT false,
    "role" TEXT NOT NULL DEFAULT 'user',
    "plan" TEXT NOT NULL DEFAULT 'free',
    "planExpiresAt" DATETIME,
    "basePlan" TEXT NOT NULL DEFAULT 'free',
    "verified" BOOLEAN NOT NULL DEFAULT false,
    "suspendedAt" DATETIME,
    "suspendReason" TEXT NOT NULL DEFAULT '',
    "discordSyncedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lastLoginAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "termsVersion" TEXT NOT NULL DEFAULT '',
    "termsAcceptedAt" DATETIME,
    "partner" BOOLEAN NOT NULL DEFAULT false,
    "partnerSince" DATETIME,
    "deletedAt" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);
INSERT INTO "new_User" ("accentColor", "avatarHash", "avatarUrl", "banned", "bannerHash", "createdAt", "deletedAt", "discordId", "discordSyncedAt", "globalName", "id", "identities", "lastLoginAt", "ngAccount", "partner", "partnerSince", "plan", "planExpiresAt", "provider", "role", "suspendReason", "suspendedAt", "termsAcceptedAt", "termsVersion", "unclaimId", "updatedAt", "username", "verified") SELECT "accentColor", "avatarHash", "avatarUrl", "banned", "bannerHash", "createdAt", "deletedAt", "discordId", "discordSyncedAt", "globalName", "id", "identities", "lastLoginAt", "ngAccount", "partner", "partnerSince", "plan", "planExpiresAt", "provider", "role", "suspendReason", "suspendedAt", "termsAcceptedAt", "termsVersion", "unclaimId", "updatedAt", "username", "verified" FROM "User";
DROP TABLE "User";
ALTER TABLE "new_User" RENAME TO "User";
CREATE UNIQUE INDEX "User_unclaimId_key" ON "User"("unclaimId");
CREATE UNIQUE INDEX "User_discordId_key" ON "User"("discordId");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;

-- Link+ devient la première formule : l ancien plan « premium » est renommé « plus ».
UPDATE "User" SET "plan" = 'plus' WHERE "plan" = 'premium';
