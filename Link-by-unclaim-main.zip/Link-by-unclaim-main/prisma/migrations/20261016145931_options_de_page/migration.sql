-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Page" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "slug" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "displayName" TEXT NOT NULL,
    "pronouns" TEXT NOT NULL DEFAULT '',
    "bio" TEXT NOT NULL DEFAULT '',
    "avatarSource" TEXT NOT NULL DEFAULT 'discord',
    "avatarUrl" TEXT NOT NULL DEFAULT '',
    "bannerUrl" TEXT NOT NULL DEFAULT '',
    "ngUsername" TEXT NOT NULL DEFAULT '',
    "ngServer" TEXT NOT NULL DEFAULT 'blue',
    "theme" TEXT NOT NULL DEFAULT '{}',
    "customCss" TEXT NOT NULL DEFAULT '',
    "options" TEXT NOT NULL DEFAULT '{}',
    "published" BOOLEAN NOT NULL DEFAULT true,
    "status" TEXT NOT NULL DEFAULT 'active',
    "statusReason" TEXT NOT NULL DEFAULT '',
    "featured" BOOLEAN NOT NULL DEFAULT false,
    "views" INTEGER NOT NULL DEFAULT 0,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "Page_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_Page" ("avatarSource", "avatarUrl", "bannerUrl", "bio", "createdAt", "customCss", "displayName", "featured", "id", "ngServer", "ngUsername", "pronouns", "published", "slug", "status", "statusReason", "theme", "updatedAt", "userId", "views") SELECT "avatarSource", "avatarUrl", "bannerUrl", "bio", "createdAt", "customCss", "displayName", "featured", "id", "ngServer", "ngUsername", "pronouns", "published", "slug", "status", "statusReason", "theme", "updatedAt", "userId", "views" FROM "Page";
DROP TABLE "Page";
ALTER TABLE "new_Page" RENAME TO "Page";
CREATE UNIQUE INDEX "Page_slug_key" ON "Page"("slug");
CREATE UNIQUE INDEX "Page_userId_key" ON "Page"("userId");
CREATE INDEX "Page_status_idx" ON "Page"("status");
CREATE INDEX "Page_featured_idx" ON "Page"("featured");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
