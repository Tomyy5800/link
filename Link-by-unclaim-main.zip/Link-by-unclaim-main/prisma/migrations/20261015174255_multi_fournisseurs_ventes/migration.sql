-- CreateTable
CREATE TABLE "Order" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "userId" TEXT NOT NULL,
    "offerId" TEXT NOT NULL,
    "offerName" TEXT NOT NULL,
    "days" INTEGER NOT NULL,
    "amountCents" INTEGER NOT NULL,
    "currency" TEXT NOT NULL DEFAULT 'eur',
    "status" TEXT NOT NULL DEFAULT 'pending',
    "provider" TEXT NOT NULL DEFAULT 'stripe',
    "providerRef" TEXT,
    "paymentRef" TEXT,
    "gift" BOOLEAN NOT NULL DEFAULT false,
    "giftCode" TEXT,
    "termsAcceptedAt" DATETIME,
    "paidAt" DATETIME,
    "refundedAt" DATETIME,
    "note" TEXT NOT NULL DEFAULT '',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "Order_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_User" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "unclaimId" TEXT,
    "discordId" TEXT,
    "provider" TEXT NOT NULL DEFAULT 'discord',
    "username" TEXT NOT NULL,
    "globalName" TEXT,
    "avatarUrl" TEXT,
    "avatarHash" TEXT,
    "bannerHash" TEXT,
    "accentColor" INTEGER,
    "identities" TEXT NOT NULL DEFAULT '[]',
    "ngAccount" TEXT,
    "banned" BOOLEAN NOT NULL DEFAULT false,
    "role" TEXT NOT NULL DEFAULT 'user',
    "plan" TEXT NOT NULL DEFAULT 'free',
    "planExpiresAt" DATETIME,
    "verified" BOOLEAN NOT NULL DEFAULT false,
    "suspendedAt" DATETIME,
    "suspendReason" TEXT NOT NULL DEFAULT '',
    "discordSyncedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lastLoginAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);
INSERT INTO "new_User" ("accentColor", "avatarHash", "banned", "bannerHash", "createdAt", "discordId", "discordSyncedAt", "globalName", "id", "lastLoginAt", "plan", "planExpiresAt", "role", "suspendReason", "suspendedAt", "unclaimId", "updatedAt", "username", "verified") SELECT "accentColor", "avatarHash", "banned", "bannerHash", "createdAt", "discordId", "discordSyncedAt", "globalName", "id", "lastLoginAt", "plan", "planExpiresAt", "role", "suspendReason", "suspendedAt", "unclaimId", "updatedAt", "username", "verified" FROM "User";
DROP TABLE "User";
ALTER TABLE "new_User" RENAME TO "User";
CREATE UNIQUE INDEX "User_unclaimId_key" ON "User"("unclaimId");
CREATE UNIQUE INDEX "User_discordId_key" ON "User"("discordId");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;

-- CreateIndex
CREATE UNIQUE INDEX "Order_providerRef_key" ON "Order"("providerRef");

-- CreateIndex
CREATE INDEX "Order_userId_createdAt_idx" ON "Order"("userId", "createdAt");

-- CreateIndex
CREATE INDEX "Order_status_createdAt_idx" ON "Order"("status", "createdAt");
