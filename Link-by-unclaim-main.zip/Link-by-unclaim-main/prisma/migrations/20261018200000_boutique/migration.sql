-- CreateTable
CREATE TABLE "ShopOrder" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "pageId" TEXT NOT NULL,
    "blockId" TEXT NOT NULL,
    "items" TEXT NOT NULL,
    "total" INTEGER,
    "currency" TEXT NOT NULL DEFAULT 'EUR',
    "name" TEXT NOT NULL,
    "contact" TEXT NOT NULL,
    "note" TEXT NOT NULL DEFAULT '',
    "status" TEXT NOT NULL DEFAULT 'new',
    "senderHash" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "ShopOrder_pageId_fkey" FOREIGN KEY ("pageId") REFERENCES "Page" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateIndex
CREATE INDEX "ShopOrder_pageId_createdAt_idx" ON "ShopOrder"("pageId", "createdAt");

-- CreateIndex
CREATE INDEX "ShopOrder_pageId_status_idx" ON "ShopOrder"("pageId", "status");
