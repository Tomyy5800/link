-- CreateTable
CREATE TABLE "PageMember" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "pageId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "role" TEXT NOT NULL DEFAULT 'editor',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "PageMember_pageId_fkey" FOREIGN KEY ("pageId") REFERENCES "Page" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "PageMember_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "PageInvite" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "pageId" TEXT NOT NULL,
    "tokenHash" TEXT NOT NULL,
    "role" TEXT NOT NULL DEFAULT 'editor',
    "createdById" TEXT NOT NULL,
    "expiresAt" DATETIME NOT NULL,
    "usedAt" DATETIME,
    "usedById" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "PageInvite_pageId_fkey" FOREIGN KEY ("pageId") REFERENCES "Page" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "PartnerApplication" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "userId" TEXT NOT NULL,
    "kind" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "url" TEXT NOT NULL DEFAULT '',
    "audience" TEXT NOT NULL DEFAULT '',
    "message" TEXT NOT NULL DEFAULT '',
    "status" TEXT NOT NULL DEFAULT 'pending',
    "reviewNote" TEXT NOT NULL DEFAULT '',
    "reviewedById" TEXT,
    "reviewedAt" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "PartnerApplication_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "ContactMessage" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "pageId" TEXT NOT NULL,
    "blockId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "contact" TEXT NOT NULL DEFAULT '',
    "message" TEXT NOT NULL,
    "senderHash" TEXT NOT NULL,
    "read" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "ContactMessage_pageId_fkey" FOREIGN KEY ("pageId") REFERENCES "Page" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Page" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "slug" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "label" TEXT NOT NULL DEFAULT '',
    "displayName" TEXT NOT NULL,
    "pronouns" TEXT NOT NULL DEFAULT '',
    "bio" TEXT NOT NULL DEFAULT '',
    "avatarSource" TEXT NOT NULL DEFAULT 'discord',
    "avatarUrl" TEXT NOT NULL DEFAULT '',
    "bannerUrl" TEXT NOT NULL DEFAULT '',
    "ngUsername" TEXT NOT NULL DEFAULT '',
    "ngServer" TEXT NOT NULL DEFAULT 'blue',
    "theme" TEXT NOT NULL DEFAULT '{}',
    "customCss" TEXT NOT NULL DEFAULT '',
    "options" TEXT NOT NULL DEFAULT '{}',
    "published" BOOLEAN NOT NULL DEFAULT true,
    "status" TEXT NOT NULL DEFAULT 'active',
    "statusReason" TEXT NOT NULL DEFAULT '',
    "featured" BOOLEAN NOT NULL DEFAULT false,
    "views" INTEGER NOT NULL DEFAULT 0,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "Page_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_Page" ("avatarSource", "avatarUrl", "bannerUrl", "bio", "createdAt", "customCss", "displayName", "featured", "id", "ngServer", "ngUsername", "options", "pronouns", "published", "slug", "status", "statusReason", "theme", "updatedAt", "userId", "views") SELECT "avatarSource", "avatarUrl", "bannerUrl", "bio", "createdAt", "customCss", "displayName", "featured", "id", "ngServer", "ngUsername", "options", "pronouns", "published", "slug", "status", "statusReason", "theme", "updatedAt", "userId", "views" FROM "Page";
DROP TABLE "Page";
ALTER TABLE "new_Page" RENAME TO "Page";
CREATE UNIQUE INDEX "Page_slug_key" ON "Page"("slug");
CREATE INDEX "Page_userId_idx" ON "Page"("userId");
CREATE INDEX "Page_status_idx" ON "Page"("status");
CREATE INDEX "Page_featured_idx" ON "Page"("featured");
CREATE TABLE "new_User" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "unclaimId" TEXT,
    "discordId" TEXT,
    "provider" TEXT NOT NULL DEFAULT 'discord',
    "username" TEXT NOT NULL,
    "globalName" TEXT,
    "avatarUrl" TEXT,
    "avatarHash" TEXT,
    "bannerHash" TEXT,
    "accentColor" INTEGER,
    "identities" TEXT NOT NULL DEFAULT '[]',
    "ngAccount" TEXT,
    "banned" BOOLEAN NOT NULL DEFAULT false,
    "role" TEXT NOT NULL DEFAULT 'user',
    "plan" TEXT NOT NULL DEFAULT 'free',
    "planExpiresAt" DATETIME,
    "verified" BOOLEAN NOT NULL DEFAULT false,
    "suspendedAt" DATETIME,
    "suspendReason" TEXT NOT NULL DEFAULT '',
    "discordSyncedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lastLoginAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "termsVersion" TEXT NOT NULL DEFAULT '',
    "termsAcceptedAt" DATETIME,
    "partner" BOOLEAN NOT NULL DEFAULT false,
    "partnerSince" DATETIME,
    "deletedAt" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);
INSERT INTO "new_User" ("accentColor", "avatarHash", "avatarUrl", "banned", "bannerHash", "createdAt", "discordId", "discordSyncedAt", "globalName", "id", "identities", "lastLoginAt", "ngAccount", "plan", "planExpiresAt", "provider", "role", "suspendReason", "suspendedAt", "unclaimId", "updatedAt", "username", "verified") SELECT "accentColor", "avatarHash", "avatarUrl", "banned", "bannerHash", "createdAt", "discordId", "discordSyncedAt", "globalName", "id", "identities", "lastLoginAt", "ngAccount", "plan", "planExpiresAt", "provider", "role", "suspendReason", "suspendedAt", "unclaimId", "updatedAt", "username", "verified" FROM "User";
DROP TABLE "User";
ALTER TABLE "new_User" RENAME TO "User";
CREATE UNIQUE INDEX "User_unclaimId_key" ON "User"("unclaimId");
CREATE UNIQUE INDEX "User_discordId_key" ON "User"("discordId");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;

-- CreateIndex
CREATE INDEX "PageMember_userId_idx" ON "PageMember"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "PageMember_pageId_userId_key" ON "PageMember"("pageId", "userId");

-- CreateIndex
CREATE UNIQUE INDEX "PageInvite_tokenHash_key" ON "PageInvite"("tokenHash");

-- CreateIndex
CREATE INDEX "PageInvite_pageId_idx" ON "PageInvite"("pageId");

-- CreateIndex
CREATE INDEX "PartnerApplication_status_createdAt_idx" ON "PartnerApplication"("status", "createdAt");

-- CreateIndex
CREATE INDEX "PartnerApplication_userId_idx" ON "PartnerApplication"("userId");

-- CreateIndex
CREATE INDEX "ContactMessage_pageId_createdAt_idx" ON "ContactMessage"("pageId", "createdAt");
