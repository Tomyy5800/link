// Crée une page d'exemple publique (/exemple) pour découvrir le rendu sans se connecter.
// Usage : npm run db:seed
import path from "node:path";
import { PrismaClient } from "@prisma/client";
import { createBlock } from "../src/lib/blocks";
import { getPreset } from "../src/lib/theme";

// Même résolution que src/lib/server/db.ts : un chemin SQLite relatif part du dossier prisma/.
const url = process.env.DATABASE_URL;
const prisma = new PrismaClient({
  datasourceUrl: url && /^file:\.\.?\//.test(url) ? `file:${path.resolve(__dirname, url.slice(5))}` : url,
});

async function main() {
  const user = await prisma.user.upsert({
    where: { discordId: "100000000000000003" },
    create: { discordId: "100000000000000003", username: "exemple.unclaim", globalName: "Exemple", accentColor: 0x5865f2 },
    update: {},
  });

  const blocks = [
    createBlock("socials", {
      items: [
        { platform: "twitch", url: "https://twitch.tv" },
        { platform: "youtube", url: "https://youtube.com" },
        { platform: "discord", url: "https://discord.gg/discord-developers" },
      ],
    }),
    createBlock("discord", { note: "Écris-moi pour une alliance !" }),
    { ...createBlock("nationsglory", {}), width: "half" as const },
    { ...createBlock("skin", { animation: "walk", height: 300 }), width: "half" as const },
    createBlock("heading", { text: "Mes liens" }),
    createBlock("link", { label: "Mon serveur Discord", url: "https://discord.gg/discord-developers", highlight: true }),
    createBlock("text", { text: "**Bienvenue !** Cette page a été créée par le script de démonstration.\n-# Modifie-la ou supprime-la librement." }),
  ];

  await prisma.page.deleteMany({ where: { userId: user.id } });
  await prisma.page.create({
    data: {
      slug: "exemple",
      userId: user.id,
      displayName: "Exemple",
      bio: "Une page **Link by Unclaim** de démonstration.\n-# Profil NationsGlory, skin 3D, liens et réseaux.",
      ngUsername: "Unclaim_Demo",
      theme: JSON.stringify(getPreset("aurora")!.theme),
      blocks: {
        create: blocks.map((block, position) => ({
          id: block.id,
          type: block.type,
          position,
          width: block.width,
          visible: block.visible,
          data: JSON.stringify(block.data),
        })),
      },
    },
  });
  console.log("✓ Page d'exemple disponible sur /exemple");
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
