import type { NextConfig } from "next";

const securityHeaders = [
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "X-Frame-Options", value: "DENY" },
  { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=(), payment=()" },
];

const nextConfig: NextConfig = {
  poweredByHeader: false,
  // Serveur autonome (.next/standalone) pour l'image Docker uniquement : `npm start` garde `next start`.
  output: process.env.NEXT_OUTPUT === "standalone" ? "standalone" : undefined,
  // Racine explicite : évite que Next remonte jusqu'à un package-lock.json parent.
  turbopack: { root: process.cwd() },
  outputFileTracingRoot: process.cwd(),
  // En développement, autorise aussi http://127.0.0.1:3000 (en plus de localhost).
  allowedDevOrigins: ["127.0.0.1"],
  async headers() {
    return [{ source: "/:path*", headers: securityHeaders }];
  },
  // Les navigateurs demandent /favicon.ico : on sert l'icône du site plutôt qu'une 404.
  async rewrites() {
    return [{ source: "/favicon.ico", destination: "/icon.svg" }];
  },
};

export default nextConfig;
