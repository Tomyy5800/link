# Logos

- `link-mark.svg` : le symbole sur sa tuile `surface` (#0f172b), chunks `claim` (#ffc247) et `signal` (#22c9e8). Icône d'application, favicon, avatar de compte.
- `link-mark-light.svg` : symbole une encre, `ink` du thème Nuit (#f8fafc), pour fonds sombres.
- `link-mark-dark.svg` : symbole une encre, `ink` du thème Jour (#0b1120), pour fonds clairs.

Le logotype n'existe pas en image : compose-le en texte (voir le composant Logo).
