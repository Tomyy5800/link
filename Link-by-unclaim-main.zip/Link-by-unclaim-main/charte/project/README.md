Link by Unclaim transforme une bio Discord en page de profil. L'application appartient à la famille Unclaim : elle reprend la nuit, les liserés, la grille HUD et la couleur d'action d'Unclaim Auth, et y ajoute sa propre signature, l'ambre `claim`. L'idée qui tient le tout : **la carte des chunks**. Sur un serveur comme NationsGlory, un terrain se revendique chunk par chunk ; Link est le chunk que chaque joueur revendique sur le web, relié au reste par Unclaim.

Cette charte habille l'application (landing, connexion, éditeur, e-mails, visuels). Les pages publiques des utilisateurs gardent leurs propres thèmes : la charte n'y signe que le pied de page.

## Voix et contenu

- Tutoie toujours, en français. Phrases courtes, verbe en tête : « Crée ta page », « Copier le lien », « Ajouter un bloc ».
- Un bouton dit exactement ce qui se passe, puis l'état confirme : « Enregistrer » → « Enregistré ».
- Une erreur dit ce qui ne va pas et comment corriger : « Cette adresse est déjà prise. » plutôt que « Erreur ».
- Pas d'emoji, pas de point d'exclamation, sauf dans un message de réussite rare.
- Micro-libellés en capitales, style `label` : « ADRESSE DE TA PAGE », « STATISTIQUES ».
- Écriture inclusive au point médian quand un participe vise la personne : « Connecté·e avec Google ».
- Nomme les services tels qu'ils s'appellent : Discord, Google, Twitch, NationsGlory, Unclaim Auth. Jamais « le SSO » ni « l'OAuth » face à l'utilisateur.

## Couleur

- Pose l'application sur `ground`, les panneaux sur `surface`, ce qui flotte ou se survole sur `surface-raised`. Une barre collante prend `ground-elevated`.
- `signal` est la seule couleur d'action : bouton principal, lien, onglet actif, interrupteur allumé, anneau de focus. Le texte sur un aplat `signal` est `on-signal`, jamais du blanc en dur.
- `claim` signe Link : le chunk ambre du logo, la mise en avant d'un élément, les chunks « revendiqués » des illustrations et états vides. N'en mets jamais plus d'une touche par écran, et jamais pour un état.
- Les couleurs de marque des fournisseurs (Discord, Google, Twitch…) ne servent qu'à leurs boutons « Continuer avec … », qui partent par Unclaim Auth.
- **Link+** signe l'offre payante : le symbole Link et un « + » de cinq chunks ambre (`logos/link-plus-mark.svg`, `link-plus-mark-light.svg`, `link-plus-lockup.svg`). Il remplace le symbole Link seulement là où l'on parle de l'offre (page des tarifs, carte Link+ de l'éditeur).
- Les statuts `ok`, `warn` et `danger` s'accompagnent toujours d'une icône et d'un mot : la couleur seule ne porte jamais l'information.
- Sépare par des liserés (`line`) plutôt que par des ombres. Un contrôle se délimite avec `line-control` (3:1 minimum).
- Le thème Nuit est celui du produit. Le thème Jour sert aux documents imprimés, aux e-mails et à un futur mode clair : mêmes rôles, valeurs ajustées pour garder 4,5:1.

## Grille et carte des chunks

- Pose la grille HUD sur `ground` : des lignes `grid` tous les `space-16` (64 px), fixes au défilement, comme sur Unclaim Auth.
- Les illustrations et états vides se construisent en chunks : des carrés de `space-4` de côté, coins `radius-xs`, alignés sur une grille. Quelques chunks pleins en `claim` (revendiqués), un en `signal` (relié), le reste en contour `line`.
- Pas de dégradé décoratif, pas de halo coloré derrière les titres.

## Typographie

- `display-xl`, `display` et `title` en Chakra Petch : titres et grands chiffres seulement, jamais un paragraphe.
- `heading`, `body` et `body-sm` en Inter pour toute l'interface. Garde le texte courant autour de 65 caractères de large.
- `label` et `data` en JetBrains Mono : micro-libellés, adresses de page (`ton-domaine/ton-pseudo`), identifiants `uncl_…`, valeurs à copier.
- Chiffres alignés en colonne : `font-variant-numeric: tabular-nums`.

## Formes et profondeur

- `radius-sm` pour les boutons, champs et segments ; `radius-md` pour les panneaux ; `radius-lg` pour les grands conteneurs (cadre d'aperçu, carte de connexion) ; `radius-pill` pour les puces de statut et interrupteurs, rien d'autre.
- Un panneau HUD porte quatre équerres d'angle de 8 px en `line-control` et un micro-libellé en tête : réserve-le aux panneaux qui résument (statistiques, compte, adresse).
- `shadow-float` uniquement pour ce qui flotte : menus, cadre d'aperçu, barre mobile.

## Interaction et mouvement

- Focus clavier : `focus-ring` sur tous les contrôles, sans exception.
- Survol : changement de fond ou de liseré en 150 ms ; ouverture de panneau en 220 ms ; courbe ease-out.
- Un élément « en direct » (statut Discord, compteur) peut pulser doucement en `signal`. Coupe toute animation sous `prefers-reduced-motion`.

## Iconographie

- Icônes Lucide, trait de 1,75, à 16 px dans les contrôles et 20 px dans les titres, en `currentColor`.
- Logos de plateformes (Discord, YouTube, Twitch…) en tracés simple-icons, monochromes, à la couleur du texte.
- Pas d'emoji comme icône.

## Logo

- Le symbole : deux chunks entrelacés, l'ambre `claim` pour Link, le cyan `signal` pour Unclaim. Les deux se croisent en dessus-dessous : ne supprime jamais ces coupures.
- `link-mark.svg` (tuile `surface`) pour l'icône d'application, le favicon et les avatars de compte.
- `link-mark-light.svg` sur fond sombre et `link-mark-dark.svg` sur fond clair quand une seule encre est possible.
- Le logotype se compose en texte : « Link » en Chakra Petch 700, `ink`, puis « by Unclaim » en JetBrains Mono, `ink-muted`, à 70 % de la hauteur de « Link ».
- Laisse autour du symbole une marge d'un quart de sa largeur ; ne descends pas sous 16 px. Ne recolore pas les chunks, ne les tourne pas, ne les ombre pas.

## Accessibilité

- Chaque couleur de texte indique dans sa note les fonds où elle tient 4,5:1 ; reste sur ces fonds.
- `ink-faint` ne porte jamais un texte à lire : seulement un état désactivé ou un repère secondaire.
- Les cibles tactiles font au moins 40 × 40 px dans l'éditeur.
