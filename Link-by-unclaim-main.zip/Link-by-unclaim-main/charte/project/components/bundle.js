/* @ds-bundle: {"format":4,"namespace":"LinkUI","components":[{"name":"Button"},{"name":"Field"},{"name":"Toggle"},{"name":"Chip"},{"name":"Panel"},{"name":"Logo"}]} */
(function () {
  var React = window.React;
  var h = React.createElement;
  var uid = 0;

  function cx() {
    return Array.prototype.filter.call(arguments, Boolean).join(" ");
  }

  function omit(obj, keys) {
    var out = {};
    for (var k in obj) if (Object.prototype.hasOwnProperty.call(obj, k) && keys.indexOf(k) === -1) out[k] = obj[k];
    return out;
  }

  /** Bouton. variant : primary (signal) | secondary (liseré) | ghost | discord. */
  function Button(props) {
    var variant = props.variant || "secondary";
    var size = props.size || "md";
    var rest = omit(props, ["variant", "size", "icon", "className", "children"]);
    return h(
      "button",
      Object.assign({ type: "button" }, rest, {
        className: cx("lk-btn", "lk-btn--" + variant, size === "sm" && "lk-btn--sm", props.className),
      }),
      props.icon ? h("span", { className: "lk-btn__icon", "aria-hidden": "true" }, props.icon) : null,
      props.children
    );
  }

  /** Champ de saisie avec libellé, aide, erreur et préfixe optionnel. */
  function Field(props) {
    var idRef = React.useRef(null);
    if (!idRef.current) idRef.current = "lk-field-" + ++uid;
    var id = props.id || idRef.current;
    var rest = omit(props, ["label", "hint", "error", "prefix", "id", "className"]);
    var describedBy = props.error || props.hint ? id + "-note" : undefined;
    return h(
      "div",
      { className: cx("lk-field", props.className) },
      h("label", { className: "lk-field__label", htmlFor: id }, props.label),
      h(
        "div",
        { className: "lk-field__row" },
        props.prefix ? h("span", { className: "lk-field__prefix" }, props.prefix) : null,
        h(
          "input",
          Object.assign({}, rest, {
            id: id,
            className: cx("lk-input", props.prefix && "lk-input--prefixed"),
            "aria-invalid": props.error ? true : undefined,
            "aria-describedby": describedBy,
          })
        )
      ),
      props.error
        ? h("p", { id: id + "-note", className: "lk-field__error", role: "alert" }, props.error)
        : props.hint
          ? h("p", { id: id + "-note", className: "lk-field__hint" }, props.hint)
          : null
    );
  }

  /** Interrupteur (role switch). Contrôlé si checked est fourni. */
  function Toggle(props) {
    var state = React.useState(!!props.defaultChecked);
    var checked = props.checked !== undefined ? props.checked : state[0];
    function flip() {
      if (props.checked === undefined) state[1](!checked);
      if (props.onChange) props.onChange(!checked);
    }
    return h(
      "div",
      { className: "lk-toggle" },
      h(
        "span",
        { className: "lk-toggle__text" },
        h("span", { className: "lk-toggle__label" }, props.label),
        props.description ? h("span", { className: "lk-toggle__desc" }, props.description) : null
      ),
      h(
        "button",
        {
          type: "button",
          role: "switch",
          "aria-checked": checked,
          "aria-label": props.label,
          disabled: props.disabled,
          className: "lk-switch",
          onClick: flip,
        },
        h("span", { className: "lk-switch__thumb" })
      )
    );
  }

  /** Puce. tone : neutral | signal | claim | ok | warn | danger. mono : libellé façon donnée. */
  function Chip(props) {
    var tone = props.tone || "neutral";
    return h(
      "span",
      { className: cx("lk-chip", "lk-chip--" + tone, props.mono && "lk-chip--mono") },
      props.dot ? h("span", { className: "lk-chip__dot", "aria-hidden": "true" }) : null,
      props.children
    );
  }

  /** Panneau. hud : équerres d'angle + micro-libellé en tête (label). */
  function Panel(props) {
    return h(
      "section",
      { className: cx("lk-panel", props.hud && "lk-panel--hud", props.className), "aria-label": props.label },
      props.hud ? h("span", { className: "lk-panel__corners", "aria-hidden": "true" }) : null,
      props.label ? h("p", { className: "lk-panel__label" }, props.label) : null,
      props.children
    );
  }

  /** Logo : symbole aux deux chunks entrelacés + logotype en texte. */
  function Logo(props) {
    var size = props.size || 28;
    var idRef = React.useRef(null);
    if (!idRef.current) idRef.current = "lk-logo-" + ++uid;
    var a = idRef.current + "-a";
    var b = idRef.current + "-b";
    var mark = h(
      "svg",
      { viewBox: "0 0 64 64", width: size, height: size, "aria-hidden": "true", className: "lk-logo__mark" },
      h(
        "defs",
        null,
        h("mask", { id: a, maskUnits: "userSpaceOnUse", x: 0, y: 0, width: 64, height: 64 },
          h("rect", { width: 64, height: 64, fill: "#fff" }),
          h("rect", { x: 21.5, y: 31, width: 9, height: 14, fill: "#000" })),
        h("mask", { id: b, maskUnits: "userSpaceOnUse", x: 0, y: 0, width: 64, height: 64 },
          h("rect", { width: 64, height: 64, fill: "#fff" }),
          h("rect", { x: 33.5, y: 19, width: 9, height: 14, fill: "#000" }))
      ),
      props.tile === false ? null : h("rect", { className: "lk-logo__tile", width: 64, height: 64, rx: 14 }),
      h("rect", { className: "lk-logo__b", x: 26, y: 26, width: 24, height: 24, rx: 3, mask: "url(#" + b + ")" }),
      h("rect", { className: "lk-logo__a", x: 14, y: 14, width: 24, height: 24, rx: 3, mask: "url(#" + a + ")" })
    );
    if (props.markOnly) return h("span", { className: "lk-logo", role: "img", "aria-label": "Link by Unclaim" }, mark);
    return h(
      "span",
      { className: "lk-logo", role: "img", "aria-label": "Link by Unclaim", style: { "--lk-logo-size": size + "px" } },
      mark,
      h("span", { className: "lk-logo__word", "aria-hidden": "true" }, "Link", h("span", { className: "lk-logo__by" }, "by Unclaim"))
    );
  }

  window.LinkUI = Object.assign(window.LinkUI || {}, {
    Button: Button,
    Field: Field,
    Toggle: Toggle,
    Chip: Chip,
    Panel: Panel,
    Logo: Logo,
  });
})();
