# Chip

La puce étiquette un état ou une donnée courte : statut d'enregistrement, serveur NationsGlory, badge « Nouveau ».

- `tone` choisit le rôle : `signal` (actif, relié), `claim` (mis en avant, une seule touche par écran), `ok`, `warn`, `danger` (toujours avec un mot), `neutral` par défaut.
- `mono` pour une donnée ou un statut technique (« DÉMO ») ; `dot` pour un statut en direct.
- Le consommateur fournit le texte, court (un à trois mots).
- Ne pas : rendre une puce cliquable sans lui donner l'apparence d'un bouton.
