# Logo

Le logo de Link by Unclaim : deux chunks entrelacés (`claim` pour Link, `signal` pour Unclaim) suivis du logotype composé en texte.

- `size` règle le côté du symbole en px (16 minimum) ; le logotype suit à 68 % de cette taille.
- `markOnly` pour le symbole seul (favicon, avatar de compte, barre mobile) ; `tile={false}` pour le poser sans tuile sur un fond déjà `surface`.
- Laisse une marge d'un quart de la largeur du symbole tout autour.
- Ne pas : recolorer les chunks, supprimer les coupures du croisement, composer « by Unclaim » dans une autre police que JetBrains Mono.
