# Toggle

L'interrupteur active ou désactive un réglage qui s'applique tout de suite, sans bouton « Valider ».

- Le consommateur fournit `label`, `checked` et `onChange` ; `description` précise l'effet en une ligne.
- Allumé : piste `signal`, curseur `on-signal`. Éteint : piste `surface-raised`, bordure `line-control`.
- Ne pas : l'utiliser pour une action ponctuelle (prendre un Button) ou pour un choix entre plus de deux options (prendre un segment).
