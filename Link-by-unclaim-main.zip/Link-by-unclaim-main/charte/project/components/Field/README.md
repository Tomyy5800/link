# Field

Le champ de saisie de l'éditeur : un libellé au-dessus, une aide ou une erreur en dessous, jamais les deux à la fois.

- Le consommateur fournit `label`, `value` et `onChange` ; `hint` explique à quoi sert la valeur, `error` dit ce qui ne va pas et comment corriger.
- `prefix` affiche en JetBrains Mono ce qui précède la valeur, typiquement le domaine devant l'adresse de page.
- Bordure `line-control`, focus `focus-ring` et bordure `signal`, erreur en `danger` avec le message.
- Ne pas : remplacer le libellé par un placeholder, signaler une erreur avant que la personne ait fini de taper.
