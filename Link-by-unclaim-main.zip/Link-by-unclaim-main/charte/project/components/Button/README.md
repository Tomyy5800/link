# Button

Le bouton déclenche une action ; son libellé commence par un verbe et dit exactement ce qui se passe (« Créer ma page », « Copier le lien »).

- `primary` (aplat `signal`, texte `on-signal`) : l'action pour laquelle l'écran existe, une seule fois par vue.
- `secondary` (liseré `line-control`) : toutes les autres actions.
- `ghost` : actions tertiaires dans une barre d'outils (déconnexion, fermer).
- `discord` : uniquement « Continuer avec Discord », qui ouvre Unclaim Auth.
- Le consommateur fournit le libellé, `onClick`, et éventuellement une icône Lucide de 16 px via `icon`.
- Ne pas : mettre deux `primary` côte à côte, écrire le libellé en capitales, utiliser `claim` comme couleur de bouton.
