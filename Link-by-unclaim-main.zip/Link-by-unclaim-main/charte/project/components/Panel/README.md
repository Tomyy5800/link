# Panel

Le panneau regroupe un ensemble de réglages ou un résumé ; un micro-libellé en capitales le nomme.

- Le consommateur fournit `label` (le micro-libellé, aussi nom accessible) et le contenu.
- `hud` ajoute les quatre équerres d'angle d'Unclaim : réserve-le aux panneaux qui résument (statistiques, compte relié, adresse de page), un ou deux par écran.
- Fond `surface`, liseré `line`, coins `radius-md` (`radius-xs` en version HUD).
- Ne pas : imbriquer un panneau dans un panneau, ajouter une ombre (les panneaux ne flottent pas).
