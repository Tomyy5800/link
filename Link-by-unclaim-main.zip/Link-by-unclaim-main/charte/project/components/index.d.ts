import type * as React from "react";

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** primary : action principale (signal), une par écran · secondary : liseré · ghost : discret · discord : connexion via Unclaim Auth uniquement. */
  variant?: "primary" | "secondary" | "ghost" | "discord";
  size?: "md" | "sm";
  /** Icône Lucide de 16 px, placée avant le libellé. */
  icon?: React.ReactNode;
}
export declare function Button(props: ButtonProps): React.ReactElement;

export interface FieldProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "prefix"> {
  label: string;
  /** Aide sous le champ (body-sm, ink-muted). Masquée quand error est présent. */
  hint?: string;
  /** Message d'erreur : ce qui ne va pas et comment corriger. */
  error?: string;
  /** Préfixe en JetBrains Mono, par exemple le domaine devant l'adresse de page. */
  prefix?: string;
}
export declare function Field(props: FieldProps): React.ReactElement;

export interface ToggleProps {
  label: string;
  description?: string;
  checked?: boolean;
  defaultChecked?: boolean;
  disabled?: boolean;
  onChange?: (checked: boolean) => void;
}
export declare function Toggle(props: ToggleProps): React.ReactElement;

export interface ChipProps {
  tone?: "neutral" | "signal" | "claim" | "ok" | "warn" | "danger";
  /** Libellé en capitales JetBrains Mono (données, statuts techniques). */
  mono?: boolean;
  /** Pastille de couleur avant le libellé (statut en direct). */
  dot?: boolean;
  children?: React.ReactNode;
}
export declare function Chip(props: ChipProps): React.ReactElement;

export interface PanelProps {
  /** Micro-libellé en tête, en capitales. Sert aussi de nom accessible. */
  label?: string;
  /** Équerres d'angle HUD : panneaux qui résument (statistiques, compte, adresse). */
  hud?: boolean;
  className?: string;
  children?: React.ReactNode;
}
export declare function Panel(props: PanelProps): React.ReactElement;

export interface LogoProps {
  /** Côté du symbole en px (16 minimum). */
  size?: number;
  /** Symbole seul, sans logotype. */
  markOnly?: boolean;
  /** false : symbole sans tuile de fond. */
  tile?: boolean;
}
export declare function Logo(props: LogoProps): React.ReactElement;

declare global {
  interface Window {
    LinkUI: {
      Button: typeof Button;
      Field: typeof Field;
      Toggle: typeof Toggle;
      Chip: typeof Chip;
      Panel: typeof Panel;
      Logo: typeof Logo;
    };
  }
}
