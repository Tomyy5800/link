// Construit le paquet à déposer sur un serveur Pterodactyl (egg « Node.js » générique).
//
//   npm run build:pterodactyl            → deploy/link-by-unclaim-pterodactyl.zip
//   npm run build:pterodactyl -- --x64   sans les moteurs ARM64 (paquet plus léger)
//
// Le build se fait dans une copie du projet (dossier temporaire du système) : un `npm start`
// lancé ici continue de servir son propre build, et le .env local (secrets, adresses de
// développement) n'entre ni dans le build ni dans le paquet. Le paquet contient le serveur
// Next.js autonome, les moteurs Prisma pour Linux (Debian x64 et ARM64), la CLI Prisma pour les
// migrations, start.js (le « Main file » de l'egg) et .env.example. Guide : docs/PTERODACTYL.md
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import { createRequire } from "node:module";
import os from "node:os";
import path from "node:path";

const ROOT = path.resolve(import.meta.dirname, "..");
const WORK = path.join(fs.realpathSync.native(os.tmpdir()), "lbu-pterodactyl");
const COPY = path.join(WORK, "projet");
const OUT = path.join(WORK, "paquet");
const APP = path.join(OUT, "app");
const TEMPLATES = path.join(ROOT, "scripts", "pterodactyl");
const ZIP = process.platform !== "linux";
const ARCHIVE = path.join(ROOT, "deploy", `link-by-unclaim-pterodactyl.${ZIP ? "zip" : "tar.gz"}`);
const TARGETS = { x64: "debian-openssl-3.0.x", arm64: "linux-arm64-openssl-3.0.x" };
const targets = process.argv.includes("--x64") ? [TARGETS.x64] : Object.values(TARGETS);

const step = (title) => console.log(`\n▸ ${title}`);
function run(command, args, { quiet = false, ...options } = {}) {
  const result = spawnSync(command, args, { stdio: quiet ? "pipe" : "inherit", encoding: "utf8", ...options });
  if (result.status !== 0) {
    if (quiet) process.stderr.write(`${result.stdout ?? ""}${result.stderr ?? ""}`);
    console.error(`\n× Échec de : ${path.basename(command)} ${args.join(" ")}`);
    process.exit(1);
  }
}

// ─── 1. Copie du projet ───────────────────────────────────────────────────────

// Hors de la copie : builds, secrets et données locales, client Prisma (régénéré dans la copie).
const SKIP = [
  /^\.next$/,
  /^\.git$/,
  /^\.claude$/,
  /^deploy$/,
  /^data$/,
  /^coverage$/,
  /^\.tmp$/,
  /^\.env(?!\.example$)/,
  /\.tsbuildinfo$/,
  /\.log$/,
  /^prisma\/.*\.db(-journal)?$/,
  /^node_modules\/\.prisma$/,
  /^node_modules\/\.cache$/,
];
const skipped = (rel) => SKIP.some((pattern) => pattern.test(rel));

/**
 * Suppression récursive en JavaScript : sous Windows, fs.rmSync (natif depuis Node 23) ne
 * supprime rien, et sans erreur, sur les chemins accentués (« C:\Users\Noé… »).
 */
function remove(target) {
  let stat;
  try {
    stat = fs.lstatSync(target);
  } catch {
    return;
  }
  if (stat.isDirectory()) {
    for (const name of fs.readdirSync(target)) remove(path.join(target, name));
    fs.rmdirSync(target);
  } else if (stat.isSymbolicLink() && process.platform === "win32") {
    fs.rmdirSync(target); // jonction
  } else {
    if (!(stat.mode & 0o200)) fs.chmodSync(target, 0o666); // lecture seule
    fs.unlinkSync(target);
  }
}

/** Copie les fichiers nouveaux ou modifiés, retire ceux qui n'existent plus (sauf les exclus). */
function sync(from, to, rel = "") {
  fs.mkdirSync(to, { recursive: true });
  const kept = new Set();
  for (const entry of fs.readdirSync(from, { withFileTypes: true })) {
    const relPath = rel ? `${rel}/${entry.name}` : entry.name;
    if (skipped(relPath)) continue;
    const source = path.join(from, entry.name);
    const target = path.join(to, entry.name);
    let stat;
    try {
      stat = fs.statSync(source);
    } catch {
      continue; // lien cassé
    }
    kept.add(entry.name);
    const current = fs.existsSync(target) ? fs.lstatSync(target) : null;
    if (stat.isDirectory()) {
      if (current && !current.isDirectory()) remove(target);
      sync(source, target, relPath);
    } else if (stat.isFile()) {
      if (current?.isDirectory()) remove(target);
      const same = current?.isFile() && current.size === stat.size && Math.floor(current.mtimeMs) === Math.floor(stat.mtimeMs);
      if (!same) {
        fs.copyFileSync(source, target);
        fs.utimesSync(target, stat.atime, stat.mtime);
      }
    }
  }
  for (const name of fs.readdirSync(to)) {
    const relPath = rel ? `${rel}/${name}` : name;
    if (!kept.has(name) && !skipped(relPath)) remove(path.join(to, name));
  }
}

/**
 * Copie récursive qui suit les liens (Turbopack crée des jonctions Windows dans .next). En
 * JavaScript plutôt que fs.cpSync, dont la version native échoue sous Windows sur les chemins
 * accentués (« C:\Users\Noé… »).
 */
function copyDir(from, to, filter = () => true) {
  fs.mkdirSync(to, { recursive: true });
  for (const name of fs.readdirSync(from)) {
    const source = path.join(from, name);
    if (!filter(source)) continue;
    const target = path.join(to, name);
    const stat = fs.statSync(source);
    if (stat.isDirectory()) copyDir(source, target, filter);
    else if (stat.isFile()) fs.copyFileSync(source, target);
  }
}

/** Vide un dossier : renommé d'abord, pour que Windows libère le nom tout de suite. */
function clearDir(dir) {
  if (fs.existsSync(dir)) fs.renameSync(dir, `${dir}-${Date.now()}.old`);
  for (const name of fs.readdirSync(path.dirname(dir))) {
    if (name.endsWith(".old")) remove(path.join(path.dirname(dir), name));
  }
}

const started = Date.now();
// --no-build : réassemble le paquet à partir du dernier build (mise au point du script).
const rebuild = !process.argv.includes("--no-build") || !fs.existsSync(path.join(COPY, ".next", "standalone"));
if (rebuild) {
  step(`Copie du projet dans ${COPY}`);
  sync(ROOT, COPY);

  // ─── 2. Build ─────────────────────────────────────────────────────────────────

  step("Client Prisma (moteurs Linux compris)");
  run(process.execPath, [path.join(COPY, "node_modules", "prisma", "build", "index.js"), "generate"], { cwd: COPY });

  step("Build Next.js (serveur autonome)");
  // Environnement neutre : aucune variable de l'application n'est figée dans le build.
  const buildEnv = { ...process.env, NEXT_OUTPUT: "standalone", NEXT_TELEMETRY_DISABLED: "1", NODE_ENV: "production" };
  for (const key of Object.keys(buildEnv)) {
    if (/^(APP_URL|SESSION_SECRET|DATABASE_URL|UNCLAIM_|NATIONSGLORY_|ADMIN_|UPLOADS_|STRIPE_|ANTHROPIC_|ASSISTANT_)/.test(key)) delete buildEnv[key];
  }
  // Base vide et migrée : les pages qui la lisent avant de passer en rendu à la demande ne
  // remplissent pas le journal d'erreurs. Elle reste sur la machine de build.
  const buildDb = path.join(WORK, "build.db");
  remove(buildDb);
  buildEnv.DATABASE_URL = `file:${buildDb}`;
  run(process.execPath, [path.join(COPY, "node_modules", "prisma", "build", "index.js"), "migrate", "deploy"], { cwd: COPY, env: buildEnv, quiet: true });
  run(process.execPath, [path.join(COPY, "node_modules", "next", "dist", "bin", "next"), "build"], { cwd: COPY, env: buildEnv });
}

// ─── 3. Assemblage ────────────────────────────────────────────────────────────

step("Assemblage du paquet");
clearDir(OUT);
copyDir(path.join(COPY, ".next", "standalone"), APP);
copyDir(path.join(COPY, ".next", "static"), path.join(APP, ".next", "static"));
if (fs.existsSync(path.join(COPY, "public"))) copyDir(path.join(COPY, "public"), path.join(APP, "public"));
remove(path.join(APP, "prisma"));
fs.mkdirSync(path.join(APP, "prisma"), { recursive: true });
fs.copyFileSync(path.join(COPY, "prisma", "schema.prisma"), path.join(APP, "prisma", "schema.prisma"));
copyDir(path.join(COPY, "prisma", "migrations"), path.join(APP, "prisma", "migrations"));

// CLI Prisma (migrate deploy) et toutes ses dépendances, que le serveur autonome n'embarque pas.
const packages = new Set();
function addPackage(name, fromDir) {
  for (let dir = fromDir; dir.startsWith(COPY); dir = path.dirname(dir)) {
    const candidate = path.join(dir, "node_modules", name);
    if (!fs.existsSync(path.join(candidate, "package.json"))) continue;
    if (packages.has(candidate)) return;
    packages.add(candidate);
    const pkg = JSON.parse(fs.readFileSync(path.join(candidate, "package.json"), "utf8"));
    for (const dep of Object.keys({ ...pkg.dependencies, ...pkg.optionalDependencies })) addPackage(dep, candidate);
    return;
  }
}
addPackage("prisma", COPY);
const windowsOnly = (source) => !/\.(exe|dll\.node)$|[\\/]node_modules[\\/][^\\/]*win32[^\\/]*$/.test(source);
for (const dir of packages) {
  copyDir(dir, path.join(APP, path.relative(COPY, dir)), (source) => windowsOnly(source) && !source.startsWith(path.join(dir, "node_modules")));
}

// Moteur de migration (schema-engine) pour Linux, téléchargé depuis les serveurs de Prisma.
step(`Moteurs Prisma pour ${targets.join(", ")}`);
const enginesRequire = createRequire(path.join(COPY, "node_modules", "@prisma", "engines", "package.json"));
const { download, BinaryType } = enginesRequire("@prisma/fetch-engine");
const { enginesVersion } = enginesRequire("@prisma/engines-version");
const enginesDir = path.join(WORK, "moteurs");
fs.mkdirSync(enginesDir, { recursive: true });
await download({ binaries: { [BinaryType.SchemaEngineBinary]: enginesDir }, version: enginesVersion, binaryTargets: targets, showProgress: false, failSilent: false });
const clientDir = path.join(APP, "node_modules", ".prisma", "client");
for (const target of targets) {
  fs.copyFileSync(path.join(enginesDir, `schema-engine-${target}`), path.join(APP, "node_modules", "@prisma", "engines", `schema-engine-${target}`));
  const library = `libquery_engine-${target}.so.node`;
  if (!fs.existsSync(path.join(clientDir, library))) {
    fs.copyFileSync(path.join(COPY, "node_modules", ".prisma", "client", library), path.join(clientDir, library));
  }
}

// Rien de propre à Windows (ni aux cibles écartées) dans le paquet.
for (const name of fs.readdirSync(clientDir)) {
  const engine = /^(lib)?query_engine-(.+?)\.(so\.node|dll\.node|dylib\.node)/.exec(name);
  if (engine && !targets.includes(engine[2])) remove(path.join(clientDir, name));
}
function removeWindowsPackages(dir) {
  if (!fs.existsSync(dir)) return;
  for (const name of fs.readdirSync(dir)) {
    const full = path.join(dir, name);
    if (name.startsWith("@")) removeWindowsPackages(full);
    else if (/win32/.test(name)) remove(full);
  }
}
removeWindowsPackages(path.join(APP, "node_modules"));

// Allègement : rien de ce qui suit ne sert à l'exécution. Le serveur utilise le moteur Prisma
// natif (pas les variantes WebAssembly « edge »), la CLI ne sert qu'à `migrate deploy` (ni
// générateur, ni Studio, ni moteurs en double), et le site n'utilise pas next/image (sharp).
const modulesDir = path.join(APP, "node_modules");
for (const rel of ["sharp", "@img", "prisma/prisma-client", "prisma/build/public"]) {
  remove(path.join(modulesDir, rel));
}
function removeFiles(dir, test, recursive = false) {
  if (!fs.existsSync(dir)) return;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (recursive) removeFiles(full, test, true);
    } else if (test(entry.name)) remove(full);
  }
}
removeFiles(path.join(modulesDir, "prisma"), (name) => /^(lib)?query_engine/.test(name));
removeFiles(path.join(modulesDir, "prisma", "build"), (name) => /^query_(engine|compiler)_bg\..+\.wasm$/.test(name));
removeFiles(path.join(modulesDir, "@prisma", "client", "runtime"), (name) => /\.wasm-base64\.m?js$/.test(name));
removeFiles(modulesDir, (name) => /\.(d\.[cm]?ts|map)$/.test(name), true);

// Turbopack charge les paquets externes sous un nom haché (« @prisma/client-2c3a… ») via des
// jonctions dans .next/node_modules, devenues des copies complètes : un simple renvoi suffit.
const externalsDir = path.join(APP, ".next", "node_modules");
if (fs.existsSync(externalsDir)) {
  const externals = fs.readdirSync(externalsDir).flatMap((name) => (name.startsWith("@") ? fs.readdirSync(path.join(externalsDir, name)).map((sub) => `${name}/${sub}`) : [name]));
  for (const hashed of externals) {
    const original = /^(.+)-[0-9a-f]{16}$/.exec(hashed)?.[1];
    if (!original || !fs.existsSync(path.join(modulesDir, original, "package.json"))) continue;
    const dir = path.join(externalsDir, hashed);
    remove(dir);
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, "package.json"), `${JSON.stringify({ name: hashed, private: true, main: "index.js" })}\n`);
    fs.writeFileSync(path.join(dir, "index.js"), `module.exports = require(${JSON.stringify(original)});\n`);
  }
}

// Démarrage, configuration, mode d'emploi et version.
fs.copyFileSync(path.join(TEMPLATES, "start.js"), path.join(OUT, "start.js"));
fs.copyFileSync(path.join(TEMPLATES, "env.example"), path.join(OUT, ".env.example"));
fs.copyFileSync(path.join(TEMPLATES, "LISEZMOI.txt"), path.join(OUT, "LISEZMOI.txt"));
const buildId = fs.readFileSync(path.join(COPY, ".next", "BUILD_ID"), "utf8").trim();
const version = JSON.parse(fs.readFileSync(path.join(COPY, "package.json"), "utf8")).version;
fs.writeFileSync(path.join(APP, "build-info.json"), `${JSON.stringify({ version, buildId, builtAt: new Date().toISOString(), targets }, null, 2)}\n`);

// ─── 4. Vérifications et archive ──────────────────────────────────────────────

step("Vérifications");
const required = [
  "start.js",
  "app/server.js",
  "app/.next/BUILD_ID",
  "app/.next/static",
  "app/prisma/schema.prisma",
  "app/node_modules/prisma/build/index.js",
  ...targets.flatMap((t) => [`app/node_modules/.prisma/client/libquery_engine-${t}.so.node`, `app/node_modules/@prisma/engines/schema-engine-${t}`]),
];
const missing = required.filter((rel) => !fs.existsSync(path.join(OUT, rel)));
if (missing.length) {
  console.error(`× Fichiers manquants dans le paquet :\n  ${missing.join("\n  ")}`);
  process.exit(1);
}
// Turbopack référence les paquets externes par des jonctions : elles doivent être devenues des dossiers.
function findLinks(dir, found = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isSymbolicLink()) found.push(path.relative(OUT, full));
    else if (entry.isDirectory()) findLinks(full, found);
  }
  return found;
}
const links = findLinks(OUT);
if (links.length) {
  console.error(`× Liens symboliques restés dans le paquet :\n  ${links.join("\n  ")}`);
  process.exit(1);
}
console.log("  ✓ serveur, fichiers statiques, migrations, CLI et moteurs Prisma présents");

step("Archive");
fs.mkdirSync(path.dirname(ARCHIVE), { recursive: true });
remove(ARCHIVE);
const entries = ["start.js", ".env.example", "LISEZMOI.txt", "app"];
if (ZIP) {
  // bsdtar (fourni avec Windows) écrit des chemins avec « / », lisibles par Pterodactyl.
  const tar = process.platform === "win32" ? path.join(process.env.SystemRoot ?? "C:\\Windows", "System32", "tar.exe") : "tar";
  run(tar, ["-a", "-c", "-f", ARCHIVE, "-C", OUT, ...entries]);
} else {
  run("tar", ["-czf", ARCHIVE, "-C", OUT, ...entries]);
}
const size = (fs.statSync(ARCHIVE).size / 1024 / 1024).toFixed(1);
console.log(`\n✓ Paquet prêt en ${Math.round((Date.now() - started) / 1000)} s : ${path.relative(ROOT, ARCHIVE)} (${size} Mo, build ${buildId})`);
console.log("  Mode d'emploi : LISEZMOI.txt dans l'archive, ou docs/PTERODACTYL.md");
