// Génère le client Prisma, même quand un serveur Link tourne déjà (npm start / npm run dev).
// Sous Windows, un serveur lancé verrouille le moteur (query_engine-windows.dll.node) et
// `prisma generate` échoue en EPERM. Un fichier chargé peut toutefois être renommé : on le met
// de côté, on régénère, et on supprime les anciennes copies qui ne sont plus utilisées.
// Usage : node scripts/prisma-generate.mjs (appelé par npm run build)
import { spawnSync } from "node:child_process";
import { existsSync, readdirSync, renameSync, unlinkSync } from "node:fs";
import path from "node:path";

const clientDir = path.join(process.cwd(), "node_modules", ".prisma", "client");

function generate() {
  const result = spawnSync("npx prisma generate", { encoding: "utf8", shell: true });
  process.stdout.write(result.stdout ?? "");
  return { ok: result.status === 0, output: `${result.stdout ?? ""}${result.stderr ?? ""}` };
}

/** Supprime les anciennes copies du moteur qui ne sont plus chargées par aucun serveur. */
function cleanup() {
  if (!existsSync(clientDir)) return;
  for (const name of readdirSync(clientDir)) {
    if (!/\.node\.(old|tmp)/.test(name)) continue;
    try {
      unlinkSync(path.join(clientDir, name));
    } catch {
      // encore utilisée par un serveur lancé : elle partira à la prochaine génération
    }
  }
}

let { ok, output } = generate();
if (!ok && /EPERM|EBUSY/.test(output) && existsSync(clientDir)) {
  console.log("Moteur Prisma verrouillé par un serveur lancé : mise de côté et nouvelle génération…");
  for (const name of readdirSync(clientDir)) {
    if (!/^(libquery_engine|query_engine).*\.node$/.test(name)) continue;
    renameSync(path.join(clientDir, name), path.join(clientDir, `${name}.old-${Date.now()}`));
  }
  ({ ok, output } = generate());
}
if (!ok) {
  process.stderr.write(output);
  console.error("\n× prisma generate a échoué. Arrête les serveurs Link (npm start, npm run dev) puis relance la commande.");
  process.exit(1);
}
cleanup();
