// Link by Unclaim — démarrage sur Pterodactyl (egg « Node.js » générique, Main file : start.js).
//
// À chaque démarrage : lit .env (à côté de ce fichier), prépare data/ (base SQLite, fichiers
// importés, sauvegardes), applique les migrations de la base puis lance le serveur Next.js sur
// le port alloué par Pterodactyl. Rien à installer : app/ contient déjà tout.
//
//   /home/container/
//     start.js   ce fichier          .env    la configuration (copie de .env.example)
//     app/       le site (remplacé à chaque mise à jour)
//     data/      base, fichiers importés, sauvegardes (à garder et à sauvegarder)
"use strict";

const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const http = require("node:http");
const { spawnSync } = require("node:child_process");

const ROOT = __dirname;
const APP = path.join(ROOT, "app");
const DATA = path.join(ROOT, "data");

const log = (message) => console.log(`[link] ${message}`);
const warn = (message) => console.warn(`[link] ⚠ ${message}`);
function fail(message) {
  console.error(`[link] ✖ ${message}`);
  process.exit(1);
}

// ─── Vérifications ───────────────────────────────────────────────────────────

const [major, minor] = process.versions.node.split(".").map(Number);
if (major < 20 || (major === 20 && minor < 9)) {
  fail(`Node.js ${process.versions.node} est trop ancien : choisis l'image Node.js 22 (ou plus récente) dans Startup → Docker Image.`);
}
if (!fs.existsSync(path.join(APP, "server.js"))) {
  fail("Dossier app/ introuvable : décompresse l'archive dans /home/container, start.js et app/ côte à côte.");
}

// ─── Configuration (.env) ────────────────────────────────────────────────────

/** Lit un fichier .env (KEY=valeur, guillemets et commentaires #) sans écraser l'environnement. */
function loadEnvFile(file) {
  if (!fs.existsSync(file)) return false;
  const text = fs.readFileSync(file, "utf8").replace(/^﻿/, "");
  for (const line of text.split(/\r?\n/)) {
    const match = /^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=(.*)$/.exec(line);
    if (!match) continue;
    let value = match[2].trim();
    const quoted = /^"((?:[^"\\]|\\.)*)"/.exec(value) ?? /^'([^']*)'/.exec(value);
    if (quoted) {
      value = quoted[1];
      if (quoted[0][0] === '"') value = value.replace(/\\n/g, "\n").replace(/\\(["\\])/g, "$1");
    } else {
      value = value.replace(/\s+#.*$/, "");
    }
    if (process.env[match[1]] === undefined) process.env[match[1]] = value;
  }
  return true;
}

const setDefault = (key, value) => {
  if (!process.env[key]) process.env[key] = value;
};

if (!loadEnvFile(path.join(ROOT, ".env"))) {
  warn("Pas de fichier .env : copie .env.example en .env et remplis-le (adresse du site, Unclaim Auth…).");
}

process.env.NODE_ENV = "production";
setDefault("NEXT_TELEMETRY_DISABLED", "1");
setDefault("CHECKPOINT_DISABLE", "1");
setDefault("PRISMA_HIDE_UPDATE_MESSAGE", "1");

// Port alloué par Pterodactyl. Docker définit HOSTNAME (nom du conteneur) : sans cette ligne,
// Next.js n'écouterait que sur cette adresse-là.
const port = Number(process.env.SERVER_PORT || process.env.PORT || 3000);
process.env.PORT = String(port);
process.env.HOSTNAME = process.env.LISTEN_HOST || "0.0.0.0";

// Chemins relatifs (« file:./data/link.db », « ./data/uploads ») : relatifs au dossier de
// start.js, jamais à app/, qui est remplacé à chaque mise à jour.
fs.mkdirSync(DATA, { recursive: true });
const database = /^file:(.*?)(\?.*)?$/.exec(process.env.DATABASE_URL || "file:./data/link.db");
let databaseFile = null;
if (database) {
  databaseFile = path.resolve(ROOT, database[1]);
  fs.mkdirSync(path.dirname(databaseFile), { recursive: true });
  process.env.DATABASE_URL = `file:${databaseFile}${database[2] ?? ""}`;
}
setDefault("UPLOADS_DRIVER", "disk");
process.env.UPLOADS_DIR = path.resolve(ROOT, process.env.UPLOADS_DIR || "./data/uploads");

// Secret d'anonymisation des visiteurs : généré une fois et gardé dans data/ s'il manque.
if (!process.env.SESSION_SECRET) {
  const file = path.join(DATA, "session-secret");
  let secret = fs.existsSync(file) ? fs.readFileSync(file, "utf8").trim() : "";
  if (!secret) {
    secret = crypto.randomBytes(32).toString("base64url");
    fs.writeFileSync(file, `${secret}\n`, { mode: 0o600 });
    log("SESSION_SECRET absent de .env : un secret a été généré dans data/session-secret.");
  }
  process.env.SESSION_SECRET = secret;
}

if (!process.env.APP_URL) {
  const ip = process.env.SERVER_IP && process.env.SERVER_IP !== "0.0.0.0" ? process.env.SERVER_IP : "localhost";
  process.env.APP_URL = `http://${ip}:${port}`;
  warn(`APP_URL absent de .env : ${process.env.APP_URL} est utilisé. Indique l'adresse publique du site (ex. https://link.mondomaine.fr), sinon la connexion échouera.`);
}
if (!process.env.UNCLAIM_API_URL || !process.env.UNCLAIM_CLIENT_ID || !process.env.UNCLAIM_CLIENT_SECRET) {
  warn("UNCLAIM_API_URL, UNCLAIM_CLIENT_ID ou UNCLAIM_CLIENT_SECRET manque dans .env : personne ne pourra se connecter.");
}

// ─── Moteurs Prisma (Linux) ──────────────────────────────────────────────────

if (process.platform === "linux") {
  if (fs.existsSync("/etc/alpine-release")) {
    fail("Image Alpine détectée : choisis une image Debian, par exemple ghcr.io/parkervcp/yolks:nodejs_22.");
  }
  const target = { x64: "debian-openssl-3.0.x", arm64: "linux-arm64-openssl-3.0.x" }[process.arch];
  if (!target) fail(`Processeur ${process.arch} non pris en charge (x64 ou arm64 uniquement).`);
  const library = path.join(APP, "node_modules", ".prisma", "client", `libquery_engine-${target}.so.node`);
  const schemaEngine = path.join(APP, "node_modules", "@prisma", "engines", `schema-engine-${target}`);
  if (!fs.existsSync(library) || !fs.existsSync(schemaEngine)) {
    fail(`Moteurs de base de données pour ${target} absents du paquet : reconstruis-le avec « npm run build:pterodactyl » (sans --x64 pour un serveur ARM).`);
  }
  const libDirs = ["/usr/lib/x86_64-linux-gnu", "/lib/x86_64-linux-gnu", "/usr/lib/aarch64-linux-gnu", "/lib/aarch64-linux-gnu", "/usr/lib", "/lib"];
  if (!libDirs.some((dir) => fs.existsSync(path.join(dir, "libssl.so.3")))) {
    warn("OpenSSL 3 introuvable dans l'image : si la base ne démarre pas, choisis une image Node.js 22 récente (Debian 12).");
  }
  // Une archive décompressée perd souvent le droit d'exécution.
  fs.chmodSync(schemaEngine, 0o755);
  setDefault("PRISMA_QUERY_ENGINE_LIBRARY", library);
  setDefault("PRISMA_SCHEMA_ENGINE_BINARY", schemaEngine);
}

// ─── Base de données : sauvegarde puis migrations ────────────────────────────

const migrations = fs
  .readdirSync(path.join(APP, "prisma", "migrations"), { withFileTypes: true })
  .filter((entry) => entry.isDirectory())
  .map((entry) => entry.name)
  .sort()
  .join("\n");
const stampFile = path.join(DATA, ".migrations");
const knownMigrations = fs.existsSync(stampFile) ? fs.readFileSync(stampFile, "utf8") : null;

// Nouvelle version du site (nouvelles migrations) : copie de la base avant d'y toucher.
if (migrations !== knownMigrations && databaseFile && fs.existsSync(databaseFile) && fs.statSync(databaseFile).size > 0) {
  const dir = path.join(DATA, "sauvegardes");
  fs.mkdirSync(dir, { recursive: true });
  const name = `link-${new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19)}.db`;
  fs.copyFileSync(databaseFile, path.join(dir, name));
  const backups = fs.readdirSync(dir).filter((file) => /^link-.*\.db$/.test(file)).sort();
  for (const old of backups.slice(0, -5)) fs.rmSync(path.join(dir, old), { force: true });
  log(`Nouvelle version : base sauvegardée dans data/sauvegardes/${name}`);
}

log("Mise à jour de la base de données…");
const migrate = spawnSync(
  process.execPath,
  [path.join(APP, "node_modules", "prisma", "build", "index.js"), "migrate", "deploy", "--schema", path.join(APP, "prisma", "schema.prisma")],
  { cwd: APP, stdio: "inherit", env: process.env },
);
if (migrate.status !== 0) fail("Les migrations de la base ont échoué (voir ci-dessus) : le site n'a pas été lancé.");
fs.writeFileSync(stampFile, migrations);

// ─── Serveur ─────────────────────────────────────────────────────────────────

log(`Démarrage du serveur sur le port ${port}…`);
require(path.join(APP, "server.js"));

// Annonce la mise en ligne une fois le site joignable (ligne à indiquer à Pterodactyl comme
// signal de démarrage : « est en ligne »).
const started = Date.now();
const probeHost = process.env.HOSTNAME === "0.0.0.0" ? "127.0.0.1" : process.env.HOSTNAME;
(function probe() {
  const request = http.get({ host: probeHost, port, path: "/api/health", timeout: 5000 }, (response) => {
    response.resume();
    if (response.statusCode === 200) log(`Link by Unclaim est en ligne : ${process.env.APP_URL}`);
    else warn(`Le site répond mais la base est injoignable (code ${response.statusCode}).`);
  });
  request.on("timeout", () => request.destroy());
  request.on("error", () => {
    if (Date.now() - started < 120_000) setTimeout(probe, 500);
    else warn("Le site ne répond pas après deux minutes : vérifie les messages ci-dessus.");
  });
})();
