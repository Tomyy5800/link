// Génère src/components/icons/brand-paths.ts à partir de simple-icons (CC0).
// On n'embarque que les icônes utiles plutôt que tout le paquet dans le bundle.
// Usage : npm run icons:generate
import { writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import * as icons from "simple-icons";

const WANTED = {
  discord: "siDiscord",
  youtube: "siYoutube",
  twitch: "siTwitch",
  kick: "siKick",
  tiktok: "siTiktok",
  instagram: "siInstagram",
  x: "siX",
  bluesky: "siBluesky",
  threads: "siThreads",
  reddit: "siReddit",
  github: "siGithub",
  spotify: "siSpotify",
  soundcloud: "siSoundcloud",
  steam: "siSteam",
  patreon: "siPatreon",
  kofi: "siKofi",
  paypal: "siPaypal",
  telegram: "siTelegram",
  snapchat: "siSnapchat",
  facebook: "siFacebook",
  pinterest: "siPinterest",
  // Fournisseurs de connexion Unclaim Auth.
  google: "siGoogle",
  apple: "siApple",
  // Plateformes du bloc « Écouter partout ».
  applemusic: "siApplemusic",
  deezer: "siDeezer",
  tidal: "siTidal",
  bandcamp: "siBandcamp",
  youtubemusic: "siYoutubemusic",
  // Partage d'une page publique.
  whatsapp: "siWhatsapp",
};

const entries = [];
for (const [key, exportName] of Object.entries(WANTED)) {
  const icon = icons[exportName];
  if (!icon) {
    console.warn(`⚠ Icône introuvable dans simple-icons : ${exportName} (ignorée)`);
    continue;
  }
  entries.push(`  ${key}: { title: ${JSON.stringify(icon.title)}, hex: "#${icon.hex}", path: ${JSON.stringify(icon.path)} },`);
}

const out = `// Fichier généré par scripts/generate-brand-icons.mjs — ne pas modifier à la main.
// Tracés issus de simple-icons (licence CC0 1.0).

export type BrandIcon = { title: string; hex: string; path: string };

export const BRAND_ICONS = {
${entries.join("\n")}
} satisfies Record<string, BrandIcon>;

export type BrandIconKey = keyof typeof BRAND_ICONS;
`;

const target = fileURLToPath(new URL("../src/components/icons/brand-paths.ts", import.meta.url));
writeFileSync(target, out);
console.log(`✓ ${entries.length} icônes écrites dans src/components/icons/brand-paths.ts`);
