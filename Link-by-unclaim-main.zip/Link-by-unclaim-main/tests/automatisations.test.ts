import { describe, expect, it } from "vitest";
import { applyAutomations, automationSchema, describeTrigger, localClock, triggerActive, type Automation } from "@/lib/automations";
import { createBlock } from "@/lib/blocks";
import { maskWebhook, notificationsSchema, parseNotifications } from "@/lib/notifications";
import { DEFAULT_PAGE_OPTIONS, parsePageOptions, type PageView } from "@/lib/page-schema";
import { googleFontsHref, parseTheme } from "@/lib/theme";

const TZ = "Europe/Paris";
// Mercredi 21 octobre 2026, 21 h 30 à Paris (UTC+2).
const WED_2130 = new Date("2026-10-21T19:30:00Z");
const ctx = (now: Date, live = false) => ({ now, timeZone: TZ, live: { on: live, url: live ? "https://twitch.tv/kaelis" : null } });

function page(blocks = [createBlock("link", { label: "A", url: "https://a.fr" }), createBlock("link", { label: "B", url: "https://b.fr" })]): PageView {
  return {
    slug: "test",
    published: true,
    views: 0,
    theme: parseTheme({}),
    customCss: "",
    options: DEFAULT_PAGE_OPTIONS,
    blocks,
    profile: { displayName: "Test", pronouns: "", bio: "", avatarSource: "discord", avatarUrl: "", bannerUrl: "", ngUsername: "", ngServer: "blue" },
  };
}

describe("automatisations", () => {
  it("lit l'heure locale de la page", () => {
    expect(localClock(WED_2130, TZ)).toEqual({ day: 3, minutes: 21 * 60 + 30, monthDay: "10-21" });
  });

  it("déclenche un créneau hebdomadaire, y compris quand il passe minuit", () => {
    const evening = { type: "weekly" as const, days: [3], from: "20:00", to: "23:00" };
    expect(triggerActive(evening, ctx(WED_2130), null)).toBe(true);
    expect(triggerActive({ ...evening, days: [4] }, ctx(WED_2130), null)).toBe(false);
    const night = { type: "weekly" as const, days: [3], from: "22:00", to: "02:00" };
    expect(triggerActive(night, ctx(WED_2130), null)).toBe(false);
    // Jeudi 1 h du matin à Paris : toujours dans la nuit de mercredi.
    expect(triggerActive(night, ctx(new Date("2026-10-21T23:00:00Z")), null)).toBe(true);
  });

  it("déclenche entre deux dates, pendant un live et le jour de l'anniversaire", () => {
    expect(triggerActive({ type: "dates", start: "2026-10-20T00:00:00Z", end: "2026-10-22T00:00:00Z" }, ctx(WED_2130), null)).toBe(true);
    expect(triggerActive({ type: "live" }, ctx(WED_2130, true), null)).toBe(true);
    expect(triggerActive({ type: "live" }, ctx(WED_2130), null)).toBe(false);
    expect(triggerActive({ type: "birthday" }, ctx(WED_2130), "10-21")).toBe(true);
    expect(triggerActive({ type: "birthday" }, ctx(WED_2130), "10-22")).toBe(false);
  });

  it("applique bandeau, mise en avant, masquage et thème", () => {
    const p = page();
    const [a, b] = p.blocks;
    const rules: Automation[] = [
      {
        id: "r1",
        name: "Live",
        enabled: true,
        trigger: { type: "live" },
        actions: [
          { type: "banner", text: "En live !", url: "", style: "live" },
          { type: "highlight", blockId: b.id },
        ],
      },
      { id: "r2", name: "Nuit", enabled: true, trigger: { type: "weekly", days: [3], from: "21:00", to: "23:00" }, actions: [{ type: "theme", preset: "sakura" }, { type: "hide", blockId: a.id }] },
      { id: "r3", name: "Off", enabled: false, trigger: { type: "live" }, actions: [{ type: "banner", text: "jamais", url: "", style: "info" }] },
    ];
    const out = applyAutomations(p, rules, ctx(WED_2130, true));
    expect(out.active).toEqual(["r1", "r2"]);
    expect(out.banners).toEqual([{ id: "r1-0", text: "En live !", url: "https://twitch.tv/kaelis", style: "live" }]);
    expect(out.page.blocks.map((x) => x.id)).toEqual([b.id]);
    expect(out.page.theme.accent).not.toBe(p.theme.accent);
    // Aperçu de l'éditeur : une règle forcée s'applique même hors de son créneau.
    expect(applyAutomations(p, rules, { ...ctx(WED_2130), force: ["r3"] }).active).toContain("r3");
  });

  it("valide les règles et garde les options lisibles si une règle est cassée", () => {
    expect(automationSchema.safeParse({ id: "x", trigger: { type: "weekly", days: [], from: "20:00", to: "21:00" }, actions: [{ type: "theme", preset: "neon" }] }).success).toBe(false);
    const stored = JSON.stringify({ seoTitle: "Titre", automations: [{ id: "ok", trigger: { type: "live" }, actions: [{ type: "theme", preset: "neon" }] }, { id: "cassée" }] });
    const options = parsePageOptions(stored);
    expect(options.seoTitle).toBe("Titre");
    expect(options.automations.map((r) => r.id)).toEqual(["ok"]);
    expect(describeTrigger({ type: "weekly", days: [3, 5], from: "20:00", to: "23:00" })).toBe("Le mercredi, vendredi de 20:00 à 23:00");
    // Dates écrites dans le fuseau de la page (Paris par défaut), quel que soit celui de la machine.
    const dates = { type: "dates", start: "2026-10-21T18:00:00.000Z", end: "2026-10-21T21:00:00.000Z" } as const;
    expect(describeTrigger(dates)).toBe("Du 21/10/2026 20:00 au 21/10/2026 23:00");
    expect(describeTrigger(dates, "America/Montreal")).toBe("Du 21/10/2026 14:00 au 21/10/2026 17:00");
  });
});

describe("notifications et polices", () => {
  const hook = `https://discord.com/api/webhooks/123456789012345678/${"a".repeat(68)}`;

  it("n'accepte que des webhooks Discord et masque le jeton", () => {
    expect(notificationsSchema.safeParse({ discordWebhook: hook }).success).toBe(true);
    expect(notificationsSchema.safeParse({ discordWebhook: "https://exemple.fr/api/webhooks/1/abc" }).success).toBe(false);
    expect(maskWebhook(hook)).toBe("https://discord.com/api/webhooks/123456789012345678/aaaa…aaaa");
    expect(parseNotifications("pas du json")).toMatchObject({ discordWebhook: "", onMessage: true, weekly: true });
  });

  it("construit l'adresse Google Fonts des polices choisies", () => {
    expect(googleFontsHref({ googleFont: "", googleHeadingFont: "" })).toBeNull();
    expect(googleFontsHref({ googleFont: "Space Grotesk", googleHeadingFont: "Press Start 2P" })).toBe(
      "https://fonts.googleapis.com/css2?family=Space+Grotesk&family=Press+Start+2P&display=swap",
    );
    expect(parseTheme({ googleFont: "Evil<script>" }).googleFont).toBe("");
  });
});
