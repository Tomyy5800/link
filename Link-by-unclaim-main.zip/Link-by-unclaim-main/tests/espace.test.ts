import { describe, expect, it } from "vitest";
import { blockSchema, blockSummary, createBlock } from "@/lib/blocks";
import { DEFAULT_SETTINGS } from "@/lib/features";
import { GAMES, GAME_IDS, cleanGameId, gameInfo } from "@/lib/games";
import { TERMS_VERSION } from "@/lib/legal";
import { PARTNER_KIND_KEYS, partnerPerks } from "@/lib/partners";
import { RESERVED_SLUGS } from "@/lib/slug";
import { PAGE_TEMPLATES } from "@/lib/templates";
import { entitlementsFrom } from "@/lib/server/entitlements";

const account = (patch: Partial<{ role: string; plan: string; partner: boolean }> = {}) => ({
  role: "user",
  plan: "free",
  planExpiresAt: null as Date | null,
  discordId: null as string | null,
  unclaimId: "uncl_TEST" as string | null,
  partner: false,
  ...patch,
});

describe("plusieurs pages et partenaires", () => {
  it("limite le nombre de pages et de collaborateurs selon l'offre", () => {
    const free = entitlementsFrom(account(), DEFAULT_SETTINGS, { freeForAll: false });
    expect(free.limits.pages).toBe(1);
    expect(free.partner).toBe(false);
    const plus = entitlementsFrom(account({ plan: "premium" }), DEFAULT_SETTINGS, { freeForAll: false });
    expect(plus.tier).toBe("plus");
    expect(plus.limits.pages).toBe(DEFAULT_SETTINGS.limits.plus.pages);
    expect(plus.limits.members).toBeGreaterThan(free.limits.members);
  });

  it("donne Link+ et les limites « partenaires » aux partenaires officiels", () => {
    const partner = entitlementsFrom(account({ partner: true }), DEFAULT_SETTINGS, { freeForAll: false });
    expect(partner.partner).toBe(true);
    expect(partner.premium).toBe(true);
    expect(partner.limits).toEqual(DEFAULT_SETTINGS.limits.partner);
    expect(partnerPerks(partner.limits, "Link+").map((p) => p.title)).toContain(`${partner.limits.pages} pages et ${partner.limits.members} collaborateurs`);
    expect(PARTNER_KIND_KEYS).toContain("nation");
  });

  it("réserve les adresses de « Mon espace », des invitations et des partenaires", () => {
    for (const slug of ["bienvenue", "invitation", "partenaires", "cgu", "compte"]) expect(RESERVED_SLUGS.has(slug)).toBe(true);
  });

  it("date la version des CGU", () => {
    expect(TERMS_VERSION).toMatch(/^\d{4}-\d{2}-\d{2}$/);
  });
});

describe("profil de jeu", () => {
  it("reconnaît les identifiants des jeux en direct", () => {
    expect(cleanGameId("minecraft", "Notch")).toBe("Notch");
    expect(cleanGameId("minecraft", "pas valide!")).toBeNull();
    expect(cleanGameId("chesscom", "Hikaru")).toBe("hikaru");
    expect(cleanGameId("steam", "https://steamcommunity.com/id/gabelogannewell/")).toBe("id:gabelogannewell");
    expect(cleanGameId("steam", "https://steamcommunity.com/profiles/76561197960287930")).toBe("p:76561197960287930");
    expect(cleanGameId("steam", "76561197960287930")).toBe("p:76561197960287930");
    expect(cleanGameId("roblox", "builderman")).toBe("builderman");
    expect(cleanGameId("paladium", "Notch")).toBeNull(); // pas d'API publique
  });

  it("décrit chaque jeu, avec un repli pour les jeux inconnus", () => {
    expect(GAME_IDS.filter((id) => GAMES[id].live).sort()).toEqual(["chesscom", "lichess", "minecraft", "roblox", "steam"]);
    expect(gameInfo("inconnu").name).toBe("Autre jeu");
    expect(GAMES.hypixel.profileUrl("Notch")).toBe("https://plancke.io/hypixel/player/stats/Notch");
  });

  it("valide les blocs « Profil de jeu » et « Formulaire de contact »", () => {
    const game = createBlock("game", { game: "paladium", username: "Notch", rank: "Faction Alpha", stats: [{ label: "Niveau", value: "87" }] });
    expect(blockSchema.safeParse(game).success).toBe(true);
    expect(blockSummary(game)).toBe("Paladium · Notch");
    const contact = createBlock("contact", {});
    expect(blockSchema.safeParse(contact).success).toBe(true);
    expect(contact.data.contactField).toBe("optional");
    expect(blockSchema.safeParse({ ...game, data: { ...game.data, game: "tetris" } }).success).toBe(false);
  });

  it("propose des modèles dont tous les blocs sont valides", () => {
    for (const template of PAGE_TEMPLATES) {
      for (const block of template.blocks({ ngUsername: "Notch", hasDiscord: true })) {
        expect(blockSchema.safeParse(block).success, `${template.id} · ${block.type}`).toBe(true);
      }
    }
  });
});
