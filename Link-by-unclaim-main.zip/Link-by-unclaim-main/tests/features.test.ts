import { describe, expect, it } from "vitest";
import { blockSchema, createBlock, isWithinSchedule, parseStoredBlock } from "@/lib/blocks";
import { mockCountryList, mockNgCountry, normalizeCountry, normalizeCountrySummary, ngFlagUrl, roleLabel } from "@/lib/nationsglory-shared";
import { normalizeLanyard } from "@/lib/presence";
import { DEFAULT_THEME, THEME_PRESETS, exportTheme, importTheme, parseTheme, themeVars } from "@/lib/theme";

describe("programmation des blocs", () => {
  const day = 86_400_000;
  const now = Date.parse("2026-10-13T12:00:00Z");

  it("affiche un bloc sans dates, cache un bloc futur ou expiré", () => {
    expect(isWithinSchedule({ startsAt: null, endsAt: null }, now)).toBe(true);
    expect(isWithinSchedule({ startsAt: new Date(now + day).toISOString(), endsAt: null }, now)).toBe(false);
    expect(isWithinSchedule({ startsAt: null, endsAt: new Date(now - 1).toISOString() }, now)).toBe(false);
    expect(isWithinSchedule({ startsAt: new Date(now - day).toISOString(), endsAt: new Date(now + day).toISOString() }, now)).toBe(true);
  });

  it("normalise les dates en ISO UTC et relit les colonnes de la base", () => {
    const block = blockSchema.parse({ ...createBlock("link"), startsAt: "2026-12-24T18:00:00+01:00" });
    expect(block.startsAt).toBe("2026-12-24T17:00:00.000Z");
    const stored = parseStoredBlock({
      id: block.id,
      type: "link",
      width: "full",
      visible: true,
      data: JSON.stringify(block.data),
      startsAt: new Date("2026-12-24T17:00:00Z"),
      endsAt: null,
    });
    expect(stored?.startsAt).toBe("2026-12-24T17:00:00.000Z");
    expect(stored?.endsAt).toBeNull();
  });

  it("refuse une date illisible", () => {
    expect(blockSchema.safeParse({ ...createBlock("text"), endsAt: "demain" }).success).toBe(false);
  });
});

describe("nouveaux blocs", () => {
  it("crée chaque nouveau type avec des valeurs par défaut valides", () => {
    for (const type of ["countdown", "gallery", "faq", "badges", "copy", "ngCountry", "discordPresence"] as const) {
      expect(blockSchema.safeParse(createBlock(type)).success).toBe(true);
    }
  });

  it("limite la galerie à 12 images et refuse les URL dangereuses", () => {
    const gallery = createBlock("gallery");
    const many = Array.from({ length: 13 }, () => ({ url: "https://exemple.fr/a.png", alt: "" }));
    expect(blockSchema.safeParse({ ...gallery, data: { ...gallery.data, images: many } }).success).toBe(false);
    expect(blockSchema.safeParse({ ...gallery, data: { ...gallery.data, images: [{ url: "javascript:alert(1)", alt: "" }] } }).success).toBe(false);
  });

  it("valide le serveur NationsGlory du bloc pays", () => {
    const block = createBlock("ngCountry");
    expect(blockSchema.safeParse({ ...block, data: { ...block.data, server: "Blue!" } }).success).toBe(false);
  });
});

describe("thème v2", () => {
  it("lit un ancien thème en complétant les nouveaux réglages", () => {
    const theme = parseTheme(JSON.stringify({ accent: "#8b5cf6", font: "grotesk", cardStyle: "glass" }));
    expect(theme.accent).toBe("#8b5cf6");
    expect(theme.bgEffect).toBe("none");
    expect(theme.headerLayout).toBe("classic");
    expect(theme.headingFont).toBeNull();
  });

  it("exporte puis réimporte un thème à l'identique (hors image importée)", () => {
    const theme = { ...DEFAULT_THEME, accent: "#ff2bd6", bgEffect: "stars" as const, bgImage: "/api/uploads/abc123def456" };
    const back = importTheme(exportTheme(theme));
    expect(back).not.toBeNull();
    expect(back?.accent).toBe("#ff2bd6");
    expect(back?.bgEffect).toBe("stars");
    expect(back?.bgImage).toBe("");
    expect(back?.preset).toBe("custom");
    expect(importTheme('{"hello": 1}')).toBeNull();
    expect(importTheme("pas du json")).toBeNull();
  });

  it("propose douze thèmes de départ valides, dont la charte Unclaim", () => {
    expect(THEME_PRESETS).toHaveLength(12);
    expect(THEME_PRESETS[0].key).toBe("unclaim");
    for (const preset of THEME_PRESETS) expect(parseTheme(preset.theme)).toEqual(preset.theme);
  });

  it("applique l'opacité choisie et le dégradé des boutons", () => {
    const vars = themeVars({ ...DEFAULT_THEME, cardStyle: "solid", cardColor: "#0f172b", cardOpacity: 50, buttonGradient: true }) as Record<string, string>;
    expect(vars["--lbu-card-bg"]).toBe("rgba(15, 23, 43, 0.5)");
    expect(vars["--lbu-accent-fill"]).toContain("linear-gradient");
    expect(vars["--lbu-card-blur"]).not.toBe("none");
  });
});

describe("statut Discord (Lanyard)", () => {
  it("normalise statut, statut personnalisé, jeu et Spotify", () => {
    const presence = normalizeLanyard({
      success: true,
      data: {
        discord_status: "dnd",
        listening_to_spotify: true,
        spotify: { song: "Cornfield Chase", artist: "Hans Zimmer", album_art_url: "https://i.scdn.co/image/x", track_id: "6pWgRkpqVfxnj3WuIcJ7WP" },
        activities: [
          { type: 4, state: "En guerre sur Blue", emoji: { name: "⚔️" } },
          { type: 0, name: "Minecraft", details: "NationsGlory" },
          { type: 2, name: "Spotify" },
        ],
      },
    });
    expect(presence.monitored).toBe(true);
    expect(presence.status).toBe("dnd");
    expect(presence.customStatus).toEqual({ text: "En guerre sur Blue", emoji: "⚔️" });
    expect(presence.activities).toEqual([{ kind: "Joue à", name: "Minecraft", details: "NationsGlory", state: null }]);
    expect(presence.spotify?.trackUrl).toBe("https://open.spotify.com/track/6pWgRkpqVfxnj3WuIcJ7WP");
  });

  it("signale un compte non suivi par Lanyard", () => {
    expect(normalizeLanyard({ success: false, error: { code: "user_not_monitored" } }).monitored).toBe(false);
  });
});

describe("pays NationsGlory (API v1)", () => {
  const flag = "a".repeat(64);

  it("normalise une fiche pays et ses membres sans champ inattendu", () => {
    const country = normalizeCountry(
      "blue",
      {
        data: {
          country_id: "c-123",
          name: "France",
          leader: "Kaelis_",
          members_count: 2,
          power: 120,
          power_max: 150,
          claims: 300,
          is_empire: true,
          recruitment_open: true,
          tags: ["build", "trade"],
          flag_sha256: flag,
          token: "secret",
        },
      },
      { data: [{ username: "Kaelis_", role: "LEADER" }, { username: "Orvane", role: "RECRUIT" }] },
    );
    expect(country).toMatchObject({ countryId: "c-123", name: "France", leader: "Kaelis_", membersCount: 2, power: 120, powerMax: 150, claims: 300 });
    expect(country.badges).toEqual(["Empire", "Recrute"]);
    expect(country.tags).toEqual(["Construction", "Commerce"]);
    expect(country.members).toEqual([
      { username: "Kaelis_", role: "Chef" },
      { username: "Orvane", role: "Recrue" },
    ]);
    expect(country.flagUrl).toBe(`https://nationsglory.fr/gamedata/img/${flag}.png`);
    expect(JSON.stringify(country)).not.toContain("secret");
  });

  it("garde null pour les valeurs inconnues (jamais zéro)", () => {
    const country = normalizeCountry("blue", { data: { country_id: "x", name: "Inconnu" } });
    expect(country.power).toBeNull();
    expect(country.membersCount).toBeNull();
    expect(country.flagUrl).toBeNull();
  });

  it("résume les pays de la liste et refuse les entrées incomplètes", () => {
    expect(normalizeCountrySummary({ country_id: "c-1", name: "Japon", members_count: 12 })).toEqual({
      countryId: "c-1",
      name: "Japon",
      membersCount: 12,
      flagUrl: null,
    });
    expect(normalizeCountrySummary({ name: "Sans identifiant" })).toBeNull();
  });

  it("traduit les rangs et valide les empreintes de drapeau", () => {
    expect(roleLabel("OFFICER")).toBe("Officier");
    expect(roleLabel("ADMIN")).toBeNull();
    expect(ngFlagUrl("../etc/passwd")).toBeNull();
  });

  it("produit des données de démo stables, retrouvables par identifiant ou par nom", () => {
    const [first] = mockCountryList("blue");
    expect(mockNgCountry("blue", first.countryId).name).toBe(first.name);
    expect(mockNgCountry("blue", "corée du sud").name).toBe("Corée du Sud");
    expect(mockNgCountry("blue", "France").members).toEqual(mockNgCountry("blue", "France").members);
  });
});
