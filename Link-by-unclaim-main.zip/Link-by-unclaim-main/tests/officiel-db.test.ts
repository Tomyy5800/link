import { execSync } from "node:child_process";
import { existsSync, mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";

// Tests sur une vraie base SQLite temporaire (migrations appliquées) : ce que les règles
// d'accès et d'attribution font réellement en base, y compris en cas d'accès simultanés.

const dir = mkdtempSync(path.join(tmpdir(), "lbu-test-"));
const dbFile = path.join(dir, "test.db").replace(/\\/g, "/");
process.env.DATABASE_URL = `file:${dbFile}`;
process.env.APP_URL = "http://localhost:3000";
process.env.STRIPE_SECRET_KEY = "sk_test_unitaire";
process.env.DISCORD_BOT_TOKEN = "bot-token-de-test-suffisamment-long";

type Db = typeof import("@/lib/server/db");
let prisma: Db["prisma"];
let badges: typeof import("@/lib/server/badges");
let slugs: typeof import("@/lib/server/slugs");
let discord: typeof import("@/lib/server/discord-sync");
let payments: typeof import("@/lib/server/payments");
let shop: typeof import("@/lib/server/official-shop");
let access: typeof import("@/lib/server/access");

let seq = 0;
async function user(over: Record<string, unknown> = {}) {
  seq++;
  return prisma.user.create({
    data: {
      username: `compte${seq}`,
      unclaimId: `uncl_TEST${String(seq).padStart(20, "0")}`,
      discordId: `1000000000000${String(seq).padStart(5, "0")}`,
      termsVersion: "x",
      termsAcceptedAt: new Date(),
      ...over,
    },
  });
}
async function page(userId: string, slug: string, published = true) {
  return prisma.page.create({ data: { userId, slug, displayName: slug, published } });
}

beforeAll(async () => {
  execSync("npx prisma migrate deploy", { env: { ...process.env, DATABASE_URL: `file:${dbFile}` }, stdio: "ignore", cwd: process.cwd() });
  ({ prisma } = await import("@/lib/server/db"));
  badges = await import("@/lib/server/badges");
  slugs = await import("@/lib/server/slugs");
  discord = await import("@/lib/server/discord-sync");
  payments = await import("@/lib/server/payments");
  shop = await import("@/lib/server/official-shop");
  access = await import("@/lib/server/access");
  await badges.ensureSystemBadges();
}, 120_000);

afterAll(async () => {
  await prisma?.$disconnect();
  if (existsSync(dir)) {
    try {
      rmSync(dir, { recursive: true, force: true });
    } catch {
      // Windows : le fichier peut rester verrouillé un instant, il sera nettoyé avec le dossier temporaire.
    }
  }
});

describe("badge « premiers comptes »", () => {
  it("ne dépasse jamais la limite, même avec des inscriptions simultanées", async () => {
    const badge = await prisma.badge.create({
      data: { key: "pionnier", name: "Pionnier", rule: JSON.stringify({ type: "early", limit: 3, requireDiscord: true, requirePage: false }) },
    });
    const accounts = await Promise.all(Array.from({ length: 8 }, () => user()));
    const results = await Promise.all(accounts.map((a) => badges.claimEarlySlot(badge, a.id)));
    expect(results.filter(Boolean)).toHaveLength(3);
    expect(await prisma.userBadge.count({ where: { badgeId: badge.id } })).toBe(3);
    expect((await prisma.badge.findUniqueOrThrow({ where: { id: badge.id } })).autoGranted).toBe(3);
    // Une deuxième tentative pour un compte déjà servi ne prend pas de place.
    const winner = accounts[results.indexOf(true)]!;
    expect(await badges.claimEarlySlot(badge, winner.id)).toBe(false);
  });

  it("exige un compte Discord (un compte Discord = une place) et une page publiée si demandé", async () => {
    const badge = await prisma.badge.create({
      data: { key: "pionnier-2", name: "Pionnier 2", rule: JSON.stringify({ type: "early", limit: 10, requireDiscord: true, requirePage: true }) },
    });
    const noDiscord = await user({ discordId: null });
    const noPage = await user();
    const ok = await user();
    await page(ok.id, `page-ok-${seq}`);
    await badges.evaluateEarlyBadges(noDiscord.id);
    await badges.evaluateEarlyBadges(noPage.id);
    await badges.evaluateEarlyBadges(ok.id);
    const holders = await prisma.userBadge.findMany({ where: { badgeId: badge.id } });
    expect(holders.map((h) => h.userId)).toEqual([ok.id]);
  });
});

describe("badges : attribution, calcul, affichage", () => {
  it("refuse l'attribution manuelle d'un badge calculé et respecte le masquage choisi", async () => {
    const premium = await prisma.badge.findUniqueOrThrow({ where: { key: "premium" } });
    const subscriber = await user({ subTier: "plus", subUntil: new Date(Date.now() + 86_400_000) });
    await expect(badges.grantBadge(prisma, { badge: premium, userId: subscriber.id, actorId: "admin", source: "manual" })).rejects.toThrow();
    expect((await badges.publicBadgesOf(subscriber)).map((b) => b.key)).toContain("premium");
    // Le titulaire masque son badge « Premium » : préférence enregistrée, rien n'est attribué.
    await prisma.userBadge.create({ data: { userId: subscriber.id, badgeId: premium.id, source: badges.PREF_SOURCE, hidden: true } });
    expect((await badges.publicBadgesOf(subscriber)).map((b) => b.key)).not.toContain("premium");
    // Sans abonnement, la préférence seule ne donne pas le badge.
    const free = await user();
    await prisma.userBadge.create({ data: { userId: free.id, badgeId: premium.id, source: badges.PREF_SOURCE, hidden: false } });
    expect((await badges.badgesOf(free)).map((o) => o.badge.key)).not.toContain("premium");
  });

  it("attribue un badge du staff temporaire, l'affiche, puis le retire à l'échéance", async () => {
    const dev = await prisma.badge.findUniqueOrThrow({ where: { key: "developpeur" } });
    const someone = await user();
    await badges.grantBadge(prisma, { badge: dev, userId: someone.id, actorId: "admin", source: "manual", expiresAt: new Date(Date.now() + 60_000) });
    expect((await badges.publicBadgesOf(someone)).map((b) => b.key)).toContain("developpeur");
    await badges.purgeExpiredBadges(new Date(Date.now() + 120_000));
    expect((await badges.publicBadgesOf(someone)).map((b) => b.key)).not.toContain("developpeur");
    const log = await prisma.auditLog.findMany({ where: { targetType: "badge", targetId: dev.id }, orderBy: { createdAt: "asc" } });
    expect(log.map((l) => l.action)).toEqual(["badge.grant", "badge.expire"]);
  });

  it("n'affiche ni les badges désactivés ni le sceau d'un badge non validé", async () => {
    const custom = await prisma.badge.create({ data: { key: "champion", name: "Champion", active: false } });
    const someone = await user();
    await badges.grantBadge(prisma, { badge: custom, userId: someone.id, actorId: "admin", source: "manual" });
    expect((await badges.publicBadgesOf(someone)).find((b) => b.key === "champion")).toBeUndefined();
    await prisma.badge.update({ where: { id: custom.id }, data: { active: true } });
    expect((await badges.publicBadgesOf(someone)).find((b) => b.key === "champion")?.validated).toBe(false);
  });
});

describe("adresses de profil", () => {
  it("garde l'ancienne adresse 30 jours pour son propriétaire et redirige", async () => {
    const owner = await user();
    const other = await user();
    const p = await page(owner.id, "ancien-pseudo");
    expect(await slugs.changePageSlug(p, "nouveau-pseudo")).toBeNull();
    expect(await slugs.resolveOldSlug("ancien-pseudo")).toBe("nouveau-pseudo");
    // Personne d'autre ne peut reprendre l'ancienne adresse pendant le délai…
    expect((await slugs.slugAvailability("ancien-pseudo", other.id)).available).toBe(false);
    // …mais son propriétaire, oui (retour à l'ancienne adresse).
    expect((await slugs.slugAvailability("ancien-pseudo", owner.id)).available).toBe(true);
    const moved = await prisma.page.findUniqueOrThrow({ where: { id: p.id } });
    expect(await slugs.changePageSlug(moved, "ancien-pseudo")).toBeNull();
    expect(await slugs.resolveOldSlug("ancien-pseudo")).toBeNull();
    expect(await slugs.resolveOldSlug("nouveau-pseudo")).toBe("ancien-pseudo");
    // Une adresse déjà prise est refusée.
    await page(other.id, "deja-pris");
    expect(await slugs.changePageSlug({ ...moved, slug: "ancien-pseudo" }, "deja-pris")).toMatch(/déjà prise/);
  });

  it("ne redirige pas si la page l'a désactivé", async () => {
    const owner = await user();
    const p = await prisma.page.create({ data: { userId: owner.id, slug: "sans-suivi", displayName: "x", options: JSON.stringify({ redirectOldSlugs: false }) } });
    await slugs.changePageSlug(p, "sans-suivi-2");
    expect(await slugs.resolveOldSlug("sans-suivi")).toBeNull();
  });
});

describe("rôles personnalisés", () => {
  it("appliquent leurs permissions seulement si la formule du propriétaire le permet", async () => {
    const owner = await user();
    const member = await user();
    const p = await page(owner.id, `equipe-${seq}`);
    const role = await prisma.memberRole.create({ data: { pageId: p.id, name: "Modération messages", permissions: JSON.stringify(["messages.read", "messages.manage"]) } });
    await prisma.pageMember.create({ data: { pageId: p.id, userId: member.id, role: "editor", customRoleId: role.id } });
    // Propriétaire gratuit : le rôle personnalisé est ignoré, le rôle de base (Éditeur) s'applique.
    let a = await access.pageAccess(member.id, p.id);
    expect(a?.customRole).toBeNull();
    expect(a && access.hasPagePermission(a, "content")).toBe(true);
    // Propriétaire abonné Link+ : seules les permissions du rôle valent.
    await prisma.user.update({ where: { id: owner.id }, data: { subTier: "plus", subUntil: new Date(Date.now() + 86_400_000) } });
    a = await access.pageAccess(member.id, p.id);
    expect(a?.customRole?.name).toBe("Modération messages");
    expect(a && access.hasPagePermission(a, "content")).toBe(false);
    expect(a && access.hasPagePermission(a, "messages.manage")).toBe(true);
    expect(a && access.hasPagePermission(a, "orders")).toBe(false);
  });
});

describe("synchronisation Discord", () => {
  it("donne et retire les badges des rôles, sans toucher aux badges donnés à la main", async () => {
    const staffBadge = await prisma.badge.findUniqueOrThrow({ where: { key: "moderateur" } });
    const devBadge = await prisma.badge.findUniqueOrThrow({ where: { key: "developpeur" } });
    await prisma.discordRoleLink.create({ data: { roleId: "900000000000000001", roleName: "Modo", badgeId: staffBadge.id, removeOnLoss: true } });
    await prisma.discordRoleLink.create({ data: { roleId: "900000000000000002", roleName: "Dev", badgeId: devBadge.id, removeOnLoss: true } });
    const links = (await prisma.discordRoleLink.findMany({ include: { badge: true } })).filter((l) => l.badge.active);
    const modo = await user();
    // Badge « Développeur » donné à la main : la synchronisation ne doit jamais le retirer.
    await badges.grantBadge(prisma, { badge: devBadge, userId: modo.id, actorId: "admin", source: "manual" });

    expect(await discord.applyRoles(modo.id, ["900000000000000001"], links)).toEqual({ granted: 1, revoked: 0 });
    expect((await prisma.userBadge.findMany({ where: { userId: modo.id } })).map((g) => g.source).sort()).toEqual(["discord", "manual"]);
    expect(await discord.applyRoles(modo.id, [], links)).toEqual({ granted: 0, revoked: 1 });
    const left = await prisma.userBadge.findMany({ where: { userId: modo.id } });
    expect(left.map((g) => g.badgeId)).toEqual([devBadge.id]);
  });

  it("lit les rôles avec le jeton du bot et signale l'absence de configuration", async () => {
    const calls: string[] = [];
    vi.stubGlobal(
      "fetch",
      vi.fn(async (url: string, init: RequestInit) => {
        calls.push(`${url} ${(init.headers as Record<string, string>).Authorization}`);
        return new Response(JSON.stringify({ roles: ["900000000000000001"] }), { status: 200 });
      }),
    );
    expect(await discord.memberRoles("111111111111111111", "222222222222222222")).toEqual(["900000000000000001"]);
    expect(calls[0]).toBe("https://discord.com/api/v10/guilds/111111111111111111/members/222222222222222222 Bot bot-token-de-test-suffisamment-long");
    vi.unstubAllGlobals();
    const status = await discord.runDiscordSync();
    expect(status.ok).toBe(false);
    expect(status.message).toMatch(/serveur Discord/);
  });
});

describe("abonnements Stripe", () => {
  const sub = (over: Partial<import("@/lib/server/payments").StripeSubscription> = {}) => ({
    id: "sub_TEST000001",
    customer: "cus_TEST000001",
    status: "active",
    cancel_at_period_end: false,
    canceled_at: null,
    current_period_end: Math.floor(Date.now() / 1000) + 30 * 86_400,
    metadata: { tier: "pro", offerId: "pro-mois" },
    items: { data: [{ id: "si_1", price: { unit_amount: 499, currency: "eur", recurring: { interval: "month" } } }] },
    ...over,
  });

  it("n'active la formule que pour le compte du client Stripe, et la retire à la résiliation", async () => {
    const buyer = await user({ stripeCustomerId: "cus_TEST000001" });
    await payments.storeSubscription(sub());
    let fresh = await prisma.user.findUniqueOrThrow({ where: { id: buyer.id } });
    expect(fresh.subTier).toBe("pro");
    expect(fresh.subRenews).toBe(true);
    // Résilié à la fin de la période : la formule reste, sans renouvellement.
    await payments.storeSubscription(sub({ cancel_at_period_end: true }));
    fresh = await prisma.user.findUniqueOrThrow({ where: { id: buyer.id } });
    expect(fresh.subTier).toBe("pro");
    expect(fresh.subRenews).toBe(false);
    // Fin de l'abonnement chez Stripe : plus d'accès.
    await payments.storeSubscription(sub({ status: "canceled" }));
    fresh = await prisma.user.findUniqueOrThrow({ where: { id: buyer.id } });
    expect(fresh.subTier).toBe("free");
    expect(fresh.subUntil).toBeNull();
  });

  it("ne rattache pas l'abonnement d'un tiers à un autre compte via les métadonnées", async () => {
    const victim = await user({ stripeCustomerId: "cus_VICTIME0001" });
    const stored = await payments.storeSubscription(sub({ id: "sub_TEST000002", customer: "cus_INCONNU0001", metadata: { tier: "team", userId: victim.id } }));
    expect(stored).toBeNull();
    expect((await prisma.user.findUniqueOrThrow({ where: { id: victim.id } })).subTier).toBe("free");
  });

  it("relit l'abonnement chez Stripe à chaque événement (jamais le contenu seul)", async () => {
    const buyer = await user({ stripeCustomerId: "cus_TEST000003" });
    const fetched: string[] = [];
    vi.stubGlobal(
      "fetch",
      vi.fn(async (url: string, init: RequestInit) => {
        fetched.push(`${init.method} ${url} ${(init.headers as Record<string, string>)["Stripe-Version"]}`);
        return new Response(JSON.stringify(sub({ id: "sub_TEST000003", customer: "cus_TEST000003", metadata: { tier: "team", offerId: "equipe-mois" } })), { status: 200 });
      }),
    );
    // L'événement prétend « Équipe actif » mais seul ce que renvoie l'API compte.
    await payments.handleStripeEvent({ id: "evt_1", type: "customer.subscription.updated", data: { object: { id: "sub_TEST000003", status: "active" } } });
    vi.unstubAllGlobals();
    expect(fetched).toEqual([`GET https://api.stripe.com/v1/subscriptions/sub_TEST000003 ${payments.STRIPE_API_VERSION}`]);
    expect((await prisma.user.findUniqueOrThrow({ where: { id: buyer.id } })).subTier).toBe("team");
  });
});

describe("boutique officielle", () => {
  it("livre la récompense une seule fois après paiement et la reprend au remboursement", async () => {
    const buyer = await user();
    const item = await prisma.shopItem.create({ data: { slug: "cadre-or", category: "profil", name: "Cadre Or", priceCents: 299, reward: JSON.stringify({ type: "frame", frame: "or" }), active: true } });
    const order = await prisma.order.create({ data: { userId: buyer.id, kind: "item", itemId: item.id, offerId: item.slug, offerName: item.name, days: 0, amountCents: 299 } });
    expect(await shop.framesOf(buyer)).toEqual([]);
    await payments.fulfillOrder(order.id, "pi_1");
    await payments.fulfillOrder(order.id, "pi_1"); // événement reçu deux fois
    expect(await shop.framesOf(buyer)).toEqual(["or"]);
    expect(await prisma.userUnlock.count({ where: { userId: buyer.id } })).toBe(1);
    await payments.markRefunded(order.id, "admin", true);
    expect(await shop.framesOf(buyer)).toEqual([]);
  });

  it("refuse de vendre un badge du staff", async () => {
    expect(await shop.rewardError({ reward: { type: "badge", badgeKey: "administrateur" } })).toMatch(/staff/);
    expect(await shop.rewardError({ reward: { type: "badge", badgeKey: "premium" } })).toMatch(/manuelle/);
  });
});
