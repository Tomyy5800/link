// Remplace le paquet « server-only » dans les tests (voir vitest.config.mts).
export {};
