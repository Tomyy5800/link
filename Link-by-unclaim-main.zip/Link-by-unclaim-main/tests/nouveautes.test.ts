import { describe, expect, it } from "vitest";
import { daysInMonth, isValidBirthday, nextBirthday } from "@/lib/birthday";
import { blockSchema, createBlock } from "@/lib/blocks";
import { discordMarkupToText, discordTimestampTag, formatDiscordTimestamp, relativeTime } from "@/lib/discord-markup";
import { EMOJI_SHORTCODES, replaceShortcodes } from "@/lib/emoji";
import { activeRedirect, pageOptionsSchema, parsePageOptions } from "@/lib/page-schema";
import { normalizeNowPlaying, resolveRadio } from "@/lib/radio";
import { plainText } from "@/lib/text";
import { themeSchema } from "@/lib/theme";

describe("anniversaire", () => {
  it("vise le prochain anniversaire à minuit, l'année suivante s'il est passé", () => {
    const info = nextBirthday("03-15", new Date(2026, 9, 16, 14, 0), 2008);
    expect(info?.target).toEqual(new Date(2027, 2, 15));
    expect(info?.isToday).toBe(false);
    expect(info?.turning).toBe(19);
  });

  it("reconnaît le jour J toute la journée", () => {
    const info = nextBirthday("10-16", new Date(2026, 9, 16, 23, 59), 2008);
    expect(info?.isToday).toBe(true);
    expect(info?.turning).toBe(18);
  });

  it("fête le 29 février le 28 les années non bissextiles", () => {
    expect(nextBirthday("02-29", new Date(2026, 0, 1))?.target).toEqual(new Date(2026, 1, 28));
    expect(nextBirthday("02-29", new Date(2028, 0, 1))?.target).toEqual(new Date(2028, 1, 29));
  });

  it("refuse une date invalide", () => {
    expect(nextBirthday("13-01", new Date())).toBeNull();
    expect(nextBirthday("", new Date())).toBeNull();
  });

  it("ne valide que des jours qui existent (le bloc s'affiche alors sur la page publique)", () => {
    expect(isValidBirthday("02-29")).toBe(true);
    expect(isValidBirthday("04-31")).toBe(false);
    expect(isValidBirthday("")).toBe(false);
    expect([daysInMonth(2), daysInMonth(4), daysInMonth(12)]).toEqual([29, 30, 31]);
  });
});

describe("mise en forme Discord", () => {
  const ts = Date.UTC(2026, 11, 24, 19, 30) / 1000;

  it("formate les dates comme Discord, en français", () => {
    expect(formatDiscordTimestamp(ts, "t", 0, "Europe/Paris")).toBe("20:30");
    expect(formatDiscordTimestamp(ts, "d", 0, "Europe/Paris")).toBe("24/12/2026");
    expect(formatDiscordTimestamp(ts, "D", 0, "Europe/Paris")).toBe("24 décembre 2026");
    expect(formatDiscordTimestamp(ts, "R", (ts - 3 * 86_400) * 1000)).toBe("dans 3 jours");
    expect(relativeTime(-2 * 3_600_000)).toBe("il y a 2 heures");
  });

  it("produit la balise <t:…> que Discord comprend", () => {
    expect(discordTimestampTag(new Date(ts * 1000), "R")).toBe(`<t:${ts}:R>`);
  });

  it("donne une version texte des dates et des émojis personnalisés", () => {
    expect(discordMarkupToText(`Guerre <t:${ts}:D> <:epee:123456789012345678>`)).toBe("Guerre 24 décembre 2026 :epee:");
    expect(plainText("On part :fire: **ce soir**")).toBe("On part 🔥 ce soir");
  });

  it("remplace les codes d'émojis connus seulement", () => {
    expect(replaceShortcodes(":heart: :inconnu: 12:30:45")).toBe("❤️ :inconnu: 12:30:45");
    expect(Object.keys(EMOJI_SHORTCODES).length).toBeGreaterThan(200);
  });
});

describe("radio", () => {
  it("connaît LyxiaRadio", () => {
    expect(resolveRadio("lyxia")).toMatchObject({ name: "LyxiaRadio", stream: "https://radio.helyxia.fr/listen/lyxia/radio.mp3" });
  });

  it("reconnaît une page AzuraCast et un flux https, refuse le http", () => {
    expect(resolveRadio("https://radio.exemple.fr/public/ma_radio")).toMatchObject({
      stream: "https://radio.exemple.fr/listen/ma_radio/radio.mp3",
      nowPlaying: "https://radio.exemple.fr/api/nowplaying/ma_radio",
    });
    expect(resolveRadio("https://flux.exemple.fr/live.mp3")?.nowPlaying).toBeNull();
    expect(resolveRadio("http://flux.exemple.fr/live.mp3")).toBeNull();
    expect(resolveRadio("javascript:alert(1)")).toBeNull();
  });

  it("lit la réponse AzuraCast", () => {
    const now = normalizeNowPlaying({
      is_online: true,
      station: { listen_url: "https://radio.exemple.fr/listen/x/radio.mp3" },
      listeners: { current: 7 },
      live: { is_live: true, streamer_name: "DJ Kaelis" },
      now_playing: { elapsed: 30, duration: 200, song: { title: "Dai Dai", artist: "Shakira", art: "https://radio.exemple.fr/art.jpg" } },
      song_history: [{ song: { title: "Avant", artist: "Quelqu'un" } }],
    });
    expect(now).toMatchObject({ title: "Dai Dai", artist: "Shakira", listeners: 7, live: { isLive: true, streamer: "DJ Kaelis" } });
    expect(now?.history).toEqual([{ title: "Avant", artist: "Quelqu'un" }]);
    expect(normalizeNowPlaying("pas un objet")).toBeNull();
  });

  it("valide la radio d'un bloc et de la musique de fond", () => {
    expect(blockSchema.safeParse({ ...createBlock("radio"), data: { station: "ftp://x" } }).success).toBe(false);
    expect(themeSchema.parse({ audioRadio: "lyxia" }).audioRadio).toBe("lyxia");
    expect(themeSchema.safeParse({ audioRadio: "http://non-securise.fr/flux" }).success).toBe(false);
  });
});

describe("nouveaux blocs", () => {
  it("crée chaque nouveau bloc avec des valeurs par défaut valides", () => {
    for (const type of ["radio", "music", "events", "collection"] as const) {
      expect(blockSchema.safeParse(createBlock(type)).success).toBe(true);
    }
    expect(createBlock("countdown", { mode: "birthday", birthday: "07-14" }).data.birthday).toBe("07-14");
    expect(blockSchema.safeParse({ ...createBlock("countdown"), data: { mode: "birthday", birthday: "14-07" } }).success).toBe(false);
  });

  it("enrichit les liens sans casser les anciens", () => {
    const link = createBlock("link", { label: "Live", url: "https://twitch.tv/x", emoji: "🔴", animation: "pulse", sensitive: true });
    expect(link.data).toMatchObject({ emoji: "🔴", animation: "pulse", sensitive: true, layout: "classic" });
    expect(createBlock("link", { label: "Ancien" }).data.animation).toBe("none");
  });
});

describe("options de page", () => {
  it("relit des options abîmées sans planter", () => {
    expect(parsePageOptions("pas du json").shareButton).toBe(true);
    expect(parsePageOptions('{"ageGate":true}').ageGate).toBe(true);
  });

  it("n'accepte que le https pour la redirection et respecte la date de fin", () => {
    expect(pageOptionsSchema.safeParse({ redirectUrl: "http://twitch.tv/x" }).success).toBe(false);
    const options = pageOptionsSchema.parse({ redirectUrl: "https://twitch.tv/x", redirectUntil: "2026-10-16T20:00:00.000Z" });
    expect(activeRedirect(options, Date.parse("2026-10-16T19:00:00Z"))).toBe("https://twitch.tv/x");
    expect(activeRedirect(options, Date.parse("2026-10-16T21:00:00Z"))).toBeNull();
  });
});
