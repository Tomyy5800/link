import { createHmac } from "node:crypto";
import { describe, expect, it } from "vitest";
import { DEFAULT_SETTINGS, formatDuration, formatPrice, missingLegal } from "@/lib/features";
import { parseIdentities, providerMeta } from "@/lib/identity";
import { stripeForm, verifyStripeSignature } from "@/lib/server/payments";
import { settingsSchema } from "@/lib/server/settings";

const SECRET = "whsec_test_secret";
const sign = (payload: string, t: number, secret = SECRET) => `t=${t},v1=${createHmac("sha256", secret).update(`${t}.${payload}`).digest("hex")}`;

describe("webhook Stripe", () => {
  const payload = JSON.stringify({ id: "evt_1", type: "checkout.session.completed" });
  const now = Date.parse("2026-10-15T12:00:00Z");
  const t = Math.floor(now / 1000);

  it("accepte une signature valide et récente", () => {
    expect(verifyStripeSignature(payload, sign(payload, t), SECRET, now)).toBe(true);
    // Plusieurs signatures (rotation du secret) : une seule valide suffit.
    expect(verifyStripeSignature(payload, `${sign(payload, t)},v1=deadbeef`, SECRET, now)).toBe(true);
  });

  it("refuse un corps modifié, un autre secret, un rejeu ancien ou un en-tête absent", () => {
    expect(verifyStripeSignature(payload.replace("evt_1", "evt_2"), sign(payload, t), SECRET, now)).toBe(false);
    expect(verifyStripeSignature(payload, sign(payload, t, "whsec_autre"), SECRET, now)).toBe(false);
    expect(verifyStripeSignature(payload, sign(payload, t - 600), SECRET, now)).toBe(false);
    expect(verifyStripeSignature(payload, null, SECRET, now)).toBe(false);
    expect(verifyStripeSignature(payload, "t=abc,v1=", SECRET, now)).toBe(false);
  });
});

describe("API Stripe", () => {
  it("encode les paramètres imbriqués comme l'attend Stripe", () => {
    const form = stripeForm({ mode: "payment", metadata: { orderId: "o1" }, line_items: [{ quantity: 1, price_data: { unit_amount: 249 } }], skip: null });
    expect(form.toString()).toBe(
      "mode=payment&metadata%5BorderId%5D=o1&line_items%5B0%5D%5Bquantity%5D=1&line_items%5B0%5D%5Bprice_data%5D%5Bunit_amount%5D=249",
    );
  });
});

describe("offres", () => {
  it("affiche prix et durées en français", () => {
    expect(formatPrice(1999)).toMatch(/^19,99\s€$/);
    expect(formatDuration(0)).toBe("à vie");
    expect(formatDuration(30)).toBe("1 mois");
    expect(formatDuration(365)).toBe("1 an");
    expect(formatDuration(730)).toBe("2 ans");
    expect(formatDuration(45)).toBe("45 jours");
  });

  it("valide les réglages par défaut et refuse un prix sous le minimum ou un doublon", () => {
    expect(settingsSchema.safeParse(DEFAULT_SETTINGS).success).toBe(true);
    const cheap = { ...DEFAULT_SETTINGS, offers: [{ ...DEFAULT_SETTINGS.offers[0], priceCents: 10 }] };
    expect(settingsSchema.safeParse(cheap).success).toBe(false);
    const twice = { ...DEFAULT_SETTINGS, offers: [DEFAULT_SETTINGS.offers[0], DEFAULT_SETTINGS.offers[0]] };
    expect(settingsSchema.safeParse(twice).success).toBe(false);
  });

  it("signale les informations légales manquantes", () => {
    expect(missingLegal(DEFAULT_SETTINGS.legal)).toContain("sellerName");
    expect(missingLegal(DEFAULT_SETTINGS.legal)).not.toContain("vatMention");
  });
});

describe("identités", () => {
  it("ne montre publiquement que Discord, Twitch et NationsGlory", () => {
    expect(providerMeta("discord").publicHandle).toBe(true);
    expect(providerMeta("google").publicHandle).toBe(false);
    expect(providerMeta("inconnu").name).toBe("Inconnu");
  });

  it("relit les identités stockées sans planter sur une valeur abîmée", () => {
    expect(parseIdentities('[{"provider":"twitch","username":"kaelis"}]')).toEqual([{ provider: "twitch", username: "kaelis" }]);
    expect(parseIdentities("pas du json")).toEqual([]);
    expect(parseIdentities('[{"username":"sans fournisseur"}]')).toEqual([]);
  });
});
