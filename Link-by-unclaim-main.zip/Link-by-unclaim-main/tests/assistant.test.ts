import { describe, expect, it } from "vitest";
import { buildPageFromDraft, extractGames, localAssistantTurn, sanitizeDraft, type ChatMessage } from "@/lib/assistant";
import { blockSchema } from "@/lib/blocks";

function conversation(answers: string[]): ChatMessage[] {
  const messages: ChatMessage[] = [];
  for (const a of answers) messages.push({ role: "assistant", content: "…" }, { role: "user", content: a });
  return messages;
}

describe("assistant de création (mode guidé)", () => {
  it("pose la première question sans message", () => {
    const turn = localAssistantTurn([], { name: "Kaelis" });
    expect(turn.ready).toBe(false);
    expect(turn.reply).toContain("Kaelis");
  });

  it("construit une page complète en cinq réponses", () => {
    const turn = localAssistantTurn(
      conversation([
        "Kaelis",
        "Je stream sur Twitch le mercredi et je fais des tournois, anniversaire le 12 mars",
        "twitch kaelis, tiktok kaelis, https://discord.gg/abcdef, https://kaelis.fr",
        "Minecraft Notch, NationsGlory Kaelis, Valorant Kae#EUW",
        "néon",
      ]),
      { name: "Kaelis" },
    );
    expect(turn.ready).toBe(true);
    const d = turn.draft;
    expect(d.displayName).toBe("Kaelis");
    expect(d.template).toBe("streamer");
    expect(d.preset).toBe("neon");
    expect(d.birthday).toBe("03-12");
    expect(d.socials).toEqual(expect.arrayContaining(["https://twitch.tv/kaelis", "https://www.tiktok.com/@kaelis"]));
    expect(d.discordInvite).toBe("https://discord.gg/abcdef");
    expect(d.links.map((l) => l.url)).toEqual(expect.arrayContaining(["https://twitch.tv/kaelis", "https://kaelis.fr/"]));
    expect(d.ngUsername).toBe("Kaelis");
    expect(d.games.map((g) => g.game)).toEqual(["minecraft", "valorant"]);
    expect(d.events).toBe(true);

    const built = buildPageFromDraft(d, { hasDiscord: false });
    expect(built.theme.layout).toBe("grid");
    for (const block of built.blocks) expect(blockSchema.safeParse(block).success, block.type).toBe(true);
    expect(built.blocks.map((b) => b.type)).toEqual(expect.arrayContaining(["socials", "link", "discordServer", "nationsglory", "game", "events", "countdown"]));
  });

  it("ne mélange jamais deux conversations (brouillon neuf à chaque tour)", () => {
    const answers = conversation(["A", "Je stream", "twitch kaelis", "non", "néon"]);
    localAssistantTurn(answers, { name: "A" });
    expect(localAssistantTurn(answers, { name: "A" }).draft.links).toHaveLength(1);
  });

  it("accepte qu'on saute des questions", () => {
    const turn = localAssistantTurn(conversation(["Zoé", "non", "aucun", "non", "comme tu veux"]), { name: "Zoé" });
    expect(turn.ready).toBe(true);
    expect(turn.draft.template).toBe("minimal");
    expect(buildPageFromDraft(turn.draft, { hasDiscord: true }).blocks.length).toBeGreaterThan(0);
  });

  it("repère les jeux dans une phrase libre", () => {
    expect(extractGames("je joue à Paladium sous le pseudo Steve et à roblox builderman").games).toEqual([
      { game: "paladium", username: "Steve", rank: "" },
      { game: "roblox", username: "builderman", rank: "" },
    ]);
  });

  it("ne garde d'un brouillon que des valeurs sûres", () => {
    const d = sanitizeDraft({
      displayName: "  A ".repeat(40),
      template: "pirate",
      preset: "inexistant",
      links: [{ label: "x", url: "javascript:alert(1)" }, { label: "ok", url: "exemple.fr" }],
      socials: ["http://twitch.tv/x", "https://twitch.tv/x"],
      games: [{ game: "tetris", username: "a" }],
      discordInvite: "https://evil.com",
      birthday: "13-45",
    });
    expect(d.displayName.length).toBeLessThanOrEqual(48);
    expect(d.template).toBe("minimal");
    expect(d.links).toEqual([{ label: "ok", url: "https://exemple.fr/", emoji: "" }]);
    expect(d.socials).toEqual(["https://twitch.tv/x"]);
    expect(d.games).toEqual([]);
    expect(d.discordInvite).toBe("");
    expect(d.birthday).toBe("");
  });
});
