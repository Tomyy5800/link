import { describe, expect, it } from "vitest";
import { blockSchema, blockSummary, createBlock, parseStoredBlock } from "@/lib/blocks";
import { DEFAULT_SETTINGS, FEATURE_KEYS } from "@/lib/features";
import { notificationsSchema } from "@/lib/notifications";
import {
  discountPercent,
  formatMoney,
  isAvailable,
  makeProduct,
  newProductId,
  orderTotal,
  parseOrderItems,
  parsePrice,
  priceInput,
  resolveCart,
} from "@/lib/shop";

const products = [
  makeProduct({ id: "p-sweat", name: "Sweat", price: 3900, compareAt: 4900, options: ["S", "M", ""], mode: "order" }),
  makeProduct({ id: "p-poster", name: "Poster", price: 1500, mode: "order", stock: 2 }),
  makeProduct({ id: "p-libre", name: "Commission", price: null, mode: "order" }),
  makeProduct({ id: "p-lien", name: "Vinyle", price: 2400, mode: "link", url: "https://example.com" }),
  makeProduct({ id: "p-epuise", name: "Tote bag", price: 1200, mode: "order", soldOut: true }),
];

describe("boutique : prix", () => {
  it("lit les montants tapés à la française et les réécrit", () => {
    expect(parsePrice("12,5")).toBe(1250);
    expect(parsePrice("12.50 €")).toBe(1250);
    expect(parsePrice(" 3 900 ")).toBe(390000);
    expect(parsePrice("")).toBeNull();
    expect(parsePrice("abc")).toBeNull();
    expect(priceInput(1250)).toBe("12,50");
    expect(priceInput(3900)).toBe("39");
    expect(priceInput(null)).toBe("");
  });

  it("affiche les prix sans centimes inutiles et calcule la remise", () => {
    expect(formatMoney(3900, "EUR").replace(/\s/g, " ")).toBe("39 €");
    expect(formatMoney(1250, "EUR").replace(/\s/g, " ")).toBe("12,50 €");
    expect(discountPercent(3900, 4900)).toBe(20);
    expect(discountPercent(3900, 3900)).toBeNull();
    expect(discountPercent(null, 4900)).toBeNull();
  });
});

describe("boutique : panier", () => {
  it("regroupe les lignes identiques et fige nom et prix", () => {
    const cart = resolveCart(products, [
      { productId: "p-sweat", option: "M", quantity: 1 },
      { productId: "p-sweat", option: "M", quantity: 2 },
      { productId: "p-poster", option: "", quantity: 1 },
    ]);
    expect("items" in cart && cart.items).toEqual([
      { productId: "p-sweat", name: "Sweat", option: "M", quantity: 3, price: 3900 },
      { productId: "p-poster", name: "Poster", option: "", quantity: 1, price: 1500 },
    ]);
    expect("items" in cart && orderTotal(cart.items)).toBe(3 * 3900 + 1500);
  });

  it("refuse les produits introuvables, à lien, épuisés ou sans option choisie", () => {
    expect(resolveCart(products, [])).toEqual({ error: "Ton panier est vide." });
    expect("error" in resolveCart(products, [{ productId: "p-inconnu", option: "", quantity: 1 }])).toBe(true);
    expect("error" in resolveCart(products, [{ productId: "p-lien", option: "", quantity: 1 }])).toBe(true);
    expect("error" in resolveCart(products, [{ productId: "p-epuise", option: "", quantity: 1 }])).toBe(true);
    expect("error" in resolveCart(products, [{ productId: "p-sweat", option: "", quantity: 1 }])).toBe(true);
    expect("error" in resolveCart(products, [{ productId: "p-sweat", option: "XXL", quantity: 1 }])).toBe(true);
    expect("error" in resolveCart(products, [{ productId: "p-sweat", option: "S", quantity: 0 }])).toBe(true);
  });

  it("respecte le stock et laisse le total ouvert pour un prix libre", () => {
    expect(resolveCart(products, [{ productId: "p-poster", option: "", quantity: 3 }])).toEqual({ error: "Il ne reste que 2 « Poster »." });
    const cart = resolveCart(products, [{ productId: "p-libre", option: "", quantity: 1 }]);
    expect("items" in cart && orderTotal(cart.items)).toBeNull();
    expect(isAvailable({ soldOut: false, stock: 0 })).toBe(false);
  });

  it("relit des articles enregistrés, même abîmés", () => {
    expect(parseOrderItems('[{"productId":"p","name":"A","option":"","quantity":2,"price":100}]')).toEqual([
      { productId: "p", name: "A", option: "", quantity: 2, price: 100 },
    ]);
    expect(parseOrderItems("pas du json")).toEqual([]);
    expect(newProductId()).toMatch(/^p-[a-z0-9]{1,10}$/);
  });
});

describe("boutique : bloc et réglages", () => {
  it("valide un bloc boutique complet et le résume", () => {
    const block = createBlock("shop", { title: "Merch", products: products.slice(0, 2) });
    expect(blockSchema.safeParse(block).success).toBe(true);
    expect(blockSummary(block)).toBe("Merch · 2 produits");
    expect(blockSummary(createBlock("shop", {}))).toBe("Boutique vide");
  });

  it("refuse les prix négatifs et les identifiants farfelus", () => {
    const bad = createBlock("shop", {});
    expect(blockSchema.safeParse({ ...bad, data: { ...bad.data, products: [makeProduct({ id: "p-1", name: "A", price: -5 })] } }).success).toBe(false);
    expect(blockSchema.safeParse({ ...bad, data: { ...bad.data, products: [makeProduct({ id: "p 1/<x>", name: "A" })] } }).success).toBe(false);
  });

  it("garde les produits d'un bloc stocké même si un champ récent manque", () => {
    const stored = { id: crypto.randomUUID(), type: "shop", width: "full", visible: true, data: JSON.stringify({ products: [{ id: "p-old", name: "Ancien", price: 500 }] }) };
    const block = parseStoredBlock(stored);
    expect(block?.type === "shop" && block.data.products[0]).toMatchObject({ id: "p-old", name: "Ancien", price: 500, emoji: "", mode: "link" });
  });

  it("ouvre la boutique à tous par défaut et notifie les commandes", () => {
    expect(FEATURE_KEYS).toContain("shop");
    expect(DEFAULT_SETTINGS.features.shop).toBe("all");
    expect(notificationsSchema.parse({}).onOrder).toBe(true);
  });
});
