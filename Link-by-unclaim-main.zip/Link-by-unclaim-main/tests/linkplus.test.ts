import { describe, expect, it } from "vitest";
import { createBlock } from "@/lib/blocks";
import { sanitizeCss, scopeCss } from "@/lib/css";
import { describeEmbed } from "@/lib/embeds";
import { ALL_FEATURES, DEFAULT_SETTINGS, isDomainBlocked, resolveFeatures } from "@/lib/features";
import { sniffMedia } from "@/lib/media";
import { validateSlug } from "@/lib/slug";
import { entitlementsFrom, isPremium, suspension } from "@/lib/server/entitlements";
import { generateCode, hashCode, normalizeCode } from "@/lib/server/premium";

const user = (
  patch: Partial<{ role: string; plan: string; planExpiresAt: Date | null; discordId: string | null; unclaimId: string | null; verified: boolean }> = {},
) => ({
  role: "user",
  plan: "free",
  planExpiresAt: null as Date | null,
  discordId: "123456789012345678" as string | null,
  unclaimId: null as string | null,
  verified: false,
  ...patch,
});

describe("fonctionnalités et offre Link+", () => {
  it("ouvre une fonctionnalité selon son mode et l'offre du compte", () => {
    const modes = { ...DEFAULT_SETTINGS.features, effects: "plus" as const, customCss: "pro" as const, presence: "off" as const, advancedLayout: "all" as const };
    expect(resolveFeatures(modes, "free")).toMatchObject({ effects: false, customCss: false, presence: false, advancedLayout: true });
    expect(resolveFeatures(modes, "plus")).toMatchObject({ effects: true, customCss: false, presence: false, advancedLayout: true });
    expect(resolveFeatures(modes, "team")).toMatchObject({ effects: true, customCss: true, presence: false });
  });

  it("tient compte de la date de fin de Link+", () => {
    const now = Date.parse("2026-10-14T12:00:00Z");
    expect(isPremium(user({ plan: "premium", planExpiresAt: null }), now)).toBe(true);
    expect(isPremium(user({ plan: "premium", planExpiresAt: new Date(now + 1000) }), now)).toBe(true);
    expect(isPremium(user({ plan: "premium", planExpiresAt: new Date(now - 1000) }), now)).toBe(false);
    expect(isPremium(user({ plan: "free" }), now)).toBe(false);
  });

  it("applique les limites de l'offre, et tout Link+ aux administrateurs", () => {
    expect(entitlementsFrom(user(), DEFAULT_SETTINGS, { freeForAll: false }).limits).toEqual(DEFAULT_SETTINGS.limits.free);
    const admin = entitlementsFrom(user({ role: "admin" }), DEFAULT_SETTINGS, { freeForAll: false });
    expect(admin.admin).toBe(true);
    expect(admin.premium).toBe(true);
    expect(admin.tier).toBe("team");
    expect(admin.limits).toEqual(DEFAULT_SETTINGS.limits.pro);
  });

  it("offre tout Link+ à tous tant qu'il n'y a pas de clé Stripe, sauf ce qui est coupé", () => {
    const settings = { ...DEFAULT_SETTINGS, features: { ...DEFAULT_SETTINGS.features, presence: "off" as const } };
    const free = entitlementsFrom(user(), settings, { freeForAll: true });
    expect(free.premium).toBe(true);
    expect(free.freeForAll).toBe(true);
    expect(free.limits).toEqual(DEFAULT_SETTINGS.limits.pro);
    expect(free.features).toMatchObject({ effects: true, customCss: true, presence: false });
    expect(entitlementsFrom(user(), settings, { freeForAll: false }).features.effects).toBe(false);
  });

  it("repère les suspensions de compte puis de page", () => {
    expect(suspension({ suspendedAt: new Date(), suspendReason: "spam" })).toEqual({ scope: "account", reason: "spam" });
    expect(suspension({ suspendedAt: null, suspendReason: "" }, { status: "suspended", statusReason: "arnaque" })).toEqual({ scope: "page", reason: "arnaque" });
    expect(suspension({ suspendedAt: null, suspendReason: "" }, { status: "active", statusReason: "" })).toBeNull();
  });

  it("bloque un domaine et ses sous-domaines", () => {
    expect(isDomainBlocked("www.evil.example", ["evil.example"])).toBe(true);
    expect(isDomainBlocked("cdn.evil.example", ["*.evil.example"])).toBe(true);
    expect(isDomainBlocked("notevil.example", ["evil.example"])).toBe(false);
  });

  it("réserve les adresses de 3 ou 4 caractères", () => {
    expect(validateSlug("abc").ok).toBe(false);
    expect(validateSlug("abcd", { premiumName: "Link+" })).toMatchObject({ ok: false, error: expect.stringContaining("Link+") });
    expect(validateSlug("abc", { allowShort: true })).toEqual({ ok: true, slug: "abc" });
    expect(validateSlug("ab", { allowShort: true }).ok).toBe(false);
  });
});

describe("codes Link+", () => {
  it("génère des codes lisibles, sans caractères ambigus", () => {
    const code = generateCode();
    expect(code).toMatch(/^LBU-[A-HJ-KMNP-Z2-9]{4}-[A-HJ-KMNP-Z2-9]{4}-[A-HJ-KMNP-Z2-9]{4}$/);
    expect(generateCode()).not.toBe(code);
  });

  it("ignore la casse, les espaces et les tirets à la saisie", () => {
    expect(normalizeCode(" lbu-abcd efgh-2345 ")).toBe("LBUABCDEFGH2345");
    expect(hashCode("lbu-abcd-efgh-2345")).toBe(hashCode("LBU ABCD EFGH 2345"));
  });
});

describe("CSS personnalisé", () => {
  it("refuse ce qui permettrait de sortir de la page ou de charger du code", () => {
    expect(sanitizeCss("@import url(https://x.y/a.css);").ok).toBe(false);
    expect(sanitizeCss("a{background:url(javascript:alert(1))}").ok).toBe(false);
    expect(sanitizeCss("a{color:red}} body{display:none}").ok).toBe(false);
    expect(sanitizeCss("</style><script>alert(1)</script>").ok).toBe(false);
    expect(sanitizeCss("a{background:url(http://x.y/a.png)}").ok).toBe(false);
    expect(sanitizeCss("a{content:'\\3c'}").ok).toBe(false);
  });

  it("accepte une feuille raisonnable et la cantonne à la page", () => {
    const check = sanitizeCss("/* titre */ .lbu-card{border-width:2px;background:url(https://exemple.fr/a.png)} @keyframes spin{to{rotate:1turn}}");
    expect(check.ok).toBe(true);
    if (!check.ok) return;
    const scoped = scopeCss(check.css, '.lbu-page[data-page="kaelis"]');
    expect(scoped).toContain('.lbu-page[data-page="kaelis"]{.lbu-card{');
    expect(scoped.startsWith("@keyframes spin")).toBe(true);
  });
});

describe("intégrations", () => {
  const embed = (data: object) => createBlock("embed", data as never).data as Parameters<typeof describeEmbed>[0];

  it("verrouille l'iframe libre et le HTML sans Link+", () => {
    expect(describeEmbed(embed({ mode: "iframe", url: "https://exemple.fr" }), { iframe: false, html: false }, []).kind).toBe("locked");
    expect(describeEmbed(embed({ mode: "html", html: "<b>hi</b>" }), { iframe: false, html: false }, []).kind).toBe("locked");
    expect(describeEmbed(embed({ mode: "html", html: "<b>hi</b>" }), { iframe: true, html: true }, []).kind).toBe("html");
  });

  it("respecte les domaines bloqués par l'administration", () => {
    expect(describeEmbed(embed({ mode: "iframe", url: "https://evil.example/x" }), { iframe: true, html: true }, ["evil.example"]).kind).toBe("blocked");
    expect(describeEmbed(embed({ url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ" }), { iframe: false, html: false }, ["youtube-nocookie.com"]).kind).toBe(
      "blocked",
    );
    expect(describeEmbed(embed({ url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ" }), { iframe: false, html: false }, []).kind).toBe("frame");
  });

  it("expose toutes les fonctionnalités en démonstration", () => {
    expect(Object.values(ALL_FEATURES).every(Boolean)).toBe(true);
  });
});

describe("fichiers importés", () => {
  const bytes = (...parts: (number[] | string)[]) =>
    new Uint8Array(parts.flatMap((p) => (typeof p === "string" ? [...p].map((c) => c.charCodeAt(0)) : p)));

  it("reconnaît le format réel par les premiers octets", () => {
    expect(sniffMedia(bytes([0x89], "PNG", [0x0d, 0x0a, 0x1a, 0x0a]))?.mimeType).toBe("image/png");
    expect(sniffMedia(bytes("ID3", [4, 0, 0]))).toEqual({ kind: "audio", mimeType: "audio/mpeg" });
    expect(sniffMedia(bytes([0, 0, 0, 0x20], "ftypisom")))?.toEqual({ kind: "video", mimeType: "video/mp4" });
    expect(sniffMedia(bytes([0, 0, 0, 0x20], "ftypM4A ")))?.toEqual({ kind: "audio", mimeType: "audio/mp4" });
    expect(sniffMedia(bytes("<svg onload=alert(1)>"))).toBeNull();
  });
});
