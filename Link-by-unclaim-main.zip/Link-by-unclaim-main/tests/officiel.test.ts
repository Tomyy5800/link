import { afterEach, describe, expect, it } from "vitest";
import { SYSTEM_BADGES, acceptsManualGrant, badgeInputSchema, isComputedRule, parseBadgeRule } from "@/lib/badges";
import { hostFromHeaders, isCustomHost, siteHost } from "@/lib/custom-host";
import { isApexDomain, normalizeHostname } from "@/lib/domains";
import { DEFAULT_SETTINGS, FEATURES, monthlyCents } from "@/lib/features";
import { BASE_ROLE_PERMISSIONS, memberRoleInputSchema } from "@/lib/member-roles";
import { parseShopReward, shopItemInputSchema } from "@/lib/official-shop";
import { blockSchema, createBlock } from "@/lib/blocks";
import { isOfficialName } from "@/lib/reserved-names";
import { validateSlug } from "@/lib/slug";
import { can, parseStaffPermissions } from "@/lib/staff";
import { computedHolds } from "@/lib/server/badges";
import { checkDomain, statusFrom, validateHostname } from "@/lib/server/domains";
import { activeTier, entitlementsFrom } from "@/lib/server/entitlements";
import { ACCESS_STATUSES, stripeForm, subscriptionGivesAccess } from "@/lib/server/payments";
import { migrateOffer, settingsSchema } from "@/lib/server/settings";
import { isFounderLevel, staffRights } from "@/lib/server/staff";

const NOW = Date.parse("2026-10-19T12:00:00Z");
const DAY = 86_400_000;
const ENV_KEYS = ["FOUNDER_UNCLAIM_IDS", "FOUNDER_DISCORD_IDS", "ADMIN_UNCLAIM_IDS", "ADMIN_DISCORD_IDS", "CUSTOM_DOMAIN_CNAME", "CUSTOM_DOMAIN_IPV4", "APP_URL"];
const saved = Object.fromEntries(ENV_KEYS.map((k) => [k, process.env[k]]));
afterEach(() => {
  for (const k of ENV_KEYS) {
    if (saved[k] === undefined) delete process.env[k];
    else process.env[k] = saved[k];
  }
});

const account = (over: Record<string, unknown> = {}) =>
  ({
    id: "u1",
    role: "user",
    plan: "free",
    planExpiresAt: null,
    basePlan: "free",
    subTier: "free",
    subUntil: null,
    subRenews: false,
    discordId: null,
    unclaimId: null,
    partner: false,
    verified: false,
    staffPermissions: "[]",
    createdAt: new Date(NOW - 10 * DAY),
    deletedAt: null,
    banned: false,
    ...over,
  }) as never;

describe("noms officiels protégés", () => {
  it("bloque Unclaim, le staff et leurs variantes « leet »", () => {
    for (const name of ["unclaim", "Un-Cla1m", "admin", "ADMIN-2", "le-staff", "Fondateur", "modérateur", "officiel", "support", "Boutique officielle", "Développeur officiel", "4dm1n"]) {
      expect(isOfficialName(name), name).toBe(true);
    }
  });
  it("laisse passer les noms ordinaires", () => {
    for (const name of ["badminton", "kaelis", "Rédacteur", "Gérant", "Community manager", "Ma boutique", "Les Merch de Léo"]) {
      expect(isOfficialName(name), name).toBe(false);
    }
  });
  it("réserve les adresses officielles, sauf pour le staff", () => {
    expect(validateSlug("unclaim-support").ok).toBe(false);
    expect(validateSlug("admin-officiel").ok).toBe(false);
    expect(validateSlug("unclaim-support", { allowOfficial: true }).ok).toBe(true);
    expect(validateSlug("staff").ok).toBe(false); // route /staff
    expect(validateSlug("profil", { allowOfficial: true }).ok).toBe(false); // route /profil
    expect(validateSlug("Mon-Pseudo")).toEqual({ ok: true, slug: "mon-pseudo" });
  });
  it("une boutique personnelle ne peut pas s'appeler « boutique officielle »", () => {
    const block = createBlock("shop", { title: "Boutique officielle Unclaim" });
    const parsed = blockSchema.parse(block);
    expect(parsed.type === "shop" && parsed.data.title).toBe("Ma boutique");
  });
});

describe("badges", () => {
  it("crée les badges demandés, avec la règle « premiers comptes » à 100 places", () => {
    const keys = SYSTEM_BADGES.map((b) => b.key);
    expect(keys).toEqual(["fondateur", "administrateur", "developpeur", "moderateur", "staff", "partenaire", "verifie", "early-supporter", "membre-historique", "premium"]);
    expect(SYSTEM_BADGES.find((b) => b.key === "early-supporter")!.rule).toMatchObject({ type: "early", limit: 100, requireDiscord: true });
    expect(SYSTEM_BADGES.find((b) => b.key === "fondateur")).toMatchObject({ restricted: true, staffOnly: true, rule: { type: "founder" } });
  });
  it("lit une règle invalide comme manuelle et sépare règles calculées et attribuées", () => {
    expect(parseBadgeRule("pas du json")).toEqual({ type: "manual" });
    expect(parseBadgeRule('{"type":"early","limit":0}')).toEqual({ type: "manual" });
    expect(isComputedRule({ type: "plan", tier: "pro" })).toBe(true);
    expect(acceptsManualGrant({ type: "early", limit: 5, requireDiscord: true, requirePage: true })).toBe(false);
    expect(acceptsManualGrant({ type: "manual" })).toBe(true);
  });
  it("calcule les badges à condition (formule, ancienneté, vérifié, partenaire, fondateur)", () => {
    const now = NOW;
    expect(computedHolds({ type: "verified" }, account({ verified: true }), now)).toBe(true);
    expect(computedHolds({ type: "partner" }, account(), now)).toBe(false);
    expect(computedHolds({ type: "seniority", days: 365 }, account({ createdAt: new Date(now - 400 * DAY) }), now)).toBe(true);
    expect(computedHolds({ type: "seniority", days: 365 }, account(), now)).toBe(false);
    // Abonnement Pro actif : badge « Premium » (dès Link+) oui, badge réservé à Équipe non.
    const subscriber = account({ subTier: "pro", subUntil: new Date(now + 5 * DAY) });
    expect(computedHolds({ type: "plan", tier: "plus" }, subscriber, now)).toBe(true);
    expect(computedHolds({ type: "plan", tier: "team" }, subscriber, now)).toBe(false);
    process.env.FOUNDER_UNCLAIM_IDS = "uncl_FOUNDER00000000000000";
    expect(computedHolds({ type: "founder" }, account({ unclaimId: "uncl_FOUNDER00000000000000" }), now)).toBe(true);
    expect(computedHolds({ type: "founder" }, account({ unclaimId: "uncl_SOMEONE0000000000000" }), now)).toBe(false);
  });
  it("valide les champs d'un badge côté serveur", () => {
    const ok = { key: "champion", name: "Champion", description: "", icon: "trophy", imageUrl: "", color: "#ffc247", visibility: "public", staffOnly: false, restricted: false, rule: { type: "manual" }, durationDays: 30, active: true, position: 3 };
    expect(badgeInputSchema.safeParse(ok).success).toBe(true);
    expect(badgeInputSchema.safeParse({ ...ok, color: "red" }).success).toBe(false);
    expect(badgeInputSchema.safeParse({ ...ok, imageUrl: "https://evil.example/x.png" }).success).toBe(false);
    expect(badgeInputSchema.safeParse({ ...ok, icon: "<script>" }).success).toBe(false);
  });
});

describe("staff : niveaux et permissions", () => {
  it("le niveau fondateur ne vient que de l'environnement du serveur", () => {
    process.env.FOUNDER_UNCLAIM_IDS = "uncl_FOUNDER00000000000000";
    process.env.ADMIN_DISCORD_IDS = "123456789012345678";
    const founder = account({ unclaimId: "uncl_FOUNDER00000000000000" });
    const envAdmin = account({ discordId: "123456789012345678" });
    const dbAdmin = account({ role: "admin", staffPermissions: '["badges.validate","inconnue"]' });
    expect(isFounderLevel(founder)).toBe(true);
    expect(isFounderLevel(envAdmin)).toBe(false);
    expect(isFounderLevel(dbAdmin)).toBe(false);
    expect(staffRights(dbAdmin)).toEqual({ level: "admin", permissions: ["badges.validate"] });
    expect(staffRights(account())).toBeNull();
    // Un compte ordinaire qui écrirait des permissions dans sa fiche n'obtient rien.
    expect(staffRights(account({ staffPermissions: '["platform.critical"]' }))).toBeNull();
  });
  it("sans fondateur déclaré, les administrateurs d'office en tiennent lieu", () => {
    delete process.env.FOUNDER_UNCLAIM_IDS;
    delete process.env.FOUNDER_DISCORD_IDS;
    process.env.ADMIN_DISCORD_IDS = "123456789012345678";
    expect(isFounderLevel(account({ discordId: "123456789012345678" }))).toBe(true);
    expect(isFounderLevel(account({ role: "admin" }))).toBe(false);
  });
  it("lit les permissions sans doublon ni valeur inconnue", () => {
    expect(parseStaffPermissions('["discord.manage","discord.manage","root"]')).toEqual(["discord.manage"]);
    expect(can({ level: "founder", permissions: [] }, "platform.critical")).toBe(true);
    expect(can({ level: "admin", permissions: [] }, "platform.critical")).toBe(false);
  });
});

describe("abonnements et droits", () => {
  it("vend des abonnements mensuels et annuels, sans offre « à vie »", () => {
    expect(DEFAULT_SETTINGS.offers.every((o) => o.interval === "month" || o.interval === "year")).toBe(true);
    expect(DEFAULT_SETTINGS.offers.some((o) => "days" in o)).toBe(false);
    const year = DEFAULT_SETTINGS.offers.find((o) => o.id === "an")!;
    expect(monthlyCents(year)).toBe(167);
  });
  it("convertit les anciennes offres à paiement unique", () => {
    expect(migrateOffer({ id: "mois", tier: "plus", name: "1 mois", days: 30, priceCents: 249, description: "", highlight: false, active: true })).toMatchObject({ interval: "month", name: "Mensuel" });
    expect(migrateOffer({ id: "an", name: "1 an", days: 365, priceCents: 1999, description: "", highlight: true, active: true })).toMatchObject({ interval: "year", tier: "plus" });
    expect(migrateOffer({ id: "vie", tier: "plus", name: "À vie", days: 0, priceCents: 3999, description: "", highlight: false, active: true })).toBeNull();
  });
  it("donne l'accès seulement pendant la période payée (et le délai de grâce)", () => {
    const end = new Date(NOW + 2 * DAY);
    expect(subscriptionGivesAccess({ status: "active", currentPeriodEnd: end }, NOW)).toBe(true);
    expect(subscriptionGivesAccess({ status: "past_due", currentPeriodEnd: new Date(NOW - DAY) }, NOW)).toBe(true);
    expect(subscriptionGivesAccess({ status: "active", currentPeriodEnd: new Date(NOW - 5 * DAY) }, NOW)).toBe(false);
    for (const status of ["canceled", "unpaid", "incomplete", "incomplete_expired", "paused"]) {
      expect(ACCESS_STATUSES.has(status)).toBe(false);
      expect(subscriptionGivesAccess({ status, currentPeriodEnd: end }, NOW)).toBe(false);
    }
  });
  it("prend la plus haute formule entre abonnement et code, et rien après la fin", () => {
    const user = account({ plan: "plus", planExpiresAt: new Date(NOW + DAY), subTier: "team", subUntil: new Date(NOW + 10 * DAY) });
    expect(activeTier(user, NOW)).toBe("team");
    expect(activeTier(account({ subTier: "pro", subUntil: new Date(NOW - DAY) }), NOW)).toBe("free");
  });
  it("n'offre plus les formules payantes par défaut (sans abonnement vérifié)", () => {
    const rights = entitlementsFrom(account(), DEFAULT_SETTINGS);
    expect(rights.freeForAll).toBe(false);
    expect(rights.tier).toBe("free");
    expect(rights.features.effects).toBe(false);
    const launch = entitlementsFrom(account(), { ...DEFAULT_SETTINGS, launchFreeAccess: true });
    expect(launch.tier).toBe("team");
  });
  it("réserve les rôles personnalisés à Link+ et les domaines à Pro", () => {
    expect(FEATURES.customRoles.default).toBe("plus");
    expect(FEATURES.customDomains.default).toBe("pro");
    const plus = entitlementsFrom(account({ subTier: "plus", subUntil: new Date(Date.now() + 5 * DAY) }), DEFAULT_SETTINGS);
    expect(plus.features.customRoles).toBe(true);
    expect(plus.features.customDomains).toBe(false);
    expect(plus.limits.domains).toBe(0);
    expect(entitlementsFrom(account({ subTier: "pro", subUntil: new Date(Date.now() + 5 * DAY) }), DEFAULT_SETTINGS).limits.domains).toBe(1);
  });
  it("encode une souscription comme l'attend Stripe", () => {
    const form = stripeForm({ mode: "subscription", line_items: [{ price_data: { unit_amount: 249, recurring: { interval: "month" } } }] });
    expect(form.get("line_items[0][price_data][recurring][interval]")).toBe("month");
    expect(form.get("mode")).toBe("subscription");
  });
});

describe("boutiques personnelles : fermées par défaut", () => {
  it("le réglage initial est fermé et le bloc Boutique est coupé pour tout le monde", () => {
    expect(DEFAULT_SETTINGS.personalShops).toBe(false);
    expect(entitlementsFrom(account(), DEFAULT_SETTINGS).features.shop).toBe(false);
    // Même un administrateur (toutes les fonctions) n'a pas de boutique tant qu'elles sont fermées.
    expect(entitlementsFrom(account({ role: "admin" }), DEFAULT_SETTINGS).features.shop).toBe(false);
    expect(entitlementsFrom(account(), { ...DEFAULT_SETTINGS, personalShops: true }).features.shop).toBe(true);
  });
  it("une valeur enregistrée non booléenne ne les ouvre pas", () => {
    const parsed = settingsSchema.safeParse({ ...DEFAULT_SETTINGS, personalShops: "true" });
    expect(parsed.success).toBe(false);
  });
});

describe("rôles personnalisés", () => {
  const role = { name: "Rédacteur", color: "#a78bfa", icon: "pen", description: "", permissions: ["content"] };
  it("accepte un rôle d'équipe et refuse les noms officiels", () => {
    expect(memberRoleInputSchema.safeParse(role).success).toBe(true);
    for (const name of ["Fondateur", "Admin", "Administrateur", "Développeur officiel", "Staff Unclaim", "Modérateur"]) {
      expect(memberRoleInputSchema.safeParse({ ...role, name }).success, name).toBe(false);
    }
  });
  it("ne propose que des permissions limitées à la page", () => {
    expect(memberRoleInputSchema.safeParse({ ...role, permissions: ["admin"] }).success).toBe(false);
    expect(memberRoleInputSchema.safeParse({ ...role, permissions: ["badges.validate"] }).success).toBe(false);
    expect(BASE_ROLE_PERMISSIONS.viewer).toEqual(["messages.read", "stats"]);
  });
});

describe("domaines personnels", () => {
  it("normalise les noms d'hôte et refuse ce qui n'est pas un domaine public", () => {
    expect(normalizeHostname("https://WWW.MonDomaine.fr/page?x=1")).toBe("www.mondomaine.fr");
    expect(normalizeHostname("mondomaine.fr.")).toBe("mondomaine.fr");
    expect(normalizeHostname("café.fr")).toBe("xn--caf-dma.fr");
    for (const bad of ["localhost", "192.168.1.1", "intranet", "a..b.fr", "-x.fr", "site.local", "x".repeat(70) + ".fr"]) {
      expect(normalizeHostname(bad), bad).toBeNull();
    }
    expect(isApexDomain("mondomaine.fr")).toBe(true);
    expect(isApexDomain("www.mondomaine.fr")).toBe(false);
    expect(isApexDomain("mondomaine.co.uk")).toBe(true);
  });
  it("refuse le domaine du site lui-même", () => {
    process.env.APP_URL = "https://link.unclaim.fr";
    expect(validateHostname("link.unclaim.fr").ok).toBe(false);
    expect(validateHostname("pirate.link.unclaim.fr").ok).toBe(false);
    expect(validateHostname("mondomaine.fr").ok).toBe(true);
  });
  it("vérifie vraiment le TXT, le routage et HTTPS avant d'activer", async () => {
    process.env.CUSTOM_DOMAIN_CNAME = "domaines.link.unclaim.fr";
    process.env.APP_URL = "https://link.unclaim.fr";
    const domain = { hostname: "www.mondomaine.fr", token: "lbu-jeton" };
    const resolver = (txt: string[][], cname: string[]) => ({
      resolveTxt: async () => txt,
      resolveCname: async () => cname,
      resolve4: async () => [],
    });
    const { probeSignature } = await import("@/lib/server/domains");
    const okFetch = (async () => new Response(JSON.stringify({ signature: probeSignature("www.mondomaine.fr") }), { status: 200 })) as unknown as typeof fetch;
    const wrongFetch = (async () => new Response(JSON.stringify({ signature: "autre" }), { status: 200 })) as unknown as typeof fetch;

    const none = await checkDomain(domain, { resolver: resolver([], []) as never, fetcher: okFetch });
    expect(statusFrom(none)).toBe("error");
    const owned = await checkDomain(domain, { resolver: resolver([["lbu-jeton"]], []) as never, fetcher: okFetch });
    expect(owned.ownership.ok).toBe(true);
    expect(statusFrom(owned)).toBe("pending");
    const elsewhere = await checkDomain(domain, { resolver: resolver([["lbu-jeton"]], ["domaines.link.unclaim.fr."]) as never, fetcher: wrongFetch });
    expect(elsewhere.https.ok).toBe(false);
    const active = await checkDomain(domain, { resolver: resolver([["lbu-", "jeton"]], ["domaines.link.unclaim.fr."]) as never, fetcher: okFetch });
    expect(statusFrom(active)).toBe("active");
  });
  it("le proxy ne réécrit que les vrais domaines tiers", () => {
    expect(siteHost("https://link.unclaim.fr")).toBe("link.unclaim.fr");
    expect(isCustomHost("mondomaine.fr", "link.unclaim.fr")).toBe(true);
    expect(isCustomHost("link.unclaim.fr", "link.unclaim.fr")).toBe(false);
    expect(isCustomHost("cdn.link.unclaim.fr", "link.unclaim.fr")).toBe(false);
    expect(isCustomHost("localhost", "link.unclaim.fr")).toBe(false);
    expect(isCustomHost("127.0.0.1", "link.unclaim.fr")).toBe(false);
    expect(hostFromHeaders(new Headers({ host: "MonDomaine.fr:443" }))).toBe("mondomaine.fr");
  });
});

describe("boutique officielle", () => {
  it("valide les articles et leurs récompenses", () => {
    const item = { slug: "cadre-aurore", category: "profil", name: "Cadre Aurore", description: "", perks: [], priceCents: 299, icon: "sparkles", imageUrl: "", color: "#22c9e8", reward: { type: "frame", frame: "aurore" }, active: true, position: 0 };
    expect(shopItemInputSchema.safeParse(item).success).toBe(true);
    expect(shopItemInputSchema.safeParse({ ...item, priceCents: 0 }).success).toBe(false);
    expect(shopItemInputSchema.safeParse({ ...item, reward: { type: "frame", frame: "inconnu" } }).success).toBe(false);
    expect(parseShopReward('{"type":"plan","tier":"team"}')).toBeNull();
  });
});
