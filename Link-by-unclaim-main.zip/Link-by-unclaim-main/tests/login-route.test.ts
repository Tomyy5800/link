import { NextRequest } from "next/server";
import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";

const GATEWAY = "http://gateway.test";

beforeAll(() => {
  process.env.UNCLAIM_API_URL = GATEWAY;
  process.env.UNCLAIM_CLIENT_ID = "link-by-unclaim";
  process.env.UNCLAIM_CLIENT_SECRET = "uncs_test";
  process.env.APP_URL = "http://localhost:3000";
});

afterEach(() => vi.unstubAllGlobals());

/** Passerelle simulée : fournisseurs en service et fournisseurs autorisés pour le site. */
function gateway(available: string[], allowed: string[] | null) {
  vi.stubGlobal(
    "fetch",
    vi.fn(async (url: string) => {
      if (url.endsWith("/auth/config")) return Response.json({ providers_supported: available.map((id) => ({ id })) });
      if (url.endsWith("/api/v1/site")) return Response.json({ site: { providers: allowed } });
      return new Response("introuvable", { status: 404 });
    }),
  );
}

async function login(query: string) {
  vi.resetModules(); // vide le cache des fournisseurs entre deux scénarios
  const { GET } = await import("@/app/api/auth/login/route");
  const res = await GET(new NextRequest(`http://localhost:3000/api/auth/login${query}`));
  return new URL(res.headers.get("location") ?? "", "http://localhost:3000");
}

describe("connexion sans étape intermédiaire", () => {
  it("part directement chez le fournisseur choisi, sans écran de la passerelle", async () => {
    gateway(["discord", "google", "twitch"], null);
    const url = await login("?provider=google&next=/plus");
    expect(`${url.origin}${url.pathname}`).toBe(`${GATEWAY}/auth/google`);
    expect(url.searchParams.get("screen")).toBeNull();
  });

  it("part directement chez l'unique fournisseur autorisé pour le site", async () => {
    gateway(["discord", "google", "twitch"], ["twitch"]);
    const url = await login("");
    expect(url.pathname).toBe("/auth/twitch");
  });

  it("propose le choix quand plusieurs fournisseurs sont ouverts", async () => {
    gateway(["discord", "google"], null);
    const url = await login("?next=/plus");
    expect(url.pathname).toBe("/login");
    expect(url.searchParams.get("next")).toBe("/plus");
  });

  it("refuse un fournisseur que le site n'accepte pas", async () => {
    gateway(["discord", "google"], ["discord"]);
    const url = await login("?provider=google");
    expect(url.pathname).toBe("/login");
    expect(url.searchParams.get("error")).toBe("provider_unavailable");
  });

  it("se rabat sur Discord si la passerelle ne répond pas", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => Promise.reject(new TypeError("fetch failed"))));
    const url = await login("");
    expect(url.pathname).toBe("/auth/discord");
  });
});
