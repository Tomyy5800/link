import { describe, expect, it } from "vitest";
import { blockSchema, createBlock, parseStoredBlock } from "@/lib/blocks";
import { mockNgProfile } from "@/lib/nationsglory-shared";
import { pageSaveSchema } from "@/lib/page-schema";
import { suggestSlug, validateSlug } from "@/lib/slug";
import { DEFAULT_THEME, contrastRatio, parseTheme, readableOn } from "@/lib/theme";

describe("validateSlug", () => {
  it("accepte une adresse correcte et la met en minuscules", () => {
    expect(validateSlug("Kaelis_NG")).toEqual({ ok: true, slug: "kaelis_ng" });
  });

  it.each(["ab", "-kaelis", "kaelis.", "ka..elis", "dashboard", "api", "é-accent", "a".repeat(31)])("refuse « %s »", (slug) => {
    expect(validateSlug(slug).ok).toBe(false);
  });

  it("propose une adresse valide à partir d'un pseudo Discord", () => {
    const slug = suggestSlug("Éloïse ✨ la Grande");
    expect(validateSlug(slug).ok).toBe(true);
    expect(slug).toBe("eloise-la-grande");
  });
});

describe("blocs", () => {
  it("crée un bloc avec ses valeurs par défaut", () => {
    const block = createBlock("skin");
    expect(block.type).toBe("skin");
    expect(block.data).toMatchObject({ animation: "idle", autoRotate: true, height: 340 });
  });

  it("normalise les URL des liens à la validation", () => {
    const link = createBlock("link", { label: "Twitch" });
    const parsed = blockSchema.parse({ ...link, data: { ...link.data, url: "twitch.tv/kaelis" } });
    expect(parsed.type === "link" && parsed.data.url).toBe("https://twitch.tv/kaelis");
  });

  it("rejette une URL javascript:", () => {
    const link = createBlock("link");
    expect(blockSchema.safeParse({ ...link, data: { ...link.data, url: "javascript:alert(1)" } }).success).toBe(false);
  });

  it("récupère un bloc stocké aux données corrompues avec les valeurs par défaut", () => {
    const block = parseStoredBlock({ id: crypto.randomUUID(), type: "text", width: "full", visible: true, data: "{not json" });
    expect(block?.type).toBe("text");
    expect(parseStoredBlock({ id: crypto.randomUUID(), type: "inconnu", width: "full", visible: true, data: "{}" })).toBeNull();
  });

  it("refuse les identifiants de blocs en double", () => {
    const block = createBlock("divider");
    const result = pageSaveSchema.safeParse({
      profile: { displayName: "Kaelis" },
      theme: DEFAULT_THEME,
      published: true,
      blocks: [block, block],
    });
    expect(result.success).toBe(false);
  });
});

describe("thème", () => {
  it("tolère un JSON invalide ou partiellement faux", () => {
    expect(parseTheme("{oops")).toEqual(DEFAULT_THEME);
    const theme = parseTheme(JSON.stringify({ accent: "#ff0000", radius: "énorme" }));
    expect(theme.accent).toBe("#ff0000");
    expect(theme.radius).toBe(DEFAULT_THEME.radius);
  });

  it("choisit une couleur de texte lisible sur l'accent", () => {
    expect(readableOn("#f2c94c")).toBe("#0b0b10");
    expect(readableOn("#5865f2")).toBe("#ffffff");
    expect(contrastRatio("#000000", "#ffffff")).toBeCloseTo(21, 0);
  });
});

describe("NationsGlory", () => {
  it("produit un profil de démo stable, une ligne par serveur demandé", () => {
    const profile = mockNgProfile("Unclaim_Demo", ["blue", "lime"]);
    expect(profile.servers.map((s) => s.server)).toEqual(["blue", "lime"]);
    expect(profile.servers).toEqual(mockNgProfile("Unclaim_Demo", ["blue", "lime"]).servers);
    expect(profile.mock).toBe(true);
  });
});

describe("plainText", () => {
  it("retire la mise en forme et garde les spoilers masqués", async () => {
    const { plainText } = await import("@/lib/text");
    const text = plainText("Salut **toi** ! ||secret||\n-# petit\n> citation\n[NG](https://nationsglory.fr) snake_case");
    expect(text).toBe("Salut toi ! ▒▒▒ petit citation NG snake_case");
    expect(text).not.toContain("secret");
  });
});
