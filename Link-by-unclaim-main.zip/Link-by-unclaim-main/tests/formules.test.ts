import { describe, expect, it } from "vitest";
import { DEFAULT_SETTINGS } from "@/lib/features";
import { normalizeTier, paidTier, tierName } from "@/lib/plans";
import { activeTier, entitlementsFrom } from "@/lib/server/entitlements";
import { applyGrant, convertDays, dayValues } from "@/lib/server/premium";

const NOW = Date.parse("2026-10-17T12:00:00Z");
const DAY = 86_400_000;
const values = dayValues(DEFAULT_SETTINGS.offers);

describe("formules Link+", () => {
  it("nomme les formules et reprend l'ancien plan « premium »", () => {
    expect(normalizeTier("premium")).toBe("plus");
    expect(normalizeTier("n'importe quoi")).toBe("free");
    expect(paidTier("free")).toBe("plus");
    expect(["free", "plus", "pro", "team"].map((t) => tierName(normalizeTier(t), "Link+"))).toEqual(["Gratuit", "Link+", "Link+ Pro", "Link+ Équipe"]);
  });

  it("vend chaque formule et garde la cohérence des prix (année = 8 mois, chaque formule double la précédente)", () => {
    for (const tier of ["plus", "pro", "team"] as const) {
      const month = DEFAULT_SETTINGS.offers.find((o) => o.tier === tier && o.interval === "month")!;
      const year = DEFAULT_SETTINGS.offers.find((o) => o.tier === tier && o.interval === "year")!;
      expect(year.priceCents / month.priceCents).toBeCloseTo(8, 0);
    }
    expect(values.pro / values.plus).toBeCloseTo(2, 1);
    expect(values.team / values.pro).toBeCloseTo(2, 1);
  });

  it("convertit le temps restant à valeur égale", () => {
    expect(convertDays(100, "plus", "pro", values)).toBe(50);
    expect(convertDays(10, "team", "plus", values)).toBe(40);
    expect(convertDays(7, "pro", "pro", values)).toBe(7);
  });

  it("prolonge la même formule", () => {
    const next = applyGrant({ plan: "plus", planExpiresAt: new Date(NOW + 10 * DAY), basePlan: "free" }, 30, "plus", values, NOW);
    expect(next.plan).toBe("plus");
    expect(next.planExpiresAt!.getTime()).toBe(NOW + 40 * DAY);
  });

  it("passe à une formule supérieure en convertissant le temps restant", () => {
    const next = applyGrant({ plan: "plus", planExpiresAt: new Date(NOW + 100 * DAY), basePlan: "free" }, 30, "pro", values, NOW);
    expect(next.plan).toBe("pro");
    expect(next.planExpiresAt!.getTime()).toBe(NOW + (30 + 50) * DAY);
  });

  it("garde une formule « à vie » en réserve sous une formule supérieure temporaire", () => {
    const next = applyGrant({ plan: "plus", planExpiresAt: null, basePlan: "free" }, 30, "pro", values, NOW);
    expect(next).toMatchObject({ plan: "pro", basePlan: "plus" });
    // Quand Pro se termine, le compte retrouve Link+ à vie.
    expect(activeTier({ plan: next.plan, planExpiresAt: next.planExpiresAt, basePlan: next.basePlan }, NOW + 31 * DAY)).toBe("plus");
  });

  it("convertit une formule inférieure achetée pendant une formule supérieure", () => {
    const next = applyGrant({ plan: "pro", planExpiresAt: new Date(NOW + 10 * DAY), basePlan: "free" }, 30, "plus", values, NOW);
    expect(next.plan).toBe("pro");
    expect(next.planExpiresAt!.getTime()).toBe(NOW + 25 * DAY);
    const lifetimeLower = applyGrant({ plan: "pro", planExpiresAt: new Date(NOW + 10 * DAY), basePlan: "free" }, 0, "plus", values, NOW);
    expect(lifetimeLower).toMatchObject({ plan: "pro", basePlan: "plus" });
  });

  it("donne les fonctions et limites de la formule", () => {
    const pro = entitlementsFrom({ role: "user", plan: "pro", planExpiresAt: null, discordId: null, unclaimId: null }, DEFAULT_SETTINGS, { freeForAll: false });
    expect(pro.tier).toBe("pro");
    expect(pro.features).toMatchObject({ effects: true, customCss: true, webhooks: true, brandKit: false });
    expect(pro.limits).toEqual(DEFAULT_SETTINGS.limits.pro);
  });
});
