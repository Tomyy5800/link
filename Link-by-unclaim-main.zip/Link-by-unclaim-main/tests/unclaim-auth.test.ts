import { generateKeyPairSync, sign, type JsonWebKey } from "node:crypto";
import { beforeAll, describe, expect, it } from "vitest";

const ISSUER = "http://localhost:4000";
const CLIENT_ID = "link-by-unclaim";

beforeAll(() => {
  process.env.UNCLAIM_API_URL = `${ISSUER}/`;
  process.env.UNCLAIM_CLIENT_ID = CLIENT_ID;
  process.env.UNCLAIM_CLIENT_SECRET = "uncs_test";
  process.env.APP_URL = "http://localhost:3000";
});

const { publicKey, privateKey } = generateKeyPairSync("ed25519");
const jwk = { ...(publicKey.export({ format: "jwk" }) as JsonWebKey), kid: "k1" };
const keys = async () => [jwk];

const b64 = (value: unknown) => Buffer.from(JSON.stringify(value)).toString("base64url");

function token(payload: Record<string, unknown>, header: Record<string, unknown> = { alg: "EdDSA", kid: "k1" }) {
  const head = `${b64(header)}.${b64(payload)}`;
  return `${head}.${sign(null, Buffer.from(head), privateKey).toString("base64url")}`;
}

const now = Math.floor(Date.now() / 1000);
const valid = { sub: "uncl_7F3K9QW2MXB4YVNP8RTJ5CHD6A", aud: CLIENT_ID, iss: ISSUER, typ: "access", exp: now + 3600 };

describe("startLogin", () => {
  it("prépare l'URL de la passerelle avec state et PKCE S256, sans écran intermédiaire", async () => {
    const { startLogin, pkceChallenge } = await import("@/lib/server/unclaim-auth/client");
    const { url, state, codeVerifier } = startLogin("google");
    const parsed = new URL(url);
    expect(`${parsed.origin}${parsed.pathname}`).toBe(`${ISSUER}/auth/google`);
    expect(parsed.searchParams.get("client_id")).toBe(CLIENT_ID);
    expect(parsed.searchParams.get("redirect_uri")).toBe("http://localhost:3000/api/auth/callback");
    expect(parsed.searchParams.get("state")).toBe(state);
    expect(parsed.searchParams.get("code_challenge_method")).toBe("S256");
    expect(parsed.searchParams.get("code_challenge")).toBe(pkceChallenge(codeVerifier));
    expect(parsed.searchParams.get("screen")).toBeNull();
    expect(parsed.searchParams.get("scope")).toBeNull();
    expect(codeVerifier.length).toBeGreaterThanOrEqual(43);
  });

  it("refuse un identifiant de fournisseur fantaisiste", async () => {
    const { startLogin } = await import("@/lib/server/unclaim-auth/client");
    expect(() => startLogin("../admin")).toThrow();
  });

  it("calcule le défi PKCE de la RFC 7636", async () => {
    const { pkceChallenge } = await import("@/lib/server/unclaim-auth/client");
    expect(pkceChallenge("dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk")).toBe("E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM");
  });
});

describe("verifyAccessToken", () => {
  it("accepte un jeton signé par la passerelle et destiné au site", async () => {
    const { verifyAccessToken } = await import("@/lib/server/unclaim-auth/client");
    const payload = await verifyAccessToken(token(valid), { getKeys: keys });
    expect(payload?.sub).toBe(valid.sub);
  });

  it("refuse un payload modifié après signature", async () => {
    const { verifyAccessToken } = await import("@/lib/server/unclaim-auth/client");
    const [h, , s] = token(valid).split(".");
    const forged = `${h}.${b64({ ...valid, sub: "uncl_AUTRECOMPTE00000000000000" })}.${s}`;
    expect(await verifyAccessToken(forged, { getKeys: keys })).toBeNull();
  });

  it("refuse alg none, une autre audience, un autre émetteur, un refresh et un jeton expiré", async () => {
    const { verifyAccessToken } = await import("@/lib/server/unclaim-auth/client");
    const none = `${b64({ alg: "none", kid: "k1" })}.${b64(valid)}.`;
    expect(await verifyAccessToken(none, { getKeys: keys })).toBeNull();
    expect(await verifyAccessToken(token({ ...valid, aud: "autre-site" }), { getKeys: keys })).toBeNull();
    expect(await verifyAccessToken(token({ ...valid, iss: "https://evil.example" }), { getKeys: keys })).toBeNull();
    expect(await verifyAccessToken(token({ ...valid, typ: "refresh" }), { getKeys: keys })).toBeNull();
    expect(await verifyAccessToken(token({ ...valid, exp: now - 120 }), { getKeys: keys })).toBeNull();
  });

  it("recharge les clés quand le kid est inconnu (rotation)", async () => {
    const { verifyAccessToken } = await import("@/lib/server/unclaim-auth/client");
    let calls = 0;
    const rotating = async (force: boolean) => {
      calls++;
      return force ? [jwk] : [];
    };
    expect(await verifyAccessToken(token(valid), { getKeys: rotating })).not.toBeNull();
    expect(calls).toBe(2);
  });
});

describe("profil multi-fournisseurs", () => {
  it("accepte un compte Google sans Discord et ne garde ni e-mail ni identifiant privé", async () => {
    const { profileFields } = await import("@/lib/server/unclaim-auth");
    const fields = profileFields({
      unclaim_id: "uncl_7F3K9QW2MXB4YVNP8RTJ5CHD6A",
      provider: "google",
      provider_id: "1029384756",
      discord_id: null,
      username: "kaelis.dupont",
      display_name: "Kaelis Dupont",
      avatar_url: "https://lh3.googleusercontent.com/a/photo",
      identities: [{ provider: "google", provider_id: "1029384756", username: "kaelis.dupont", display_name: "Kaelis Dupont", avatar_url: null, email: "kaelis@exemple.fr" }],
    });
    expect(fields).toMatchObject({ discordId: null, provider: "google", globalName: "Kaelis Dupont", avatarUrl: "https://lh3.googleusercontent.com/a/photo", ngAccount: null });
    expect(fields.identities).not.toContain("exemple.fr");
    expect(JSON.parse(fields.identities)).toEqual([{ provider: "google", username: null }]);
  });

  it("garde Discord rattaché et reprend le pseudo NationsGlory prouvé", async () => {
    const { profileFields } = await import("@/lib/server/unclaim-auth");
    const fields = profileFields({
      unclaim_id: "uncl_7F3K9QW2MXB4YVNP8RTJ5CHD6A",
      provider: "twitch",
      discord_id: "100000000000000001",
      username: "kaelis_tv",
      display_name: "Kaelis",
      identities: [
        { provider: "twitch", provider_id: "1", username: "kaelis_tv", display_name: "Kaelis", avatar_url: null },
        { provider: "discord", provider_id: "100000000000000001", username: "kaelis", display_name: "Kaelis", avatar_url: "https://cdn.discordapp.com/avatars/1/a.png" },
        { provider: "nationsglory", provider_id: "Kaelis_NG", username: "Kaelis_NG", display_name: "Kaelis_NG", avatar_url: null },
      ],
    });
    expect(fields.discordId).toBe("100000000000000001");
    expect(fields.ngAccount).toBe("Kaelis_NG");
    expect(fields.avatarUrl).toBe("https://cdn.discordapp.com/avatars/1/a.png");
    // Les champs propres à Discord ne sont pas écrasés par une connexion Twitch.
    expect("avatarHash" in fields).toBe(false);
  });

  it("n'affiche publiquement que les pseudos publics par nature", async () => {
    const { toOwnerProfile } = await import("@/lib/discord-cdn");
    const owner = toOwnerProfile({
      id: "u1",
      discordId: null,
      provider: "google",
      username: "kaelis.dupont",
      globalName: "Kaelis",
      avatarUrl: null,
      avatarHash: null,
      bannerHash: null,
      accentColor: null,
      identities: JSON.stringify([{ provider: "google", username: null }, { provider: "twitch", username: "kaelis_tv" }]),
      ngAccount: null,
    });
    expect(owner.discordUsername).toBeNull();
    expect(owner.handles).toEqual([{ provider: "twitch", username: "kaelis_tv" }]);
    expect(owner.avatarUrl).toMatch(/^\/api\/avatar\?seed=u1&l=K$/);
  });
});
