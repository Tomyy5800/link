import { describe, expect, it } from "vitest";
import { detectPlatform, normalizeImageUrl, normalizeUrl, parseDiscordInvite, resolveEmbedSrc, toCustomFrame, toEmbed } from "@/lib/urls";

describe("normalizeUrl", () => {
  it("garde les URL http(s) valides", () => {
    expect(normalizeUrl("https://exemple.fr/page?x=1")).toBe("https://exemple.fr/page?x=1");
  });

  it("ajoute https:// aux domaines nus", () => {
    expect(normalizeUrl("twitch.tv/kaelis")).toBe("https://twitch.tv/kaelis");
  });

  it("accepte un champ vide (édition en cours)", () => {
    expect(normalizeUrl("   ")).toBe("");
  });

  it("refuse les schémas dangereux", () => {
    expect(normalizeUrl("javascript:alert(1)")).toBeNull();
    expect(normalizeUrl("JaVaScRiPt:alert(1)")).toBeNull();
    expect(normalizeUrl("data:text/html,<script>")).toBeNull();
    expect(normalizeUrl("//evil.example")).toBeNull();
    expect(normalizeUrl("pas une url")).toBeNull();
  });

  it("valide les adresses mailto", () => {
    expect(normalizeUrl("mailto:moi@exemple.fr")).toBe("mailto:moi@exemple.fr");
    expect(normalizeUrl("mailto:pas-un-email")).toBeNull();
  });
});

describe("normalizeImageUrl", () => {
  it("accepte les images importées sur la plateforme", () => {
    expect(normalizeImageUrl("/api/uploads/clx123abc456")).toBe("/api/uploads/clx123abc456");
  });

  it("refuse les autres chemins relatifs et mailto", () => {
    expect(normalizeImageUrl("/api/me/page")).toBeNull();
    expect(normalizeImageUrl("mailto:a@b.fr")).toBeNull();
  });
});

describe("detectPlatform", () => {
  it.each([
    ["https://www.youtube.com/@chaine", "youtube"],
    ["https://youtu.be/dQw4w9WgXcQ", "youtube"],
    ["https://x.com/moi", "x"],
    ["https://twitter.com/moi", "x"],
    ["discord.gg/abc", "discord"],
    ["https://nationsglory.fr", "nationsglory"],
    ["mailto:moi@exemple.fr", "email"],
    ["https://exemple.fr", "website"],
  ])("%s → %s", (url, platform) => {
    expect(detectPlatform(url)).toBe(platform);
  });
});

describe("toEmbed", () => {
  it("transforme les vidéos YouTube en lecteur sans cookies", () => {
    expect(toEmbed("https://www.youtube.com/watch?v=dQw4w9WgXcQ")).toEqual({
      provider: "youtube",
      label: "YouTube",
      src: "https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ",
      aspect: "16 / 9",
    });
    expect(toEmbed("https://youtu.be/dQw4w9WgXcQ")?.provider).toBe("youtube");
    expect(toEmbed("https://youtube.com/shorts/dQw4w9WgXcQ")?.provider).toBe("youtube");
  });

  it("gère Spotify, SoundCloud et Twitch (domaine parent ajouté dans le navigateur)", () => {
    expect(toEmbed("https://open.spotify.com/intl-fr/track/4uLU6hMCjMI75M1A2tKUQC")).toMatchObject({
      provider: "spotify",
      src: "https://open.spotify.com/embed/track/4uLU6hMCjMI75M1A2tKUQC",
      height: 152,
    });
    expect(toEmbed("https://soundcloud.com/artiste/morceau")?.provider).toBe("soundcloud");
    const twitch = toEmbed("https://www.twitch.tv/kaelis");
    expect(twitch?.provider).toBe("twitch");
    expect(resolveEmbedSrc(twitch!.src, "link.exemple.fr")).toContain("parent=link.exemple.fr");
  });

  it("reconnaît les nouveaux services", () => {
    expect(toEmbed("https://kick.com/kaelis")?.provider).toBe("kick");
    expect(toEmbed("https://vimeo.com/76979871")?.provider).toBe("vimeo");
    expect(toEmbed("https://www.tiktok.com/@kaelis/video/7234567890123456789")?.provider).toBe("tiktok");
  });

  it("refuse les sites hors liste et le JavaScript", () => {
    expect(toEmbed("https://evil.example/embed")).toBeNull();
    expect(toEmbed("javascript:alert(1)")).toBeNull();
  });

  it("n'accepte que le https pour les iframes libres", () => {
    expect(toCustomFrame("https://exemple.fr/widget")).toBe("https://exemple.fr/widget");
    expect(toCustomFrame("http://exemple.fr/widget")).toBeNull();
    expect(toCustomFrame("javascript:alert(1)")).toBeNull();
  });
});

describe("parseDiscordInvite", () => {
  it.each([
    ["https://discord.gg/abcDEF", "abcDEF"],
    ["discord.gg/nations-glory", "nations-glory"],
    ["https://discord.com/invite/xyz123", "xyz123"],
    ["abc123", "abc123"],
  ])("%s → %s", (input, code) => {
    expect(parseDiscordInvite(input)).toBe(code);
  });

  it("refuse les autres liens", () => {
    expect(parseDiscordInvite("https://evil.example/discord.gg/abc")).toBeNull();
    expect(parseDiscordInvite("")).toBeNull();
  });
});
